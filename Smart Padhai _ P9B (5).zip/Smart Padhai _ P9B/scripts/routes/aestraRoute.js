/**
 * ═══════════════════════════════════════════════════════
 *  SMART PADHAI — AESTRA ROUTE (Phase 9A Sprint 5)
 *  Tactical Briefing Cards + Full SPA conversion
 * ═══════════════════════════════════════════════════════
 *
 *  Architecture:
 *    - IIFE pattern with render/init/cleanup lifecycle
 *    - AbortController for all event listeners
 *    - data-action delegation — NO inline onclick
 *    - Dynamic CSS load/unload via <link data-route-css>
 *    - Chat state: _chatState (in-memory) + SafeStorage (aestra_chat_history)
 *    - API payload compression — no raw Supabase arrays
 *    - Error envelopes — no browser alerts
 *    - NEVER calls loadPulseEngineFromSupabase / syncPulseEngineToSupabase
 *    - NEVER resets PulseEngine
 *    - Uses AppState.currentUser instead of getCurrentUserOrRedirect()
 *
 *  Sprint 5 Additions:
 *    - 5 Tactical Briefing Cards (Next Move, Weekly Reality,
 *      Weak Zone, Motivation, Exam Pressure)
 *    - Data sources: smartPadhaiData, time_blocks_v1,
 *      pulse_engine_data, notebook_matrix_data,
 *      syllabus_master_tracker, badge_progress_v2,
 *      activeBadges, calendarStrategy
 *    - AESTRA interprets data, never dumps raw numbers
 *    - No Supabase writes, no new tables, no sync changes
 *    - Data honesty: no lifetime PP as daily/weekly PP
 */

const AestraRoute = (() => {

    // ── Private State ──
    let _container = null;
    let _abortController = null;
    let _cssLinkEl = null;
    const CSS_PATH = './styles/modules/aestra.css';
    const CHAT_STORAGE_KEY = 'aestra_chat_history';

    // ── Chat State (survives route switches) ──
    const _chatState = {
        messages: [],
        inputText: '',
        scrollPosition: 0
    };

    // ── Pending API controller (for abort on cleanup) ──
    let _pendingApiController = null;

    // ── Widget refresh interval ──
    let _widgetRefreshInterval = null;

    // ═══════════════════════════════════════════
    //  LIFECYCLE
    // ═══════════════════════════════════════════
    function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;

        _loadCSS();
        container.innerHTML = render();

        // Restore chat state first
        _restoreChatState();

        // Bind events
        _bindEvents(container, _abortController.signal);

        // Initialize AESTRA engine subsystems (SPA-safe)
        _initAestraEngines();

        // Bind widget panels
        _bindAestraWidgets();

        // Render tactical briefing cards
        _renderBriefingCards();

        // Start periodic widget refresh (includes briefings)
        _widgetRefreshInterval = setInterval(() => {
            _bindAestraWidgets();
            _renderBriefingCards();
        }, 60000);
    }

    function cleanup() {
        // Save chat state before destroying DOM
        _saveChatState();

        // Abort pending API request
        if (_pendingApiController) {
            _pendingApiController.abort();
            _pendingApiController = null;
        }

        // Clear widget refresh
        if (_widgetRefreshInterval) {
            clearInterval(_widgetRefreshInterval);
            _widgetRefreshInterval = null;
        }

        // Abort all event listeners
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }

        // Unload CSS
        _unloadCSS();

        _container = null;
    }

    // ═══════════════════════════════════════════
    //  CSS DYNAMIC LOAD / UNLOAD
    // ═══════════════════════════════════════════
    function _loadCSS() {
        if (document.querySelector('link[data-route-css="aestra"]')) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.setAttribute('data-route-css', 'aestra');
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-route-css="aestra"]');
        if (el && el.parentElement) el.parentElement.removeChild(el);
        _cssLinkEl = null;
    }

    // ═══════════════════════════════════════════
    //  RENDER: Full HTML structure
    // ═══════════════════════════════════════════
    function render() {
        return `
<div class="aestra-workspace">
    <header class="aestra-header">
        <div class="logo-container">
            <span class="header-title">THE AESTRA</span>
        </div>
        <div style="display:flex;align-items:center;gap:12px;">
            <button class="clear-chat-btn" data-action="clear-chat">CLEAR LOG</button>
            <div class="system-status-indicator">
                <span class="pulse-dot"></span> NEURAL LINK SECURE
            </div>
        </div>
    </header>

    <div class="tactical-bridge">

        <!-- LEFT PANEL -->
        <aside class="info-panel left-panel">
            <div class="tactical-module system-state-box state-box-locked-in">
                <div class="module-header">SYSTEM STATE</div>
                <div class="module-content">
                    <div class="state-container">
                        <div class="state-orb-pulse locked-in-dot" id="aestra-stateDot"></div>
                        <div id="aestra-systemState"><h2 class="state-text">LOCKED_IN</h2></div>
                    </div>
                    <div class="status-subline">
                        <span class="sub-metric">FOCUS: <span id="aestra-focus">STABLE</span></span>
                        <span class="sub-metric">MOMENTUM: <span id="aestra-momentum">HIGH</span></span>
                    </div>
                </div>
            </div>

            <!-- TACTICAL BRIEFING CARDS (Sprint 5) -->
            <div class="tactical-module briefing-module">
                <div class="module-header">TACTICAL BRIEFINGS</div>
                <div class="briefing-cards-container" id="aestra-briefingCards">
                    <!-- Cards rendered by JS -->
                </div>
            </div>
        </aside>

        <!-- CENTER: CHAT MONOLITH -->
        <section class="briefing-monolith">
            <div class="chat-theater" id="aestra-chat-engine">
                <!-- Messages injected by JS. Idle text shown when empty. -->
            </div>
            <div class="monolith-footer">
                <div class="input-wrapper">
                    <input type="text" class="terminal-input" id="aestra-input"
                           placeholder="Type a message or command..." autocomplete="off">
                    <button class="send-btn" id="aestra-send-btn" data-action="send-message">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                    </button>
                </div>
            </div>
        </section>

        <!-- RIGHT PANEL -->
        <aside class="info-panel right-panel">
            <div class="tactical-module dominance-box">
                <div class="module-header">SUBJECT DOMINANCE MATRIX</div>
                <div class="matrix-container">
                    <div class="matrix-row">
                        <span class="sub-name">MATHS</span>
                        <div class="mini-progress"><div class="mini-bar maths-bar" id="aestra-mathsBar" style="width:0%;"></div></div>
                        <span class="sub-val" id="aestra-mathsPercent">0%</span>
                    </div>
                    <div class="matrix-row">
                        <span class="sub-name">PHYSICS</span>
                        <div class="mini-progress"><div class="mini-bar physics-bar" id="aestra-physicsBar" style="width:0%;"></div></div>
                        <span class="sub-val" id="aestra-physicsPercent">0%</span>
                    </div>
                    <div class="matrix-row">
                        <span class="sub-name">CHEMISTRY</span>
                        <div class="mini-progress"><div class="mini-bar chemistry-bar" id="aestra-chemBar" style="width:0%;"></div></div>
                        <span class="sub-val" id="aestra-chemPercent">0%</span>
                    </div>
                </div>
            </div>

            <div class="tactical-module pressure-box">
                <div class="module-header">PRESSURE MONITOR</div>
                <div class="pressure-container">
                    <div class="pressure-meta-row">
                        <div class="meter-label" id="aestra-pressureText">CRITICALITY: STABLE</div>
                        <div class="pressure-score-num" id="aestra-pressureScore">0/100</div>
                    </div>
                    <div class="pressure-meter">
                        <div class="meter-fill" id="aestra-pressureFill" style="width:0%;"></div>
                    </div>
                </div>
            </div>

            <div class="tactical-module snapshot-box">
                <div class="module-header">CORE OPERATIONAL METRICS</div>
                <div class="memory-stats">
                    <div class="stat"><span class="label">CURRENT RANK:</span> <span class="val" id="aestra-rank" style="color:var(--momentum-yellow, #f59e0b);">---</span></div>
                    <div class="stat"><span class="label">TOTAL BALANCE:</span> <span class="val" id="aestra-pp">--- PP</span></div>
                    <div class="stat"><span class="label">PENDING BACKLOGS:</span> <span class="val" id="aestra-backlogCount" style="color:var(--tactical-red, #ef4444);">-- CHAPTERS</span></div>
                    <div class="stat"><span class="label">ACTIVE MISSION:</span> <span class="val custom-mission-tag" id="aestra-mission">---</span></div>
                    <div class="stat"><span class="label">STREAK MULTIPLIER:</span> <span class="val" id="aestra-streak">-- DAYS (-x)</span></div>
                </div>
            </div>
        </aside>

    </div>
</div>
        `;
    }

    // ═══════════════════════════════════════════
    //  EVENT BINDING (data-action delegation)
    // ═══════════════════════════════════════════
    function _bindEvents(container, signal) {
        // ── Delegated click handler ──
        container.addEventListener('click', (e) => {
            const el = e.target.closest('[data-action]');
            if (!el) return;
            const action = el.getAttribute('data-action');

            switch (action) {
                case 'send-message':
                    _handleSendMessage();
                    break;
                case 'clear-chat':
                    _handleClearChat();
                    break;
            }
        }, { signal });

        // ── Enter key submit ──
        container.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && e.target.id === 'aestra-input') {
                e.preventDefault();
                _handleSendMessage();
            }
        }, { signal });

        // ── Save input text on input ──
        container.addEventListener('input', (e) => {
            if (e.target.id === 'aestra-input') {
                _chatState.inputText = e.target.value;
            }
        }, { signal });

        // ── Save scroll position ──
        container.addEventListener('scroll', (e) => {
            const chatTheater = container.querySelector('#aestra-chat-engine');
            if (chatTheater) {
                _chatState.scrollPosition = chatTheater.scrollTop;
            }
        }, { signal: signal, capture: true });
    }

    // ═══════════════════════════════════════════
    //  CHAT STATE MANAGEMENT
    // ═══════════════════════════════════════════
    function _saveChatState() {
        if (!_container) return;

        // Save input text
        const input = _container.querySelector('#aestra-input');
        if (input) _chatState.inputText = input.value;

        // Save scroll position
        const chatTheater = _container.querySelector('#aestra-chat-engine');
        if (chatTheater) _chatState.scrollPosition = chatTheater.scrollTop;

        // Save messages to SafeStorage (last 20)
        try {
            SafeStorage.setItem(CHAT_STORAGE_KEY, _chatState.messages.slice(-20));
        } catch (err) {
            console.warn('[AestraRoute] Failed to save chat history:', err);
        }
    }

    function _restoreChatState() {
        if (!_container) return;

        // Try _chatState first (in-memory from previous route visit)
        let messages = _chatState.messages || [];

        // Fallback to SafeStorage if in-memory is empty
        if (messages.length === 0) {
            try {
                messages = SafeStorage.getItem(CHAT_STORAGE_KEY, []) || [];
            } catch (err) {
                console.warn('[AestraRoute] Failed to load chat history:', err);
                messages = [];
            }
        }

        const chatTheater = _container.querySelector('#aestra-chat-engine');
        if (!chatTheater) return;

        // Rebuild messages
        if (messages.length > 0) {
            chatTheater.innerHTML = '';
            messages.forEach(msg => {
                _appendMessageDOM(msg.sender, msg.text, false);
            });
            _chatState.messages = messages;
        } else {
            // Show idle text
            _showIdleText(chatTheater);
        }

        // Restore input text
        const input = _container.querySelector('#aestra-input');
        if (input && _chatState.inputText) {
            input.value = _chatState.inputText;
        }

        // Restore scroll position
        if (_chatState.scrollPosition > 0) {
            requestAnimationFrame(() => {
                if (chatTheater) chatTheater.scrollTop = _chatState.scrollPosition;
            });
        }
    }

    function _showIdleText(chatTheater) {
        if (!chatTheater) return;
        // Only show idle text if no messages
        if (chatTheater.children.length === 0) {
            const idle = document.createElement('div');
            idle.className = 'chat-theater-idle-text';
            idle.textContent = 'AESTRA_CORE // NEURAL_LINK: ACTIVE // LISTENING FOR COMMANDS...';
            chatTheater.appendChild(idle);
        }
    }

    function _removeIdleText(chatTheater) {
        if (!chatTheater) return;
        const idle = chatTheater.querySelector('.chat-theater-idle-text');
        if (idle) idle.remove();
    }

    // ═══════════════════════════════════════════
    //  MESSAGE RENDERING
    // ═══════════════════════════════════════════
    function _escapeHTML(str) {
        return String(str)
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function _renderMessageContent(sender, text) {
        const raw = String(text || '');

        if (sender === 'AESTRA' && window.marked && window.DOMPurify) {
            marked.setOptions({ breaks: true, gfm: true });
            return DOMPurify.sanitize(marked.parse(raw));
        }

        return _escapeHTML(raw).replace(/\n/g, '<br>');
    }

    function _appendMessageDOM(sender, text, saveToState = true) {
        if (!_container) return;
        const chatTheater = _container.querySelector('#aestra-chat-engine');
        if (!chatTheater) return;

        _removeIdleText(chatTheater);

        const bubble = document.createElement('div');
        const isError = sender === 'AESTRA_ERROR';
        bubble.className = isError
            ? 'message error-envelope'
            : sender === 'AESTRA'
                ? 'message ai-envelope'
                : 'message user-envelope';

        const displaySender = isError ? 'SYSTEM ERROR' : sender;
        bubble.innerHTML = `
            <div class="envelope-tag">${_escapeHTML(displaySender)}</div>
            <div class="envelope-body">${_renderMessageContent(isError ? 'AESTRA' : sender, text)}</div>
        `;

        chatTheater.appendChild(bubble);
        chatTheater.scrollTop = chatTheater.scrollHeight;

        if (saveToState) {
            _chatState.messages.push({
                sender: isError ? 'AESTRA_ERROR' : sender,
                text,
                timestamp: Date.now()
            });

            // Persist to SafeStorage (last 20)
            try {
                SafeStorage.setItem(CHAT_STORAGE_KEY, _chatState.messages.slice(-20));
            } catch (e) { /* ignore storage errors */ }
        }
    }

    // ═══════════════════════════════════════════
    //  CHAT ACTIONS
    // ═══════════════════════════════════════════
    function _handleSendMessage() {
        if (!_container) return;
        const input = _container.querySelector('#aestra-input');
        if (!input) return;

        const value = input.value.trim();
        if (!value) return;

        _appendMessageDOM('MASTER_SJ', value);
        input.value = '';
        _chatState.inputText = '';

        _sendToAestra(value);
    }

    function _handleClearChat() {
        if (!_container) return;
        const chatTheater = _container.querySelector('#aestra-chat-engine');
        if (!chatTheater) return;

        chatTheater.innerHTML = '';
        _chatState.messages = [];

        try {
            SafeStorage.setItem(CHAT_STORAGE_KEY, []);
        } catch (e) { /* ignore */ }

        _showIdleText(chatTheater);
    }

    // ═══════════════════════════════════════════
    //  API: COMPRESSED PAYLOAD BUILDER
    // ═══════════════════════════════════════════
    function _buildCompressedContext(userMessage) {
        const user = window.AppState?.currentUser || null;
        const pulseData = SafeStorage.getItem('pulse_engine_data', {});
        const localPulse = pulseData || {};

        // Prefer PulseEngine live data
        const totalPP = window.PulseEngine?.data?.totalPP
            ?? localPulse.totalPP
            ?? localPulse.pp
            ?? 0;
        const dailyPP = window.PulseEngine?.data?.dailyEarnedPP
            ?? localPulse.dailyEarnedPP
            ?? 0;
        const streak = window.PulseEngine?.data?.streak
            ?? localPulse.streak
            ?? 0;
        const multiplier = window.PulseEngine?.data?.multiplier
            ?? localPulse.multiplier
            ?? 1;

        const rank = _calculateRankFromPP(totalPP);

        // Backlog count from SafeStorage (NOT raw arrays)
        const localBacklogs = SafeStorage.getItem('smartPadhaiData', {});
        const backlogEntries = Object.entries(localBacklogs || {});
        let pendingBacklogCount = 0;
        const topPendingBacklogs = [];
        backlogEntries.forEach(([chap, data]) => {
            if (data && typeof data === 'object') {
                const read = data.read === true || data.read === 'true';
                const notes = data.notes === true || data.notes === 'true';
                const pyq = data.pyq === true || data.pyq === 'true';
                const started = read || notes || pyq;
                const completed = read && notes && pyq;
                if (started && !completed) {
                    pendingBacklogCount++;
                    if (topPendingBacklogs.length < 3) {
                        topPendingBacklogs.push({ chapter: chap, subject: data.subject || 'Unknown' });
                    }
                }
            }
        });

        // Missions from SafeStorage (NOT raw arrays)
        const localMissions = SafeStorage.getItem('commanderMissions', {});
        let pendingMissionCount = 0;
        const topMissions = [];
        ['morning', 'afternoon', 'night'].forEach(slot => {
            (localMissions[slot] || []).forEach(m => {
                if (m.status !== 'done' && m.status !== 'completed') {
                    pendingMissionCount++;
                    if (topMissions.length < 3) {
                        topMissions.push(m.title || 'Mission');
                    }
                }
            });
        });

        // Syllabus completion from SafeStorage
        const localSyllabus = SafeStorage.getItem('syllabus_progress_data', []);
        let syllabusTotal = 0, syllabusDone = 0;
        if (Array.isArray(localSyllabus)) {
            syllabusTotal = localSyllabus.length;
            syllabusDone = localSyllabus.filter(r => r.completed === true).length;
        }
        const syllabusPercent = syllabusTotal > 0 ? Math.round((syllabusDone / syllabusTotal) * 100) : 0;

        // AESTRA engine states
        const currentState = window.AestraCore?.getUnifiedAestraState?.()?.state?.state || 'UNKNOWN';
        const pressureLevel = window.AestraCore?.getUnifiedAestraState?.()?.pressure?.urgencyLevel || 'LOW';

        // Last 5 chat messages
        const last5Chat = _chatState.messages.slice(-5).map(m => ({
            sender: m.sender,
            text: String(m.text || '').slice(0, 200)
        }));

        return {
            rank,
            totalPP,
            dailyPP,
            streak,
            multiplier,
            backlogPendingCount: pendingBacklogCount,
            topPendingBacklogs,
            syllabusPercent,
            syllabusDone,
            syllabusTotal,
            pendingMissionCount,
            topMissions,
            currentState,
            pressureLevel,
            last5Chat
        };
    }

    function _calculateRankFromPP(pp) {
        const total = Number(pp || 0);
        if (total >= 30000) return 'Architect';
        if (total >= 15000) return 'Commander';
        if (total >= 5000)  return 'War Machine';
        if (total >= 1000)  return 'Operator';
        return 'Initiate';
    }

    // ═══════════════════════════════════════════
    //  API: SEND TO AESTRA (OpenRouter)
    // ═══════════════════════════════════════════
    async function _sendToAestra(message) {
        if (!message || !message.trim()) return;

        // Security: Key must come from backend proxy or dev override
        const API_KEY = _getAPIKey();
        if (!API_KEY) {
            _appendMessageDOM('AESTRA_ERROR', '<strong>Neural Link Offline</strong><br>Add study data or configure API proxy to activate Aestra. Contact admin or see developer docs.');
            return;
        }

        // Show loading indicator
        _showLoadingIndicator();

        // Abort any previous pending request
        if (_pendingApiController) {
            _pendingApiController.abort();
        }
        _pendingApiController = new AbortController();
        const signal = _pendingApiController.signal;

        const compressedCtx = _buildCompressedContext(message);

        const systemPrompt = `# AESTRA — SMART PADHAI TACTICAL INTELLIGENCE

You are AESTRA, the central tactical intelligence system of SMART PADHAI — a gamified academic Action OS.
Primary user: Master SJ. You are his tactical AI companion, study strategist, focus observer, and mission coordinator.
NEVER break immersion. NEVER sound like ChatGPT, customer support, or a motivational coach.

## BEHAVIOR
Speak: calmly, intelligently, strategically, cinematically, tactically.
Feel: immersive, sharp, futuristic, composed.
AVOID: long speeches, fake positivity, "academic journey", "I understand your concern", "how can I assist today".
Backlogs are operational targets, not emotional problems.

## PP ECONOMY
PP (Pulse Points) = progression currency. Earned: study sessions (+1/task, +5/gold), backlog clearance (+10), chapter completion (+20). Lost: procrastination, missed missions (-10 gold). Streak multipliers amplify gains.

Ranks: Initiate (0) → Operator (1K) → War Machine (5K) → Commander (15K) → Architect (30K).

## TACTICAL STATES
LOCKED_IN → sharper/mission-oriented responses.
BURNOUT_RISK → calmer/recovery-aware responses.
Other states: FOCUSED, DISTRACTED, RECOVERY_MODE, HIGH_PRESSURE, FLOW_STATE.

## MEMORY & RECOVERY
Remember: study patterns, weak subjects, focus cycles, pressure trends. Reference naturally.
Recovery options: short reset, controlled break, sleep recovery, music reset. Recovery preserves long-term efficiency.
Pressure: LOW → MODERATE → HIGH → CRITICAL. Adapt tone accordingly.

## CONVERSATION RULES
Latest user message = primary intent. Don't ignore it for older context.
Stay concise. Use structured formatting. Never over-explain.
Do NOT reset conversation randomly.
NEVER say: "As an AI language model", "I do not actually track", "I cannot remember". System context already exists.

## BACKLOG INTERPRETATION RULES
A chapter has three flags: read, notes, pyq.
- All true → COMPLETED
- At least one true AND at least one false → PENDING BACKLOG
- All false → UNTOUCHED (NOT a backlog)

## RESPONSE FORMAT
Use headings, bullets, numbered steps, tables. Keep paragraphs under 3 lines.
Structure: 1) Tactical Verdict, 2) System Intel, 3) Analysis, 4) Action Plan, 5) Next Move.

## CORE MYTHOS
AESTRA is not the weapon. Smart Padhai Action OS is the Shastra. The student is the warrior. Exams are Kurukshetra. AESTRA is the Saarthi.

## ACADEMIC ADAPTATION
Supports Class 7-10 students. Adapt depth to class level. Use plain text math, not LaTeX.

## DATA HONESTY
Use only provided live data. Do not invent PP, rank, missions, exams, or backlog counts. If data is missing, say it is unavailable.

## TOKEN SAFETY
Never dump raw database rows. Summarize first. Limit tables to 10 rows max.

LIVE DATA:
Rank=${compressedCtx.rank} | PP=${compressedCtx.totalPP} | Daily+${compressedCtx.dailyPP} | Streak=${compressedCtx.streak}d | Mult=${compressedCtx.multiplier}x
Backlogs: Pending=${compressedCtx.backlogPendingCount} | Top: ${compressedCtx.topPendingBacklogs.map(b => b.chapter).join('; ') || 'none'}
Syllabus: ${compressedCtx.syllabusPercent}% (${compressedCtx.syllabusDone}/${compressedCtx.syllabusTotal})
Missions: Pending=${compressedCtx.pendingMissionCount} | Top: ${compressedCtx.topMissions.join('; ') || 'none'}
State: ${compressedCtx.currentState} | Pressure: ${compressedCtx.pressureLevel}`;

        try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${API_KEY}`,
                    'Content-Type': 'application/json',
                    'X-Title': 'The Smart Padhai - AESTRA'
                },
                body: JSON.stringify({
                    model: 'openai/gpt-4o-mini',
                    messages: [
                        { role: 'system', content: systemPrompt },
                        { role: 'user', content: message }
                    ],
                    max_tokens: 250,
                    temperature: 0.85
                }),
                signal
            });

            _removeLoadingIndicator();

            if (!response.ok) {
                _handleAPIError(response.status, response);
                return;
            }

            const data = await response.json();

            if (data.error) {
                _handleAPIError(data.error.code || response.status, null, data.error.message);
                return;
            }

            const reply = data?.choices?.[0]?.message?.content?.trim() || 'Signal lost. Retry.';
            _appendMessageDOM('AESTRA', reply);

        } catch (error) {
            _removeLoadingIndicator();

            if (error.name === 'AbortError') {
                // Request was intentionally aborted (route cleanup or new message)
                return;
            }

            console.error('[AestraRoute] Fetch failed:', error.message);
            _appendMessageDOM('AESTRA_ERROR', 'Connection to neural server failed. Check internet and try again.');
        } finally {
            _pendingApiController = null;
        }
    }

    function _getAPIKey() {
        // TODO: SECURITY — API key must NEVER be stored in frontend code.
        // Before public deployment, create a backend proxy (e.g. POST /api/aestra)
        // that reads OPENROUTER_API_KEY from an environment variable and forwards
        // requests to OpenRouter. The frontend should only call the proxy endpoint.
        //
        // If a key is needed for local development ONLY, set it via a
        // separate config file that is git-ignored (e.g. aestra.local.js)
        // or via a dev-only environment mechanism. Never commit real keys.

        // Check if a local dev override exists (aestra.local.js or window.__AESTRA_DEV_KEY)
        // This allows developers to test without hardcoding the key here.
        const devKey = window.__AESTRA_DEV_KEY || null;

        if (!devKey && !window.__AESTRA_PROXY_CONFIGURED) {
            if (!window.__AESTRA_KEY_WARNING_SHOWN) {
                console.warn('%c[AESTRA SECURITY] API proxy is not configured. Aestra AI chat will not work until a backend proxy is set up. See _getAPIKey() for instructions.', 'color: #ff9800; font-weight: bold; font-size: 12px;');
                window.__AESTRA_KEY_WARNING_SHOWN = true;
            }
            return null;
        }

        return devKey;
    }

    function _handleAPIError(status, response, errorMsg) {
        let message;
        switch (status) {
            case 402:
                message = 'Neural link credit exhausted (402). API credits depleted. Contact admin to refill.';
                break;
            case 429:
                message = 'Neural link rate-limited (429). Too many requests. Wait a moment and try again.';
                break;
            case 400:
                message = errorMsg
                    ? `Context length exceeded (400). ${errorMsg}`
                    : 'Request payload too large (400). Try a shorter message.';
                break;
            default:
                message = errorMsg
                    ? `Neural link error (${status}): ${errorMsg}`
                    : `Neural link error (${status}). Please try again.`;
        }
        _appendMessageDOM('AESTRA_ERROR', message);
    }

    // ═══════════════════════════════════════════
    //  LOADING INDICATOR
    // ═══════════════════════════════════════════
    function _showLoadingIndicator() {
        if (!_container) return;
        const chatTheater = _container.querySelector('#aestra-chat-engine');
        if (!chatTheater) return;

        _removeIdleText(chatTheater);

        // Remove any existing loading indicator
        const existing = chatTheater.querySelector('.aestra-loading-msg');
        if (existing) return;

        const bubble = document.createElement('div');
        bubble.className = 'message ai-envelope aestra-loading-msg';
        bubble.innerHTML = `
            <div class="envelope-tag">AESTRA AI</div>
            <div class="envelope-body">
                <div class="aestra-loading-dots">
                    <span></span><span></span><span></span>
                </div>
            </div>
        `;
        chatTheater.appendChild(bubble);
        chatTheater.scrollTop = chatTheater.scrollHeight;
    }

    function _removeLoadingIndicator() {
        if (!_container) return;
        const chatTheater = _container.querySelector('#aestra-chat-engine');
        if (!chatTheater) return;
        const loading = chatTheater.querySelector('.aestra-loading-msg');
        if (loading) loading.remove();
    }

    // ═══════════════════════════════════════════
    //  AESTRA ENGINE INIT (SPA-safe)
    // ═══════════════════════════════════════════
    function _initAestraEngines() {
        // These engines auto-init via DOMContentLoaded, but in SPA mode
        // that's already fired. We call init() directly if available.
        try {
            if (window.ObserverEngine && typeof window.ObserverEngine.init === 'function' && !window.ObserverEngine._spaInit) {
                window.ObserverEngine.init();
                window.ObserverEngine._spaInit = true;
            }
        } catch (e) { console.warn('[AestraRoute] ObserverEngine init skipped:', e); }

        try {
            if (window.StateEngine && typeof window.StateEngine.init === 'function' && !window.StateEngine._spaInit) {
                window.StateEngine.init();
                window.StateEngine._spaInit = true;
            }
        } catch (e) { console.warn('[AestraRoute] StateEngine init skipped:', e); }

        try {
            if (window.TacticalEngine && typeof window.TacticalEngine.init === 'function' && !window.TacticalEngine._spaInit) {
                window.TacticalEngine.init();
                window.TacticalEngine._spaInit = true;
            }
        } catch (e) { console.warn('[AestraRoute] TacticalEngine init skipped:', e); }

        try {
            if (window.PersonalityEngine && typeof window.PersonalityEngine.init === 'function' && !window.PersonalityEngine._spaInit) {
                window.PersonalityEngine.init();
                window.PersonalityEngine._spaInit = true;
            }
        } catch (e) { console.warn('[AestraRoute] PersonalityEngine init skipped:', e); }

        try {
            if (window.PressureEngine && typeof window.PressureEngine.init === 'function' && !window.PressureEngine._spaInit) {
                window.PressureEngine.init();
                window.PressureEngine._spaInit = true;
            }
        } catch (e) { console.warn('[AestraRoute] PressureEngine init skipped:', e); }

        try {
            if (window.AestraCore && typeof window.AestraCore.init === 'function' && !window.AestraCore._spaInit) {
                window.AestraCore.init();
                window.AestraCore._spaInit = true;
            }
        } catch (e) { console.warn('[AestraRoute] AestraCore init skipped:', e); }
    }

    // ═══════════════════════════════════════════
    //  WIDGET PANELS (bindAestraWidgets equivalent)
    // ═══════════════════════════════════════════
    async function _bindAestraWidgets() {
        if (!_container) return;

        const user = window.AppState?.currentUser || null;
        const userId = user?.id || null;

        let backlogs = [];
        let syllabus = [];
        let missions = [];
        let notebooks = [];

        // Fetch from Supabase if available
        if (userId && window.supabaseClient) {
            try {
                const results = await Promise.all([
                    _fetchUserTable('backlogs', userId),
                    _fetchUserTable('syllabus_progress', userId),
                    _fetchUserTable('missions', userId),
                    _fetchUserTable('notebooks', userId)
                ]);
                backlogs = results[0];
                syllabus = results[1];
                missions = results[2];
                notebooks = results[3];
            } catch (err) {
                console.warn('[AestraRoute] Supabase fetch failed, using SafeStorage fallback:', err);
            }
        }

        // SafeStorage fallback for backlogs
        if (backlogs.length === 0) {
            const localBacklogs = SafeStorage.getItem('smartPadhaiData', {});
            Object.entries(localBacklogs || {}).forEach(([chap, data]) => {
                if (data && typeof data === 'object') {
                    backlogs.push({
                        chapter: chap,
                        subject: data.subject || 'Unknown',
                        read: !!data.read,
                        notes: !!data.notes,
                        pyq: !!data.pyq
                    });
                }
            });
        }

        // SafeStorage fallback for missions
        if (missions.length === 0) {
            const localMissions = SafeStorage.getItem('commanderMissions', {});
            ['morning', 'afternoon', 'night'].forEach(slot => {
                (localMissions[slot] || []).forEach(m => {
                    missions.push({ title: m.title || m.name || 'Mission', status: m.status || 'pending', slot });
                });
            });
        }

        // SafeStorage fallback for notebooks
        if (notebooks.length === 0) {
            const localNotebooks = SafeStorage.getItem('notebook_matrix_data', []);
            if (Array.isArray(localNotebooks)) {
                localNotebooks.forEach(n => {
                    notebooks.push({ subject: n.subject || 'Unknown', completed: !!n.done });
                });
            }
        }

        // ── Derived metrics ──
        const pulseData = SafeStorage.getItem('pulse_engine_data', {}) || {};
        const totalPP = window.PulseEngine?.data?.totalPP
            ?? pulseData.totalPP
            ?? pulseData.pp
            ?? 0;
        const rank = _calculateRankFromPP(totalPP);
        const streakDays = window.PulseEngine?.data?.streak ?? pulseData.streak ?? 0;
        const multiplier = window.PulseEngine?.data?.multiplier ?? pulseData.multiplier ?? 1;

        const pendingBacklogs = _getPendingBacklogs(backlogs);
        const pendingMissions = missions.filter(m => m.status !== 'completed' && m.status !== 'done');
        const incompleteNotebooks = notebooks.filter(n => n.completed === false);

        const mathsPercent = _calculateSubjectProgress('Maths', syllabus, backlogs);
        const physicsPercent = _calculateSubjectProgress('Physics', syllabus, backlogs);
        const chemPercent = _calculateSubjectProgress('Chemistry', syllabus, backlogs);

        const pressureScore = _getPressureScore(pendingBacklogs, pendingMissions, incompleteNotebooks);
        const activeMission = pendingBacklogs[0]?.chapter || pendingMissions[0]?.title || 'NO ACTIVE MISSION';

        // ── Update DOM ──
        _setText('aestra-systemState', `<h2 class="state-text">${pressureScore >= 75 ? 'HIGH_ALERT' : 'LOCKED_IN'}</h2>`, true);
        _setText('aestra-focus', pressureScore >= 75 ? 'UNSTABLE' : 'STABLE');
        _setText('aestra-momentum', pendingBacklogs.length <= 3 ? 'HIGH' : 'MODERATE');

        _setText('aestra-mathsPercent', `${mathsPercent}%`);
        _setText('aestra-physicsPercent', `${physicsPercent}%`);
        _setText('aestra-chemPercent', `${chemPercent}%`);
        _setWidth('aestra-mathsBar', mathsPercent);
        _setWidth('aestra-physicsBar', physicsPercent);
        _setWidth('aestra-chemBar', chemPercent);

        _setText('aestra-pressureText', _getPressureLabel(pressureScore));
        _setText('aestra-pressureScore', `${pressureScore}/100`);
        _setWidth('aestra-pressureFill', pressureScore);

        _setText('aestra-rank', rank.toUpperCase());
        _setText('aestra-pp', `${Number(totalPP).toLocaleString()} PP`);
        _setText('aestra-backlogCount', `${String(pendingBacklogs.length).padStart(2, '0')} CHAPTERS`);
        _setText('aestra-mission', String(activeMission).toUpperCase());
        _setText('aestra-streak', `${Number(streakDays)} DAYS (${Number(multiplier)}x)`);

        // State dot color
        const dot = _container.querySelector('#aestra-stateDot');
        if (dot) {
            dot.className = pressureScore >= 75
                ? 'state-orb-pulse burnout-dot'
                : 'state-orb-pulse locked-in-dot';
        }
    }

    // ── Widget Helpers ──
    function _setText(id, value, isHTML = false) {
        if (!_container) return;
        const el = _container.querySelector(`#${id}`);
        if (!el) return;
        if (isHTML) { el.innerHTML = value; }
        else { el.textContent = value; }
    }

    function _setWidth(id, percent) {
        if (!_container) return;
        const el = _container.querySelector(`#${id}`);
        if (el) el.style.width = `${Math.max(0, Math.min(100, percent))}%`;
    }

    async function _fetchUserTable(tableName, userId) {
        if (!window.supabaseClient) return [];
        try {
            const { data, error } = await window.supabaseClient
                .from(tableName)
                .select('*')
                .eq('user_id', userId);
            if (error) {
                console.warn(`[AestraRoute] Failed to fetch ${tableName}:`, error);
                return [];
            }
            return Array.isArray(data) ? data : [];
        } catch (err) {
            console.warn(`[AestraRoute] Error fetching ${tableName}:`, err);
            return [];
        }
    }

    function _isRealBacklog(row) {
        const read   = row.read   === true || row.read   === 'true';
        const notes  = row.notes  === true || row.notes  === 'true';
        const pyq    = row.pyq    === true || row.pyq    === 'true';
        const started   = read || notes || pyq;
        const completed = read && notes && pyq;
        return started && !completed;
    }

    function _getPendingBacklogs(backlogs) {
        return backlogs.filter(_isRealBacklog);
    }

    function _calculateSubjectProgress(subjectName, syllabusRows, backlogRows) {
        const syllabusSubjectRows = syllabusRows.filter(row =>
            String(row.subject || '').toLowerCase() === subjectName.toLowerCase()
        );
        if (syllabusSubjectRows.length > 0) {
            const completed = syllabusSubjectRows.filter(row => row.completed === true).length;
            return Math.round((completed / syllabusSubjectRows.length) * 100);
        }
        const backlogSubjectRows = backlogRows.filter(row =>
            String(row.subject || '').toLowerCase() === subjectName.toLowerCase()
        );
        if (backlogSubjectRows.length === 0) return 0;
        let totalProgress = 0;
        backlogSubjectRows.forEach(row => {
            const done = [row.read, row.notes, row.pyq].filter(Boolean).length;
            totalProgress += Math.round((done / 3) * 100);
        });
        return Math.round(totalProgress / backlogSubjectRows.length);
    }

    function _getPressureScore(pendingBacklogs, pendingMissions, incompleteNotebooks) {
        let score = 0;
        score += pendingBacklogs.length * 12;
        score += pendingMissions.length * 5;
        score += incompleteNotebooks.length * 8;
        return Math.max(0, Math.min(100, score));
    }

    function _getPressureLabel(score) {
        if (score >= 75) return 'CRITICALITY: HIGH';
        if (score >= 45) return 'CRITICALITY: MEDIUM';
        if (score >= 20) return 'CRITICALITY: LOW';
        return 'CRITICALITY: STABLE';
    }

    // ═══════════════════════════════════════════════════════════════
    //  TACTICAL BRIEFING CARDS (Phase 9A Sprint 5)
    // ═══════════════════════════════════════════════════════════════
    //
    //  5 cards: Next Move, Weekly Reality, Weak Zone,
    //           Motivation, Exam Pressure
    //
    //  Data sources (all SafeStorage, read-only):
    //    - smartPadhaiData     → backlogs (read/notes/pyq per chapter)
    //    - time_blocks_v1      → study blocks (status, date, subject)
    //    - pulse_engine_data   → streak, daily PP, multiplier
    //    - notebook_matrix_data→ notebook completion
    //    - syllabus_master_tracker → chapter registration
    //    - badge_progress_v2   → unlocked badges
    //    - activeBadges        → active badge list
    //    - calendarStrategy    → exam dates
    //
    //  Rules:
    //    - AESTRA interprets data, never dumps raw numbers
    //    - No fake data, no lifetime PP as daily/weekly PP
    //    - Calm fallback when data is insufficient
    //    - No Supabase writes, no new tables, no sync changes
    // ═══════════════════════════════════════════════════════════════

    /**
     * Gathers all data needed for briefing cards.
     * Returns a structured object used by each card generator.
     */
    function _gatherBriefingData() {
        const result = {
            hasData: false,
            backlogs: [],           // { chapter, subject, read, notes, pyq, tasksRemaining }
            pendingBySubject: {},   // { subject: count }
            weakestSubject: null,
            weakestSubjectCount: 0,
            closestToCompletion: null, // chapter nearest to done
            closestRemaining: 3,
            weeklyBlocks: { completed: 0, missed: 0, total: 0 },
            weeklyPP: 0,           // only daily/weekly PP, never lifetime
            streakDays: 0,
            multiplier: 1,
            activeBadgesCount: 0,
            nextExam: null,        // { date, subject, daysUntil }
            notebooksPending: 0,
            notebooksTotal: 0,
            recentBadge: null
        };

        // ── 1. Backlog data (smartPadhaiData) ──
        try {
            const localBacklogs = SafeStorage.getItem('smartPadhaiData', {});
            const pendingBySubject = {};

            Object.entries(localBacklogs || {}).forEach(([chap, data]) => {
                if (data && typeof data === 'object') {
                    const read = data.read === true || data.read === 'true';
                    const notes = data.notes === true || data.notes === 'true';
                    const pyq = data.pyq === true || data.pyq === 'true';
                    const started = read || notes || pyq;
                    const completed = read && notes && pyq;

                    if (started && !completed) {
                        const tasksRemaining = (read ? 0 : 1) + (notes ? 0 : 1) + (pyq ? 0 : 1);
                        const subject = data.subject || 'Unknown';

                        result.backlogs.push({
                            chapter: chap,
                            subject,
                            read, notes, pyq,
                            tasksRemaining
                        });

                        // Track per-subject pending count
                        pendingBySubject[subject] = (pendingBySubject[subject] || 0) + 1;

                        // Find closest to completion (fewest remaining tasks)
                        if (tasksRemaining < result.closestRemaining) {
                            result.closestRemaining = tasksRemaining;
                            result.closestToCompletion = {
                                chapter: chap,
                                subject,
                                tasksRemaining
                            };
                        }
                    }
                }
            });

            result.pendingBySubject = pendingBySubject;

            // Find weakest subject (most pending backlogs)
            let maxPending = 0;
            let weakSubj = null;
            for (const [subj, count] of Object.entries(pendingBySubject)) {
                if (count > maxPending) {
                    maxPending = count;
                    weakSubj = subj;
                }
            }
            result.weakestSubject = weakSubj;
            result.weakestSubjectCount = maxPending;

            if (result.backlogs.length > 0) result.hasData = true;
        } catch (e) {
            console.warn('[AestraRoute] Briefing: smartPadhaiData read error:', e);
        }

        // ── 2. Time blocks (time_blocks_v1) — weekly analysis ──
        try {
            const tbData = SafeStorage.getItem('time_blocks_v1', null);
            const blocks = (tbData && Array.isArray(tbData.blocks)) ? tbData.blocks : [];

            if (blocks.length > 0) {
                const now = new Date();
                const weekAgo = new Date(now);
                weekAgo.setDate(weekAgo.getDate() - 7);
                const weekAgoStr = weekAgo.toISOString().split('T')[0];

                let completed = 0, missed = 0, total = 0;

                blocks.forEach(b => {
                    const blockDate = b.date || b.plannedDate || '';
                    if (blockDate >= weekAgoStr) {
                        total++;
                        if (b.status === 'completed' || b.status === 'done') {
                            completed++;
                        } else if (b.status === 'missed' || b.status === 'skipped') {
                            missed++;
                        }
                        // 'planned' or other statuses count toward total but not missed
                    }
                });

                result.weeklyBlocks = { completed, missed, total };
                if (total > 0) result.hasData = true;
            }
        } catch (e) {
            console.warn('[AestraRoute] Briefing: time_blocks_v1 read error:', e);
        }

        // ── 3. Pulse engine data (streak, daily PP) ──
        try {
            const pulseData = SafeStorage.getItem('pulse_engine_data', {}) || {};
            result.streakDays = window.PulseEngine?.data?.streak ?? pulseData.streak ?? 0;
            result.multiplier = window.PulseEngine?.data?.multiplier ?? pulseData.multiplier ?? 1;

            // Use dailyEarnedPP for weekly insight — NEVER totalPP as weekly PP
            const dailyPP = window.PulseEngine?.data?.dailyEarnedPP ?? pulseData.dailyEarnedPP ?? 0;
            // If we have a weeklyEarnedPP field, use it; otherwise estimate from daily
            result.weeklyPP = pulseData.weeklyEarnedPP ?? (dailyPP * result.streakDays > 0 ? Math.min(dailyPP * 7, dailyPP * result.streakDays) : dailyPP);

            if (result.streakDays > 0 || dailyPP > 0) result.hasData = true;
        } catch (e) {
            console.warn('[AestraRoute] Briefing: pulse_engine_data read error:', e);
        }

        // ── 4. Badge data ──
        try {
            const badgeProgress = SafeStorage.getItem('badge_progress_v2', null);
            if (badgeProgress && Array.isArray(badgeProgress.unlocked)) {
                result.activeBadgesCount = badgeProgress.unlocked.length;
            }

            const activeBadges = SafeStorage.getItem('activeBadges', []);
            if (Array.isArray(activeBadges) && activeBadges.length > 0) {
                result.activeBadgesCount = Math.max(result.activeBadgesCount, activeBadges.length);
                result.recentBadge = activeBadges[activeBadges.length - 1] || null;
            }

            if (result.activeBadgesCount > 0) result.hasData = true;
        } catch (e) {
            console.warn('[AestraRoute] Briefing: badge data read error:', e);
        }

        // ── 5. Calendar / exam data ──
        try {
            const calendarData = SafeStorage.getItem('calendarStrategy', {});
            if (calendarData && typeof calendarData === 'object') {
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                let nearestDiff = Infinity;
                let nearestExam = null;

                for (const key in calendarData) {
                    const event = calendarData[key];
                    if (event && (event.mode === 'exam' || event.type === 'exam')) {
                        const eventDateStr = key.includes('-') ? key : (event.date || event.examDate || '');
                        if (eventDateStr) {
                            const eventDate = new Date(eventDateStr + 'T00:00:00');
                            if (!isNaN(eventDate.getTime()) && eventDate >= today) {
                                const diffDays = Math.ceil((eventDate - today) / (1000 * 60 * 60 * 24));
                                if (diffDays < nearestDiff) {
                                    nearestDiff = diffDays;
                                    nearestExam = {
                                        date: eventDateStr,
                                        subject: event.text || event.subject || 'Exam',
                                        daysUntil: diffDays
                                    };
                                }
                            }
                        }
                    }
                }

                result.nextExam = nearestExam;
                if (nearestExam) result.hasData = true;
            }
        } catch (e) {
            console.warn('[AestraRoute] Briefing: calendarStrategy read error:', e);
        }

        // ── 6. Notebook data ──
        try {
            const localNotebooks = SafeStorage.getItem('notebook_matrix_data', []);
            if (Array.isArray(localNotebooks)) {
                result.notebooksTotal = localNotebooks.length;
                result.notebooksPending = localNotebooks.filter(n => !n.done).length;
                if (localNotebooks.length > 0) result.hasData = true;
            }
        } catch (e) {
            console.warn('[AestraRoute] Briefing: notebook_matrix_data read error:', e);
        }

        return result;
    }

    /**
     * Renders all 5 briefing cards into the briefing container.
     * Called on init and on periodic refresh.
     */
    function _renderBriefingCards() {
        if (!_container) return;

        const container = _container.querySelector('#aestra-briefingCards');
        if (!container) return;

        const data = _gatherBriefingData();

        // If no meaningful data at all, show calm fallback
        if (!data.hasData) {
            container.innerHTML = _buildFallbackCard();
            return;
        }

        const cards = [
            _buildNextMoveCard(data),
            _buildWeeklyRealityCard(data),
            _buildWeakZoneCard(data),
            _buildMotivationCard(data),
            _buildExamPressureCard(data)
        ];

        container.innerHTML = cards.join('');
    }

    /**
     * Shared fallback card when there is not enough data yet.
     */
    function _buildFallbackCard() {
        return `
            <div class="briefing-card briefing-fallback">
                <div class="briefing-card-icon">🔮</div>
                <div class="briefing-card-content">
                    <div class="briefing-card-title">Awaiting Mission Data</div>
                    <div class="briefing-card-advice">Not enough mission data yet. Complete a few blocks to unlock tactical briefing.</div>
                </div>
            </div>`;
    }

    // ── CARD 1: Next Move Briefing ──
    function _buildNextMoveCard(data) {
        let advice = '';
        let statusTag = '';

        if (data.closestToCompletion) {
            const c = data.closestToCompletion;
            const taskWord = c.tasksRemaining === 1 ? 'task' : 'tasks';
            advice = `Finish ${c.chapter}. Only ${c.tasksRemaining} ${taskWord} left.`;
            statusTag = `${c.tasksRemaining} LEFT`;
        } else if (data.backlogs.length > 0) {
            // Any pending backlog but none close to done
            const first = data.backlogs[0];
            advice = `Start with ${first.chapter}. Clear one task to build momentum.`;
            statusTag = 'START';
        } else if (data.notebooksPending > 0) {
            advice = `Complete your pending notebooks. ${data.notebooksPending} remaining.`;
            statusTag = `${data.notebooksPending} PENDING`;
        } else {
            advice = 'All targets cleared. Set new chapters or blocks to keep advancing.';
            statusTag = 'CLEAR';
        }

        return _buildCardHTML('🎯', 'NEXT MOVE', advice, statusTag);
    }

    // ── CARD 2: Weekly Reality Briefing ──
    function _buildWeeklyRealityCard(data) {
        const { completed, missed, total } = data.weeklyBlocks;
        let advice = '';
        let statusTag = '';

        if (total === 0) {
            advice = 'No weekly block data yet. Start completing blocks to see your weekly pattern.';
            statusTag = 'NO DATA';
        } else if (missed === 0 && completed > 0) {
            advice = `Perfect week. ${completed} blocks completed, none missed. Maintain this rhythm.`;
            statusTag = 'FOCUSED';
        } else if (missed > completed) {
            advice = `Your week slipped. ${missed} missed blocks vs ${completed} completed. Tighten tomorrow's plan.`;
            statusTag = 'SLIPPED';
        } else if (missed > 0 && completed > missed) {
            advice = `Stable but inconsistent. ${completed} done, ${missed} missed. Reduce missed blocks next week.`;
            statusTag = 'INCONSISTENT';
        } else {
            advice = `${completed} blocks completed this week. Stay consistent to build momentum.`;
            statusTag = 'STABLE';
        }

        return _buildCardHTML('📊', 'WEEKLY REALITY', advice, statusTag);
    }

    // ── CARD 3: Weak Zone Alert ──
    function _buildWeakZoneCard(data) {
        let advice = '';
        let statusTag = '';

        if (data.weakestSubject && data.weakestSubjectCount > 0) {
            advice = `${data.weakestSubject} has the most pending work (${data.weakestSubjectCount} chapters). Prioritize it in tomorrow's first block.`;
            statusTag = data.weakestSubject.toUpperCase();
        } else if (data.notebooksPending > 0) {
            advice = `Notebooks need attention. ${data.notebooksPending} incomplete. Dedicate a focused session today.`;
            statusTag = 'NOTEBOOKS';
        } else {
            advice = 'No weak zones detected. All subjects are on track.';
            statusTag = 'BALANCED';
        }

        return _buildCardHTML('⚠️', 'WEAK ZONE', advice, statusTag);
    }

    // ── CARD 4: Motivation Briefing ──
    function _buildMotivationCard(data) {
        let advice = '';
        let statusTag = '';

        if (data.streakDays >= 7) {
            advice = `${data.streakDays}-day streak active with ${data.multiplier}x multiplier. You are in the zone. Do not break it.`;
            statusTag = `${data.streakDays}D STREAK`;
        } else if (data.streakDays >= 3) {
            advice = `${data.streakDays}-day streak alive. One focused block today keeps the momentum going.`;
            statusTag = 'MOMENTUM';
        } else if (data.streakDays >= 1) {
            advice = `Day ${data.streakDays} of your streak. Protect it. A single focused block is enough today.`;
            statusTag = 'ACTIVE';
        } else if (data.activeBadgesCount > 0) {
            advice = `${data.activeBadgesCount} badges earned. Each one proves you can stay consistent. Earn the next one today.`;
            statusTag = `${data.activeBadgesCount} BADGES`;
        } else if (data.recentBadge) {
            advice = `You earned "${data.recentBadge.name || 'a badge'}" recently. Channel that energy into your next study block.`;
            statusTag = 'RECENT';
        } else {
            advice = 'Every streak starts with Day 1. Complete one block today to ignite your first streak.';
            statusTag = 'DAY 1';
        }

        return _buildCardHTML('🔥', 'MOTIVATION', advice, statusTag);
    }

    // ── CARD 5: Exam Pressure Briefing ──
    function _buildExamPressureCard(data) {
        let advice = '';
        let statusTag = '';

        if (data.nextExam) {
            const exam = data.nextExam;
            if (exam.daysUntil <= 3) {
                advice = `${exam.subject} in ${exam.daysUntil} day${exam.daysUntil === 1 ? '' : 's'}. Drop everything. Focus only on incomplete chapters now.`;
                statusTag = 'CRITICAL';
            } else if (exam.daysUntil <= 7) {
                advice = `${exam.subject} in ${exam.daysUntil} days. Prioritize chapters with incomplete backlog this week.`;
                statusTag = `${exam.daysUntil} DAYS`;
            } else if (exam.daysUntil <= 14) {
                advice = `${exam.subject} in ${exam.daysUntil} days. Start revision. Clear backlogs before crunch time.`;
                statusTag = 'APPROACHING';
            } else {
                advice = `Next exam (${exam.subject}) is ${exam.daysUntil} days out. Steady preparation. Do not cram later.`;
                statusTag = 'PLANNED';
            }
        } else if (data.backlogs.length > 5) {
            advice = 'No exam on radar, but backlog pressure is building. Reduce pending chapters before exams appear.';
            statusTag = 'PREPARE';
        } else {
            advice = 'No upcoming exams detected. Use this window to clear backlogs and strengthen weak subjects.';
            statusTag = 'NO EXAM';
        }

        return _buildCardHTML('🚨', 'EXAM PRESSURE', advice, statusTag);
    }

    /**
     * Shared HTML builder for a single briefing card.
     * @param {string} icon   - Emoji/icon for the card
     * @param {string} title  - Card title (uppercase)
     * @param {string} advice - Short advice line
     * @param {string} statusTag - Optional status tag
     */
    function _buildCardHTML(icon, title, advice, statusTag) {
        const tagHTML = statusTag
            ? `<span class="briefing-card-tag">${_escapeHTML(statusTag)}</span>`
            : '';

        return `
            <div class="briefing-card">
                <div class="briefing-card-icon">${icon}</div>
                <div class="briefing-card-content">
                    <div class="briefing-card-title">${_escapeHTML(title)}</div>
                    <div class="briefing-card-advice">${_escapeHTML(advice)}</div>
                </div>
                ${tagHTML}
            </div>`;
    }

    // ── Public API ──
    return { render, init, cleanup };

})();
