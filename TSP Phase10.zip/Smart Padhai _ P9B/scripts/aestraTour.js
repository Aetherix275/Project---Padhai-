/*
 * Smart Padhai — AESTRA System Briefing
 * Scripted, local-only onboarding tour. No AI/API calls are made here.
 */
(function () {
    'use strict';

    const STORAGE_KEY = 'smart_padhai_aestra_intro_tour_seen';
    const ROUTE_WAIT_MS = 520;
    const MODULE_LOADING_TEXT = 'Opening module...';

    const state = {
        active: false,
        introOpen: false,
        index: 0,
        overlay: null,
        panel: null,
        highlighted: null,
        loading: false,
        personalization: null
    };

    const steps = [
        {
            id: 'aestra-online',
            route: 'dashboard',
            title: 'AESTRA Online',
            message: 'Welcome, operative. I am AESTRA — your study command assistant. My chat module is locked for this demo build, but I can still brief you on how Smart Padhai works.'
        },
        {
            id: 'smart-padhai-system',
            route: 'dashboard',
            title: 'Not Just a Study Tracker',
            message: 'Smart Padhai connects syllabus, backlog, homework, notebooks, notes, missions, timetable, calendar, exam planning, and discipline into one command system.',
            targetSelector: '.dashboard-wrapper, [data-tour="dashboard-controls"], .hero-section, .hero-dashboard'
        },
        {
            id: 'dashboard-command-center',
            route: 'dashboard',
            title: 'Dashboard Command Center',
            message: 'This is your main control room. It summarizes your academic reality: progress, PP, rank, consistency, directives, panic state, and next actions.',
            targetSelector: '.dashboard-wrapper, .dash-stats-section, .hero-section, .hero-dashboard'
        },
        {
            id: 'hero-identity',
            route: 'dashboard',
            title: 'Your Study Identity',
            message: 'Your hero section shows your nickname, operative type, rank, PP progress, and command identity. This makes the dashboard personal to you.',
            targetSelector: '.dashboard-hero, .hero-section, .hero-card, .rank-container, #heroName, #commander-rank'
        },
        {
            id: 'pulse-points',
            route: 'dashboard',
            title: 'Pulse Points',
            message: 'PP is earned through real academic execution. It is not for random clicking. It helps measure discipline and unlock rank progression.',
            targetSelector: '#pulse-square, #scoreCircle, .pulse-score-card, .pp-trend-card, [data-section-id="weeklyPPGoal"]'
        },
        {
            id: 'rank-journey',
            route: 'dashboard',
            title: 'Rank Journey',
            message: 'Ranks show your discipline level. The path is Initiate, Operator, War Machine, Commander, and Architect.',
            targetSelector: '#rank-icon, #commander-rank, .rank-badge, .rank-journey-btn, .rank-container'
        },
        {
            id: 'daily-directive',
            route: 'dashboard',
            title: 'Tactical Daily Directive',
            message: 'The Directive tells you what needs attention now. It is designed to reduce confusion and give you a clear next action.',
            targetSelector: '#dailyDirectiveCard, .dash-directive-section, .tdd-card'
        },
        {
            id: 'syllabus-tracker',
            route: '#/syllabus',
            title: 'Syllabus Tracker',
            message: 'The Syllabus page is the source of truth for your class chapters. When syllabus data is added, dashboard progress and exam planning become smarter.',
            targetSelector: '.syllabus-wrapper, .syllabus-page-header, #chapterList'
        },
        {
            id: 'syllabus-progress-logic',
            route: '#/syllabus',
            title: 'How Syllabus Data Helps',
            message: 'When you mark chapters as read, notes completed, revised, or practiced, Smart Padhai can calculate real progress instead of guessing.',
            targetSelector: '.chapter-card, #chapterList, .chapter-list-container, .syllabus-stats-grid'
        },
        {
            id: 'backlog-manager',
            route: '#/backlog',
            title: 'Backlog Manager',
            message: 'Backlog is pending academic work. This page helps you see what is incomplete and what should be cleared first.',
            targetSelector: '.backlog-wrapper, .backlog-master-container, .backlog-stats-container'
        },
        {
            id: 'backlog-priority',
            route: '#/backlog',
            title: 'Priority Ranking',
            message: 'Instead of a random list, backlog items are ranked so you can focus on what matters most.',
            targetSelector: '#autoRankSection, .auto-rank-section, .rank-panel-header, .priority-list, .backlog-list'
        },
        {
            id: 'notebook-system',
            route: '#/notebooks',
            title: 'Notebook Command Center',
            message: 'Notebook manages your C.W. Copy, H.W. Missions, Notes Vault, Sticky Board, and Notebook Mission Center.',
            targetSelector: '.notebook-container, .nb-command-center, .nb-copy-tabs'
        },
        {
            id: 'cw-hw',
            route: '#/notebooks',
            title: 'Classwork and Homework',
            message: 'C.W. Copy tracks your classwork notebooks. H.W. Missions tracks daily homework, due dates, pending tasks, and completion.',
            targetSelector: '.nb-copy-tabs, [data-tab="cw"], [data-tab="hw"], .nb-cw-panel, .nb-hw-panel'
        },
        {
            id: 'notes-vault-sticky',
            route: '#/notebooks',
            title: 'Notes Vault and Sticky Board',
            message: 'Notes Vault stores formulas, weak points, mistakes, and revision items. Sticky Board is for quick reminders and important warnings.',
            targetSelector: '.nb-notes-vault, .nb-sticky-board, [data-tab="notes"], [data-tab="sticky"], .nb-copy-tabs'
        },
        {
            id: 'notebook-missions',
            route: '#/notebooks',
            title: 'Notebook Missions',
            message: 'Notebook Missions collect C.W., H.W., notes, and reminders into executable tasks with estimated time and timer support.',
            targetSelector: '#nbMissionBoard, .nb-mission-board, .nb-mission-header, .nb-mission-preview-grid'
        },
        {
            id: 'panic-protocol',
            route: '#/dashboard',
            title: 'Panic Protocol',
            message: 'Panic Protocol helps when exams are near or workload is heavy. Set exam scope first so the system can plan around real chapters.',
            targetSelector: '#panicProtocolV2Card, .panic-v2-card, .panic-v2-header, [data-section-id="panicProtocol"]'
        },
        {
            id: 'planning-layer',
            route: '#/timetable',
            title: 'Planning Layer',
            message: 'Timetable helps you allocate time. Calendar tracks exams, deadlines, and important study dates. Together, they help you plan before pressure becomes panic.',
            targetSelector: '.timetable-wrapper, .mission-stats-container, .hero-dashboard, #sector-dawn, #morning-grid'
        },
        {
            id: 'plans-access',
            route: '#/plans',
            title: 'Plans and Access',
            message: 'All accounts currently start on Free. Starter, Pro, and Elite are preview plans for future updates.',
            targetSelector: '.plans-page, .plans-header, .plans-grid'
        },
        {
            id: 'aestra-ai-coming-soon',
            route: '#/aestra',
            title: 'AESTRA AI — Coming Soon',
            message: 'My full AI chat module is locked for stability in this build. In future, I will use your syllabus, backlog, notebook, and progress data to guide smarter decisions.',
            targetSelector: '.aestra-gate, .aestra-gate-content, .aestra-gate-badge, .aestra-gate-orb'
        },
        {
            id: 'first-three-actions',
            route: '#/dashboard',
            title: 'Your First 3 Actions',
            message: 'Start simple. Add your syllabus, create one C.W. or H.W. item, and complete one small task to earn PP. The system becomes useful when real data enters it.'
        },
        {
            id: 'briefing-complete',
            route: '#/dashboard',
            title: 'System Briefing Complete',
            message: 'You are ready. Do not try to master everything at once. Use one module, complete one task, and let Smart Padhai become your command system.',
            primaryAction: 'finish',
            secondaryAction: 'open-syllabus'
        }
    ];

    function storageGet(key) {
        try {
            if (window.SafeStorage && typeof window.SafeStorage.getItem === 'function') {
                const value = window.SafeStorage.getItem(key, null);
                if (value !== null && value !== undefined) return value;
            }
        } catch (err) { /* local fallback below */ }
        try { return localStorage.getItem(key); } catch (err) { return null; }
    }

    function storageSet(key, value) {
        try {
            if (window.SafeStorage && typeof window.SafeStorage.setItem === 'function') {
                window.SafeStorage.setItem(key, value);
                return;
            }
        } catch (err) { /* local fallback below */ }
        try { localStorage.setItem(key, String(value)); } catch (err) { /* no-op */ }
    }

    function isSeen() {
        const raw = storageGet(STORAGE_KEY);
        return raw === true || raw === 'true' || raw === '1';
    }

    function markSeen() {
        storageSet(STORAGE_KEY, true);
    }

    function parseStoredObject(key) {
        const raw = storageGet(key);
        if (!raw) return null;
        if (typeof raw === 'object') return raw;
        try { return JSON.parse(raw); } catch (err) { return null; }
    }

    function readProfile() {
        const candidates = [
            parseStoredObject('smart_padhai_profile'),
            parseStoredObject('smartPadhaiProfile'),
            parseStoredObject('user_profile'),
            parseStoredObject('smartPadhaiUser'),
            parseStoredObject('smartPadhaiData')
        ].filter(Boolean);

        const profile = Object.assign({}, ...candidates);
        const nested = profile.profile || profile.studentProfile || profile.user || {};
        const data = Object.assign({}, profile, nested);
        const emailPrefix = typeof data.email === 'string' ? data.email.split('@')[0] : '';
        const displayName = data.operativeName || data.nickname || data.name || data.fullName || data.displayName || emailPrefix || 'operative';
        const operativeLevel = data.operativeLevel || data.studentType || data.level || data.type || '';
        const classLevel = data.classLevel || data.class || data.grade || data.standard || '';
        const board = data.board || data.curriculum || '';

        return {
            displayName: String(displayName || 'operative').trim(),
            operativeLevel: String(operativeLevel || '').trim(),
            classLine: [classLevel, board].filter(Boolean).join(' ')
        };
    }

    function getPersonalGreeting() {
        state.personalization = state.personalization || readProfile();
        const profile = state.personalization;
        if (!profile || !profile.displayName || profile.displayName.toLowerCase() === 'operative') {
            return 'Welcome, operative.';
        }
        const classText = profile.classLine ? ` ${profile.classLine} detected.` : '';
        return `Welcome, ${escapeHtml(profile.displayName)}.${classText} Let me brief you on your command system.`;
    }

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>'"]/g, (char) => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
        }[char]));
    }

    function normalizeRoute(route) {
        if (!route) return null;
        let value = String(route).trim();
        if (value.startsWith('#')) value = value.slice(1);
        if (!value.startsWith('/')) value = '/' + value;
        if (value === '/upgrade') value = '/plans';
        return value;
    }

    function currentRoute() {
        if (window.SpaRouter && typeof window.SpaRouter.getCurrentRoute === 'function') {
            return window.SpaRouter.getCurrentRoute();
        }
        return normalizeRoute(window.location.hash.slice(1) || '/dashboard');
    }

    function wait(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    async function navigateIfNeeded(route) {
        const normalized = normalizeRoute(route);
        if (!normalized) return;
        if (currentRoute() === normalized) return;
        setLoading(true);
        try {
            if (window.SpaRouter && typeof window.SpaRouter.navigate === 'function') {
                await window.SpaRouter.navigate(normalized);
            } else {
                window.location.hash = '#' + normalized;
            }
        } catch (err) {
            console.warn('[AESTRA Tour] Route navigation failed:', err);
        } finally {
            await wait(ROUTE_WAIT_MS);
            setLoading(false);
        }
    }

    function buildShell() {
    removeShell();

    const overlay = document.createElement('div');
    overlay.className = 'aestra-tour-overlay';
    overlay.setAttribute('aria-hidden', 'true');
    overlay.innerHTML = `<div class="aestra-tour-scrim"></div>`;

    const panel = document.createElement('section');
    panel.className = 'aestra-tour-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'true');
    panel.setAttribute('aria-live', 'polite');
    panel.innerHTML = `
        <div class="aestra-tour-orb-wrap" aria-hidden="true">
            <div class="aestra-tour-orb"></div>
            <div class="aestra-tour-ring aestra-tour-ring-one"></div>
            <div class="aestra-tour-ring aestra-tour-ring-two"></div>
        </div>
        <div class="aestra-tour-kicker">AESTRA System Briefing</div>
        <div class="aestra-tour-step-count"></div>
        <h2 class="aestra-tour-title"></h2>
        <p class="aestra-tour-message"></p>
        <div class="aestra-tour-loading" hidden>${MODULE_LOADING_TEXT}</div>
        <div class="aestra-tour-actions"></div>
    `;

    document.body.appendChild(overlay);
    document.body.appendChild(panel);

    state.overlay = overlay;
    state.panel = panel;
    document.body.classList.add('aestra-tour-active');
}

   function removeShell() {
    clearHighlight();

    document.querySelectorAll('.aestra-tour-overlay').forEach(el => el.remove());
    document.querySelectorAll('.aestra-tour-panel').forEach(el => el.remove());

    state.overlay = null;
    state.panel = null;
    document.body.classList.remove('aestra-tour-active');
}

    function buildIntro() {
    if (state.introOpen || state.active || isSeen()) return;
    state.introOpen = true;
    removeShell();

    const overlay = document.createElement('div');
    overlay.className = 'aestra-tour-overlay aestra-tour-intro-overlay';
    overlay.setAttribute('aria-hidden', 'true');
    overlay.innerHTML = `<div class="aestra-tour-scrim"></div>`;

    const panel = document.createElement('section');
    panel.className = 'aestra-tour-panel aestra-tour-intro-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'true');
    panel.innerHTML = `
        <div class="aestra-tour-orb-wrap" aria-hidden="true">
            <div class="aestra-tour-orb"></div>
            <div class="aestra-tour-ring aestra-tour-ring-one"></div>
            <div class="aestra-tour-ring aestra-tour-ring-two"></div>
        </div>
        <div class="aestra-tour-kicker">First-Time Command Briefing</div>
        <h2 class="aestra-tour-title">AESTRA System Briefing</h2>
        <p class="aestra-tour-message">Welcome to Smart Padhai. I am AESTRA, your study command assistant. My full AI chat module is still being upgraded, but I can guide you through the entire command system.</p>
        <p class="aestra-tour-personal-line">${getPersonalGreeting()}</p>
        <div class="aestra-tour-actions">
            <button type="button" class="aestra-tour-btn aestra-tour-btn-ghost" data-aestra-intro="skip">Skip for Now</button>
            <button type="button" class="aestra-tour-btn aestra-tour-btn-primary" data-aestra-intro="start">Start Full Tour</button>
        </div>
    `;

    document.body.appendChild(overlay);
    document.body.appendChild(panel);

    state.overlay = overlay;
    state.panel = panel;
    document.body.classList.add('aestra-tour-active');

    panel.addEventListener('click', (event) => {
        const action = event.target?.closest('[data-aestra-intro]')?.dataset.aestraIntro;
        if (!action) return;

        if (action === 'skip') {
            markSeen();
            state.introOpen = false;
            removeShell();
        } else if (action === 'start') {
            state.introOpen = false;
            start({ force: true });
        }
    });
}
    function setLoading(isLoading) {
        state.loading = isLoading;
        if (!state.panel) return;
        const loadingEl = state.panel.querySelector('.aestra-tour-loading');
        if (loadingEl) loadingEl.hidden = !isLoading;
        state.panel.classList.toggle('aestra-tour-panel-loading', isLoading);
    }

    function findTarget(selector) {
        if (!selector) return null;
        try {
            const nodes = document.querySelectorAll(selector);
            return Array.from(nodes).find((node) => node && node.offsetParent !== null) || nodes[0] || null;
        } catch (err) {
            console.warn('[AESTRA Tour] Bad target selector:', selector, err);
            return null;
        }
    }

    function clearHighlight() {
        if (state.highlighted) {
            state.highlighted.classList.remove('aestra-tour-highlight');
            state.highlighted = null;
        }
    }

    function highlight(selector) {
        clearHighlight();
        const target = findTarget(selector);
        if (!target) return;
        target.classList.add('aestra-tour-highlight');
        state.highlighted = target;
        try { target.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' }); } catch (err) { /* no-op */ }
    }

    async function renderStep() {
        if (!state.active) return;
        const step = steps[state.index];
        if (!step) return finish();

        if (!state.overlay) buildShell();
        renderPanel(step);
        await navigateIfNeeded(step.route);
        if (!state.active) return;
        renderPanel(step);
        window.requestAnimationFrame(() => highlight(step.targetSelector));
    }

    function renderPanel(step) {
        if (!state.panel) return;
        const titleEl = state.panel.querySelector('.aestra-tour-title');
        const messageEl = state.panel.querySelector('.aestra-tour-message');
        const countEl = state.panel.querySelector('.aestra-tour-step-count');
        const actionsEl = state.panel.querySelector('.aestra-tour-actions');
        if (countEl) countEl.textContent = `Step ${state.index + 1} of ${steps.length}`;
        if (titleEl) titleEl.textContent = step.title;
        if (messageEl) {
            const prefix = state.index === 0 ? `${getPersonalGreeting()} ` : '';
            messageEl.innerHTML = `${prefix}${escapeHtml(step.message)}`;
        }
        if (actionsEl) actionsEl.innerHTML = getActionsHtml(step);
        bindActionButtons();
    }

    function getActionsHtml(step) {
        const isFirst = state.index === 0;
        const isLast = state.index === steps.length - 1;
        if (isLast) {
            return `
                <button type="button" class="aestra-tour-btn aestra-tour-btn-ghost" data-aestra-tour="open-notebook">Open Notebook</button>
                <button type="button" class="aestra-tour-btn aestra-tour-btn-ghost" data-aestra-tour="open-syllabus">Open Syllabus</button>
                <button type="button" class="aestra-tour-btn aestra-tour-btn-primary" data-aestra-tour="finish">Finish</button>
            `;
        }
        return `
            <button type="button" class="aestra-tour-btn aestra-tour-btn-ghost" data-aestra-tour="skip">Skip</button>
            <button type="button" class="aestra-tour-btn aestra-tour-btn-muted" data-aestra-tour="back" ${isFirst ? 'disabled' : ''}>Back</button>
            <button type="button" class="aestra-tour-btn aestra-tour-btn-primary" data-aestra-tour="next">Next</button>
        `;
    }

    function bindActionButtons() {
        if (!state.panel) return;
        state.panel.querySelectorAll('[data-aestra-tour]').forEach((button) => {
            button.onclick = () => handleAction(button.dataset.aestraTour);
        });
    }

    function handleAction(action) {
        if (state.loading) return;
        if (action === 'next') return next();
        if (action === 'back') return back();
        if (action === 'skip') return skip();
        if (action === 'finish') return finish();
        if (action === 'open-syllabus') return finishAndOpen('/syllabus');
        if (action === 'open-notebook') return finishAndOpen('/notebooks');
    }

    function next() {
        if (state.index >= steps.length - 1) return finish();
        state.index += 1;
        renderStep();
    }

    function back() {
        if (state.index <= 0) return;
        state.index -= 1;
        renderStep();
    }

    function skip() {
        markSeen();
        state.active = false;
        removeShell();
    }

    function finish() {
        markSeen();
        state.active = false;
        removeShell();
    }

    async function finishAndOpen(route) {
        markSeen();
        state.active = false;
        removeShell();
        try {
            if (window.SpaRouter && typeof window.SpaRouter.navigate === 'function') {
                await window.SpaRouter.navigate(route);
            } else {
                window.location.hash = '#' + route;
            }
        } catch (err) {
            console.warn('[AESTRA Tour] Finish route failed:', err);
        }
    }

    function start(options = {}) {
        if (state.active && !options.force) return;
        state.introOpen = false;
        state.active = true;
        state.index = 0;
        state.personalization = readProfile();
        buildShell();
        renderStep();
    }

    function maybeShowIntro() {
        if (state.active || state.introOpen || isSeen()) return;
        const route = normalizeRoute(window.location.hash.slice(1) || '/dashboard');
        if (route !== '/dashboard') return;
        window.setTimeout(() => {
            if (!state.active && !state.introOpen && !isSeen()) buildIntro();
        }, 350);
    }

    window.SmartPadhaiAestraTour = {
        start,
        maybeShowIntro,
        isActive: () => state.active,
        getSteps: () => steps.slice()
    };
})();
