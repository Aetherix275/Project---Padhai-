/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — NOTEBOOKS ROUTE MODULE (Phase 6E + 7H-1..7H-5)
 *  Full SPA conversion of Notebook Matrix
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear state
 *
 *  Data: SafeStorage-first, Supabase mirror second
 *  Events: All via event delegation + AbortController. Zero inline onclick.
 *
 *  Phase 7H-1: Data Bridge + Audit
 *    - Added nb_notes_v1 storage key alongside existing notebook_matrix_data
 *    - Added _notes state, note ID generation, health score calculation
 *    - Health score: deterministic local formula (0-100), no AI/API calls
 *    - Backward compatible: notebook_matrix_data structure is NEVER changed
 *    - Dashboard/Backlog/AESTRA continue to read notebook_matrix_data as-is
 *
 *  Phase 7H-2: Hero Metrics + Health Meter
 *    - Upgraded page identity: NOTEBOOK INTELLIGENCE
 *    - Hero metrics strip: Total Subjects, Verified Rate, Pending, Avg Health
 *    - Full-width health meter with tier label
 *    - Metrics auto-update on every data mutation
 *
 *  Phase 7H-3: Matrix Table Upgrade
 *    - Added Health column per row (notes-based or matrix fallback)
 *    - Added Revision column per row (notes-based or matrix fallback)
 *    - Premium row styling: health-based left accent, type pills, improved toggles
 *    - All existing data-actions preserved exactly
 *
 *  Phase 7H-4: Note Entry CRUD
 *    - Deploy New Note button in hero area
 *    - Note modal with full field set (Title, Subject, Chapter, Content, Summary, Tags, Revision, Gold)
 *    - Create/Edit/Delete operations on nb_notes_v1.entries
 *    - Notes list section below matrix with intelligence cards
 *    - Full metrics sync after every CRUD operation
 *    - New data-actions: deploy-note, save-note, edit-note, delete-note, close-note-modal
 *
 *  Phase 7H-5: Notebook Intelligence Sections
 *    - Subject Overview: per-subject health cards with linked notes, verified/incident status
 *    - Revision Pending: overdue/pending note cards sorted by urgency + weakest health
 *    - Weak Notes: healthScore < 40 with missing-reason diagnostics
 *    - Recent Notes: upgraded to show latest 5 with health tier dot, subject/chapter, edit action
 *    - Quick Actions: Mark Reviewed, Mark Pending, Mark Overdue, Strengthen/Edit
 *    - Missing Reasons diagnostic for weak notes
 *    - Clean empty states for all sections
 *    - New data-actions: mark-note-reviewed, mark-note-pending, mark-note-overdue, strengthen-note
 *    - All existing data-actions and identifiers preserved exactly
 * ═══════════════════════════════════════════════════════════════════
 */

const NotebooksRoute = (() => {

    // ── Private state ──
    let _container = null;
    let _abortController = null;
    let _rows = [];
    let _notes = null; // Phase 7H-1: nb_notes_v1 data object { version, entries }
    let _editingNoteId = null; // Phase 7H-4: null = creating new, 'nbe_xxx' = editing existing
    let _editingHomeworkIndex = null;
    let _editingCwCopyIndex = null;
    let _editingCwChapterContext = null;
    let _expandedCWCardId = null;
    let _homeworkIntakeDraft = [];
    let _cssLinkEl = null;
    let _activeCopyTab = 'cw'; // 'cw' | 'hw'

    const STORAGE_KEY = 'notebook_matrix_data'; // Phase 6E: existing matrix — NEVER restructure
    const CW_STORAGE_KEY = 'smart_padhai_cw_notebooks';
    const HW_STORAGE_KEY = 'smart_padhai_hw_tasks';
    const HOMEWORK_INTAKE_KEY = 'smart_padhai_homework_intake_log';
    const NOTES_STORAGE_KEY = 'nb_notes_v1';    // Phase 7H-1: new notes entries — additive only
    const CW_EXPANDED_KEY = 'smart_padhai_cw_expanded_cards';
    const CSS_PATH = './styles/modules/notebooks.css';

    // ── Phase 8D-5A: SyncManager Naming Compatibility Helpers ──
    // Resolves window.SPSyncManager (actual app sync manager)
    // Falls back to window.SyncManager (legacy), then null.
    // NEVER touches Aestra Ai/syncManager.js
    function _getSyncManager() {
        return window.SPSyncManager || window.SyncManager || null;
    }

    // ── Canonical User ID Helper ── (Phase 8D-5A)
    // Priority: SyncManager → AppState → SafeStorage fallback
    function _getUserId() {
        const sync = _getSyncManager();
        return sync?.getUserId?.()
            || window.AppState?.currentUser?.id
            || SafeStorage.getItem('_current_user_id', null)
            || null;
    }

    function _getLocalDateKey(date = new Date()) {
        const d = date instanceof Date ? date : new Date(date);
        if (isNaN(d.getTime())) return '';
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const dd = String(d.getDate()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
    }

    function _getHomeworkIntakeLog() {
        const log = SafeStorage.getItem(HOMEWORK_INTAKE_KEY, []);
        return Array.isArray(log) ? log : [];
    }

    function _hasCompletedTodayHomeworkIntake() {
        const todayKey = _getLocalDateKey();
        return _getHomeworkIntakeLog().some(item => item?.date === todayKey && item.completed === true);
    }

    function _saveTodayHomeworkIntake({ skipped = false, taskIds = [] } = {}) {
        const todayKey = _getLocalDateKey();
        const log = _getHomeworkIntakeLog().filter(item => item?.date !== todayKey);
        log.push({ date: todayKey, completed: true, skipped: !!skipped, taskIds });
        SafeStorage.setItem(HOMEWORK_INTAKE_KEY, log);
    }


    // ── Syllabus Catalog Builder (for Import from Syllabus modal) ──
    // Reads smartPadhaiData and builds a structured catalog:
    //   { subjects: { SubjectName: { BookName: [chapterName, ...] } } }
    // Also filters by user profile (classLevel, board, academicYear) when available.
    // This is the foundation for the subject/book/chapter selector UI.
    function _buildSyllabusCatalog() {
        const masterData = SafeStorage.getItem('smartPadhaiData', {});
        if (!masterData || typeof masterData !== 'object') return { subjects: {} };

        // Read user profile for filtering
        const profile = _getAcademicProfileSafe();

        const catalog = { subjects: {} };
        for (const [chapterName, entry] of Object.entries(masterData)) {
            if (!entry || typeof entry !== 'object') continue;
            if (entry.isSyllabus !== true) continue;

            // Filter by user profile if metadata is present
            if (entry.classLevel && profile.classLevel && Number(entry.classLevel) !== Number(profile.classLevel)) continue;
            if (entry.board && profile.board && String(entry.board).toUpperCase() !== String(profile.board).toUpperCase()) continue;
            if (entry.academicYear && profile.academicYear && String(entry.academicYear) !== String(profile.academicYear)) continue;

            const subject = String(entry.subject || 'Unknown').trim();
            const book = String(entry.book || 'General').trim();
            const chapter = String(chapterName).trim();
            if (!chapter) continue;

            if (!catalog.subjects[subject]) catalog.subjects[subject] = {};
            if (!catalog.subjects[subject][book]) catalog.subjects[subject][book] = [];
            catalog.subjects[subject][book].push(chapter);
        }

        // Sort chapters alphabetically within each book
        for (const subj in catalog.subjects) {
            for (const book in catalog.subjects[subj]) {
                catalog.subjects[subj][book].sort((a, b) => a.localeCompare(b));
            }
        }

        return catalog;
    }

    // ── Academic Profile Helper (mirrors SyllabusRoute._getAcademicProfileSafe) ──
    function _getAcademicProfileSafe() {
        try {
            const rawProfile = (typeof window !== 'undefined' && window.SMART_PADHAI_PROFILE)
                ? window.SMART_PADHAI_PROFILE
                : (typeof SafeStorage !== 'undefined' && SafeStorage?.getItem
                    ? SafeStorage.getItem('smart_padhai_user_profile', null)
                    : null);
            const profile = rawProfile && typeof rawProfile === 'object' ? rawProfile : {};
            const classLevel = parseInt(String(profile.classLevel || profile.class || profile.grade || profile.standard || '').replace(/[^0-9]/g, ''), 10);
            const board = String(profile.board || 'CBSE').trim().toUpperCase() || 'CBSE';
            const academicYear = String(profile.academicYear || profile.academic_year || '2026-27').trim() || '2026-27';
            return {
                classLevel: Number.isFinite(classLevel) && classLevel > 0 ? classLevel : null,
                board,
                academicYear
            };
        } catch (err) {
            return { classLevel: null, board: 'CBSE', academicYear: '2026-27' };
        }
    }

    // ── Guess initial subject/book from notebook name ──
    // Returns { subject, book } or { subject: null, book: null }
    // This is ONLY a hint for the dropdown default — it does NOT control results.
    function _guessSyllabusSubjectForNotebook(notebookName, catalog) {
        if (!notebookName || !catalog || !catalog.subjects) return { subject: null, book: null };
        const nameLower = String(notebookName).trim().toLowerCase();
        if (!nameLower) return { subject: null, book: null };

        // 1. Exact match against catalog subject names (case-insensitive)
        for (const subj of Object.keys(catalog.subjects)) {
            if (subj.toLowerCase() === nameLower) {
                return { subject: subj, book: null };
            }
        }

        // 2. Exact match against book names within any subject
        for (const [subj, books] of Object.entries(catalog.subjects)) {
            for (const book of Object.keys(books)) {
                if (book.toLowerCase() === nameLower) {
                    return { subject: subj, book: book };
                }
            }
        }

        // 3. Partial match: notebook name appears inside a subject or book name
        for (const subj of Object.keys(catalog.subjects)) {
            if (subj.toLowerCase().includes(nameLower) || nameLower.includes(subj.toLowerCase())) {
                return { subject: subj, book: null };
            }
        }
        for (const [subj, books] of Object.entries(catalog.subjects)) {
            for (const book of Object.keys(books)) {
                if (book.toLowerCase().includes(nameLower) || nameLower.includes(book.toLowerCase())) {
                    return { subject: subj, book: book };
                }
            }
        }

        // 4. Alias map for common abbreviations
        const aliasMap = {
            'chem': 'Science', 'chemistry': 'Science',
            'phys': 'Science', 'physics': 'Science',
            'bio': 'Science', 'biology': 'Science',
            'math': 'Maths', 'maths': 'Maths', 'mathematics': 'Maths',
            'sst': 'SocialScience', 'social': 'SocialScience', 'social science': 'SocialScience',
            'socialscience': 'SocialScience',
            'history': 'SocialScience', 'geography': 'SocialScience',
            'civics': 'SocialScience', 'economics': 'SocialScience',
            'pol sc': 'SocialScience', 'political science': 'SocialScience',
            'eng': 'English', 'english': 'English',
            'hin': 'Hindi', 'hindi': 'Hindi',
            'cs': 'ComputerApplications', 'computer': 'ComputerApplications',
            'comp': 'ComputerApplications', 'computer applications': 'ComputerApplications'
        };
        const mappedSubject = aliasMap[nameLower];
        if (mappedSubject && catalog.subjects[mappedSubject]) {
            // Also try to match book within the mapped subject
            for (const book of Object.keys(catalog.subjects[mappedSubject])) {
                if (book.toLowerCase() === nameLower || nameLower.includes(book.toLowerCase())) {
                    return { subject: mappedSubject, book: book };
                }
            }
            return { subject: mappedSubject, book: null };
        }

        return { subject: null, book: null };
    }

    function _loadExpandedCwCards() {
        try {
            const saved = SafeStorage.getItem(CW_EXPANDED_KEY, null);
            _expandedCWCardId = Array.isArray(saved) ? (saved[0] || null) : (saved ? String(saved) : null);
        } catch (err) {
            _expandedCWCardId = null;
        }
    }

    function _saveExpandedCwCards() {
        try {
            SafeStorage.setItem(CW_EXPANDED_KEY, _expandedCWCardId || null);
        } catch (err) {
            console.warn('[NotebooksRoute] C.W. expanded state save failed:', err);
        }
    }

    function _isHomeworkRow(row) {
        return String(row?.copyType || row?.type || '').toUpperCase() === 'HW'
            || String(row?.type || '').toUpperCase() === 'HOMEWORK';
    }

    function _isClassworkRow(row) {
        return !_isHomeworkRow(row);
    }

    function _getCopyRows(tab = _activeCopyTab) {
        const wantsHw = tab === 'hw';
        return _rows
            .map((row, index) => ({ row, index }))
            .filter(item => wantsHw ? _isHomeworkRow(item.row) : _isClassworkRow(item.row));
    }

    function _normalizeCwChapter(chapter = {}, fallbackOrder = 1) {
        const now = new Date().toISOString();
        const rawStatus = String(chapter.status || 'not_started').toLowerCase();
        const allowedStatus = ['complete', 'incomplete', 'current', 'not_started'].includes(rawStatus) ? rawStatus : 'not_started';
        const pendingPages = Math.max(0, Math.round(Number(chapter.pendingPages || chapter.pagesToComplete || chapter.delta || 0)));
        const normalizedStatus = allowedStatus === 'complete' ? 'complete' : allowedStatus;
        return {
            ...chapter,
            id: chapter.id || `cw_ch_${Date.now()}_${Math.random().toString(16).slice(2)}`,
            order: Number.isFinite(Number(chapter.order)) ? Number(chapter.order) : fallbackOrder,
            chapterName: String(chapter.chapterName || chapter.chapter || chapter.name || '').trim(),
            status: normalizedStatus,
            pendingPages: normalizedStatus === 'complete' ? 0 : pendingPages,
            estimatedMinutes: chapter.estimatedMinutes === null || chapter.estimatedMinutes === undefined ? null : Number(chapter.estimatedMinutes || 0),
            teacherChecked: chapter.teacherChecked === true,
            deadline: chapter.deadline || null,
            linkedBacklog: chapter.linkedBacklog === true,
            backlogEntryName: chapter.backlogEntryName || '',
            updatedAt: chapter.updatedAt || now
        };
    }

    function _getCwChapters(row = {}) {
        if (!Array.isArray(row.chapters)) return [];
        return row.chapters
            .map((chapter, idx) => _normalizeCwChapter(chapter, idx + 1))
            .filter(chapter => chapter.chapterName || chapter.status !== 'not_started' || Number(chapter.pendingPages || 0) > 0)
            .sort((a, b) => Number(a.order || 0) - Number(b.order || 0));
    }

    function _normalizeNotebookRow(row = {}) {
        const isHw = _isHomeworkRow(row);
        return {
            ...row,
            id: row.id || Date.now(),
            type: isHw ? 'HOMEWORK' : (row.type || 'CLASSWORK'),
            copyType: isHw ? 'HW' : 'CW',
            done: !!row.done,
            incident: !!row.incident,
            delta: Number(row.delta || row.pendingPages || 0),
            chapter: row.chapter || '',
            taskTitle: row.taskTitle || row.title || '',
            dueDate: row.dueDate || '',
            status: row.status || (row.done ? 'done' : 'pending'),
            hwType: row.hwType || row.homeworkType || (isHw ? 'homework' : ''),
            priority: row.priority || 'medium',
            deadline: row.deadline || null,
            deadlineType: row.deadlineType || null,
            estimatedMinutes: row.estimatedMinutes === null || row.estimatedMinutes === undefined ? null : Number(row.estimatedMinutes || 0),
            sentToBacklog: row.sentToBacklog === true,
            backlogEntryName: row.backlogEntryName || '',
            chapters: Array.isArray(row.chapters) ? row.chapters.map((chapter, idx) => _normalizeCwChapter(chapter, idx + 1)) : [],
            dateAssigned: row.dateAssigned || row.createdAt?.slice?.(0, 10) || _getLocalDateKey(),
            addedToMission: row.addedToMission === true,
            createdAt: row.createdAt || new Date().toISOString(),
            updatedAt: row.updatedAt || new Date().toISOString(),
            teacherChecked: row.teacherChecked === true || row.verified === true || row.done === true
        };
    }

    function _hydrateNotebookRowsFromStorage() {
        const legacyRows = SafeStorage.getItem(STORAGE_KEY, [
            { id: 1, subject: 'Physics', type: 'CLASSWORK', copyType: 'CW', done: false, incident: false, delta: 0 }
        ]);
        const rowMap = new Map();

        if (Array.isArray(legacyRows)) {
            legacyRows.forEach(row => {
                const normalized = _normalizeNotebookRow(row);
                rowMap.set(String(normalized.id), normalized);
            });
        }

        const savedCw = SafeStorage.getItem(CW_STORAGE_KEY, []);
        const savedHw = SafeStorage.getItem(HW_STORAGE_KEY, []);
        if (Array.isArray(savedCw)) {
            savedCw.forEach(row => {
                const normalized = _normalizeNotebookRow({ ...row, type: row.type || 'CLASSWORK', copyType: 'CW' });
                rowMap.set(String(normalized.id), { ...(rowMap.get(String(normalized.id)) || {}), ...normalized });
            });
        }
        if (Array.isArray(savedHw)) {
            savedHw.forEach(row => {
                const normalized = _normalizeNotebookRow({ ...row, type: 'HOMEWORK', copyType: 'HW' });
                rowMap.set(String(normalized.id), { ...(rowMap.get(String(normalized.id)) || {}), ...normalized });
            });
        }

        return Array.from(rowMap.values());
    }

    function _saveSplitNotebookData() {
        try {
            SafeStorage.setItem(CW_STORAGE_KEY, _rows.filter(_isClassworkRow));
            SafeStorage.setItem(HW_STORAGE_KEY, _rows.filter(_isHomeworkRow));
        } catch (err) {
            console.warn('[NotebooksRoute] Split notebook save failed:', err);
        }
    }

    function _isPastDue(dateValue) {
        if (!dateValue) return false;
        const due = new Date(dateValue);
        if (isNaN(due.getTime())) return false;
        due.setHours(0, 0, 0, 0);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return due < today;
    }


    function _syncHomeworkStatuses({ persist = false } = {}) {
        let changed = false;
        _rows.forEach(row => {
            if (!_isHomeworkRow(row)) return;
            const status = _getHomeworkStatus(row);
            if (status === 'overdue' && row.status !== 'overdue') {
                row.status = 'overdue';
                row.done = false;
                row.updatedAt = new Date().toISOString();
                changed = true;
            }
        });
        if (changed && persist) _save();
        return changed;
    }

    function _isDueTomorrow(dateValue) {
        if (!dateValue) return false;
        const d = new Date(dateValue);
        if (isNaN(d.getTime())) return false;
        d.setHours(0, 0, 0, 0);
        const tomorrow = new Date();
        tomorrow.setHours(0, 0, 0, 0);
        tomorrow.setDate(tomorrow.getDate() + 1);
        return d.getTime() === tomorrow.getTime();
    }

    function _formatHomeworkDueText(dueDate) {
        if (!dueDate) return 'No deadline';
        if (_isPastDue(dueDate)) return `Overdue · ${dueDate}`;
        const todayKey = _getLocalDateKey();
        if (dueDate === todayKey) return 'Due today';
        if (_isDueTomorrow(dueDate)) return 'Due tomorrow';
        return `Due ${dueDate}`;
    }

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════

    async function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;

        // Load CSS
        _loadCSS();

        // Load data from SafeStorage
        _rows = _hydrateNotebookRowsFromStorage();
        _loadExpandedCwCards();

        // Try loading from cloud via SyncManager (best-effort merge)
        await _loadFromCloud();

        // Phase 7H-1: Load notes data (additive, separate from matrix)
        _notes = _loadNotesData();
        await _loadNotesFromCloud();

        // Phase 7H-1: Recalculate health scores on every load (catches stale scores)
        const healthChanged = _recalcAllHealthScores();
        if (healthChanged) {
            _saveNotesData(_notes);
        }

        _syncHomeworkStatuses({ persist: true });
        _syncOverdueHomeworkBacklogs();

        // Render
        container.innerHTML = renderFullUI();
        _render();

        // Phase 7H-2: Update metrics + health meter after initial render
        _updateNotebookMetricsUI();

        // Phase 7H-5: Render all intelligence sections
        _renderIntelligenceSections();

        // Bind events
        _bindEvents(container, _abortController.signal);

        if (!_hasCompletedTodayHomeworkIntake()) {
            setTimeout(() => _openDailyHomeworkIntakeModal(), 120);
        }

        console.log('[NotebooksRoute] Initialized');
    }

    function cleanup() {
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }
        // Remove any open popups
        document.querySelectorAll('.cloud-popup').forEach(p => p.remove());
        _unloadCSS();
        _container = null;
        _rows = [];
        _notes = null; // Phase 7H-1: clear notes state
        _editingNoteId = null; // Phase 7H-4: clear edit state
        console.log('[NotebooksRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.notebooksCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-notebooks-css]');
        if (el) { el.remove(); _cssLinkEl = null; }
    }

    // ════════════════════════════════════════════════════════
    //  SYNC MANAGER SYNC (Phase 8D-5A)
    //  Uses _getSyncManager() to resolve window.SPSyncManager.
    //  Falls back to direct Supabase if SyncManager unavailable.
    //  Row mapping and conflict keys unchanged.
    // ════════════════════════════════════════════════════════

    /**
     * Load notebook data from cloud via SyncManager.
     * Falls back to direct Supabase query if SyncManager unavailable.
     * Conservative merge: cloud-only rows added, local rows never overwritten.
     */
    async function _loadFromCloud() {
        // ── Try SyncManager first (Phase 8D-5A: via _getSyncManager) ──
        const sync = _getSyncManager();
        if (sync && typeof sync.loadFromCloud === 'function') {
            try {
                const rows = await sync.loadFromCloud('notebooks', {
                    columns: '*',
                    statusKey: 'notebooks'
                });
                if (rows && rows.length > 0) {
                    _mergeCloudRows(rows);
                    return;
                }
                return; // No rows — nothing to merge
            } catch (err) {
                console.warn('[NotebooksRoute] SyncManager load failed, trying fallback:', err);
            }
        }

        // ── Fallback: direct Supabase query (legacy path) ──
        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) {
            console.warn('[NotebooksRoute] Supabase load skipped — no userId available');
            return;
        }

        try {
            const { data, error } = await window.supabaseClient
                .from('notebooks')
                .select('*')
                .eq('user_id', userId);

            if (error || !data || data.length === 0) return;

            _mergeCloudRows(data);
        } catch (err) {
            console.warn('[NotebooksRoute] Fallback Supabase load failed:', err);
        }
    }

    /**
     * Merge cloud rows into local notebook_matrix_data.
     * Conservative: cloud-only rows added, existing local rows never overwritten.
     * @param {array} rows - Rows from notebooks table
     */
    function _mergeCloudRows(rows) {
        const local = SafeStorage.getItem(STORAGE_KEY, []);
        let merged = false;

        rows.forEach(row => {
            const raw = (row.raw_data && typeof row.raw_data === 'object') ? row.raw_data : {};
            const rawId = raw.id;
            const sourceId = row.source_key ? String(row.source_key).replace(/^nb_/, '') : rawId;
            const id = Number(sourceId);
            if (!id) return;

            const existing = local.find(r => Number(r.id) === id);
            if (!existing) {
                local.push({
                    id,
                    subject: row.subject || raw.subject || '',
                    type: row.notebook_type || raw.type || 'CLASSWORK',
                    done: row.completed === true || raw.done === true,
                    incident: raw.incident === true,
                    delta: Number(row.delta_pages ?? raw.delta ?? 0),
                    copyType: raw.copyType || (String(row.notebook_type || raw.type || '').toUpperCase() === 'HOMEWORK' ? 'HW' : 'CW'),
                    chapter: raw.chapter || '',
                    taskTitle: raw.taskTitle || '',
                    dueDate: raw.dueDate || '',
                    status: raw.status || (row.completed === true || raw.done === true ? 'done' : 'pending'),
                    hwType: raw.hwType || '',
                    priority: raw.priority || 'medium',
                    deadline: raw.deadline || null,
                    deadlineType: raw.deadlineType || null,
                    estimatedMinutes: raw.estimatedMinutes === null || raw.estimatedMinutes === undefined ? null : Number(raw.estimatedMinutes || 0),
                    sentToBacklog: raw.sentToBacklog === true,
                    backlogEntryName: raw.backlogEntryName || '',
                    chapters: Array.isArray(raw.chapters) ? raw.chapters.map((chapter, idx) => _normalizeCwChapter(chapter, idx + 1)) : [],
                    dateAssigned: raw.dateAssigned || '',
                    addedToMission: raw.addedToMission === true,
                    createdAt: raw.createdAt || '',
                    updatedAt: raw.updatedAt || '',
                    teacherChecked: raw.teacherChecked === true || row.completed === true || raw.done === true
                });
                merged = true;
            }
        });

        if (merged) {
            SafeStorage.setItem(STORAGE_KEY, local);
            _rows = local;
            console.log(`[NotebooksRoute] Merged ${rows.length} cloud rows. Local rows: ${local.length}`);
        }
    }

    /**
     * Build a row for the notebooks table from a local notebook entry.
     * Row mapping unchanged from previous implementation.
     * SyncManager injects user_id automatically on enqueue.
     * @param {object} row - Local notebook row from _rows
     * @returns {object} Row object for Supabase upsert
     */
    function _buildNotebookRow(row) {
        if (!row || typeof row !== 'object') return null;

        const deltaPages = Number(row.delta || 0);
        const notebookType = row.type || 'CLASSWORK';
        const subject = row.subject || '';

        return {
            source_key: `nb_${row.id}`,
            subject: subject,
            notebook_type: notebookType,
            title: subject,
            completed: !!row.done,
            delta_pages: deltaPages,
            raw_data: {
                id: row.id,
                subject: subject,
                type: notebookType,
                done: !!row.done,
                incident: !!row.incident,
                delta: deltaPages,
                copyType: row.copyType || (_isHomeworkRow(row) ? 'HW' : 'CW'),
                chapter: row.chapter || '',
                taskTitle: row.taskTitle || '',
                dueDate: row.dueDate || '',
                status: row.status || (row.done ? 'done' : 'pending'),
                hwType: row.hwType || '',
                priority: row.priority || 'medium',
                deadline: row.deadline || null,
                deadlineType: row.deadlineType || null,
                estimatedMinutes: row.estimatedMinutes === null || row.estimatedMinutes === undefined ? null : Number(row.estimatedMinutes || 0),
                sentToBacklog: row.sentToBacklog === true,
                backlogEntryName: row.backlogEntryName || '',
                chapters: Array.isArray(row.chapters) ? row.chapters.map((chapter, idx) => _normalizeCwChapter(chapter, idx + 1)) : [],
                dateAssigned: row.dateAssigned || '',
                addedToMission: row.addedToMission === true,
                createdAt: row.createdAt || '',
                updatedAt: row.updatedAt || '',
                teacherChecked: row.teacherChecked === true || row.done === true,
                linkedSyllabusSubject: row.linkedSyllabusSubject || null,
                linkedSyllabusGroup: row.linkedSyllabusGroup || null
            },
            last_updated: new Date().toISOString(),
            user_key: _getUserId() || ''
        };
    }

    /**
     * Enqueue all notebook rows for upsert via SyncManager.
     * Falls back to direct Supabase upsert if SyncManager unavailable/rejected.
     * Row mapping and conflict keys unchanged.
     */
    function _enqueueAllRowsUpsert() {
        const sync = _getSyncManager();

        if (sync && typeof sync.enqueue === 'function') {
            for (const row of _rows) {
                const supabaseRow = _buildNotebookRow(row);
                if (!supabaseRow) continue;
                sync.enqueue('notebooks', supabaseRow, {
                    conflictKey: 'user_id,source_key',
                    statusKey: 'notebooks'
                });
            }
            console.log('[NotebooksRoute] Enqueued rows via SyncManager');
            return;
        }

        // Fallback: direct Supabase upsert using ONLY real notebooks table columns.
        if (!window.supabaseClient) {
            console.warn('[NotebooksRoute] No SyncManager and no Supabase client — sync skipped');
            return;
        }

        const userId = _getUserId();
        if (!userId) {
            console.warn('[NotebooksRoute] Upsert skipped — no userId');
            return;
        }

        for (const row of _rows) {
            const supabaseRow = _buildNotebookRow(row);
            if (!supabaseRow) continue;

            window.supabaseClient
                .from('notebooks')
                .upsert({ ...supabaseRow, user_id: userId }, { onConflict: 'user_id,source_key' })
                .then(function (result) {
                    if (result.error) {
                        console.warn('[NotebooksRoute] Direct upsert failed:', result.error.message);
                    }
                })
                .catch(function (err) {
                    console.warn('[NotebooksRoute] Direct upsert error:', err);
                });
        }
        console.log('[NotebooksRoute] Direct upsert queued for', _rows.length, 'rows');
    }

    function _enqueueNotebookRowDelete(row) {
        if (!row || !row.id) return;
        const sourceKey = `nb_${row.id}`;
        const sync = _getSyncManager();
        if (sync && typeof sync.enqueue === 'function') {
            sync.enqueue('notebooks', {}, {
                operation: 'delete',
                deleteFilter: 'source_key',
                deleteValue: sourceKey,
                statusKey: 'notebooks'
            });
            return;
        }

        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) return;

        window.supabaseClient
            .from('notebooks')
            .delete()
            .eq('user_id', userId)
            .eq('source_key', sourceKey)
            .then(result => {
                if (result.error) console.warn('[NotebooksRoute] Notebook row delete skipped:', result.error.message);
            })
            .catch(err => console.warn('[NotebooksRoute] Notebook row delete unavailable:', err));
    }

    // ════════════════════════════════════════════════════════
    //  DATA OPERATIONS
    // ════════════════════════════════════════════════════════

    function _save() {
        SafeStorage.setItem(STORAGE_KEY, _rows);
        _saveSplitNotebookData();
        _enqueueAllRowsUpsert(); // Phase 8D-5A: via SyncManager
    }

    /**
     * _fullSync — single function to re-render matrix, metrics, and all sections
     * Called after any mutation that changes note data or matrix state
     */
    function _fullSync() {
        _render();
        _updateNotebookMetricsUI();
        _renderNotebookDirective();
        _renderIntelligenceSections();
    }

    function _dispatchNotebookUpdated(extra = {}) {
        try {
            window.dispatchEvent(new CustomEvent('smartPadhai:notebooksUpdated', {
                detail: {
                    rows: _rows.length,
                    notes: _notes?.entries?.length || 0,
                    ...extra
                }
            }));
            window.dispatchEvent(new CustomEvent('smartPadhai:dashboardDataUpdated', {
                detail: { source: 'notebooks', ...extra }
            }));
        } catch (err) {
            console.warn('[NotebooksRoute] Event dispatch failed:', err);
        }
    }

    function _dispatchBacklogUpdated(extra = {}) {
        try {
            window.dispatchEvent(new CustomEvent('smartPadhai:backlogUpdated', { detail: extra }));
        } catch (err) {
            console.warn('[NotebooksRoute] Backlog event dispatch failed:', err);
        }
    }

    function _completeLinkedNotebookBacklogs(row) {
        if (!row || !row.id) return false;

        try {
            const masterData = SafeStorage.getItem('smartPadhaiData', {});
            if (!masterData || typeof masterData !== 'object') return false;

            let changed = false;
            const completedAt = new Date().toISOString();
            Object.keys(masterData).forEach(chapterName => {
                const entry = masterData[chapterName];
                if (!entry || typeof entry !== 'object') return;
                if (entry.isNotebook === true && (Number(entry.notebookRowId) === Number(row.id) || Number(entry.homeworkTaskId) === Number(row.id) || chapterName === row.backlogEntryName)) {
                    masterData[chapterName] = {
                        ...entry,
                        read: true,
                        notes: true,
                        revised: true,
                        pyq: true,
                        completedAt,
                        lastUpdated: completedAt
                    };
                    changed = true;
                }
            });

            if (changed) {
                SafeStorage.setItem('smartPadhaiData', masterData);
                _dispatchBacklogUpdated({ source: 'notebook_done', notebookRowId: row.id });
            }
            return changed;
        } catch (err) {
            console.warn('[NotebooksRoute] Linked backlog completion failed:', err);
            return false;
        }
    }

    function _removeLinkedNotebookBacklogs(row) {
        if (!row || !row.id) return false;

        try {
            const masterData = SafeStorage.getItem('smartPadhaiData', {});
            if (!masterData || typeof masterData !== 'object') return false;

            let changed = false;
            Object.keys(masterData).forEach(chapterName => {
                const entry = masterData[chapterName];
                if (!entry || typeof entry !== 'object') return;
                if (entry.isNotebook === true && Number(entry.notebookRowId) === Number(row.id)) {
                    delete masterData[chapterName];
                    changed = true;
                }
            });

            if (changed) {
                SafeStorage.setItem('smartPadhaiData', masterData);
                _dispatchBacklogUpdated({ source: 'notebook_task_deleted', notebookRowId: row.id });
            }
            return changed;
        } catch (err) {
            console.warn('[NotebooksRoute] Linked backlog removal failed:', err);
            return false;
        }
    }

    function _syncHomeworkBacklog(row) {
        if (!row || !_isHomeworkRow(row) || row.sentToBacklog !== true) return false;
        try {
            let masterData = SafeStorage.getItem('smartPadhaiData', {});
            if (!masterData || typeof masterData !== 'object') masterData = {};
            const subject = row.subject || 'Homework';
            const title = row.taskTitle || row.chapter || 'Homework Task';
            const entryName = row.backlogEntryName || `HW: ${subject} - ${title}`;
            masterData[entryName] = {
                ...(masterData[entryName] && typeof masterData[entryName] === 'object' ? masterData[entryName] : {}),
                read: false,
                notes: true,
                revised: false,
                pyq: true,
                isNotebook: true,
                isHomework: true,
                isSyllabus: false,
                source: 'homework_task',
                subject,
                chapter: title,
                homeworkTaskId: row.id,
                notebookRowId: row.id,
                dueDate: row.dueDate || '',
                estimatedMinutes: Number(row.estimatedMinutes || 0),
                priority: row.priority || 'medium',
                lastUpdated: new Date().toISOString()
            };
            row.backlogEntryName = entryName;
            SafeStorage.setItem('smartPadhaiData', masterData);
            _dispatchBacklogUpdated({ source: 'homework_task', chapter: entryName, homeworkTaskId: row.id });
            return true;
        } catch (err) {
            console.warn('[NotebooksRoute] Homework backlog sync failed:', err);
            return false;
        }
    }

    function _syncOverdueHomeworkBacklogs() {
        const changed = _syncHomeworkStatuses();
        if (changed) {
            _save();
            _dispatchNotebookUpdated({ action: 'homework_overdue_sync' });
        }
    }

    // ════════════════════════════════════════════════════════
    //  CREATE C.W. NOTEBOOK MODAL (Phase 9N-CW)
    //  Premium custom modal replaces browser prompt.
    //  Fields: Notebook Name, Linked Syllabus Subject, Linked
    //  Syllabus Group/Book, Starting Mode, Teacher Checked,
    //  Deadline Default.
    // ════════════════════════════════════════════════════════

    // Syllabus subject options for the dropdown
    const _CW_SYLLABUS_SUBJECTS = [
        'Science', 'Maths', 'Social Science', 'English', 'Hindi', 'Computer Applications', 'Custom / None'
    ];

    // Groups (books) per subject for the secondary dropdown
    const _CW_SYLLABUS_GROUPS = {
        'Science': ['Physics', 'Chemistry', 'Biology'],
        'Social Science': ['History', 'Geography', 'Political Science', 'Economics'],
        'Maths': ['Number Systems', 'Algebra', 'Geometry', 'Coordinate Geometry', 'Mensuration', 'Statistics & Probability'],
        'English': [],
        'Hindi': [],
        'Computer Applications': []
    };

    function _openCwCreateModal() {
        const modal = _container?.querySelector('#nbCwCreateModal');
        if (!modal) return;

        // Reset all fields
        const setVal = (id, value) => {
            const el = _container.querySelector('#' + id);
            if (el) el.value = value ?? '';
        };
        setVal('nbCwCreateName', '');
        setVal('nbCwCreateSubject', '');
        setVal('nbCwCreateGroup', '');
        setVal('nbCwCreateDeadline', '');

        // Hide group dropdown initially
        const groupRow = _container.querySelector('#nbCwCreateGroupRow');
        if (groupRow) groupRow.style.display = 'none';

        // Populate subject dropdown dynamically from catalog
        const subjectSelect = _container.querySelector('#nbCwCreateSubject');
        if (subjectSelect) {
            const catalog = _buildSyllabusCatalog();
            const catalogSubjects = Object.keys(catalog.subjects || {});
            subjectSelect.innerHTML = '<option value="">Select subject...</option>' +
                _CW_SYLLABUS_SUBJECTS.filter(s => s !== 'Custom / None').map(s =>
                    `<option value="${s}">${s}</option>`
                ).join('') +
                (catalogSubjects.length > 0
                    ? catalogSubjects
                        .filter(s => !_CW_SYLLABUS_SUBJECTS.includes(s))
                        .map(s => `<option value="${s}">${s}</option>`)
                        .join('')
                    : '') +
                '<option value="Custom / None">Custom / None</option>';
        }

        // Starting Mode — default to "import_later"
        setVal('nbCwCreateStartMode', 'import_later');
        _container.querySelectorAll('#nbCwCreateStartModePills .nb-ch-seg-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.value === 'import_later');
        });

        // Teacher Checked toggle — default off
        setVal('nbCwCreateTeacherChecked', 'no');
        const teacherToggle = _container.querySelector('.nb-ch-toggle[data-action="toggle-cw-create-teacher"]');
        if (teacherToggle) teacherToggle.classList.remove('active');
        const teacherLabel = _container.querySelector('#nbCwCreateTeacherCheckedLabel');
        if (teacherLabel) teacherLabel.textContent = 'Not checked';

        // Clear validation error
        const nameError = _container.querySelector('#nbCwCreateNameError');
        if (nameError) nameError.style.display = 'none';

        modal.style.display = 'flex';
        setTimeout(() => _container?.querySelector('#nbCwCreateName')?.focus(), 80);
    }

    function _closeCwCreateModal() {
        const modal = _container?.querySelector('#nbCwCreateModal');
        if (modal) modal.style.display = 'none';
    }

    function _handleCwCreateSubjectChange() {
        const subjectSelect = _container?.querySelector('#nbCwCreateSubject');
        const groupSelect = _container?.querySelector('#nbCwCreateGroup');
        const groupRow = _container?.querySelector('#nbCwCreateGroupRow');
        if (!subjectSelect || !groupSelect || !groupRow) return;

        const subject = subjectSelect.value;
        const catalog = _buildSyllabusCatalog();

        // Get groups from static map and from catalog
        let groups = _CW_SYLLABUS_GROUPS[subject] || [];
        if (catalog.subjects[subject]) {
            const catalogBooks = Object.keys(catalog.subjects[subject]);
            catalogBooks.forEach(book => {
                if (!groups.includes(book)) groups.push(book);
            });
        }

        if (groups.length > 0 && subject !== 'Custom / None') {
            groupSelect.innerHTML = '<option value="">Select group/book...</option>' +
                groups.map(g => `<option value="${g}">${g}</option>`).join('');
            groupRow.style.display = '';
        } else {
            groupSelect.innerHTML = '';
            groupRow.style.display = 'none';
        }
    }

    function _handleCwCreateStartModeSelect(target) {
        if (!target.classList.contains('nb-ch-seg-btn')) return;
        const value = target.dataset.value;
        const hiddenInput = _container?.querySelector('#nbCwCreateStartMode');
        if (hiddenInput) hiddenInput.value = value;
        _container.querySelectorAll('#nbCwCreateStartModePills .nb-ch-seg-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.value === value);
        });
    }

    function _handleCwCreateTeacherToggle() {
        const hiddenInput = _container?.querySelector('#nbCwCreateTeacherChecked');
        const toggle = _container?.querySelector('.nb-ch-toggle[data-action="toggle-cw-create-teacher"]');
        const label = _container?.querySelector('#nbCwCreateTeacherCheckedLabel');
        if (!hiddenInput) return;
        const current = hiddenInput.value === 'yes';
        hiddenInput.value = current ? 'no' : 'yes';
        if (toggle) toggle.classList.toggle('active', !current);
        if (label) label.textContent = !current ? 'Verified' : 'Not checked';
    }

    function _handleCwCreateSave() {
        const getVal = (id) => (_container?.querySelector('#' + id)?.value || '').trim();

        const notebookName = getVal('nbCwCreateName');
        const linkedSubject = getVal('nbCwCreateSubject');
        const linkedGroup = getVal('nbCwCreateGroup');
        const startMode = getVal('nbCwCreateStartMode') || 'import_later';
        const teacherChecked = getVal('nbCwCreateTeacherChecked') === 'yes';
        const deadline = getVal('nbCwCreateDeadline') || null;

        // Validation
        const nameError = _container?.querySelector('#nbCwCreateNameError');
        if (!notebookName) {
            if (nameError) nameError.style.display = '';
            _container?.querySelector('#nbCwCreateName')?.focus();
            return;
        }
        if (nameError) nameError.style.display = 'none';

        // Create the new notebook row
        const newId = _rows.length > 0 ? Math.max(..._rows.map(r => Number(r.id) || 0)) + 1 : 1;
        const now = new Date().toISOString();
        const newRow = {
            id: newId,
            subject: notebookName,
            type: 'CLASSWORK',
            copyType: 'CW',
            done: false,
            incident: false,
            delta: 0,
            teacherChecked: teacherChecked,
            deadline: deadline,
            deadlineType: deadline ? 'set' : null,
            estimatedMinutes: 25,
            chapters: [],
            linkedSyllabusSubject: linkedSubject && linkedSubject !== 'Custom / None' ? linkedSubject : null,
            linkedSyllabusGroup: linkedGroup || null,
            createdAt: now,
            updatedAt: now
        };

        _rows.push(newRow);
        _save();
        _fullSync();
        _dispatchNotebookUpdated({ action: 'row_added', rowId: newId, copyType: 'cw' });

        _closeCwCreateModal();

        // After-create behavior based on starting mode
        const newIndex = _rows.findIndex(r => Number(r.id) === Number(newId));
        if (startMode === 'add_chapter' && newIndex >= 0) {
            // Auto-expand the new card and open custom chapter modal
            _expandedCWCardId = newId;
            _saveExpandedCwCards();
            _fullSync();
            setTimeout(() => _openCwChapterModal(newIndex, null), 150);
        } else if (startMode === 'import_later') {
            // Auto-expand the new card to show "Index not created yet"
            _expandedCWCardId = newId;
            _saveExpandedCwCards();
            _fullSync();
        } else {
            // empty — just show the card
            _fullSync();
        }

        _showToast(`C.W. Notebook "${notebookName}" created.`);
    }


    function _parseLocalDate(dateValue) {
        if (!dateValue) return null;
        const date = new Date(`${String(dateValue).slice(0, 10)}T00:00:00`);
        return isNaN(date.getTime()) ? null : date;
    }

    function _getCwChapterDeadlineInfo(chapter = {}) {
        return _getCwDeadlineInfo({ deadline: chapter.deadline, incident: chapter.status === 'incomplete' || chapter.status === 'current', delta: chapter.pendingPages });
    }

    function _getCwIndexSummary(row = {}) {
        const chapters = _getCwChapters(row);
        const total = chapters.length;
        const completeCount = chapters.filter(chapter => chapter.status === 'complete').length;
        const incompleteCount = chapters.filter(chapter => ['incomplete', 'current'].includes(chapter.status) || Number(chapter.pendingPages || 0) > 0).length;
        const current = chapters.find(chapter => chapter.status === 'current') || null;
        const pendingPages = chapters.reduce((sum, chapter) => sum + Math.max(0, Number(chapter.pendingPages || 0)), 0);
        const estimatedMinutes = chapters.reduce((sum, chapter) => sum + Math.max(0, Number(chapter.estimatedMinutes || 0)), 0);
        const hasOverdue = chapters.some(chapter => _getCwChapterDeadlineInfo(chapter).status === 'overdue');
        const hasDueSoon = chapters.some(chapter => ['today', 'tomorrow', 'soon'].includes(_getCwChapterDeadlineInfo(chapter).status));
        let risk = { label: 'No index', cssClass: 'none', score: 1 };
        if (total > 0 && completeCount === total) risk = { label: 'Safe', cssClass: 'complete', score: 0 };
        else if (hasOverdue) risk = { label: 'Critical', cssClass: 'overdue', score: 4 };
        else if (pendingPages > 0 || incompleteCount > 0) risk = { label: 'High', cssClass: 'warning', score: 3 };
        else if (hasDueSoon) risk = { label: 'Due soon', cssClass: 'soon', score: 2 };
        return { chapters, total, completeCount, incompleteCount, current, pendingPages, estimatedMinutes, risk };
    }

    function _getCWStatus(row = {}) {
        const summary = _getCwIndexSummary(row);
        if (summary.total > 0) {
            // All chapters complete → safe/complete
            if (summary.completeCount === summary.total) {
                return { key: 'complete', label: 'Safe', complete: true, risk: 'safe' };
            }
            // Overdue deadline → high risk
            if (summary.risk.score >= 4) {
                return { key: 'incident', label: 'High Risk', complete: false, risk: 'high' };
            }
            // Any incomplete/current chapters with pending pages → at risk
            if (summary.incompleteCount > 0 || summary.pendingPages > 0) {
                return { key: 'pending', label: 'Pending', complete: false, risk: 'medium' };
            }
            // Due soon but no incomplete chapters
            return { key: 'pending', label: 'Pending', complete: false, risk: 'medium' };
        }

        const pendingPages = Number(row.delta || row.pendingPages || 0);
        const hasIncident = row.incident === true || pendingPages > 0;

        if (hasIncident) {
            return { key: 'incident', label: 'At Risk', complete: false, risk: 'high' };
        }

        if (row.done === true) {
            return { key: 'complete', label: 'Safe', complete: true, risk: 'safe' };
        }

        return { key: 'no-index', label: 'No Index', complete: false, risk: 'none' };
    }

    function _getCwDeadlineInfo(row = {}) {
        const deadline = row.deadline ? String(row.deadline).slice(0, 10) : '';
        if (!deadline) {
            return {
                key: '',
                label: 'No deadline set',
                shortLabel: 'No deadline',
                status: 'none',
                daysLeft: null,
                cssClass: row.incident || Number(row.delta || 0) > 0 ? 'warning' : 'none'
            };
        }

        const due = _parseLocalDate(deadline);
        const today = _parseLocalDate(_getLocalDateKey(new Date()));
        if (!due || !today) {
            return { key: deadline, label: deadline, shortLabel: deadline, status: 'future', daysLeft: null, cssClass: 'future' };
        }

        const daysLeft = Math.round((due.getTime() - today.getTime()) / 86400000);
        if (daysLeft < 0) return { key: deadline, label: 'Overdue', shortLabel: 'Overdue', status: 'overdue', daysLeft, cssClass: 'overdue' };
        if (daysLeft === 0) return { key: deadline, label: 'Due today', shortLabel: 'Today', status: 'today', daysLeft, cssClass: 'today' };
        if (daysLeft === 1) return { key: deadline, label: 'Due tomorrow', shortLabel: 'Tomorrow', status: 'tomorrow', daysLeft, cssClass: 'tomorrow' };
        return {
            key: deadline,
            label: `Due in ${daysLeft} days`,
            shortLabel: `${daysLeft}d left`,
            status: daysLeft <= 3 ? 'soon' : 'future',
            daysLeft,
            cssClass: daysLeft <= 3 ? 'soon' : 'future'
        };
    }

    function _getCwRiskInfo(row = {}) {
        const summary = _getCwIndexSummary(row);
        if (summary.total > 0) return summary.risk;
        const status = _getCWStatus(row);
        const deadline = _getCwDeadlineInfo(row);
        if (status.key === 'complete') return { label: 'Complete', cssClass: 'complete', score: 0 };
        if (status.key === 'incident') return { label: deadline.status === 'overdue' ? 'Overdue' : 'High risk', cssClass: deadline.status === 'overdue' ? 'overdue' : 'warning', score: deadline.status === 'overdue' ? 4 : 3 };
        if (deadline.status === 'overdue') return { label: 'Overdue', cssClass: 'overdue', score: 4 };
        if (deadline.status === 'today') return { label: 'Due today', cssClass: 'today', score: 3 };
        if (deadline.status === 'tomorrow' || deadline.status === 'soon') return { label: 'Due soon', cssClass: 'soon', score: 2 };
        return { label: 'No index', cssClass: 'none', score: 1 };
    }

    function _computeCwPriority(row = {}) {
        const risk = _getCwRiskInfo(row);
        if (risk.score >= 4) return 'high';
        if (risk.score >= 2) return 'medium';
        return row.incident || Number(row.delta || 0) > 0 ? 'medium' : 'low';
    }

    // ════════════════════════════════════════════════════════
    //  NOTEBOOK DIRECTIVE SYSTEM (Phase 9N-D)
    //  Smart priority engine: what should the student do next?
    // ════════════════════════════════════════════════════════

    function _getNotebookDirectiveSafe() {
        try {
            return _computeNotebookDirective();
        } catch (err) {
            console.warn('[NotebooksRoute] Directive computation failed, using stable fallback:', err);
            return {
                type: 'stable',
                title: 'All notebook systems stable.',
                why: 'No urgent C.W., H.W., or note review pending.',
                estimatedMinutes: 0,
                risk: 'safe',
                subject: '',
                chapter: '',
                rowId: null,
                chapterId: null,
                taskId: null,
                noteId: null,
                actionLabel: 'Review Notebook',
                source: 'System'
            };
        }
    }

    function _computeNotebookDirective() {
        const candidates = [];

        // ── C.W. CHAPTER DIRECTIVE RULES ──
        const cwRows = _rows.filter(_isClassworkRow);
        for (const row of cwRows) {
            const chapters = _getCwChapters(row);
            for (const chapter of chapters) {
                if (chapter.status === 'complete') continue;

                let score = 0;
                const dlInfo = _getCwChapterDeadlineInfo(chapter);
                const pendingPages = Number(chapter.pendingPages || 0);

                // Deadline scoring
                if (dlInfo.status === 'overdue') score += 100;
                else if (dlInfo.status === 'today') score += 85;
                else if (dlInfo.status === 'tomorrow') score += 70;

                // Status scoring
                if (chapter.status === 'current' && pendingPages > 0) score += 60;
                else if (chapter.status === 'incomplete' && pendingPages > 0) score += 45;
                else if (chapter.status === 'current') score += 35;
                else if (chapter.status === 'incomplete') score += 25;

                // Pending pages boost
                score += pendingPages * 5;

                // Backlog linked bonus
                if (chapter.linkedBacklog) score += 10;

                if (score > 0) {
                    let risk = 'medium';
                    if (dlInfo.status === 'overdue' && pendingPages > 0) risk = 'critical';
                    else if (dlInfo.status === 'overdue' || (dlInfo.status === 'today' && pendingPages > 0)) risk = 'high';
                    else if (pendingPages > 0 || ['today', 'tomorrow'].includes(dlInfo.status)) risk = 'medium';

                    const whyParts = [];
                    if (dlInfo.status === 'overdue') whyParts.push('Deadline overdue');
                    else if (dlInfo.status === 'today') whyParts.push('Due today');
                    else if (dlInfo.status === 'tomorrow') whyParts.push('Due tomorrow');
                    if (pendingPages > 0) whyParts.push(`${pendingPages} page${pendingPages !== 1 ? 's' : ''} pending`);
                    if (chapter.status === 'current') whyParts.push('Currently in progress');
                    else if (chapter.status === 'incomplete') whyParts.push('Marked incomplete');

                    candidates.push({
                        type: 'cw',
                        title: `Finish "${chapter.chapterName || 'Unnamed chapter'}"`,
                        why: whyParts.length > 0 ? whyParts.join(' · ') : 'Needs attention',
                        estimatedMinutes: Number(chapter.estimatedMinutes || 0) || 25,
                        risk,
                        subject: row.subject || '',
                        chapter: chapter.chapterName || '',
                        rowId: row.id,
                        chapterId: chapter.id,
                        taskId: null,
                        noteId: null,
                        actionLabel: 'Start Mission',
                        source: 'C.W. Copy',
                        _score: score
                    });
                }
            }
        }

        // ── H.W. TASK DIRECTIVE RULES ──
        const hwRows = _rows.filter(_isHomeworkRow);
        for (const task of hwRows) {
            if (task.done || task.status === 'done') continue;

            let score = 0;
            const deadline = task.dueDate ? String(task.dueDate).slice(0, 10) : '';
            const dlInfo = deadline ? _getCwDeadlineInfo({ deadline, incident: true, delta: 1 }) : { status: 'none' };

            if (dlInfo.status === 'overdue') score += 90;
            else if (dlInfo.status === 'today') score += 75;
            else if (dlInfo.status === 'tomorrow') score += 60;

            if (String(task.priority || '').toLowerCase() === 'high') score += 20;
            else if (String(task.priority || '').toLowerCase() === 'medium') score += 10;

            if (score > 0) {
                let risk = 'medium';
                if (dlInfo.status === 'overdue') risk = 'critical';
                else if (dlInfo.status === 'today') risk = 'high';

                const taskLabel = task.taskTitle || task.chapter || 'Homework task';
                const whyParts = [];
                if (dlInfo.status === 'overdue') whyParts.push('Overdue');
                else if (dlInfo.status === 'today') whyParts.push('Due today');
                else if (dlInfo.status === 'tomorrow') whyParts.push('Due tomorrow');
                if (String(task.priority || '').toLowerCase() === 'high') whyParts.push('High priority');

                candidates.push({
                    type: 'hw',
                    title: `Complete "${taskLabel}"`,
                    why: whyParts.length > 0 ? whyParts.join(' · ') : 'Homework pending',
                    estimatedMinutes: Number(task.estimatedMinutes || 0) || 20,
                    risk,
                    subject: task.subject || '',
                    chapter: '',
                    rowId: task.id,
                    chapterId: null,
                    taskId: task.id,
                    noteId: null,
                    actionLabel: 'Start Mission',
                    source: 'H.W. Missions',
                    _score: score
                });
            }
        }

        // ── NOTES DIRECTIVE RULES ──
        if (_notes && Array.isArray(_notes.entries)) {
            for (const entry of _notes.entries) {
                let score = 0;
                const revStatus = String(entry.revisionStatus || 'none').toLowerCase();
                const healthScore = Number(entry.healthScore || 0);

                if (revStatus === 'overdue') score += 50;
                if (healthScore < 50) score += 40;
                else if (revStatus === 'pending') score += 30;

                if (score > 0) {
                    let risk = 'medium';
                    if (revStatus === 'overdue') risk = 'high';
                    else if (healthScore < 40) risk = 'high';

                    const whyParts = [];
                    if (revStatus === 'overdue') whyParts.push('Review overdue');
                    else if (revStatus === 'pending') whyParts.push('Pending review');
                    if (healthScore < 50) whyParts.push(`Health: ${healthScore}`);

                    candidates.push({
                        type: 'note',
                        title: `Review note: "${entry.title || 'Untitled'}"`,
                        why: whyParts.length > 0 ? whyParts.join(' · ') : 'Needs review',
                        estimatedMinutes: 10,
                        risk,
                        subject: entry.subject || '',
                        chapter: entry.chapter || '',
                        rowId: null,
                        chapterId: null,
                        taskId: null,
                        noteId: entry.id,
                        actionLabel: 'Open Note',
                        source: 'Notes Vault',
                        _score: score
                    });
                }
            }
        }

        // ── Pick highest scoring candidate ──
        if (candidates.length > 0) {
            candidates.sort((a, b) => b._score - a._score);
            const best = candidates[0];
            delete best._score;
            return best;
        }

        // ── DEFAULT STABLE STATE ──
        return {
            type: 'stable',
            title: 'All notebook systems stable.',
            why: 'No urgent C.W., H.W., or note review pending.',
            estimatedMinutes: 0,
            risk: 'safe',
            subject: '',
            chapter: '',
            rowId: null,
            chapterId: null,
            taskId: null,
            noteId: null,
            actionLabel: 'Review Notebook',
            source: 'System'
        };
    }

    function _renderNotebookDirective() {
        const card = _container?.querySelector('#nbDirectiveCard');
        if (!card) return;

        const d = _getNotebookDirectiveSafe();

        // Risk class
        card.className = 'nb-directive-card nb-directive-risk-' + d.risk;

        // Title
        const titleEl = card.querySelector('.nb-directive-title');
        if (titleEl) titleEl.textContent = d.title;

        // Why
        const whyEl = card.querySelector('.nb-directive-why');
        if (whyEl) whyEl.textContent = d.why;

        // ETA
        const etaEl = card.querySelector('.nb-directive-eta');
        if (etaEl) etaEl.textContent = d.estimatedMinutes > 0 ? `${d.estimatedMinutes} min` : '—';

        // Risk label
        const riskEl = card.querySelector('.nb-directive-risk-label');
        if (riskEl) {
            const riskLabels = { critical: 'CRITICAL', high: 'HIGH', medium: 'MEDIUM', safe: 'SAFE' };
            const riskColors = { critical: '#ff4c4c', high: '#f59e0b', medium: '#00d4ff', safe: '#00ff9d' };
            riskEl.textContent = riskLabels[d.risk] || 'SAFE';
            riskEl.style.color = riskColors[d.risk] || '#94a3b8';
        }

        // Source badge
        const sourceEl = card.querySelector('.nb-directive-source');
        if (sourceEl) sourceEl.textContent = d.source;

        // Subject
        const subjectEl = card.querySelector('.nb-directive-subject');
        if (subjectEl) {
            subjectEl.textContent = d.subject || '';
            subjectEl.style.display = d.subject ? '' : 'none';
        }

        // Action label
        const actionBtn = card.querySelector('.nb-directive-action-btn');
        if (actionBtn) actionBtn.textContent = d.actionLabel;

        // Action buttons visibility
        const backlogBtn = card.querySelector('[data-action="directive-backlog"]');
        if (backlogBtn) backlogBtn.style.display = (d.type === 'cw' || d.type === 'hw') ? '' : 'none';

        const doneBtn = card.querySelector('[data-action="directive-done"]');
        if (doneBtn) doneBtn.textContent = d.type === 'note' ? 'Mark Reviewed' : 'Mark Done';

        // Store directive data on the card for action handlers
        card.dataset.directiveType = d.type || 'stable';
        card.dataset.directiveRowId = d.rowId || '';
        card.dataset.directiveChapterId = d.chapterId || '';
        card.dataset.directiveTaskId = d.taskId || '';
        card.dataset.directiveNoteId = d.noteId || '';
    }

    function _executeDirectiveAction() {
        const card = _container?.querySelector('#nbDirectiveCard');
        if (!card) return;

        const type = card.dataset.directiveType;
        const rowId = card.dataset.directiveRowId;
        const chapterId = card.dataset.directiveChapterId;
        const noteId = card.dataset.directiveNoteId;

        if (type === 'cw' && rowId) {
            const rowIndex = _rows.findIndex(r => String(r.id) === String(rowId));
            if (rowIndex < 0) return;
            const row = _rows[rowIndex];
            const chapters = _getCwChapters(row);
            const chapter = chapterId ? chapters.find(ch => String(ch.id) === String(chapterId)) : null;
            if (chapter) {
                _syncCwChapterBacklog(row, chapter);
                _save();
                _fullSync();
                _dispatchNotebookUpdated({ action: 'directive_cw_mission', rowId: row.id, chapterId: chapter.id });
                _showToast('C.W. chapter sent to mission.');
            }
        } else if (type === 'hw' && rowId) {
            const rowIndex = _rows.findIndex(r => String(r.id) === String(rowId));
            if (rowIndex < 0) return;
            _addHomeworkToMissions(rowIndex);
        } else if (type === 'note' && noteId) {
            _openNoteModal(noteId);
        }
    }

    function _executeDirectiveBacklog() {
        const card = _container?.querySelector('#nbDirectiveCard');
        if (!card) return;

        const type = card.dataset.directiveType;
        const rowId = card.dataset.directiveRowId;
        const chapterId = card.dataset.directiveChapterId;

        if (type === 'cw' && rowId) {
            const rowIndex = _rows.findIndex(r => String(r.id) === String(rowId));
            if (rowIndex < 0) return;
            const row = _rows[rowIndex];
            const chapters = _getCwChapters(row);
            const chapter = chapterId ? chapters.find(ch => String(ch.id) === String(chapterId)) : null;
            if (chapter) {
                _syncCwChapterBacklog(row, chapter);
                _save();
                _fullSync();
                _dispatchBacklogUpdated({ source: 'directive_cw_backlog', chapter: chapter.chapterName, notebookRowId: row.id });
                _dispatchNotebookUpdated({ action: 'directive_cw_backlog', rowId: row.id });
                _showToast('C.W. chapter sent to Backlog.');
            }
        } else if (type === 'hw' && rowId) {
            const rowIndex = _rows.findIndex(r => String(r.id) === String(rowId));
            if (rowIndex < 0) return;
            _addHomeworkToMissions(rowIndex);
        }
    }

    function _executeDirectiveDone() {
        const card = _container?.querySelector('#nbDirectiveCard');
        if (!card) return;

        const type = card.dataset.directiveType;
        const rowId = card.dataset.directiveRowId;
        const chapterId = card.dataset.directiveChapterId;
        const noteId = card.dataset.directiveNoteId;

        if (type === 'cw' && rowId && chapterId) {
            const rowIndex = _rows.findIndex(r => String(r.id) === String(rowId));
            if (rowIndex < 0) return;
            const row = _rows[rowIndex];
            const chapters = _getCwChapters(row);
            const chapter = chapters.find(ch => String(ch.id) === String(chapterId));
            if (chapter) {
                chapter.status = 'complete';
                chapter.pendingPages = 0;
                chapter.updatedAt = new Date().toISOString();
                _completeLinkedCwChapterBacklog(row, chapter);
                // Re-evaluate row done state
                const summary = _getCwIndexSummary(row);
                if (summary.total > 0 && summary.completeCount === summary.total) {
                    row.done = true; row.incident = false; row.delta = 0;
                } else {
                    row.done = false; row.delta = summary.pendingPages; row.incident = summary.pendingPages > 0;
                }
                row.updatedAt = new Date().toISOString();
                _save();
                _fullSync();
                _dispatchNotebookUpdated({ action: 'directive_cw_done', rowId: row.id, chapterId: chapter.id });
                _showToast('C.W. chapter marked complete.');
            }
        } else if (type === 'hw' && rowId) {
            const rowIndex = _rows.findIndex(r => String(r.id) === String(rowId));
            if (rowIndex < 0) return;
            _markHomeworkDone(rowIndex);
        } else if (type === 'note' && noteId) {
            _markNoteReviewed(noteId);
        }
    }

    function _completeLinkedCwChapterBacklog(row, chapter) {
        if (!row || !chapter) return false;
        try {
            const masterData = SafeStorage.getItem('smartPadhaiData', {});
            if (!masterData || typeof masterData !== 'object') return false;
            const entryName = chapter.backlogEntryName || `CW: ${row.subject || 'Classwork'} - ${chapter.chapterName || 'Chapter'}`;
            const entry = masterData[entryName];
            if (entry && typeof entry === 'object' && entry.isNotebook === true) {
                const now = new Date().toISOString();
                masterData[entryName] = {
                    ...entry,
                    read: true, notes: true, revised: true, pyq: true,
                    completedAt: now, lastUpdated: now
                };
                SafeStorage.setItem('smartPadhaiData', masterData);
                _dispatchBacklogUpdated({ source: 'cw_chapter_complete', chapter: entryName, notebookRowId: row.id });
                return true;
            }
            return false;
        } catch (err) {
            console.warn('[NotebooksRoute] C.W. chapter backlog completion failed:', err);
            return false;
        }
    }

    function _getLinkedBacklogStatus(row = {}) {
        if (!row) return 'Not linked';
        try {
            const masterData = SafeStorage.getItem('smartPadhaiData', {});
            if (!masterData || typeof masterData !== 'object') return row.sentToBacklog ? 'Linked' : 'Not linked';
            const entry = row.backlogEntryName ? masterData[row.backlogEntryName] : null;
            if (entry) {
                return entry.read && entry.notes && entry.revised && entry.pyq ? 'Completed' : 'Linked';
            }
            const linked = Object.values(masterData).find(item => item && typeof item === 'object' && item.isNotebook === true && Number(item.notebookRowId) === Number(row.id));
            if (!linked) return row.sentToBacklog ? 'Linked' : 'Not linked';
            return linked.read && linked.notes && linked.revised && linked.pyq ? 'Completed' : 'Linked';
        } catch (err) {
            return row.sentToBacklog ? 'Linked' : 'Not linked';
        }
    }

    function _toggleCwCard(index) {
        const row = _rows[index];
        if (!row) return;
        const key = String(row.id || index);
        _expandedCWCardId = _expandedCWCardId === key ? null : key;
        _saveExpandedCwCards();
        _render();
    }

    function _openCwUpdateModal(index) {
        const row = _rows[index];
        const modal = _container?.querySelector('#nbCwUpdateModal');
        if (!row || !modal) return;
        _editingCwCopyIndex = index;
        const status = _getCWStatus(row);
        const setVal = (id, value) => {
            const el = _container.querySelector('#' + id);
            if (el) el.value = value ?? '';
        };
        const setChecked = (id, value) => {
            const el = _container.querySelector('#' + id);
            if (el) el.checked = !!value;
        };
        setVal('nbCwUpdateSubject', row.subject || '');
        setVal('nbCwUpdateChapter', row.chapter || '');
        setVal('nbCwUpdateStatus', status.key === 'complete' ? 'complete' : status.key === 'incident' ? 'incident' : 'pending');
        setVal('nbCwUpdatePendingPages', Number(row.delta || 0));
        setVal('nbCwUpdateTeacherChecked', row.teacherChecked ? 'yes' : 'no');
        setVal('nbCwUpdateDeadlineDate', row.deadline || '');
        setVal('nbCwUpdateDeadlineType', row.deadlineType || 'self');
        setVal('nbCwUpdateEstimatedMinutes', row.estimatedMinutes || '');
        setChecked('nbCwUpdateSendBacklog', row.sentToBacklog || row.backlogEntryName || status.key === 'incident');
        const title = _container.querySelector('#nbCwUpdateTitle');
        if (title) title.textContent = `UPDATE C.W. COPY${row.subject ? ` — ${row.subject}` : ''}`;
        modal.style.display = 'flex';
        setTimeout(() => _container?.querySelector('#nbCwUpdateSubject')?.focus(), 80);
    }

    function _closeCwUpdateModal() {
        const modal = _container?.querySelector('#nbCwUpdateModal');
        if (modal) modal.style.display = 'none';
        _editingCwCopyIndex = null;
    }

    function _saveCwUpdateFromModal() {
        const row = _rows[_editingCwCopyIndex];
        if (!row) return;
        const getVal = (id) => (_container?.querySelector('#' + id)?.value || '').trim();
        const getChecked = (id) => _container?.querySelector('#' + id)?.checked === true;
        const subject = getVal('nbCwUpdateSubject');
        if (!subject) {
            _showToast('Subject is required.');
            _container?.querySelector('#nbCwUpdateSubject')?.focus();
            return;
        }
        const status = getVal('nbCwUpdateStatus') || 'pending';
        let pendingPages = Math.max(0, Math.round(Number(getVal('nbCwUpdatePendingPages') || 0)));

        row.subject = subject;
        row.chapter = getVal('nbCwUpdateChapter');
        row.teacherChecked = getVal('nbCwUpdateTeacherChecked') === 'yes';
        row.deadline = getVal('nbCwUpdateDeadlineDate') || null;
        row.deadlineType = getVal('nbCwUpdateDeadlineType') || null;
        const minutes = Math.round(Number(getVal('nbCwUpdateEstimatedMinutes') || 0));
        row.estimatedMinutes = Number.isFinite(minutes) && minutes > 0 ? minutes : null;

        if (status === 'complete') {
            row.done = true;
            row.incident = false;
            row.delta = 0;
            pendingPages = 0;
            if (Array.isArray(row.chapters)) {
                row.chapters = row.chapters.map((chapter, idx) => {
                    const normalized = _normalizeCwChapter(chapter, idx + 1);
                    normalized.status = 'complete';
                    normalized.pendingPages = 0;
                    normalized.updatedAt = new Date().toISOString();
                    _completeLinkedCwChapterBacklog(row, normalized);
                    return normalized;
                });
            }
            _completeLinkedNotebookBacklogs(row);
        } else if (status === 'incident') {
            row.done = false;
            row.incident = true;
            row.delta = pendingPages > 0 ? pendingPages : 1;
            pendingPages = row.delta;
        } else {
            row.done = false;
            row.delta = pendingPages;
            row.incident = pendingPages > 0;
        }

        const sendToBacklog = getChecked('nbCwUpdateSendBacklog');
        row.updatedAt = new Date().toISOString();
        let backlogChanged = false;
        if (!row.done && (sendToBacklog || row.incident || Number(row.delta || 0) > 0)) {
            backlogChanged = _syncClassworkPendingBacklog(row, row.delta || pendingPages || 0);
        }

        _save();
        _fullSync();
        _dispatchNotebookUpdated({ action: 'cw_copy_updated', rowId: row.id, status: _getCWStatus(row).key, backlogChanged });
        _closeCwUpdateModal();
    }

    function _completeLinkedCwChapterBacklog(row, chapter) {
        if (!row || !chapter) return false;
        try {
            const masterData = SafeStorage.getItem('smartPadhaiData', {});
            if (!masterData || typeof masterData !== 'object') return false;
            const completedAt = new Date().toISOString();
            let changed = false;
            Object.keys(masterData).forEach(entryName => {
                const entry = masterData[entryName];
                if (!entry || typeof entry !== 'object') return;
                if (entry.isNotebook === true && Number(entry.notebookRowId) === Number(row.id) && (entry.notebookChapterId === chapter.id || entryName === chapter.backlogEntryName)) {
                    masterData[entryName] = { ...entry, read: true, notes: true, revised: true, pyq: true, completedAt, lastUpdated: completedAt };
                    changed = true;
                }
            });
            if (changed) {
                SafeStorage.setItem('smartPadhaiData', masterData);
                _dispatchBacklogUpdated({ source: 'cw_chapter_completed', notebookRowId: row.id, notebookChapterId: chapter.id });
            }
            return changed;
        } catch (err) {
            console.warn('[NotebooksRoute] C.W. chapter backlog completion failed:', err);
            return false;
        }
    }

    function _syncCwChapterBacklog(row, chapter) {
        if (!row || !chapter) return false;
        try {
            const subjectName = String(row.subject || 'Classwork').trim() || 'Classwork';
            const chapterName = String(chapter.chapterName || 'Chapter').trim() || 'Chapter';
            let masterData = SafeStorage.getItem('smartPadhaiData', {});
            if (!masterData || typeof masterData !== 'object') masterData = {};
            const entryName = `CW: ${subjectName} - ${chapterName}`;
            const existingName = chapter.backlogEntryName && masterData[chapter.backlogEntryName] ? chapter.backlogEntryName : entryName;
            const existing = (masterData[existingName] && typeof masterData[existingName] === 'object') ? masterData[existingName] : {};
            const now = new Date().toISOString();
            if (existingName !== entryName && masterData[existingName]) delete masterData[existingName];
            masterData[entryName] = {
                ...existing,
                read: existing.read === true,
                notes: existing.notes !== false,
                revised: existing.revised === true,
                pyq: existing.pyq !== false,
                isNotebook: true,
                isSyllabus: false,
                source: 'cw_chapter_pending',
                subject: subjectName,
                chapter: chapterName,
                notebookRowId: row.id,
                notebookChapterId: chapter.id,
                pagesToComplete: Math.max(0, Number(chapter.pendingPages || 0)),
                deadline: chapter.deadline || null,
                estimatedMinutes: chapter.estimatedMinutes || 25,
                priority: _getCwChapterDeadlineInfo(chapter).status === 'overdue' ? 'high' : (Number(chapter.pendingPages || 0) > 0 ? 'medium' : 'low'),
                lastUpdated: now
            };
            chapter.linkedBacklog = true;
            chapter.backlogEntryName = entryName;
            SafeStorage.setItem('smartPadhaiData', masterData);
            _dispatchBacklogUpdated({ source: 'cw_chapter_pending', chapter: entryName, notebookRowId: row.id, notebookChapterId: chapter.id });
            return true;
        } catch (err) {
            console.warn('[NotebooksRoute] C.W. chapter backlog sync failed:', err);
            return false;
        }
    }

    function _openCwChapterModal(index, chapterId = null) {
        const row = _rows[index];
        const modal = _container?.querySelector('#nbCwChapterModal');
        if (!row || !modal) return;
        const chapters = _getCwChapters(row);
        const chapter = chapterId ? chapters.find(item => String(item.id) === String(chapterId)) : null;
        _editingCwChapterContext = { rowIndex: index, chapterId: chapter?.id || null };
        const setVal = (id, value) => {
            const el = _container.querySelector('#' + id);
            if (el) el.value = value ?? '';
        };

        // Set basic fields
        setVal('nbCwChapterName', chapter?.chapterName || '');
        setVal('nbCwChapterOrder', chapter?.order || (chapters.length + 1));
        setVal('nbCwChapterStatus', chapter?.status || 'not_started');
        setVal('nbCwChapterPendingPages', chapter?.pendingPages || 0);
        setVal('nbCwChapterEstimatedMinutes', chapter?.estimatedMinutes || '');
        setVal('nbCwChapterDeadline', chapter?.deadline || '');

        // Subject (read-only tag display)
        const subjectEl = _container.querySelector('#nbCwChapterSubjectDisplay');
        if (subjectEl) subjectEl.textContent = row.subject || '—';

        // Status segmented buttons — set active state
        const statusValue = chapter?.status || 'not_started';
        _container.querySelectorAll('#nbCwChapterStatusPills .nb-ch-seg-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.value === statusValue);
        });

        // Teacher checked toggle
        const teacherChecked = chapter?.teacherChecked === true;
        setVal('nbCwChapterTeacherChecked', teacherChecked ? 'yes' : 'no');
        const teacherToggle = _container.querySelector('.nb-ch-toggle[data-action="toggle-teacher-chapter"]');
        if (teacherToggle) teacherToggle.classList.toggle('active', teacherChecked);
        const teacherLabel = _container.querySelector('#nbCwChapterTeacherCheckedLabel');
        if (teacherLabel) teacherLabel.textContent = teacherChecked ? 'Verified' : 'Not checked';

        // Backlog toggle
        const backlogEnabled = chapter?.linkedBacklog || (chapter && ['incomplete', 'current'].includes(chapter.status) && Number(chapter.pendingPages || 0) > 0);
        setVal('nbCwChapterSendBacklog', backlogEnabled ? 'yes' : 'no');
        const backlogToggle = _container.querySelector('.nb-ch-toggle[data-action="toggle-backlog-chapter"]');
        if (backlogToggle) backlogToggle.classList.toggle('active', !!backlogEnabled);
        const backlogLabel = _container.querySelector('#nbCwChapterBacklogLabel');
        if (backlogLabel) backlogLabel.textContent = backlogEnabled ? 'On' : 'Off';

        // Backlog row visual emphasis based on status
        const backlogRow = _container.querySelector('#nbCwChapterBacklogRow');
        if (backlogRow) {
            const isComplete = (chapter?.status || 'not_started') === 'complete';
            backlogRow.classList.toggle('de-emphasized', isComplete);
        }

        // Delete button — only show when editing existing chapter
        const deleteBtn = _container.querySelector('#nbCwChapterDeleteBtn');
        if (deleteBtn) deleteBtn.style.display = chapter ? '' : 'none';

        // Title
        const title = _container.querySelector('#nbCwChapterModalTitle');
        if (title) title.textContent = chapter ? 'Custom Chapter Setup' : 'Custom Chapter Setup';

        // Initial summary update
        _updateChapterSheetSummary();

        modal.style.display = 'flex';
        setTimeout(() => _container?.querySelector('#nbCwChapterName')?.focus(), 80);
    }

    function _updateChapterSheetSummary() {
        const getVal = (id) => (_container?.querySelector('#' + id)?.value || '').trim();
        const status = getVal('nbCwChapterStatus') || 'not_started';
        const pendingPages = Math.max(0, Number(getVal('nbCwChapterPendingPages') || 0));
        const eta = Number(getVal('nbCwChapterEstimatedMinutes') || 0);
        const deadline = getVal('nbCwChapterDeadline');
        const teacherChecked = getVal('nbCwChapterTeacherChecked') === 'yes';
        const backlogEnabled = getVal('nbCwChapterSendBacklog') === 'yes';

        // Status label
        const statusLabels = { complete: 'Complete', current: 'Current', incomplete: 'Incomplete', not_started: 'Not Started' };
        const statusColors = { complete: '#00ff9d', current: '#67e8f9', incomplete: '#ffb86b', not_started: '#94a3b8' };
        const setStatus = (id, text, color) => {
            const el = _container?.querySelector('#' + id);
            if (el) { el.textContent = text; el.style.color = color || ''; }
        };

        setStatus('nbSummaryStatus', statusLabels[status] || 'Not Started', statusColors[status] || '#94a3b8');
        setStatus('nbSummaryPending', pendingPages > 0 ? `${pendingPages} page${pendingPages !== 1 ? 's' : ''}` : 'None', pendingPages > 0 ? '#ffb86b' : '#94a3b8');
        setStatus('nbSummaryEta', eta > 0 ? `${eta} min` : '—', eta > 0 ? '#67e8f9' : '#94a3b8');

        // Deadline helper
        const deadlineHelper = _container?.querySelector('#nbCwChapterDeadlineHelper');
        if (deadlineHelper) {
            if (!deadline) {
                deadlineHelper.textContent = 'No deadline set';
                deadlineHelper.className = 'nb-ch-deadline-hint';
            } else {
                const due = _parseLocalDate(deadline);
                const today = _parseLocalDate(_getLocalDateKey(new Date()));
                if (due && today) {
                    const daysLeft = Math.round((due.getTime() - today.getTime()) / 86400000);
                    if (daysLeft < 0) {
                        deadlineHelper.textContent = `Overdue by ${Math.abs(daysLeft)} day${Math.abs(daysLeft) !== 1 ? 's' : ''}`;
                        deadlineHelper.className = 'nb-ch-deadline-hint overdue';
                    } else if (daysLeft === 0) {
                        deadlineHelper.textContent = 'Due today';
                        deadlineHelper.className = 'nb-ch-deadline-hint today';
                    } else if (daysLeft === 1) {
                        deadlineHelper.textContent = 'Due tomorrow';
                        deadlineHelper.className = 'nb-ch-deadline-hint soon';
                    } else if (daysLeft <= 3) {
                        deadlineHelper.textContent = `Due in ${daysLeft} days`;
                        deadlineHelper.className = 'nb-ch-deadline-hint soon';
                    } else {
                        deadlineHelper.textContent = `Due in ${daysLeft} days`;
                        deadlineHelper.className = 'nb-ch-deadline-hint future';
                    }
                } else {
                    deadlineHelper.textContent = deadline;
                    deadlineHelper.className = 'nb-ch-deadline-hint';
                }
            }
        }

        // Summary deadline
        const dlInfo = deadline ? _getCwChapterDeadlineInfo({ deadline, status: status === 'complete' ? 'complete' : 'incomplete', pendingPages }) : null;
        setStatus('nbSummaryDeadline', dlInfo ? dlInfo.shortLabel : 'No deadline', dlInfo ? (dlInfo.status === 'overdue' ? '#ff4c4c' : (dlInfo.status === 'none' ? '#94a3b8' : '#67e8f9')) : '#94a3b8');

        // Risk calculation
        let risk = 'None';
        let riskColor = '#94a3b8';
        if (status === 'complete') {
            risk = 'None'; riskColor = '#00ff9d';
        } else if (dlInfo?.status === 'overdue' && pendingPages > 0) {
            risk = 'High'; riskColor = '#ff4c4c';
        } else if ((dlInfo?.status === 'today' || dlInfo?.status === 'tomorrow' || dlInfo?.status === 'soon') && pendingPages > 0) {
            risk = 'High'; riskColor = '#ffb86b';
        } else if (pendingPages > 0 || status === 'incomplete') {
            risk = 'Medium'; riskColor = '#fbbf24';
        } else if (status === 'current') {
            risk = 'Low'; riskColor = '#67e8f9';
        }
        setStatus('nbSummaryRisk', risk, riskColor);

        // Smart field behavior: if Complete, auto-disable pending pages
        const pendingInput = _container?.querySelector('#nbCwChapterPendingPages');
        if (status === 'complete') {
            if (pendingInput && Number(pendingInput.value || 0) !== 0) pendingInput.value = '0';
            if (pendingInput) pendingInput.disabled = true;
        } else {
            if (pendingInput) pendingInput.disabled = false;
        }

        // Backlog row de-emphasis when Complete
        const backlogRow = _container?.querySelector('#nbCwChapterBacklogRow');
        if (backlogRow) {
            backlogRow.classList.toggle('de-emphasized', status === 'complete');
        }
    }

    function _closeCwChapterModal() {
        const modal = _container?.querySelector('#nbCwChapterModal');
        if (modal) modal.style.display = 'none';
        _editingCwChapterContext = null;
    }

    function _deleteCwChapterInline() {
        const ctx = _editingCwChapterContext;
        if (!ctx || !ctx.chapterId) return;
        const row = _rows[ctx?.rowIndex];
        if (!row) return;
        const chapters = _getCwChapters(row);
        const chapter = chapters.find(item => String(item.id) === String(ctx.chapterId));
        if (!chapter) return;
        if (!confirm(`Delete chapter "${chapter.chapterName || 'this chapter'}"?`)) return;
        const filtered = chapters.filter(item => String(item.id) !== String(ctx.chapterId));
        row.chapters = filtered;
        const summary = _getCwIndexSummary(row);
        if (summary.total > 0 && summary.completeCount === summary.total) {
            row.done = true; row.incident = false; row.delta = 0;
        } else {
            row.done = false; row.delta = summary.pendingPages; row.incident = summary.pendingPages > 0;
        }
        row.updatedAt = new Date().toISOString();
        _closeCwChapterModal();
        _save();
        _fullSync();
        _dispatchNotebookUpdated({ action: 'cw_chapter_deleted', rowId: row.id, chapterId: ctx.chapterId });
        _showToast('Chapter deleted.');
    }

    function _saveCwChapterFromModal() {
        const ctx = _editingCwChapterContext;
        const row = _rows[ctx?.rowIndex];
        if (!ctx || !row) return;
        const getVal = (id) => (_container?.querySelector('#' + id)?.value || '').trim();
        const chapterName = getVal('nbCwChapterName');
        if (!chapterName) {
            _showToast('Chapter name is required.');
            _container?.querySelector('#nbCwChapterName')?.focus();
            return;
        }
        const chapters = _getCwChapters(row);
        const existingIndex = chapters.findIndex(item => String(item.id) === String(ctx.chapterId));
        const existing = existingIndex >= 0 ? chapters[existingIndex] : {};
        let status = getVal('nbCwChapterStatus') || 'not_started';
        let pendingPages = Math.max(0, Math.round(Number(getVal('nbCwChapterPendingPages') || 0)));
        if (status === 'complete') pendingPages = 0;
        const minutes = Math.round(Number(getVal('nbCwChapterEstimatedMinutes') || 0));
        const chapter = _normalizeCwChapter({
            ...existing,
            id: existing.id || `cw_ch_${Date.now()}`,
            chapterName,
            order: Math.max(1, Math.round(Number(getVal('nbCwChapterOrder') || chapters.length + 1))),
            status,
            pendingPages,
            estimatedMinutes: Number.isFinite(minutes) && minutes > 0 ? minutes : null,
            teacherChecked: getVal('nbCwChapterTeacherChecked') === 'yes',
            deadline: getVal('nbCwChapterDeadline') || null,
            updatedAt: new Date().toISOString()
        }, chapters.length + 1);

        if (existingIndex >= 0) chapters[existingIndex] = chapter;
        else chapters.push(chapter);
        row.chapters = chapters.sort((a, b) => Number(a.order || 0) - Number(b.order || 0));
        const summary = _getCwIndexSummary(row);
        if (summary.total > 0 && summary.completeCount === summary.total) {
            row.done = true;
            row.incident = false;
            row.delta = 0;
        } else {
            row.done = false;
            row.delta = summary.pendingPages;
            row.incident = summary.pendingPages > 0;
        }
        row.updatedAt = new Date().toISOString();

        if (chapter.status === 'complete') {
            _completeLinkedCwChapterBacklog(row, chapter);
        } else if (getVal('nbCwChapterSendBacklog') === 'yes' && Number(chapter.pendingPages || 0) > 0) {
            _syncCwChapterBacklog(row, chapter);
        }

        _save();
        _fullSync();
        _dispatchNotebookUpdated({ action: 'cw_chapter_saved', rowId: row.id, chapterId: chapter.id });
        _closeCwChapterModal();
    }

    function _syncClassworkPendingBacklog(row, pages) {
        if (!row) return false;
        try {
            const subjectName = String(row.subject || 'Classwork').trim() || 'Classwork';
            const pageCount = Math.max(0, Math.round(Number(pages ?? row.delta ?? 0)));
            let masterData = SafeStorage.getItem('smartPadhaiData', {});
            if (!masterData || typeof masterData !== 'object') masterData = {};
            const entryName = `CW: ${subjectName} - ${pageCount || 0} pages`;
            const existingName = row.backlogEntryName && masterData[row.backlogEntryName] ? row.backlogEntryName : entryName;
            const existing = (masterData[existingName] && typeof masterData[existingName] === 'object') ? masterData[existingName] : {};
            const now = new Date().toISOString();
            const priority = _computeCwPriority(row);
            const updatedEntry = {
                ...existing,
                read: existing.read === true,
                notes: existing.notes !== false,
                revised: existing.revised === true,
                pyq: existing.pyq !== false,
                isNotebook: true,
                isSyllabus: false,
                source: 'cw_copy_pending',
                subject: subjectName,
                chapter: row.chapter || '',
                notebookRowId: row.id,
                pagesToComplete: pageCount,
                deadline: row.deadline || null,
                estimatedMinutes: row.estimatedMinutes || 25,
                priority,
                lastUpdated: now
            };
            if (existingName !== entryName && masterData[existingName]) delete masterData[existingName];
            masterData[entryName] = updatedEntry;
            row.backlogEntryName = entryName;
            row.sentToBacklog = true;
            SafeStorage.setItem('smartPadhaiData', masterData);
            _dispatchBacklogUpdated({ source: 'cw_copy_pending', chapter: entryName, notebookRowId: row.id, topTask: entryName });
            return true;
        } catch (err) {
            console.warn('[NotebooksRoute] C.W. backlog sync failed:', err);
            return false;
        }
    }

    function _reportClassworkPendingPages(index) {
        const row = _rows[index];
        if (!row || !_isClassworkRow(row)) return;
        const input = prompt('Pending pages / delta', row.delta || '');
        if (input === null) return;
        const pages = Math.max(0, Math.round(Number(input || 0)));
        if (!Number.isFinite(pages) || pages <= 0) {
            _showToast('Enter pending pages greater than 0.');
            return;
        }
        row.incident = true;
        row.done = false;
        row.delta = pages;
        row.updatedAt = new Date().toISOString();
        _syncClassworkPendingBacklog(row, pages);
        _save();
        _fullSync();
        _dispatchNotebookUpdated({ action: 'cw_pending_pages_reported', rowId: row.id, pages });
    }

    function _sendClassworkToBacklog(index) {
        const row = _rows[index];
        if (!row || !_isClassworkRow(row) || _getCWStatus(row).complete) return;
        let pages = Number(row.delta || 0);
        if (!Number.isFinite(pages) || pages <= 0) {
            const input = prompt('Pages to complete', '1');
            if (input === null) return;
            pages = Math.max(1, Math.round(Number(input || 0)));
        }
        if (!Number.isFinite(pages) || pages <= 0) return;
        row.incident = true;
        row.done = false;
        row.delta = pages;
        row.updatedAt = new Date().toISOString();
        if (_syncClassworkPendingBacklog(row, pages)) {
            _save();
            _fullSync();
            _dispatchNotebookUpdated({ action: 'cw_sent_to_backlog', rowId: row.id, pages });
            _showToast('C.W. pending work sent to Backlog.');
        }
    }

    function _editClassworkCopy(index) {
        const row = _rows[index];
        if (!row || !_isClassworkRow(row)) return;
        const subject = prompt('Edit C.W. subject', row.subject || '');
        if (subject === null) return;
        const cleanSubject = String(subject || '').trim();
        if (!cleanSubject) {
            _showToast('Subject cannot be empty.');
            return;
        }
        const chapter = prompt('Edit chapter / unit', row.chapter || '');
        if (chapter === null) return;
        row.subject = cleanSubject;
        row.chapter = String(chapter || '').trim();
        row.updatedAt = new Date().toISOString();
        _updateLinkedNotesForRow(row);
        if (row.sentToBacklog || row.backlogEntryName) _syncClassworkPendingBacklog(row, row.delta || 0);
        _save();
        _fullSync();
        _dispatchNotebookUpdated({ action: 'cw_copy_edited', rowId: row.id });
    }

    function _deleteClassworkCopy(index) {
        const row = _rows[index];
        if (!row || !_isClassworkRow(row)) return;
        if (!confirm(`Delete C.W. copy for ${row.subject || 'this subject'}? Linked notebook backlog will be cleared.`)) return;
        _rows.splice(index, 1);
        _removeLinkedNotebookBacklogs(row);
        _enqueueNotebookRowDelete(row);
        _save();
        _fullSync();
        _dispatchNotebookUpdated({ action: 'cw_copy_deleted', rowId: row.id });
    }

    function _openHomeworkTaskModal(index = null) {
        const modal = _container?.querySelector('#nbHwTaskModal');
        if (!modal) return;

        _editingHomeworkIndex = Number.isInteger(index) ? index : null;
        const row = _editingHomeworkIndex !== null ? _rows[_editingHomeworkIndex] : null;

        const titleEl = _container.querySelector('#nbHwModalTitle');
        if (titleEl) titleEl.textContent = row ? 'EDIT H.W. TASK' : 'ADD H.W. TASK';

        const setVal = (id, value) => {
            const el = _container.querySelector('#' + id);
            if (el) el.value = value || '';
        };

        setVal('nbHwSubject', row?.subject || '');
        setVal('nbHwTaskTitle', row?.taskTitle || '');
        setVal('nbHwDueDate', row?.dueDate || '');
        setVal('nbHwType', row?.hwType || 'homework');
        setVal('nbHwPriority', row?.priority || 'medium');
        setVal('nbHwStatus', row?.status || (row?.done ? 'done' : 'pending'));
        setVal('nbHwEstimatedMinutes', ['10', '20', '30', '45', '60'].includes(String(row?.estimatedMinutes || '')) ? row?.estimatedMinutes : (row?.estimatedMinutes ? 'custom' : '30'));
        setVal('nbHwEstimatedCustom', row?.estimatedMinutes && !['10', '20', '30', '45', '60'].includes(String(row.estimatedMinutes)) ? row.estimatedMinutes : '');
        const deleteBtn = _container.querySelector('#nbHwDeleteBtn');
        if (deleteBtn) deleteBtn.style.display = row ? '' : 'none';

        modal.style.display = 'flex';
        setTimeout(() => _container?.querySelector('#nbHwTaskTitle')?.focus(), 80);
    }

    function _closeHomeworkTaskModal() {
        const modal = _container?.querySelector('#nbHwTaskModal');
        if (modal) modal.style.display = 'none';
        _editingHomeworkIndex = null;
    }

    function _saveHomeworkTaskFromModal() {
        const getVal = (id) => (_container?.querySelector('#' + id)?.value || '').trim();
        const taskTitle = getVal('nbHwTaskTitle');
        const subject = getVal('nbHwSubject');
        const dueDate = getVal('nbHwDueDate');
        const hwType = getVal('nbHwType') || 'homework';
        const priority = getVal('nbHwPriority') || 'medium';
        const status = getVal('nbHwStatus') || 'pending';
        const estimateChoice = getVal('nbHwEstimatedMinutes');
        const estimatedMinutes = Math.max(0, Math.round(Number(estimateChoice === 'custom' ? getVal('nbHwEstimatedCustom') : estimateChoice || 0)));

        if (!subject) {
            _showToast('Subject is required for H.W. tasks.');
            _container?.querySelector('#nbHwSubject')?.focus();
            return;
        }
        if (!taskTitle) {
            _showToast('Add a homework task title first.');
            _container?.querySelector('#nbHwTaskTitle')?.focus();
            return;
        }

        let row;
        if (_editingHomeworkIndex !== null && _rows[_editingHomeworkIndex]) {
            row = _rows[_editingHomeworkIndex];
            const finalStatus = status !== 'done' && _isPastDue(dueDate) ? 'overdue' : status;
            Object.assign(row, { subject, taskTitle, dueDate, hwType, priority, estimatedMinutes, status: finalStatus, done: finalStatus === 'done', type: 'HOMEWORK', copyType: 'HW', updatedAt: new Date().toISOString() });
        } else {
            const newId = _rows.length > 0 ? Math.max(..._rows.map(r => Number(r.id) || 0)) + 1 : 1;
            const finalStatus = status !== 'done' && _isPastDue(dueDate) ? 'overdue' : status;
            row = { id: newId, dateAssigned: _getLocalDateKey(), subject, taskTitle, dueDate, status: finalStatus, hwType, priority, estimatedMinutes, addedToMission: false, sentToBacklog: false, backlogEntryName: '', type: 'HOMEWORK', copyType: 'HW', done: finalStatus === 'done', incident: false, delta: 0, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
            _rows.push(row);
        }

        if (row.done) _completeLinkedNotebookBacklogs(row);
        else if (row.sentToBacklog === true) _syncHomeworkBacklog(row);

        _save();
        _closeHomeworkTaskModal();
        _fullSync();
        _dispatchNotebookUpdated({ action: 'homework_saved', rowId: row.id });
        _showToast('H.W. task saved.');
    }

    function _deleteHomeworkTask(index) {
        const row = _rows[index];
        if (!row || !_isHomeworkRow(row)) return;
        const label = row.taskTitle || row.subject || 'this homework task';

        _rows.splice(index, 1);
        _removeLinkedNotebookBacklogs(row);
        _dispatchBacklogUpdated({ source: 'homework_deleted', notebookRowId: row.id });
        _enqueueNotebookRowDelete(row);
        _save();
        _fullSync();
        _dispatchNotebookUpdated({ action: 'homework_deleted', rowId: row.id });
        _showToast('H.W. task deleted.');
    }

    function _deleteCurrentHomeworkTask() {
        if (_editingHomeworkIndex === null) return;
        const index = _editingHomeworkIndex;
        _closeHomeworkTaskModal();
        _deleteHomeworkTask(index);
    }

    function _addHomeworkTaskFromData(data = {}) {
        const newId = _rows.length > 0 ? Math.max(..._rows.map(r => Number(r.id) || 0)) + 1 : 1;
        const now = new Date().toISOString();
        const row = {
            id: newId,
            dateAssigned: data.dateAssigned || _getLocalDateKey(),
            subject: data.subject || '',
            taskTitle: data.taskTitle || '',
            dueDate: data.dueDate || '',
            hwType: data.hwType || data.type || 'homework',
            priority: data.priority || 'medium',
            estimatedMinutes: Math.max(0, Math.round(Number(data.estimatedMinutes || 0))),
            status: data.status && data.status !== 'pending' ? data.status : (_isPastDue(data.dueDate) ? 'overdue' : 'pending'),
            addedToMission: false,
            sentToBacklog: false,
            backlogEntryName: '',
            type: 'HOMEWORK',
            copyType: 'HW',
            done: data.status === 'done',
            incident: false,
            delta: 0,
            createdAt: now,
            updatedAt: now
        };
        _rows.push(row);
        return row;
    }

    function _getPendingHomeworkItems() {
        return _rows
            .map((row, index) => ({ row, index }))
            .filter(item => {
                if (!_isHomeworkRow(item.row) || item.row.done || item.row.status === 'done') return false;
                if (_isPastDue(item.row.dueDate)) item.row.status = 'overdue';
                return item.row.status === 'pending' || item.row.status === 'overdue';
            });
    }

    function _addHomeworkToMissions(index) {
        const task = _rows[index];
        if (!task || !_isHomeworkRow(task)) return;

        try {
            let masterData = SafeStorage.getItem('smartPadhaiData', {});
            if (!masterData || typeof masterData !== 'object') masterData = {};

            const subject = task.subject || 'Homework';
            const title = task.taskTitle || task.chapter || 'Homework Task';
            const entryName = `HW: ${subject} - ${title}`;
            masterData[entryName] = {
                ...(masterData[entryName] && typeof masterData[entryName] === 'object' ? masterData[entryName] : {}),
                read: false,
                notes: true,
                revised: false,
                pyq: true,
                isNotebook: true,
                isHomework: true,
                isSyllabus: false,
                source: 'homework_task',
                subject,
                chapter: title,
                homeworkTaskId: task.id,
                notebookRowId: task.id,
                dueDate: task.dueDate || '',
                estimatedMinutes: Number(task.estimatedMinutes || 0),
                priority: task.priority || 'medium',
                lastUpdated: new Date().toISOString()
            };
            SafeStorage.setItem('smartPadhaiData', masterData);

            task.addedToMission = true;
            task.sentToBacklog = true;
            task.backlogEntryName = entryName;
            task.updatedAt = new Date().toISOString();
            _save();
            _fullSync();
            _dispatchBacklogUpdated({ source: 'homework_task', chapter: entryName, homeworkTaskId: task.id });
            _dispatchNotebookUpdated({ action: 'homework_sent_to_backlog', rowId: task.id });
            _showToast('H.W. sent to Backlog.');
        } catch (err) {
            console.warn('[NotebooksRoute] Send homework to backlog failed:', err);
            _showToast('Could not send homework to Backlog.');
        }
    }

    function _markHomeworkDone(index) {
        const task = _rows[index];
        if (!task || !_isHomeworkRow(task)) return;
        task.status = 'done';
        task.done = true;
        task.completedAt = new Date().toISOString();
        task.updatedAt = task.completedAt;
        _completeLinkedNotebookBacklogs(task);
        _save();
        _fullSync();
        _dispatchNotebookUpdated({ action: 'homework_done', rowId: task.id });
        _showToast('H.W. marked done.');
    }

    function _getHomeworkIntakeFieldData() {
        const getVal = (id) => (_container?.querySelector('#' + id)?.value || '').trim();
        return {
            subject: getVal('nbIntakeSubject'),
            taskTitle: getVal('nbIntakeTaskTitle'),
            dueDate: getVal('nbIntakeDueDate'),
            hwType: getVal('nbIntakeType') || 'homework',
            priority: getVal('nbIntakePriority') || 'medium',
            estimatedMinutes: Math.max(0, Math.round(Number(getVal('nbIntakeEstimatedMinutes') === 'custom' ? getVal('nbIntakeEstimatedCustom') : getVal('nbIntakeEstimatedMinutes') || 0)))
        };
    }

    function _clearHomeworkIntakeFields({ keepSubject = true } = {}) {
        const ids = keepSubject ? ['nbIntakeTaskTitle', 'nbIntakeDueDate', 'nbIntakeEstimatedMinutes'] : ['nbIntakeSubject', 'nbIntakeTaskTitle', 'nbIntakeDueDate', 'nbIntakeEstimatedMinutes'];
        ids.forEach(id => { const el = _container?.querySelector('#' + id); if (el) el.value = ''; });
        const typeEl = _container?.querySelector('#nbIntakeType');
        const priorityEl = _container?.querySelector('#nbIntakePriority');
        const estimateEl = _container?.querySelector('#nbIntakeEstimatedMinutes');
        const customEl = _container?.querySelector('#nbIntakeEstimatedCustom');
        if (typeEl) typeEl.value = 'homework';
        if (priorityEl) priorityEl.value = 'medium';
        if (estimateEl) estimateEl.value = '30';
        if (customEl) customEl.value = '';
    }

    function _renderHomeworkIntakeDraft() {
        const list = _container?.querySelector('#nbIntakeDraftList');
        if (!list) return;
        if (_homeworkIntakeDraft.length === 0) {
            list.innerHTML = '<div class="health-no-intel">No homework added yet.</div>';
            return;
        }
        list.innerHTML = _homeworkIntakeDraft.map((task, idx) => `
            <div class="nb-subject-card" style="padding:10px 12px;margin-top:8px;">
                <strong>${_escHtml(task.subject || 'Homework')}</strong> · ${_escHtml(task.taskTitle || 'Untitled task')}
                <span class="type-pill type-homework">${_escHtml(task.hwType || 'homework')}</span>
                <span class="type-pill type-${_escHtml(task.priority || 'medium')}">${_escHtml(task.priority || 'medium')}</span>
                <button class="sp-btn sp-btn-danger" data-action="remove-intake-draft" data-index="${idx}" style="float:right;">×</button>
            </div>`).join('');
    }

    function _addHomeworkIntakeDraft({ clearAfter = true } = {}) {
        const task = _getHomeworkIntakeFieldData();
        if (!task.subject || !task.taskTitle) {
            _showToast('Add subject and homework title first.');
            return false;
        }
        _homeworkIntakeDraft.push(task);
        _renderHomeworkIntakeDraft();
        if (clearAfter) _clearHomeworkIntakeFields({ keepSubject: true });
        return true;
    }

    function _openDailyHomeworkIntakeModal() {
        const modal = _container?.querySelector('#nbDailyHomeworkModal');
        if (!modal) return;
        _homeworkIntakeDraft = [];
        _renderHomeworkIntakeDraft();
        _clearHomeworkIntakeFields({ keepSubject: false });
        modal.style.display = 'flex';
        setTimeout(() => _container?.querySelector('#nbIntakeSubject')?.focus(), 80);
    }

    function _closeDailyHomeworkIntakeModal() {
        const modal = _container?.querySelector('#nbDailyHomeworkModal');
        if (modal) modal.style.display = 'none';
    }

    function _saveDailyHomeworkIntake() {
        const fieldTask = _getHomeworkIntakeFieldData();
        if (fieldTask.subject && fieldTask.taskTitle) _homeworkIntakeDraft.push(fieldTask);

        const taskIds = _homeworkIntakeDraft.map(task => _addHomeworkTaskFromData(task).id);
        _saveTodayHomeworkIntake({ skipped: false, taskIds });
        _save();
        _closeDailyHomeworkIntakeModal();
        _activeCopyTab = 'hw';
        _fullSync();
        _dispatchNotebookUpdated({ action: 'daily_homework_intake_saved', taskIds });
        _showToast(taskIds.length > 0 ? "Today's homework saved." : 'Homework check-in completed.');
    }

    function _skipDailyHomeworkIntake() {
        _saveTodayHomeworkIntake({ skipped: true, taskIds: [] });
        _closeDailyHomeworkIntakeModal();
        _dispatchNotebookUpdated({ action: 'daily_homework_intake_skipped' });
        _showToast('Homework check-in skipped for today.');
    }

    // ════════════════════════════════════════════════════════
    //  NOTES DATA BRIDGE (Phase 7H-1)
    //  Separate storage key: nb_notes_v1
    //  Additive only — never touches notebook_matrix_data
    // ════════════════════════════════════════════════════════

    function generateNoteId() {
        return 'nbe_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
    }

    function _createEmptyNotesData() {
        return { version: 1, entries: [] };
    }

    function _loadNotesData() {
        try {
            const existing = SafeStorage.getItem(NOTES_STORAGE_KEY, null);
            if (existing && existing.version === 1 && Array.isArray(existing.entries)) {
                return existing;
            }
            const fresh = _createEmptyNotesData();
            SafeStorage.setItem(NOTES_STORAGE_KEY, fresh);
            console.log('[NotebooksRoute] Created fresh nb_notes_v1');
            return fresh;
        } catch (err) {
            console.warn('[NotebooksRoute] Notes data load failed, creating fresh:', err);
            const fresh = _createEmptyNotesData();
            try { SafeStorage.setItem(NOTES_STORAGE_KEY, fresh); } catch (e) { /* ignore */ }
            return fresh;
        }
    }

    function _saveNotesData(data) {
        try {
            SafeStorage.setItem(NOTES_STORAGE_KEY, data);
        } catch (err) {
            console.warn('[NotebooksRoute] Notes data save failed:', err);
        }
    }

    function _buildNoteRow(entry) {
        if (!entry || typeof entry !== 'object' || !entry.id) return null;

        const now = new Date().toISOString();
        return {
            note_id: entry.id,
            subject: entry.subject || '',
            chapter: entry.chapter || '',
            title: entry.title || '',
            content: entry.content || '',
            summary: entry.summary || '',
            tags: Array.isArray(entry.tags) ? entry.tags : [],
            revision_status: entry.revisionStatus || 'none',
            health_score: Number(entry.healthScore || 0),
            is_gold: !!entry.isGold,
            created_at: entry.createdAt || entry.updatedAt || now,
            updated_at: entry.updatedAt || now,
            raw_data: { ...entry },
            user_key: _getUserId() || ''
        };
    }

    function _isMissingNotebookNotesTableError(err) {
        const msg = String(err?.message || err?.details || err || '').toLowerCase();
        return msg.includes('notebook_notes') || msg.includes('schema cache') || msg.includes('does not exist') || msg.includes('column');
    }

    function _enqueueNoteUpsert(entry) {
        const row = _buildNoteRow(entry);
        if (!row) return;

        const sync = _getSyncManager();
        if (sync && typeof sync.enqueue === 'function') {
            try {
                sync.enqueue('notebook_notes', row, {
                    conflictKey: 'user_id,note_id',
                    statusKey: 'notebook_notes'
                });
                return;
            } catch (err) {
                console.warn('[NotebooksRoute] Note SyncManager enqueue failed, trying Supabase fallback:', err);
            }
        }

        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) return;

        window.supabaseClient
            .from('notebook_notes')
            .upsert({ ...row, user_id: userId }, { onConflict: 'user_id,note_id' })
            .then(result => {
                if (result.error) {
                    console.warn('[NotebooksRoute] notebook_notes upsert skipped:', result.error.message);
                }
            })
            .catch(err => console.warn('[NotebooksRoute] notebook_notes upsert unavailable:', err));
    }

    function _enqueueNoteDelete(noteId) {
        if (!noteId) return;

        const sync = _getSyncManager();
        if (sync && typeof sync.enqueueDelete === 'function') {
            try {
                sync.enqueueDelete('notebook_notes', { note_id: noteId }, {
                    conflictKey: 'user_id,note_id',
                    statusKey: 'notebook_notes'
                });
                return;
            } catch (err) {
                console.warn('[NotebooksRoute] Note delete SyncManager enqueue failed, trying Supabase fallback:', err);
            }
        }

        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) return;

        window.supabaseClient
            .from('notebook_notes')
            .delete()
            .eq('user_id', userId)
            .eq('note_id', noteId)
            .then(result => {
                if (result.error) {
                    console.warn('[NotebooksRoute] notebook_notes delete skipped:', result.error.message);
                }
            })
            .catch(err => console.warn('[NotebooksRoute] notebook_notes delete unavailable:', err));
    }

    function _cloudRowToNoteEntry(row) {
        const raw = row?.raw_data && typeof row.raw_data === 'object' ? row.raw_data : {};
        const entry = {
            ...raw,
            id: raw.id || row.note_id,
            title: row.title ?? raw.title ?? '',
            subject: row.subject ?? raw.subject ?? '',
            chapter: row.chapter ?? raw.chapter ?? '',
            content: row.content ?? raw.content ?? '',
            summary: row.summary ?? raw.summary ?? '',
            tags: Array.isArray(row.tags) ? row.tags : (Array.isArray(raw.tags) ? raw.tags : []),
            revisionStatus: row.revision_status ?? raw.revisionStatus ?? 'none',
            healthScore: Number(row.health_score ?? raw.healthScore ?? 0),
            isGold: row.is_gold ?? raw.isGold ?? false,
            createdAt: row.created_at || raw.createdAt || new Date().toISOString(),
            updatedAt: row.updated_at || raw.updatedAt || row.created_at || new Date().toISOString()
        };
        return entry.id ? entry : null;
    }

    function _mergeCloudNotes(rows) {
        if (!Array.isArray(rows) || rows.length === 0) return false;
        if (!_notes || !Array.isArray(_notes.entries)) _notes = _createEmptyNotesData();

        let merged = false;
        rows.forEach(row => {
            const cloudEntry = _cloudRowToNoteEntry(row);
            if (!cloudEntry) return;

            const localIndex = _notes.entries.findIndex(entry => entry.id === cloudEntry.id);
            if (localIndex === -1) {
                _notes.entries.push(cloudEntry);
                merged = true;
                return;
            }

            const localEntry = _notes.entries[localIndex];
            const localUpdated = new Date(localEntry.updatedAt || localEntry.createdAt || 0).getTime() || 0;
            const cloudUpdated = new Date(cloudEntry.updatedAt || cloudEntry.createdAt || 0).getTime() || 0;
            if (cloudUpdated > localUpdated) {
                _notes.entries[localIndex] = { ...localEntry, ...cloudEntry };
                merged = true;
            }
        });

        if (merged) _saveNotesData(_notes);
        return merged;
    }

    async function _loadNotesFromCloud() {
        const sync = _getSyncManager();
        if (sync && typeof sync.loadFromCloud === 'function') {
            try {
                const rows = await sync.loadFromCloud('notebook_notes', {
                    columns: '*',
                    statusKey: 'notebook_notes'
                });
                _mergeCloudNotes(rows || []);
                return;
            } catch (err) {
                console.warn('[NotebooksRoute] notebook_notes SyncManager load skipped:', err);
            }
        }

        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) return;

        try {
            const { data, error } = await window.supabaseClient
                .from('notebook_notes')
                .select('*')
                .eq('user_id', userId);

            if (error) {
                console.warn('[NotebooksRoute] notebook_notes cloud load skipped:', error.message);
                return;
            }
            _mergeCloudNotes(data || []);
        } catch (err) {
            console.warn('[NotebooksRoute] notebook_notes cloud load unavailable:', err);
        }
    }

    // ── Formula/Example detection keywords ──
    const _FORMULA_KEYWORDS = ['=', 'formula', 'equation', 'eq.', 'eq:', '∴', '→', '×', '÷', '±', '≈', '≠', '≤', '≥', '∝', '∑', '∫', 'π', 'θ', 'α', 'β', 'γ', 'Δ', '√'];
    const _EXAMPLE_KEYWORDS = ['example', 'ex:', 'ex.', 'e.g.', 'eg:', 'sample', 'illustration', 'demo', 'for instance', 'such as', 'like:'];

    function _calculateHealthScore(entry) {
        if (!entry) return 0;
        let score = 0;

        if (entry.title && entry.title.trim().length > 0) score += 15;

        const contentLen = (entry.content && typeof entry.content === 'string') ? entry.content.trim().length : 0;
        if (contentLen >= 200) score += 25;
        else if (contentLen >= 50) score += 15;
        else if (contentLen > 0) score += 5;

        if (entry.summary && entry.summary.trim().length > 0) score += 15;

        if (entry.content && typeof entry.content === 'string') {
            const lowerContent = entry.content.toLowerCase();
            if (_FORMULA_KEYWORDS.some(kw => lowerContent.includes(kw.toLowerCase()))) score += 8;
            if (_EXAMPLE_KEYWORDS.some(kw => lowerContent.includes(kw.toLowerCase()))) score += 7;
        }

        if (entry.lastReviewedAt) {
            try {
                const reviewedDate = new Date(entry.lastReviewedAt);
                const daysSinceReview = (Date.now() - reviewedDate.getTime()) / (1000 * 60 * 60 * 24);
                if (daysSinceReview <= 7) score += 15;
            } catch (e) { /* invalid date */ }
        }

        if (entry.subject && entry.subject.trim().length > 0) {
            if (_rows.some(r => r.subject && r.subject.trim().toLowerCase() === entry.subject.trim().toLowerCase())) {
                score += 10;
            }
        }

        if (entry.revisionStatus !== 'overdue') score += 5;

        return Math.min(100, Math.max(0, score));
    }

    function _recalcAllHealthScores() {
        if (!_notes || !Array.isArray(_notes.entries)) return false;
        let changed = false;
        _notes.entries.forEach(entry => {
            const newScore = _calculateHealthScore(entry);
            if (newScore !== entry.healthScore) {
                entry.healthScore = newScore;
                changed = true;
            }
        });
        return changed;
    }

    function _getHealthTier(score) {
        if (score >= 80) return { tier: 'strong',   label: 'COMBAT READY',       color: '#00ff9d' };
        if (score >= 60) return { tier: 'adequate', label: 'NEEDS POLISH',       color: '#00d4ff' };
        if (score >= 40) return { tier: 'weak',     label: 'UNDER-ARMED',        color: '#f59e0b' };
        return               { tier: 'critical', label: 'REQUIRES DEPLOYMENT', color: '#FF4C4C' };
    }

    // ════════════════════════════════════════════════════════
    //  PER-ROW HEALTH + REVISION (Phase 7H-3)
    // ════════════════════════════════════════════════════════

    function _getLinkedNotesForSubject(subjectName) {
        if (!_notes || !Array.isArray(_notes.entries) || !subjectName || !subjectName.trim()) return [];
        const lowerName = subjectName.trim().toLowerCase();
        return _notes.entries.filter(e => e.subject && e.subject.trim().toLowerCase() === lowerName);
    }

    function _getRowHealth(row) {
        const linkedNotes = _getLinkedNotesForSubject(row.subject);
        if (linkedNotes.length > 0) {
            const sum = linkedNotes.reduce((acc, e) => acc + (e.healthScore || 0), 0);
            const avgScore = Math.round(sum / linkedNotes.length);
            return { score: avgScore, tier: _getHealthTier(avgScore), hasIntel: true };
        }
        if (!row.subject || !row.subject.trim()) return { score: null, tier: null, hasIntel: false };
        let fallbackScore = 50;
        if (row.done) fallbackScore = 75;
        else if (row.incident) fallbackScore = Math.max(15, 35 - (row.delta || 0) * 2);
        return { score: fallbackScore, tier: _getHealthTier(fallbackScore), hasIntel: true };
    }

    function _getRowRevision(row) {
        const linkedNotes = _getLinkedNotesForSubject(row.subject);
        if (linkedNotes.length > 0) {
            const hasOverdue = linkedNotes.some(e => e.revisionStatus === 'overdue');
            const hasPending = linkedNotes.some(e => e.revisionStatus === 'pending');
            if (hasOverdue) return { status: 'OVERDUE',   cssClass: 'rev-overdue',   color: '#FF4C4C' };
            if (hasPending) return { status: 'PENDING',    cssClass: 'rev-pending',   color: '#f59e0b' };
            return { status: 'ON TRACK', cssClass: 'rev-ontrack', color: '#00ff9d' };
        }
        if (!row.subject || !row.subject.trim()) return { status: 'NO INTEL', cssClass: 'rev-nointel', color: '#444' };
        if (row.incident) return { status: 'PENDING',    cssClass: 'rev-pending',   color: '#f59e0b' };
        if (row.done) return { status: 'ON TRACK', cssClass: 'rev-ontrack', color: '#00ff9d' };
        return { status: 'PENDING', cssClass: 'rev-pending', color: '#f59e0b' };
    }

    // ════════════════════════════════════════════════════════
    //  NOTEBOOK METRICS (Phase 7H-2)
    // ════════════════════════════════════════════════════════

    function _computeNotebookMetrics() {
        const totalSubjects = _rows.length;
        const verifiedCount = _rows.filter(r => r.done).length;
        const incidentCount = _rows.filter(r => r.incident).length;
        const verifiedRate = totalSubjects > 0 ? Math.round((verifiedCount / totalSubjects) * 100) : 0;

        let avgHealth = null;
        let healthTier = null;

        if (_notes && Array.isArray(_notes.entries) && _notes.entries.length > 0) {
            const sum = _notes.entries.reduce((acc, e) => acc + (e.healthScore || 0), 0);
            avgHealth = Math.round(sum / _notes.entries.length);
        } else if (totalSubjects > 0) {
            let fallbackSum = 0;
            _rows.forEach(r => {
                if (r.done) fallbackSum += 75;
                else if (r.incident) fallbackSum += 25;
                else fallbackSum += 50;
            });
            avgHealth = Math.round(fallbackSum / totalSubjects);
        }

        if (avgHealth !== null) healthTier = _getHealthTier(avgHealth);

        return { totalSubjects, verifiedRate, incidentCount, avgHealth, healthTier };
    }

    function _updateNotebookMetricsUI() {
        if (!_container) return;
        const m = _computeNotebookMetrics();

        const totalEl = _container.querySelector('#nb-metric-total');
        if (totalEl) totalEl.textContent = m.totalSubjects;

        const verifiedEl = _container.querySelector('#nb-metric-verified');
        if (verifiedEl) verifiedEl.textContent = m.verifiedRate + '%';

        const incidentEl = _container.querySelector('#nb-metric-incident');
        if (incidentEl) incidentEl.textContent = m.incidentCount;

        const healthEl = _container.querySelector('#nb-metric-health');
        if (healthEl) healthEl.textContent = m.avgHealth !== null ? m.avgHealth : 'N/A';

        const verifiedCard = _container.querySelector('#nb-card-verified');
        if (verifiedCard) {
            verifiedCard.classList.remove('metric-accent-green', 'metric-accent-yellow', 'metric-accent-red');
            if (m.totalSubjects === 0) verifiedCard.classList.add('metric-accent-yellow');
            else if (m.verifiedRate >= 50) verifiedCard.classList.add('metric-accent-green');
            else if (m.verifiedRate >= 25) verifiedCard.classList.add('metric-accent-yellow');
            else verifiedCard.classList.add('metric-accent-red');
        }

        const incidentCard = _container.querySelector('#nb-card-incident');
        if (incidentCard) {
            incidentCard.classList.remove('metric-accent-green', 'metric-accent-red');
            incidentCard.classList.add(m.incidentCount === 0 ? 'metric-accent-green' : 'metric-accent-red');
        }

        const healthCard = _container.querySelector('#nb-card-health');
        if (healthCard) {
            healthCard.classList.remove('metric-accent-green', 'metric-accent-cyan', 'metric-accent-yellow', 'metric-accent-red');
            if (m.avgHealth === null) healthCard.classList.add('metric-accent-yellow');
            else if (m.avgHealth >= 80) healthCard.classList.add('metric-accent-green');
            else if (m.avgHealth >= 60) healthCard.classList.add('metric-accent-cyan');
            else if (m.avgHealth >= 40) healthCard.classList.add('metric-accent-yellow');
            else healthCard.classList.add('metric-accent-red');
        }

        const meterFill = _container.querySelector('#nb-health-fill');
        const meterScore = _container.querySelector('#nb-health-score-text');
        const meterTier = _container.querySelector('#nb-health-tier');
        const meterBar = _container.querySelector('#nb-health-bar');

        if (m.avgHealth !== null && m.healthTier) {
            if (meterFill) { meterFill.style.width = m.avgHealth + '%'; meterFill.style.background = `linear-gradient(90deg, ${m.healthTier.color}, ${m.healthTier.color}88)`; meterFill.style.boxShadow = `0 0 20px ${m.healthTier.color}55`; }
            if (meterScore) { meterScore.textContent = m.avgHealth; meterScore.style.color = m.healthTier.color; }
            if (meterTier) { meterTier.textContent = m.healthTier.label; meterTier.style.color = m.healthTier.color; meterTier.classList.remove('tier-strong', 'tier-adequate', 'tier-weak', 'tier-critical'); meterTier.classList.add('tier-' + m.healthTier.tier); }
            if (meterBar) { meterBar.style.borderColor = m.healthTier.color + '33'; }
        } else {
            if (meterFill) meterFill.style.width = '0%';
            if (meterScore) { meterScore.textContent = '--'; meterScore.style.color = '#555'; }
            if (meterTier) { meterTier.textContent = 'AWAITING DATA'; meterTier.style.color = '#555'; meterTier.classList.remove('tier-strong', 'tier-adequate', 'tier-weak', 'tier-critical'); }
        }
    }

    // ════════════════════════════════════════════════════════
    //  NOTE ENTRY CRUD (Phase 7H-4)
    // ════════════════════════════════════════════════════════

    function _openNoteModal(noteId) {
        const modal = _container?.querySelector('#nbNoteModal');
        if (!modal) return;

        _editingNoteId = noteId || null;

        const titleEl = _container.querySelector('#nbModalTitle');
        const saveBtnEl = _container.querySelector('#nbBtnSave');
        const editIdEl = _container.querySelector('#nbEditNoteId');

        _populateSubjectSelect();

        if (_editingNoteId) {
            const entry = _notes.entries.find(e => e.id === _editingNoteId);
            if (!entry) { _showToast('Note not found!'); return; }

            if (titleEl) titleEl.textContent = 'EDIT NOTE INTEL';
            if (saveBtnEl) saveBtnEl.textContent = 'UPDATE NOTE';
            if (editIdEl) editIdEl.value = _editingNoteId;

            const f = (id) => _container.querySelector('#' + id);
            if (f('nbNoteTitle')) f('nbNoteTitle').value = entry.title || '';
            if (f('nbNoteSubject')) f('nbNoteSubject').value = entry.subjectRowId || '';
            if (f('nbNoteChapter')) f('nbNoteChapter').value = entry.chapter || '';
            if (f('nbNoteContent')) f('nbNoteContent').value = entry.content || '';
            if (f('nbNoteSummary')) f('nbNoteSummary').value = entry.summary || '';
            if (f('nbNoteTags')) f('nbNoteTags').value = (entry.tags || []).join(', ');
            if (f('nbNoteRevision')) f('nbNoteRevision').value = entry.revisionStatus || 'none';
            if (f('nbNoteGold')) f('nbNoteGold').checked = entry.isGold || false;
        } else {
            if (titleEl) titleEl.textContent = 'DEPLOY NEW NOTE';
            if (saveBtnEl) saveBtnEl.textContent = 'DEPLOY NOTE';
            if (editIdEl) editIdEl.value = '';

            ['nbNoteTitle', 'nbNoteChapter', 'nbNoteContent', 'nbNoteSummary', 'nbNoteTags'].forEach(id => {
                const el = _container.querySelector('#' + id);
                if (el) el.value = '';
            });

            const subjectInput = _container.querySelector('#nbNoteSubject');
            if (subjectInput) subjectInput.value = '';
            const revisionInput = _container.querySelector('#nbNoteRevision');
            if (revisionInput) revisionInput.value = 'none';
            const goldInput = _container.querySelector('#nbNoteGold');
            if (goldInput) goldInput.checked = false;
        }

        modal.style.display = 'flex';
        setTimeout(() => { const t = _container?.querySelector('#nbNoteTitle'); if (t) t.focus(); }, 120);
    }

    function _closeNoteModal() {
        const modal = _container?.querySelector('#nbNoteModal');
        if (modal) modal.style.display = 'none';
        _editingNoteId = null;
    }

    function _populateSubjectSelect() {
        const select = _container?.querySelector('#nbNoteSubject');
        if (!select) return;
        select.innerHTML = '<option value="">— Select Subject —</option>';
        _rows.forEach(row => {
            if (row.subject && row.subject.trim()) {
                const opt = document.createElement('option');
                opt.value = row.id;
                opt.textContent = row.subject;
                select.appendChild(opt);
            }
        });
    }

    function _saveNote() {
        if (!_notes || !Array.isArray(_notes.entries)) return;

        const title = (_container.querySelector('#nbNoteTitle')?.value || '').trim();
        const subjectRowIdStr = _container.querySelector('#nbNoteSubject')?.value || '';
        const chapter = (_container.querySelector('#nbNoteChapter')?.value || '').trim();
        const content = _container.querySelector('#nbNoteContent')?.value || '';
        const summary = (_container.querySelector('#nbNoteSummary')?.value || '').trim();
        const tagsStr = (_container.querySelector('#nbNoteTags')?.value || '').trim();
        const revisionStatus = _container.querySelector('#nbNoteRevision')?.value || 'none';
        const isGold = _container.querySelector('#nbNoteGold')?.checked || false;

        if (!title) { _showToast('Title is required!'); _container.querySelector('#nbNoteTitle')?.focus(); return; }

        const tags = tagsStr ? tagsStr.split(',').map(t => t.trim()).filter(t => t.length > 0) : [];
        const subjectRowId = subjectRowIdStr ? parseInt(subjectRowIdStr) : null;
        const subjectRow = subjectRowId ? _rows.find(r => r.id === subjectRowId) : null;
        const subjectName = subjectRow ? subjectRow.subject : '';

        const lowerContent = content.toLowerCase();
        const hasFormulas = _FORMULA_KEYWORDS.some(kw => lowerContent.includes(kw.toLowerCase()));
        const hasExamples = _EXAMPLE_KEYWORDS.some(kw => lowerContent.includes(kw.toLowerCase()));

        if (_editingNoteId) {
            const entry = _notes.entries.find(e => e.id === _editingNoteId);
            if (!entry) { _showToast('Note not found!'); return; }

            entry.title = title;
            entry.subjectRowId = subjectRowId;
            entry.subject = subjectName;
            entry.chapter = chapter;
            entry.content = content;
            entry.summary = summary;
            entry.tags = tags;
            entry.revisionStatus = revisionStatus;
            entry.isGold = isGold;
            entry.hasFormulas = hasFormulas;
            entry.hasExamples = hasExamples;
            entry.type = subjectRow ? subjectRow.type : (entry.type || 'CLASSWORK');
            entry.updatedAt = new Date().toISOString();
            entry.healthScore = _calculateHealthScore(entry);

            _saveNotesData(_notes);
            _enqueueNoteUpsert(entry);
            _closeNoteModal();
            _fullSync();
            _dispatchNotebookUpdated({ action: 'note_saved', noteId: entry.id });
            _showToast('Note intel updated!');
        } else {
            const newEntry = {
                id: generateNoteId(),
                subjectRowId: subjectRowId,
                title: title,
                subject: subjectName,
                chapter: chapter,
                content: content,
                summary: summary,
                tags: tags,
                type: subjectRow ? subjectRow.type : 'CLASSWORK',
                healthScore: 0,
                revisionStatus: revisionStatus,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
                lastReviewedAt: null,
                isGold: isGold,
                hasFormulas: hasFormulas,
                hasExamples: hasExamples
            };

            newEntry.healthScore = _calculateHealthScore(newEntry);
            _notes.entries.push(newEntry);
            _saveNotesData(_notes);
            _enqueueNoteUpsert(newEntry);
            _closeNoteModal();
            _fullSync();
            _dispatchNotebookUpdated({ action: 'note_saved', noteId: newEntry.id });
            _showToast('Note deployed!');
        }
    }

    function _deleteNote(noteId) {
        if (!noteId || !_notes || !Array.isArray(_notes.entries)) return;
        if (!confirm('Delete this note? This action cannot be undone.')) return;

        const idx = _notes.entries.findIndex(e => e.id === noteId);
        if (idx === -1) { _showToast('Note not found!'); return; }

        _notes.entries.splice(idx, 1);
        _saveNotesData(_notes);
        _enqueueNoteDelete(noteId);
        if (_editingNoteId === noteId) _closeNoteModal();
        _fullSync();
        _dispatchNotebookUpdated({ action: 'note_deleted', noteId });
        _showToast('Note deleted.');
    }

    // ════════════════════════════════════════════════════════
    //  QUICK ACTIONS (Phase 7H-5)
    //  Mark Reviewed / Pending / Overdue / Strengthen
    // ════════════════════════════════════════════════════════

    function _markNoteReviewed(noteId) {
        const entry = _notes?.entries?.find(e => e.id === noteId);
        if (!entry) return;
        entry.lastReviewedAt = new Date().toISOString();
        entry.revisionStatus = 'none';
        entry.updatedAt = new Date().toISOString();
        entry.healthScore = _calculateHealthScore(entry);
        _saveNotesData(_notes);
        _enqueueNoteUpsert(entry);
        _fullSync();
        _dispatchNotebookUpdated({ action: 'note_reviewed', noteId });
        _showToast('Marked as reviewed!');
    }

    function _markNotePending(noteId) {
        const entry = _notes?.entries?.find(e => e.id === noteId);
        if (!entry) return;
        entry.revisionStatus = 'pending';
        entry.updatedAt = new Date().toISOString();
        entry.healthScore = _calculateHealthScore(entry);
        _saveNotesData(_notes);
        _enqueueNoteUpsert(entry);
        _fullSync();
        _dispatchNotebookUpdated({ action: 'note_pending', noteId });
        _showToast('Marked as pending.');
    }

    function _markNoteOverdue(noteId) {
        const entry = _notes?.entries?.find(e => e.id === noteId);
        if (!entry) return;
        entry.revisionStatus = 'overdue';
        entry.updatedAt = new Date().toISOString();
        entry.healthScore = _calculateHealthScore(entry);
        _saveNotesData(_notes);
        _enqueueNoteUpsert(entry);
        _fullSync();
        _dispatchNotebookUpdated({ action: 'note_overdue', noteId });
        _showToast('Marked as overdue.');
    }

    // ════════════════════════════════════════════════════════
    //  MISSING REASONS DIAGNOSTIC (Phase 7H-5)
    //  Returns array of reason strings for why a note is weak
    // ════════════════════════════════════════════════════════

    function _getMissingReasons(entry) {
        if (!entry) return [];
        const reasons = [];

        // No summary
        if (!entry.summary || !entry.summary.trim()) {
            reasons.push('No summary');
        }

        // Content too short
        const contentLen = (entry.content && typeof entry.content === 'string') ? entry.content.trim().length : 0;
        if (contentLen < 50) {
            reasons.push('Content too short');
        }

        // No formulas
        if (!entry.hasFormulas) {
            const hasFormula = entry.content && typeof entry.content === 'string' &&
                _FORMULA_KEYWORDS.some(kw => entry.content.toLowerCase().includes(kw.toLowerCase()));
            if (!hasFormula) reasons.push('No formulas');
        }

        // No examples
        if (!entry.hasExamples) {
            const hasExample = entry.content && typeof entry.content === 'string' &&
                _EXAMPLE_KEYWORDS.some(kw => entry.content.toLowerCase().includes(kw.toLowerCase()));
            if (!hasExample) reasons.push('No examples');
        }

        // Not reviewed
        if (!entry.lastReviewedAt) {
            reasons.push('Not reviewed');
        } else {
            try {
                const daysSinceReview = (Date.now() - new Date(entry.lastReviewedAt).getTime()) / (1000 * 60 * 60 * 24);
                if (daysSinceReview > 7) reasons.push('Not reviewed recently');
            } catch (e) { reasons.push('Not reviewed'); }
        }

        // No subject link
        if (!entry.subject || !entry.subject.trim()) {
            reasons.push('No subject link');
        } else {
            const linked = _rows.some(r => r.subject && r.subject.trim().toLowerCase() === entry.subject.trim().toLowerCase());
            if (!linked) reasons.push('Subject not in matrix');
        }

        return reasons;
    }

    // ════════════════════════════════════════════════════════
    //  INTELLIGENCE SECTIONS RENDERING (Phase 7H-5)
    // ════════════════════════════════════════════════════════

    /**
     * _renderIntelligenceSections — master render for all intelligence sections
     */
    function _renderIntelligenceSections() {
        _renderSubjectOverview();
        _renderRevisionPending();
        _renderWeakNotes();
        _renderRecentNotes();
    }

    /**
     * _renderSubjectOverview — per-subject health cards
     */
    function _renderSubjectOverview() {
        const grid = _container?.querySelector('#nbSubjectGrid');
        if (!grid) return;

        const validRows = _rows.filter(row => row && typeof row.subject === 'string' && row.subject.trim().length > 0);
        if (validRows.length === 0) {
            grid.innerHTML = `<div class="nb-empty-state sp-empty-state"><span class="sp-empty-state-icon">📓</span><h3 class="sp-empty-state-title">No Subject Intel Yet</h3><p class="sp-empty-state-text">Add a named C.W. copy or H.W. task to unlock subject overview.</p></div>`;
            return;
        }

        grid.innerHTML = validRows.map(row => {
            const linked = _getLinkedNotesForSubject(row.subject);
            const health = _getRowHealth(row);
            const subjectName = _escHtml(row.subject.trim());

            const noteCount = linked.length;
            const avgHealth = health.hasIntel && health.score !== null ? health.score : null;
            const tier = health.tier;
            const verifiedBadge = row.done ? '<span class="nb-subject-verified">VERIFIED</span>' : '';
            const incidentBadge = row.incident ? '<span class="nb-subject-incident">INCIDENT</span>' : '';

            let healthBarHTML = '';
            if (avgHealth !== null && tier) {
                healthBarHTML = `
                    <div class="nb-subject-health">
                        <div class="nb-subject-health-bar">
                            <div class="nb-subject-health-fill" style="width:${avgHealth}%; background:${tier.color};"></div>
                        </div>
                        <span class="nb-subject-health-score" style="color:${tier.color};">${avgHealth}</span>
                    </div>`;
            } else {
                healthBarHTML = `<div class="nb-subject-health"><span class="nb-subject-no-notes">NO NOTES</span></div>`;
            }

            return `
            <div class="nb-subject-card">
                <div class="nb-subject-header">
                    <span class="nb-subject-name">${subjectName}</span>
                    <div class="nb-subject-badges">
                        ${verifiedBadge}${incidentBadge}
                    </div>
                </div>
                <div class="nb-subject-meta">
                    <span class="nb-subject-note-count">${noteCount} note${noteCount !== 1 ? 's' : ''}</span>
                    <span class="nb-subject-type">${row.type || 'CLASSWORK'}</span>
                </div>
                ${healthBarHTML}
            </div>`;
        }).join('');
    }

    /**
     * _renderRevisionPending — overdue + pending notes, sorted by urgency then weakest health
     */
    function _renderRevisionPending() {
        const grid = _container?.querySelector('#nbRevisionGrid');
        const countEl = _container?.querySelector('#nbRevisionCount');
        if (!grid) return;

        const entries = _notes?.entries || [];
        const pending = entries.filter(e => e.revisionStatus === 'overdue' || e.revisionStatus === 'pending');

        if (countEl) countEl.textContent = pending.length;

        if (pending.length === 0) {
            grid.innerHTML = `<div class="nb-empty-state sp-empty-state"><span class="sp-empty-state-icon">✅</span><h3 class="sp-empty-state-title">All Notes On Track</h3><p class="sp-empty-state-text">No revision pending. Everything is combat-ready.</p></div>`;
            return;
        }

        // Sort: overdue first, then weakest health first
        const sorted = [...pending].sort((a, b) => {
            if (a.revisionStatus === 'overdue' && b.revisionStatus !== 'overdue') return -1;
            if (a.revisionStatus !== 'overdue' && b.revisionStatus === 'overdue') return 1;
            return (a.healthScore || 0) - (b.healthScore || 0);
        });

        grid.innerHTML = sorted.map(entry => {
            const tier = _getHealthTier(entry.healthScore || 0);
            const revClass = entry.revisionStatus === 'overdue' ? 'rev-overdue' : 'rev-pending';
            const revLabel = entry.revisionStatus === 'overdue' ? 'OVERDUE' : 'PENDING';
            const timeAgo = _formatTimeAgo(entry.updatedAt);
            const reviewedInfo = entry.lastReviewedAt ? `Reviewed ${_formatTimeAgo(entry.lastReviewedAt)}` : 'Never reviewed';

            return `
            <div class="nb-intel-card">
                <div class="nb-intel-card-top">
                    <span class="nb-intel-card-title">${_escHtml(entry.title || 'Untitled')}</span>
                    <span class="revision-badge ${revClass}">${revLabel}</span>
                </div>
                <div class="nb-intel-card-meta">
                    <span class="nb-intel-card-subject">${_escHtml(entry.subject || 'No Subject')}</span>
                    ${entry.chapter ? `<span class="nb-intel-card-chapter">${_escHtml(entry.chapter)}</span>` : ''}
                </div>
                <div class="nb-intel-card-stats">
                    <span class="nb-intel-card-health" style="color:${tier.color};">${entry.healthScore || 0} ${tier.label}</span>
                    <span class="nb-intel-card-time">${reviewedInfo}</span>
                </div>
                <div class="nb-intel-card-actions">
                    <button class="nb-quick-btn nb-quick-reviewed" data-action="mark-note-reviewed" data-note-id="${entry.id}">MARK REVIEWED</button>
                    <button class="nb-quick-btn nb-quick-edit" data-action="edit-note" data-note-id="${entry.id}">EDIT</button>
                </div>
            </div>`;
        }).join('');
    }

    /**
     * _renderWeakNotes — health < 40 with missing reason diagnostics
     */
    function _renderWeakNotes() {
        const grid = _container?.querySelector('#nbWeakGrid');
        const countEl = _container?.querySelector('#nbWeakCount');
        if (!grid) return;

        const entries = _notes?.entries || [];
        const weak = entries.filter(e => (e.healthScore || 0) < 40);

        if (countEl) countEl.textContent = weak.length;

        if (weak.length === 0) {
            grid.innerHTML = `<div class="nb-empty-state sp-empty-state"><span class="sp-empty-state-icon">💪</span><h3 class="sp-empty-state-title">No Weak Notes</h3><p class="sp-empty-state-text">All notes are combat-ready or adequate. Stay sharp.</p></div>`;
            return;
        }

        // Sort by weakest first
        const sorted = [...weak].sort((a, b) => (a.healthScore || 0) - (b.healthScore || 0));

        grid.innerHTML = sorted.map(entry => {
            const tier = _getHealthTier(entry.healthScore || 0);
            const reasons = _getMissingReasons(entry);
            const reasonsHTML = reasons.length > 0
                ? `<div class="nb-missing-reasons">${reasons.map(r => `<span class="nb-missing-tag">${r}</span>`).join('')}</div>`
                : '';

            return `
            <div class="nb-intel-card nb-weak-card">
                <div class="nb-intel-card-top">
                    <span class="nb-intel-card-title">${_escHtml(entry.title || 'Untitled')}</span>
                    <span class="nb-intel-card-health" style="color:${tier.color};">${entry.healthScore || 0}</span>
                </div>
                <div class="nb-intel-card-meta">
                    <span class="nb-intel-card-subject">${_escHtml(entry.subject || 'No Subject')}</span>
                </div>
                <div class="nb-intel-card-tier" style="color:${tier.color};">${tier.label}</div>
                ${reasonsHTML}
                <div class="nb-intel-card-actions">
                    <button class="nb-quick-btn nb-quick-strengthen" data-action="strengthen-note" data-note-id="${entry.id}">STRENGTHEN</button>
                    <button class="nb-quick-btn nb-quick-edit" data-action="edit-note" data-note-id="${entry.id}">EDIT</button>
                </div>
            </div>`;
        }).join('');
    }

    /**
     * _renderRecentNotes — latest 5 notes with health tier dot, subject/chapter, edit
     */
    function _renderRecentNotes() {
        const grid = _container?.querySelector('#nbRecentGrid');
        const countEl = _container?.querySelector('#nbRecentCount');
        if (!grid) return;

        const entries = _notes?.entries || [];
        if (countEl) countEl.textContent = entries.length;

        if (entries.length === 0) {
            grid.innerHTML = `<div class="nb-empty-state sp-empty-state"><span class="sp-empty-state-icon">📝</span><h3 class="sp-empty-state-title">No Notes Deployed</h3><p class="sp-empty-state-text">Deploy your first note to begin intelligence tracking.</p></div>`;
            return;
        }

        // Sort by updatedAt descending, take latest 5
        const sorted = [...entries].sort((a, b) => {
            const da = a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
            const db = b.updatedAt ? new Date(b.updatedAt).getTime() : 0;
            return db - da;
        }).slice(0, 5);

        grid.innerHTML = sorted.map(entry => {
            const tier = _getHealthTier(entry.healthScore || 0);
            const timeAgo = _formatTimeAgo(entry.updatedAt);

            return `
            <div class="nb-recent-item">
                <div class="nb-recent-dot" style="background:${tier.color}; box-shadow:0 0 6px ${tier.color}55;"></div>
                <div class="nb-recent-info">
                    <span class="nb-recent-title">${_escHtml(entry.title || 'Untitled')}</span>
                    <span class="nb-recent-meta">${_escHtml(entry.subject || 'No Subject')}${entry.chapter ? ' / ' + _escHtml(entry.chapter) : ''}</span>
                </div>
                <span class="nb-recent-time">${timeAgo}</span>
                <button class="nb-quick-btn nb-quick-edit nb-quick-edit-sm" data-action="edit-note" data-note-id="${entry.id}">EDIT</button>
            </div>`;
        }).join('');
    }

    // ════════════════════════════════════════════════════════
    //  UTILITY
    // ════════════════════════════════════════════════════════

    function _formatTimeAgo(isoString) {
        if (!isoString) return 'Unknown';
        try {
            const date = new Date(isoString);
            const diffMs = Date.now() - date.getTime();
            const diffMin = Math.floor(diffMs / 60000);
            const diffHr = Math.floor(diffMs / 3600000);
            const diffDay = Math.floor(diffMs / 86400000);
            if (diffMin < 1) return 'Just now';
            if (diffMin < 60) return diffMin + 'm ago';
            if (diffHr < 24) return diffHr + 'h ago';
            if (diffDay < 30) return diffDay + 'd ago';
            return date.toLocaleDateString();
        } catch (e) { return 'Unknown'; }
    }

    function _escHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    // ════════════════════════════════════════════════════════
    //  HTML RENDERING
    // ════════════════════════════════════════════════════════

    function renderFullUI() {
        return `
        <div class="notebook-container nb-command-center">
            <div class="matrix-header">
                <div>
                    <h1 class="nb-page-title">Notebook Command Center</h1>
                    <p class="nb-page-subtitle">Classwork, homework, and notes — organized for execution.</p>
                </div>
                <div class="nb-header-actions">
                    <button class="deploy-note-btn nb-btn nb-btn-ghost" data-action="deploy-note" id="nbVaultAddNoteBtn">+ DEPLOY NEW NOTE</button>
                    <button class="add-btn nb-btn nb-btn-primary" data-action="add-row" id="nbAddCopyRow">+ ADD C.W. COPY</button>
                </div>
            </div>

            <div class="nb-copy-tabs" style="display:flex;gap:10px;margin:14px 0 18px;flex-wrap:wrap;">
                <button class="add-btn nb-btn nb-btn-secondary nb-copy-tab active" data-action="switch-copy-tab" data-tab="cw" id="nbTabCw">C.W. Copy</button>
                <button class="add-btn nb-btn nb-btn-secondary nb-copy-tab" data-action="switch-copy-tab" data-tab="hw" id="nbTabHw">H.W. Missions</button>
                <button class="add-btn nb-btn nb-btn-secondary nb-copy-tab" data-action="switch-copy-tab" data-tab="notes" id="nbTabNotes">Notes Vault</button>
            </div>

            <div class="nb-metrics-strip">
                <div class="nb-metric-card metric-accent-yellow" id="nb-card-cw-risk">
                    <span class="nb-metric-label">C.W. Risk</span>
                    <span class="nb-metric-value" id="nb-summary-cw-risk">0</span>
                </div>
                <div class="nb-metric-card metric-accent-red" id="nb-card-hw-pending">
                    <span class="nb-metric-label">H.W. Pending</span>
                    <span class="nb-metric-value" id="nb-summary-hw-pending">0</span>
                </div>
                <div class="nb-metric-card metric-accent-cyan" id="nb-card-notes-review">
                    <span class="nb-metric-label">Notes to Review</span>
                    <span class="nb-metric-value" id="nb-summary-notes-review">0</span>
                </div>
                <div class="nb-metric-card metric-accent-green" id="nb-card-score">
                    <span class="nb-metric-label">Notebook Score</span>
                    <span class="nb-metric-value" id="nb-summary-score">--</span>
                </div>
            </div>

            <div class="nb-directive-card nb-directive-risk-safe" id="nbDirectiveCard">
                <div class="nb-directive-left">
                    <div class="nb-directive-header">
                        <span class="nb-directive-label">NOTEBOOK DIRECTIVE</span>
                        <span class="nb-directive-risk-label">SAFE</span>
                    </div>
                    <div class="nb-directive-title">All notebook systems stable.</div>
                    <div class="nb-directive-meta">
                        <span class="nb-directive-why">No urgent C.W., H.W., or note review pending.</span>
                        <span class="nb-directive-subject" style="display:none;"></span>
                    </div>
                </div>
                <div class="nb-directive-right">
                    <div class="nb-directive-stats">
                        <span class="nb-directive-source">System</span>
                        <span class="nb-directive-eta">&mdash;</span>
                    </div>
                    <div class="nb-directive-actions">
                        <button class="nb-directive-action-btn nb-dir-btn-primary" data-action="directive-action" type="button">Review Notebook</button>
                        <button class="nb-dir-btn-backlog" data-action="directive-backlog" type="button" style="display:none;">Backlog</button>
                        <button class="nb-dir-btn-done" data-action="directive-done" type="button">Mark Done</button>
                    </div>
                </div>
            </div>

            <div id="nbCommandBody" class="nb-command-body"></div>

            <div class="nb-note-modal-overlay" id="nbNoteModal" style="display:none;align-items:center;justify-content:center;">
                <div class="nb-note-modal-card">
                    <div class="nb-modal-header">
                        <h2 id="nbModalTitle">DEPLOY NEW NOTE</h2>
                        <button class="nb-modal-close" data-action="close-note-modal">×</button>
                    </div>
                    <input type="hidden" id="nbEditNoteId" value="">
                    <div class="nb-modal-body">
                        <div class="nb-field"><label for="nbNoteTitle">Title</label><input type="text" id="nbNoteTitle" placeholder="Note title..." autocomplete="off"></div>
                        <div class="nb-field-row">
                            <div class="nb-field nb-field-half"><label for="nbNoteSubject">Subject</label><select id="nbNoteSubject"><option value="">— Select Subject —</option></select></div>
                            <div class="nb-field nb-field-half"><label for="nbNoteChapter">Chapter</label><input type="text" id="nbNoteChapter" placeholder="e.g. Ch 7" autocomplete="off"></div>
                        </div>
                        <div class="nb-field"><label for="nbNoteContent">Content</label><textarea id="nbNoteContent" rows="6" placeholder="Your notes..."></textarea></div>
                        <div class="nb-field"><label for="nbNoteSummary">Summary</label><textarea id="nbNoteSummary" rows="3" placeholder="Brief summary..."></textarea></div>
                        <div class="nb-field"><label for="nbNoteTags">Tags (comma-separated)</label><input type="text" id="nbNoteTags" placeholder="formula, important, exam" autocomplete="off"></div>
                        <div class="nb-field-row">
                            <div class="nb-field nb-field-half"><label for="nbNoteRevision">Revision Status</label><select id="nbNoteRevision"><option value="none">None</option><option value="pending">Pending</option><option value="overdue">Overdue</option></select></div>
                            <div class="nb-field nb-field-half nb-field-check"><label for="nbNoteGold">Gold Note</label><div class="nb-checkbox-wrap"><input type="checkbox" id="nbNoteGold"><span class="nb-checkbox-label">Mark as priority</span></div></div>
                        </div>
                    </div>
                    <div class="nb-modal-footer">
                        <button class="nb-btn-cancel" data-action="close-note-modal">CANCEL</button>
                        <button class="nb-btn-save" id="nbBtnSave" data-action="save-note">DEPLOY NOTE</button>
                    </div>
                </div>
            </div>

            <div class="nb-note-modal-overlay nb-homework-modal" id="nbDailyHomeworkModal" style="display:none;align-items:center;justify-content:center;">
                <div class="nb-note-modal-card nb-homework-modal-card" style="max-width:640px;">
                    <div class="nb-modal-header"><div><h2>Daily Homework Intake</h2><p class="nb-page-subtitle" style="margin:4px 0 0;">Aaj kya homework mila?</p></div><button class="nb-modal-close" data-action="skip-homework-intake">×</button></div>
                    <div class="nb-modal-body">
                        <div class="nb-field-row"><div class="nb-field nb-field-half"><label for="nbIntakeSubject">Subject</label><input type="text" id="nbIntakeSubject" placeholder="e.g. Science" autocomplete="off"></div><div class="nb-field nb-field-half"><label for="nbIntakeDueDate">Due Date</label><input type="date" id="nbIntakeDueDate"></div></div>
                        <div class="nb-field"><label for="nbIntakeTaskTitle">Homework / Task Title</label><input type="text" id="nbIntakeTaskTitle" placeholder="e.g. Complete exercise 5.1" autocomplete="off"></div>
                        <div class="nb-field-row"><div class="nb-field nb-field-half"><label for="nbIntakeType">Type</label><select id="nbIntakeType"><option value="homework">Homework</option><option value="practice">Practice</option><option value="rough work">Rough Work</option><option value="assignment">Assignment</option><option value="project">Project</option><option value="revision task">Revision Task</option></select></div><div class="nb-field nb-field-half"><label for="nbIntakePriority">Priority</label><select id="nbIntakePriority"><option value="low">Low</option><option value="medium" selected>Medium</option><option value="high">High</option></select></div></div>
                        <div class="nb-field-row"><div class="nb-field nb-field-half"><label for="nbIntakeEstimatedMinutes">Estimated Minutes</label><select id="nbIntakeEstimatedMinutes"><option value="10">10</option><option value="20">20</option><option value="30" selected>30</option><option value="45">45</option><option value="60">60</option><option value="custom">Custom</option></select></div><div class="nb-field nb-field-half"><label for="nbIntakeEstimatedCustom">Custom Minutes</label><input type="number" min="0" id="nbIntakeEstimatedCustom" placeholder="Only if custom"></div></div>
                        <div id="nbIntakeDraftList" class="nb-intel-section-grid"></div>
                    </div>
                    <div class="nb-modal-footer" style="gap:8px;flex-wrap:wrap;"><button class="nb-btn-cancel" data-action="skip-homework-intake">SKIP TODAY</button><button class="sp-btn sp-btn-secondary" data-action="add-homework-intake-task">ADD TASK</button><button class="sp-btn sp-btn-secondary" data-action="add-another-homework-intake-task">ADD ANOTHER</button><button class="nb-btn-save" data-action="save-homework-intake">SAVE TODAY'S HOMEWORK</button></div>
                </div>
            </div>

            <div class="nb-note-modal-overlay nb-hw-task-modal" id="nbHwTaskModal" style="display:none;align-items:center;justify-content:center;">
                <div class="nb-note-modal-card nb-hw-modal-card" style="max-width:560px;">
                    <div class="nb-modal-header"><h2 id="nbHwModalTitle">ADD H.W. TASK</h2><button class="nb-modal-close" data-action="close-hw-modal">×</button></div>
                    <div class="nb-modal-body">
                        <div class="nb-field-row"><div class="nb-field nb-field-half"><label for="nbHwSubject">Subject</label><input type="text" id="nbHwSubject" placeholder="e.g. Maths" autocomplete="off"></div><div class="nb-field nb-field-half"><label for="nbHwDueDate">Due Date</label><input type="date" id="nbHwDueDate"></div></div>
                        <div class="nb-field"><label for="nbHwTaskTitle">Homework / Task</label><input type="text" id="nbHwTaskTitle" placeholder="e.g. Exercise 4.2 Q1-Q10" autocomplete="off"></div>
                        <div class="nb-field-row"><div class="nb-field nb-field-half"><label for="nbHwType">Type</label><select id="nbHwType"><option value="homework">Homework</option><option value="practice">Practice</option><option value="rough work">Rough Work</option><option value="assignment">Assignment</option><option value="project">Project</option><option value="revision task">Revision Task</option></select></div><div class="nb-field nb-field-half"><label for="nbHwPriority">Priority</label><select id="nbHwPriority"><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></div></div>
                        <div class="nb-field-row"><div class="nb-field nb-field-half"><label for="nbHwEstimatedMinutes">Estimated Minutes</label><select id="nbHwEstimatedMinutes"><option value="10">10</option><option value="20">20</option><option value="30" selected>30</option><option value="45">45</option><option value="60">60</option><option value="custom">Custom</option></select></div><div class="nb-field nb-field-half"><label for="nbHwEstimatedCustom">Custom Minutes</label><input type="number" min="0" id="nbHwEstimatedCustom" placeholder="Only if custom"></div></div>
                        <div class="nb-field"><label for="nbHwStatus">Status</label><select id="nbHwStatus"><option value="pending">Pending</option><option value="done">Done</option><option value="overdue">Overdue</option></select></div>
                    </div>
                    <div class="nb-modal-footer"><button class="nb-btn-danger" id="nbHwDeleteBtn" data-action="delete-current-hw-task" style="display:none;">DELETE</button><button class="nb-btn-cancel" data-action="close-hw-modal">CANCEL</button><button class="nb-btn-save" data-action="save-hw-task">SAVE H.W. TASK</button></div>
                </div>
            </div>


            <div class="nb-note-modal-overlay nb-cw-update-modal" id="nbCwUpdateModal" style="display:none;align-items:center;justify-content:center;">
                <div class="nb-note-modal-card nb-cw-update-card" style="max-width:620px;">
                    <div class="nb-modal-header"><h2 id="nbCwUpdateTitle">UPDATE C.W. COPY</h2><button class="nb-modal-close" data-action="close-cw-update">×</button></div>
                    <div class="nb-modal-body">
                        <div class="nb-field-row"><div class="nb-field nb-field-half"><label for="nbCwUpdateSubject">Subject</label><input type="text" id="nbCwUpdateSubject" placeholder="e.g. Chemistry" autocomplete="off"></div><div class="nb-field nb-field-half"><label for="nbCwUpdateChapter">Linked Chapter</label><input type="text" id="nbCwUpdateChapter" placeholder="Optional" autocomplete="off"></div></div>
                        <div class="nb-field-row"><div class="nb-field nb-field-half"><label for="nbCwUpdateStatus">Status</label><select id="nbCwUpdateStatus"><option value="complete">Complete</option><option value="pending">Pending</option><option value="incident">Incident</option></select></div><div class="nb-field nb-field-half"><label for="nbCwUpdatePendingPages">Pending Pages</label><input type="number" min="0" id="nbCwUpdatePendingPages" placeholder="0"></div></div>
                        <div class="nb-field-row"><div class="nb-field nb-field-half"><label for="nbCwUpdateTeacherChecked">Teacher Checked</label><select id="nbCwUpdateTeacherChecked"><option value="no">No</option><option value="yes">Yes</option></select></div><div class="nb-field nb-field-half"><label for="nbCwUpdateEstimatedMinutes">Estimated Minutes</label><input type="number" min="0" id="nbCwUpdateEstimatedMinutes" placeholder="25"></div></div>
                        <div class="nb-field-row"><div class="nb-field nb-field-half"><label for="nbCwUpdateDeadlineDate">Deadline Date</label><input type="date" id="nbCwUpdateDeadlineDate"></div><div class="nb-field nb-field-half"><label for="nbCwUpdateDeadlineType">Deadline Type</label><select id="nbCwUpdateDeadlineType"><option value="self">Self</option><option value="teacher">Teacher</option><option value="exam">Exam</option></select></div></div>
                        <div class="nb-field nb-field-check nb-cw-backlog-toggle"><label for="nbCwUpdateSendBacklog">Backlog Link</label><div class="nb-checkbox-wrap"><input type="checkbox" id="nbCwUpdateSendBacklog"><span class="nb-checkbox-label">Send incomplete copy work to Backlog</span></div></div>
                    </div>
                    <div class="nb-modal-footer"><button class="nb-btn-cancel" data-action="close-cw-update">CANCEL</button><button class="nb-btn-save" data-action="save-cw-update">SAVE COPY STATUS</button></div>
                </div>
            </div>


            <div class="nb-note-modal-overlay nb-chapter-sheet-overlay" id="nbCwChapterModal" style="display:none;align-items:center;justify-content:center;">
                <div class="nb-note-modal-card nb-chapter-sheet" style="max-width:620px;">
                    <!-- HEADER -->
                    <div class="nb-ch-header">
                        <div class="nb-ch-header-left">
                            <h2 id="nbCwChapterModalTitle">Custom Chapter Setup</h2>
                            <p class="nb-ch-subtitle">Create a manual notebook chapter entry.</p>
                        </div>
                        <button class="nb-ch-close" data-action="close-cw-chapter" type="button">&times;</button>
                    </div>

                    <div class="nb-ch-body">
                        <!-- SECTION 1: CHAPTER IDENTITY -->
                        <div class="nb-ch-sec">
                            <div class="nb-ch-sec-label">Chapter Identity</div>
                            <div class="nb-ch-name-row">
                                <div class="nb-ch-field nb-ch-field-grow">
                                    <input type="text" id="nbCwChapterName" placeholder="Enter custom chapter name" autocomplete="off">
                                </div>
                                <div class="nb-ch-field nb-ch-field-order">
                                    <label for="nbCwChapterOrder">#</label>
                                    <input type="number" min="1" id="nbCwChapterOrder" placeholder="1">
                                </div>
                            </div>
                            <div class="nb-ch-subject-tag" id="nbCwChapterSubjectDisplay">—</div>
                        </div>

                        <!-- SECTION 2: PROGRESS STATE -->
                        <div class="nb-ch-sec">
                            <div class="nb-ch-sec-label">Progress State</div>
                            <div class="nb-ch-seg" id="nbCwChapterStatusPills">
                                <button class="nb-ch-seg-btn not_started" data-action="select-chapter-status" data-value="not_started" type="button">Not Started</button>
                                <button class="nb-ch-seg-btn current" data-action="select-chapter-status" data-value="current" type="button">Current</button>
                                <button class="nb-ch-seg-btn incomplete" data-action="select-chapter-status" data-value="incomplete" type="button">Incomplete</button>
                                <button class="nb-ch-seg-btn complete" data-action="select-chapter-status" data-value="complete" type="button">Complete</button>
                            </div>
                            <input type="hidden" id="nbCwChapterStatus" value="not_started">
                            <div class="nb-ch-pair">
                                <div class="nb-ch-field">
                                    <label for="nbCwChapterPendingPages">Pending Pages</label>
                                    <input type="number" min="0" id="nbCwChapterPendingPages" placeholder="0">
                                </div>
                                <div class="nb-ch-field">
                                    <label for="nbCwChapterEstimatedMinutes">Estimated Minutes</label>
                                    <input type="number" min="0" id="nbCwChapterEstimatedMinutes" placeholder="25">
                                </div>
                            </div>
                            <div class="nb-ch-eta-chips">
                                <button class="nb-ch-eta-chip" data-action="set-chapter-eta" data-minutes="10" type="button">10m</button>
                                <button class="nb-ch-eta-chip" data-action="set-chapter-eta" data-minutes="20" type="button">20m</button>
                                <button class="nb-ch-eta-chip" data-action="set-chapter-eta" data-minutes="30" type="button">30m</button>
                                <button class="nb-ch-eta-chip" data-action="set-chapter-eta" data-minutes="45" type="button">45m</button>
                                <button class="nb-ch-eta-chip" data-action="set-chapter-eta" data-minutes="60" type="button">60m</button>
                            </div>
                        </div>

                        <!-- SECTION 3: EXECUTION SETTINGS -->
                        <div class="nb-ch-sec">
                            <div class="nb-ch-sec-label">Execution Settings</div>
                            <div class="nb-ch-field">
                                <label for="nbCwChapterDeadline">Deadline</label>
                                <input type="date" id="nbCwChapterDeadline">
                                <div class="nb-ch-deadline-hint" id="nbCwChapterDeadlineHelper">No deadline set</div>
                            </div>
                            <div class="nb-ch-toggles">
                                <div class="nb-ch-toggle-row">
                                    <div class="nb-ch-toggle-info">
                                        <span class="nb-ch-toggle-name">Teacher Checked</span>
                                        <span class="nb-ch-toggle-desc">Verified by teacher</span>
                                    </div>
                                    <div class="nb-ch-toggle" data-action="toggle-teacher-chapter">
                                        <div class="nb-ch-toggle-track"><div class="nb-ch-toggle-knob"></div></div>
                                    </div>
                                    <input type="hidden" id="nbCwChapterTeacherChecked" value="no">
                                    <span class="nb-ch-toggle-status" id="nbCwChapterTeacherCheckedLabel">Not checked</span>
                                </div>
                                <div class="nb-ch-toggle-row" id="nbCwChapterBacklogRow">
                                    <div class="nb-ch-toggle-info">
                                        <span class="nb-ch-toggle-name">Backlog Link</span>
                                        <span class="nb-ch-toggle-desc">Send incomplete to Backlog</span>
                                    </div>
                                    <div class="nb-ch-toggle" data-action="toggle-backlog-chapter">
                                        <div class="nb-ch-toggle-track"><div class="nb-ch-toggle-knob"></div></div>
                                    </div>
                                    <input type="hidden" id="nbCwChapterSendBacklog" value="no">
                                    <span class="nb-ch-toggle-status" id="nbCwChapterBacklogLabel">Off</span>
                                </div>
                            </div>
                        </div>

                        <!-- SECTION 4: LIVE SUMMARY STRIP -->
                        <div class="nb-ch-summary-strip" id="nbCwChapterSummary">
                            <div class="nb-ch-sum-cell"><span class="nb-ch-sum-k">Status</span><span class="nb-ch-sum-v" id="nbSummaryStatus">Not Started</span></div>
                            <div class="nb-ch-sum-cell"><span class="nb-ch-sum-k">Pending</span><span class="nb-ch-sum-v" id="nbSummaryPending">None</span></div>
                            <div class="nb-ch-sum-cell"><span class="nb-ch-sum-k">ETA</span><span class="nb-ch-sum-v" id="nbSummaryEta">&mdash;</span></div>
                            <div class="nb-ch-sum-cell"><span class="nb-ch-sum-k">Deadline</span><span class="nb-ch-sum-v" id="nbSummaryDeadline">None</span></div>
                            <div class="nb-ch-sum-cell nb-ch-sum-risk"><span class="nb-ch-sum-k">Risk</span><span class="nb-ch-sum-v" id="nbSummaryRisk">None</span></div>
                        </div>
                    </div>

                    <!-- FOOTER -->
                    <div class="nb-ch-footer">
                        <button class="nb-ch-btn-delete" id="nbCwChapterDeleteBtn" data-action="delete-cw-chapter-inline" type="button" style="display:none;">Delete</button>
                        <div class="nb-ch-footer-right">
                            <button class="nb-ch-btn-cancel" data-action="close-cw-chapter" type="button">Cancel</button>
                            <button class="nb-ch-btn-save" data-action="save-cw-chapter" type="button">Save Chapter</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Create C.W. Notebook Modal (Phase 9N-CW) -->
            <div class="nb-note-modal-overlay nb-chapter-sheet-overlay" id="nbCwCreateModal" style="display:none;align-items:center;justify-content:center;">
                <div class="nb-note-modal-card nb-chapter-sheet nb-cw-create-modal" style="max-width:560px;">
                    <!-- HEADER -->
                    <div class="nb-ch-header">
                        <div class="nb-ch-header-left">
                            <h2 id="nbCwCreateModalTitle">Create C.W. Notebook</h2>
                            <p class="nb-ch-subtitle">Create a digital classwork copy for a subject.</p>
                        </div>
                        <button class="nb-ch-close" data-action="close-cw-create" type="button">&times;</button>
                    </div>

                    <div class="nb-ch-body">
                        <!-- SECTION 1: NOTEBOOK IDENTITY -->
                        <div class="nb-ch-sec">
                            <div class="nb-ch-sec-label">Notebook Identity</div>
                            <div class="nb-ch-field nb-ch-field-grow">
                                <label for="nbCwCreateName">Notebook Name</label>
                                <input type="text" id="nbCwCreateName" placeholder="e.g. Chemistry C.W. / Maths Copy / Science Classwork" autocomplete="off">
                                <div class="nb-cw-create-error" id="nbCwCreateNameError" style="display:none;">Notebook name is required.</div>
                            </div>
                        </div>

                        <!-- SECTION 2: SYLLABUS LINK -->
                        <div class="nb-ch-sec">
                            <div class="nb-ch-sec-label">Syllabus Link</div>
                            <div class="nb-cw-create-pair">
                                <div class="nb-ch-field">
                                    <label for="nbCwCreateSubject">Linked Syllabus Subject</label>
                                    <select id="nbCwCreateSubject" data-action="cw-create-subject-change">
                                        <option value="">Select subject...</option>
                                    </select>
                                </div>
                                <div class="nb-ch-field" id="nbCwCreateGroupRow" style="display:none;">
                                    <label for="nbCwCreateGroup">Linked Syllabus Group / Book</label>
                                    <select id="nbCwCreateGroup">
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- SECTION 3: STARTING MODE -->
                        <div class="nb-ch-sec">
                            <div class="nb-ch-sec-label">Starting Mode</div>
                            <div class="nb-ch-seg" id="nbCwCreateStartModePills">
                                <button class="nb-ch-seg-btn" data-action="select-cw-create-start-mode" data-value="empty" type="button">Empty Notebook</button>
                                <button class="nb-ch-seg-btn active" data-action="select-cw-create-start-mode" data-value="import_later" type="button">Import Selected Later</button>
                                <button class="nb-ch-seg-btn" data-action="select-cw-create-start-mode" data-value="add_chapter" type="button">Add Custom Chapter First</button>
                            </div>
                            <input type="hidden" id="nbCwCreateStartMode" value="import_later">
                        </div>

                        <!-- SECTION 4: DEFAULTS -->
                        <div class="nb-ch-sec">
                            <div class="nb-ch-sec-label">Defaults</div>
                            <div class="nb-ch-toggles">
                                <div class="nb-ch-toggle-row">
                                    <div class="nb-ch-toggle-info">
                                        <span class="nb-ch-toggle-name">Teacher Checked</span>
                                        <span class="nb-ch-toggle-desc">Verified by teacher</span>
                                    </div>
                                    <div class="nb-ch-toggle" data-action="toggle-cw-create-teacher">
                                        <div class="nb-ch-toggle-track"><div class="nb-ch-toggle-knob"></div></div>
                                    </div>
                                    <input type="hidden" id="nbCwCreateTeacherChecked" value="no">
                                    <span class="nb-ch-toggle-status" id="nbCwCreateTeacherCheckedLabel">Not checked</span>
                                </div>
                            </div>
                            <div class="nb-ch-field" style="margin-top:10px;">
                                <label for="nbCwCreateDeadline">Deadline Default (optional)</label>
                                <input type="date" id="nbCwCreateDeadline">
                            </div>
                        </div>
                    </div>

                    <!-- FOOTER -->
                    <div class="nb-ch-footer">
                        <div class="nb-ch-footer-right" style="flex:1;justify-content:flex-end;">
                            <button class="nb-ch-btn-cancel" data-action="close-cw-create" type="button">Cancel</button>
                            <button class="nb-ch-btn-save" data-action="save-cw-create" type="button">Create Notebook</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Import Chapters from Syllabus Modal -->
            <div class="nb-note-modal-overlay nb-import-modal-overlay" id="nbCwImportModal" style="display:none;align-items:center;justify-content:center;">
                <div class="nb-note-modal-card nb-import-modal-card" style="max-width:560px;">
                    <div class="nb-modal-header">
                        <div>
                            <h2 id="nbCwImportModalTitle">Import Chapters from Syllabus</h2>
                            <p class="nb-sheet-subtitle">Select syllabus chapters to add to your notebook index.</p>
                        </div>
                        <button class="nb-modal-close" data-action="close-import-syllabus">×</button>
                    </div>
                    <div class="nb-modal-body nb-import-modal-body" id="nbCwImportModalBody">
                        <!-- Dynamically rendered by _renderImportSyllabusContent -->
                    </div>
                    <div class="nb-modal-footer nb-import-modal-footer" id="nbCwImportModalFooter">
                        <button class="nb-btn-cancel" data-action="close-import-syllabus">CANCEL</button>
                        <button class="nb-btn-save" data-action="confirm-import-syllabus" id="nbCwImportConfirmBtn">IMPORT SELECTED</button>
                    </div>
                </div>
            </div>

        </div>
        <div class="nb-toast" id="nbToast"></div>`;
    }

    // ── Import from Syllabus Modal Logic ──

    let _importSyllabusRowIndex = null; // tracks which C.W. row we're importing into
    let _importCatalog = null;          // cached catalog for this modal session

    function _openImportSyllabusModal(rowIndex) {
        const row = _rows[rowIndex];
        const modal = _container?.querySelector('#nbCwImportModal');
        if (!row || !modal) return;

        _importSyllabusRowIndex = rowIndex;
        _importCatalog = _buildSyllabusCatalog();

        // Use linked syllabus subject/group if set, otherwise guess from notebook name
        const notebookName = String(row.subject || '').trim();
        let guessSubject = row.linkedSyllabusSubject || null;
        let guessBook = row.linkedSyllabusGroup || null;

        // Validate linked subject against catalog
        if (!guessSubject || !_importCatalog.subjects[guessSubject]) {
            const guess = _guessSyllabusSubjectForNotebook(notebookName, _importCatalog);
            guessSubject = guess.subject;
            guessBook = guess.book;
        } else if (guessBook && _importCatalog.subjects[guessSubject] && !_importCatalog.subjects[guessSubject][guessBook]) {
            // Linked book not found in catalog, reset
            guessBook = null;
        }

        // Update title — notebook name is informational only
        const title = _container?.querySelector('#nbCwImportModalTitle');
        if (title) title.textContent = 'Import Chapters from Syllabus';

        _renderImportSyllabusContent(guessSubject, guessBook, row);
        modal.style.display = 'flex';
    }

    function _renderImportSyllabusContent(selectedSubject, selectedBook, row) {
        const body = _container?.querySelector('#nbCwImportModalBody');
        const footer = _container?.querySelector('#nbCwImportModalFooter');
        if (!body || !_importCatalog) return;

        const catalog = _importCatalog;
        const subjectNames = Object.keys(catalog.subjects).sort((a, b) => a.localeCompare(b));

        if (subjectNames.length === 0) {
            // No syllabus data at all
            body.innerHTML = `
                <div class="nb-import-empty">
                    <div class="nb-import-empty-icon">📭</div>
                    <p class="nb-import-empty-title">No syllabus data found.</p>
                    <p class="nb-import-empty-sub">Open the Syllabus page first to load your class syllabus, then try again. Or add a custom chapter.</p>
                </div>`;
            if (footer) {
                const confirmBtn = footer.querySelector('#nbCwImportConfirmBtn');
                if (confirmBtn) confirmBtn.disabled = true;
            }
            return;
        }

        // Validate selected subject
        const activeSubject = (selectedSubject && catalog.subjects[selectedSubject])
            ? selectedSubject
            : subjectNames[0];
        const books = catalog.subjects[activeSubject]
            ? Object.keys(catalog.subjects[activeSubject]).sort((a, b) => a.localeCompare(b))
            : [];

        // Validate selected book
        const activeBook = (selectedBook && books.includes(selectedBook))
            ? selectedBook
            : (books.length > 0 ? books[0] : null);

        // Build subject dropdown options
        const subjectOptions = subjectNames.map(s =>
            `<option value="${_escHtml(s)}" ${s === activeSubject ? 'selected' : ''}>${_escHtml(s)}</option>`
        ).join('');

        // Build book dropdown options
        const bookOptions = books.map(b =>
            `<option value="${_escHtml(b)}" ${b === activeBook ? 'selected' : ''}>${_escHtml(b)}</option>`
        ).join('');

        // Get chapters for activeSubject + activeBook
        const chapters = (activeSubject && activeBook && catalog.subjects[activeSubject] && catalog.subjects[activeSubject][activeBook])
            ? catalog.subjects[activeSubject][activeBook]
            : [];

        const existingChapters = row ? _getCwChapters(row) : [];
        const existingNames = new Set(existingChapters.map(ch => ch.chapterName.trim().toLowerCase()));

        // Build chapter checklist
        let chaptersHtml = '';
        if (chapters.length === 0) {
            chaptersHtml = `
                <div class="nb-import-chapters-empty">
                    <p>No chapters found for this selection. Try another subject/group or add a custom chapter.</p>
                </div>`;
        } else {
            chaptersHtml = `
                <div class="nb-import-select-all">
                    <input type="checkbox" id="nbImportSelectAll">
                    <label for="nbImportSelectAll">Select all (${chapters.filter(ch => !existingNames.has(ch.toLowerCase())).length} available)</label>
                </div>
                <div class="nb-import-chapter-list" id="nbImportChapterList">
                    ${chapters.map((ch, idx) => {
                        const isAlreadyAdded = existingNames.has(ch.trim().toLowerCase());
                        const checkboxId = `nbImportChk_${idx}`;
                        if (isAlreadyAdded) {
                            return `
                                <div class="nb-import-chapter-row nb-import-already-added">
                                    <input type="checkbox" id="${checkboxId}" data-chapter-name="${_escHtml(ch)}" data-book="${_escHtml(activeBook)}" data-subject="${_escHtml(activeSubject)}" disabled checked>
                                    <label for="${checkboxId}" class="nb-import-chapter-label">
                                        <span class="nb-import-chapter-name">${_escHtml(ch)}</span>
                                        <span class="nb-import-chapter-book">${_escHtml(activeBook)}</span>
                                    </label>
                                    <span class="nb-import-already-badge">Already added</span>
                                </div>`;
                        }
                        return `
                            <div class="nb-import-chapter-row">
                                <input type="checkbox" id="${checkboxId}" data-chapter-name="${_escHtml(ch)}" data-book="${_escHtml(activeBook)}" data-subject="${_escHtml(activeSubject)}">
                                <label for="${checkboxId}" class="nb-import-chapter-label">
                                    <span class="nb-import-chapter-name">${_escHtml(ch)}</span>
                                    <span class="nb-import-chapter-book">${_escHtml(activeBook)}</span>
                                </label>
                            </div>`;
                    }).join('')}
                </div>`;
        }

        // Show book selector only if subject has multiple books or any book besides "General"
        const showBookSelector = books.length > 1 || (books.length === 1 && books[0] !== 'General');
        const bookSelectorHtml = showBookSelector ? `
            <div class="nb-field nb-import-field">
                <label for="nbImportBookSelect">Group / Book</label>
                <select id="nbImportBookSelect" class="nb-import-select">${bookOptions}</select>
            </div>` : '';

        // If only "General" book, hide the selector but keep the value
        const hiddenBookValue = !showBookSelector && books.length === 1
            ? `<input type="hidden" id="nbImportBookSelect" value="${_escHtml(books[0] || 'General')}">`
            : '';

        body.innerHTML = `
            <div class="nb-field nb-import-field">
                <label for="nbImportSubjectSelect">Syllabus Subject</label>
                <select id="nbImportSubjectSelect" class="nb-import-select">${subjectOptions}</select>
            </div>
            ${bookSelectorHtml}
            ${hiddenBookValue}
            <div class="nb-import-chapters-area" id="nbImportChaptersArea">
                ${chaptersHtml}
            </div>`;

        // Wire up subject dropdown change
        const subjectSelect = body.querySelector('#nbImportSubjectSelect');
        if (subjectSelect) {
            subjectSelect.addEventListener('change', () => {
                const newSubject = subjectSelect.value;
                // Reset book to null so first book of new subject is selected
                _renderImportChapterList(newSubject, null, row);
            });
        }

        // Wire up book dropdown change
        const bookSelect = body.querySelector('#nbImportBookSelect');
        if (bookSelect) {
            bookSelect.addEventListener('change', () => {
                const currentSubject = body.querySelector('#nbImportSubjectSelect')?.value || activeSubject;
                _renderImportChapterList(currentSubject, bookSelect.value, row);
            });
        }

        // Wire up select-all and individual checkboxes if chapters exist
        _wireImportCheckboxes();
        _updateImportConfirmCount();
    }

    /**
     * Re-render only the chapters area when subject/book selection changes.
     * Keeps the dropdowns intact, avoids full body re-render.
     */
    function _renderImportChapterList(subject, book, row) {
        if (!_importCatalog || !subject) return;
        const body = _container?.querySelector('#nbCwImportModalBody');
        if (!body) return;

        const books = _importCatalog.subjects[subject]
            ? Object.keys(_importCatalog.subjects[subject]).sort((a, b) => a.localeCompare(b))
            : [];

        const showBookSelector = books.length > 1 || (books.length === 1 && books[0] !== 'General');

        // Update book dropdown options — handle show/hide
        let bookSelect = body.querySelector('#nbImportBookSelect');
        const bookFieldContainer = bookSelect ? bookSelect.closest('.nb-import-field') : null;

        if (showBookSelector) {
            if (!bookSelect) {
                // Create book selector — it didn't exist before
                const subjectField = body.querySelector('#nbImportSubjectSelect')?.closest('.nb-import-field');
                if (subjectField) {
                    const newBookField = document.createElement('div');
                    newBookField.className = 'nb-field nb-import-field';
                    newBookField.innerHTML = `
                        <label for="nbImportBookSelect">Group / Book</label>
                        <select id="nbImportBookSelect" class="nb-import-select"></select>`;
                    subjectField.after(newBookField);
                    bookSelect = newBookField.querySelector('#nbImportBookSelect');
                    // Wire book change
                    if (bookSelect) {
                        bookSelect.addEventListener('change', () => {
                            const currentSubject = body.querySelector('#nbImportSubjectSelect')?.value || subject;
                            _renderImportChapterList(currentSubject, bookSelect.value, row);
                        });
                    }
                }
            }
            if (bookSelect) {
                bookSelect.innerHTML = books.map(b =>
                    `<option value="${_escHtml(b)}" ${b === (book || books[0]) ? 'selected' : ''}>${_escHtml(b)}</option>`
                ).join('');
                bookSelect.value = book || books[0];
            }
            if (bookFieldContainer) bookFieldContainer.style.display = '';
            // Remove any hidden input placeholder
            const hiddenBook = body.querySelector('input[type="hidden"]#nbImportBookSelect');
            if (hiddenBook) hiddenBook.remove();
        } else {
            // Hide book selector if it exists
            if (bookFieldContainer) bookFieldContainer.style.display = 'none';
            // Ensure we have a hidden input with the single book value
            let hiddenBook = body.querySelector('input[type="hidden"]#nbImportBookSelect');
            if (!hiddenBook && books.length > 0) {
                hiddenBook = document.createElement('input');
                hiddenBook.type = 'hidden';
                hiddenBook.id = 'nbImportBookSelect';
                body.querySelector('#nbImportSubjectSelect')?.closest('.nb-import-field')?.after(hiddenBook);
            }
            if (hiddenBook && books.length > 0) hiddenBook.value = books[0];
        }

        const activeBook = bookSelect && showBookSelector ? bookSelect.value : (books[0] || 'General');
        const chapters = (_importCatalog.subjects[subject] && _importCatalog.subjects[subject][activeBook])
            ? _importCatalog.subjects[subject][activeBook]
            : [];

        const existingChapters = row ? _getCwChapters(row) : [];
        const existingNames = new Set(existingChapters.map(ch => ch.chapterName.trim().toLowerCase()));

        const chaptersArea = body.querySelector('#nbImportChaptersArea');
        if (!chaptersArea) return;

        if (chapters.length === 0) {
            chaptersArea.innerHTML = `
                <div class="nb-import-chapters-empty">
                    <p>No chapters found for this selection. Try another subject/group or add a custom chapter.</p>
                </div>`;
            _updateImportConfirmCount();
            return;
        }

        chaptersArea.innerHTML = `
            <div class="nb-import-select-all">
                <input type="checkbox" id="nbImportSelectAll">
                <label for="nbImportSelectAll">Select all (${chapters.filter(ch => !existingNames.has(ch.toLowerCase())).length} available)</label>
            </div>
            <div class="nb-import-chapter-list" id="nbImportChapterList">
                ${chapters.map((ch, idx) => {
                    const isAlreadyAdded = existingNames.has(ch.trim().toLowerCase());
                    const checkboxId = `nbImportChk_${idx}`;
                    if (isAlreadyAdded) {
                        return `
                            <div class="nb-import-chapter-row nb-import-already-added">
                                <input type="checkbox" id="${checkboxId}" data-chapter-name="${_escHtml(ch)}" data-book="${_escHtml(activeBook)}" data-subject="${_escHtml(subject)}" disabled checked>
                                <label for="${checkboxId}" class="nb-import-chapter-label">
                                    <span class="nb-import-chapter-name">${_escHtml(ch)}</span>
                                    <span class="nb-import-chapter-book">${_escHtml(activeBook)}</span>
                                </label>
                                <span class="nb-import-already-badge">Already added</span>
                            </div>`;
                    }
                    return `
                        <div class="nb-import-chapter-row">
                            <input type="checkbox" id="${checkboxId}" data-chapter-name="${_escHtml(ch)}" data-book="${_escHtml(activeBook)}" data-subject="${_escHtml(subject)}">
                            <label for="${checkboxId}" class="nb-import-chapter-label">
                                <span class="nb-import-chapter-name">${_escHtml(ch)}</span>
                                <span class="nb-import-chapter-book">${_escHtml(activeBook)}</span>
                            </label>
                        </div>`;
                }).join('')}
            </div>`;

        _wireImportCheckboxes();
        _updateImportConfirmCount();
    }

    function _wireImportCheckboxes() {
        const body = _container?.querySelector('#nbCwImportModalBody');
        if (!body) return;

        // Wire up select-all checkbox
        const selectAllCb = body.querySelector('#nbImportSelectAll');
        if (selectAllCb) {
            selectAllCb.addEventListener('change', () => {
                const checkboxes = body.querySelectorAll('.nb-import-chapter-row input[type="checkbox"]:not(:disabled)');
                checkboxes.forEach(cb => { cb.checked = selectAllCb.checked; });
                _updateImportConfirmCount();
            });
        }

        // Wire up individual checkboxes to update count
        body.querySelectorAll('.nb-import-chapter-row input[type="checkbox"]:not(:disabled)').forEach(cb => {
            cb.addEventListener('change', () => {
                _updateImportConfirmCount();
                // Update select-all state
                const allCbs = body.querySelectorAll('.nb-import-chapter-row input[type="checkbox"]:not(:disabled)');
                const allChecked = Array.from(allCbs).every(c => c.checked);
                const someChecked = Array.from(allCbs).some(c => c.checked);
                if (selectAllCb) {
                    selectAllCb.checked = allChecked;
                    selectAllCb.indeterminate = someChecked && !allChecked;
                }
            });
        });
    }

    function _updateImportConfirmCount() {
        const body = _container?.querySelector('#nbCwImportModalBody');
        const confirmBtn = _container?.querySelector('#nbCwImportConfirmBtn');
        if (!body || !confirmBtn) return;

        const checkedCount = body.querySelectorAll('.nb-import-chapter-row input[type="checkbox"]:checked:not(:disabled)').length;
        confirmBtn.textContent = checkedCount > 0 ? `IMPORT SELECTED (${checkedCount})` : 'IMPORT SELECTED';
        confirmBtn.disabled = checkedCount === 0;
    }

    function _closeImportSyllabusModal() {
        const modal = _container?.querySelector('#nbCwImportModal');
        if (modal) modal.style.display = 'none';
        _importSyllabusRowIndex = null;
        _importCatalog = null;
    }

    function _confirmImportSyllabus() {
        if (_importSyllabusRowIndex === null) return;
        const row = _rows[_importSyllabusRowIndex];
        if (!row) { _closeImportSyllabusModal(); return; }

        const body = _container?.querySelector('#nbCwImportModalBody');
        if (!body) return;

        // Gather selected chapters
        const checkedBoxes = body.querySelectorAll('.nb-import-chapter-row input[type="checkbox"]:checked:not(:disabled)');
        if (checkedBoxes.length === 0) { _closeImportSyllabusModal(); return; }

        const existingChapters = _getCwChapters(row);
        const existingNames = new Set(existingChapters.map(ch => ch.chapterName.trim().toLowerCase()));
        const maxOrder = existingChapters.reduce((max, ch) => Math.max(max, Number(ch.order || 0)), 0);
        const now = new Date().toISOString();

        let importedCount = 0;
        let nextOrder = maxOrder + 1;

        checkedBoxes.forEach(cb => {
            const chapterName = cb.dataset.chapterName?.trim();
            const book = cb.dataset.book?.trim() || 'General';
            if (!chapterName) return;

            // Duplicate guard: skip if already exists (case-insensitive)
            if (existingNames.has(chapterName.toLowerCase())) return;

            const newChapter = _normalizeCwChapter({
                id: `cw_syl_${Date.now()}_${Math.random().toString(16).slice(2)}_${importedCount}`,
                order: nextOrder++,
                chapterName: chapterName,
                status: 'not_started',
                pendingPages: 0,
                estimatedMinutes: 25,
                teacherChecked: false,
                deadline: null,
                linkedBacklog: false,
                source: 'syllabus_import',
                updatedAt: now
            }, nextOrder - 1);

            if (!Array.isArray(row.chapters)) row.chapters = [];
            row.chapters.push(newChapter);
            existingNames.add(chapterName.toLowerCase());
            importedCount++;
        });

        if (importedCount > 0) {
            // Re-normalize and re-sort chapters
            row.chapters = row.chapters
                .map((ch, idx) => _normalizeCwChapter(ch, idx + 1))
                .sort((a, b) => Number(a.order || 0) - Number(b.order || 0));

            // Update row-level summary
            const summary = _getCwIndexSummary(row);
            if (summary.total > 0 && summary.completeCount === summary.total) {
                row.done = true; row.incident = false; row.delta = 0;
            } else {
                row.done = false;
                row.delta = summary.pendingPages;
                row.incident = summary.pendingPages > 0;
            }
            row.updatedAt = now;

            _save();
            _fullSync();
            _dispatchNotebookUpdated({ action: 'syllabus_chapters_imported', rowId: row.id, count: importedCount });
            _showToast(`${importedCount} chapter${importedCount !== 1 ? 's' : ''} imported from syllabus.`);
        }

        _closeImportSyllabusModal();
    }

    function _getValidClassworkItems() {
        return _rows
            .map((row, index) => ({ row, index }))
            .filter(({ row }) => _isClassworkRow(row))
            .filter(({ row }) => String(row.subject || '').trim() || String(row.chapter || '').trim() || row.done || row.incident || Number(row.delta || 0) > 0);
    }

    function _getHomeworkMissionItems() {
        return _rows
            .map((row, index) => ({ row, index }))
            .filter(({ row }) => _isHomeworkRow(row))
            .filter(({ row }) => String(row.subject || '').trim() || String(row.taskTitle || row.chapter || '').trim());
    }

    function _getNoteEntriesSafe() {
        return Array.isArray(_notes?.entries) ? _notes.entries.filter(note => {
            return String(note?.title || note?.subject || note?.chapter || note?.content || '').trim();
        }) : [];
    }

    function _setText(id, value) {
        const el = _container?.querySelector(`#${id}`);
        if (el) el.textContent = value;
    }

    function _getHomeworkStatus(row) {
        if (!row) return 'pending';
        if (row.done || row.status === 'done') return 'done';
        if (row.status === 'overdue' || _isPastDue(row.dueDate)) return 'overdue';
        return 'pending';
    }

    function _getNotebookScoreSummarySafe() {
        try {
            const cwItems = _getValidClassworkItems();
            const hwItems = _getHomeworkMissionItems();
            const notes = _getNoteEntriesSafe();

            let totalCWChapters = 0;
            let completedCWChapters = 0;
            let partialCWChapters = 0;
            let cwEarnedPoints = 0;

            cwItems.forEach(({ row }) => {
                const chapters = _getCwChapters(row);
                chapters.forEach(chapter => {
                    totalCWChapters += 1;
                    const status = String(chapter.status || 'not_started').toLowerCase();
                    const pendingPages = Number(chapter.pendingPages || 0);
                    const hasWorkSignal = pendingPages > 0 || Number(chapter.estimatedMinutes || 0) > 0 || !!chapter.deadline || chapter.teacherChecked === true;

                    if (status === 'complete') {
                        completedCWChapters += 1;
                        cwEarnedPoints += 1;
                    } else if (status === 'current') {
                        partialCWChapters += 1;
                        cwEarnedPoints += 0.5;
                    } else if (status === 'incomplete') {
                        partialCWChapters += 1;
                        cwEarnedPoints += hasWorkSignal ? 0.25 : 0;
                    }
                });
            });

            const legacyCWRows = cwItems.filter(({ row }) => !_getCwChapters(row).length);
            const legacyDoneRows = legacyCWRows.filter(({ row }) => row.done || row.teacherChecked).length;

            let cwScore = 0;
            let cwSource = 'no_index';
            if (totalCWChapters > 0) {
                cwScore = Math.round((cwEarnedPoints / totalCWChapters) * 100);
                cwSource = 'chapter_index';
            } else if (legacyCWRows.length > 0) {
                cwScore = Math.round((legacyDoneRows / legacyCWRows.length) * 100);
                cwSource = 'legacy_rows';
            }

            const totalHWTasks = hwItems.length;
            const completedHWTasks = hwItems.filter(({ row }) => _getHomeworkStatus(row) === 'done').length;
            const hwScore = totalHWTasks ? Math.round((completedHWTasks / totalHWTasks) * 100) : 100;

            const totalNotes = notes.length;
            const reviewedNotes = notes.filter(note => {
                const revisionStatus = String(note.revisionStatus || 'none').toLowerCase();
                const healthScore = Number(note.healthScore ?? 0);
                return revisionStatus === 'reviewed' || (healthScore >= 60 && revisionStatus !== 'overdue');
            }).length;
            const notesScore = totalNotes ? Math.round((reviewedNotes / totalNotes) * 100) : 100;

            let score = 0;
            let formula = 'cw_hw_notes';
            if (totalCWChapters === 0 && totalHWTasks === 0 && totalNotes === 0) {
                score = 0;
                formula = 'no_data';
            } else if (totalNotes === 0) {
                score = Math.round((cwScore * 0.7) + (hwScore * 0.3));
                formula = 'cw_hw';
            } else {
                score = Math.round((cwScore * 0.5) + (hwScore * 0.3) + (notesScore * 0.2));
            }

            return {
                score: Math.max(0, Math.min(100, Number.isFinite(score) ? score : 0)),
                cwScore: Math.max(0, Math.min(100, Number.isFinite(cwScore) ? cwScore : 0)),
                hwScore: Math.max(0, Math.min(100, Number.isFinite(hwScore) ? hwScore : 100)),
                notesScore: Math.max(0, Math.min(100, Number.isFinite(notesScore) ? notesScore : 100)),
                totalCWChapters,
                completedCWChapters,
                partialCWChapters,
                totalHWTasks,
                completedHWTasks,
                totalNotes,
                reviewedNotes,
                source: cwSource,
                formula
            };
        } catch (err) {
            console.warn('[NotebooksRoute] Notebook score summary failed:', err);
            return {
                score: 0, cwScore: 0, hwScore: 100, notesScore: 100,
                totalCWChapters: 0, completedCWChapters: 0, partialCWChapters: 0,
                totalHWTasks: 0, completedHWTasks: 0, totalNotes: 0, reviewedNotes: 0,
                source: 'error', formula: 'error'
            };
        }
    }

    function _updateCommandSummary() {
        const cwItems = _getValidClassworkItems();
        const hwItems = _getHomeworkMissionItems();
        const notes = _getNoteEntriesSafe();
        const cwRisk = cwItems.filter(({ row }) => _getCwRiskInfo(row).score > 0).length;
        const hwPending = hwItems.filter(({ row }) => ['pending', 'overdue'].includes(_getHomeworkStatus(row))).length;
        const notesToReview = notes.filter(note => ['pending', 'overdue'].includes(String(note.revisionStatus || '').toLowerCase())).length;
        const scoreSummary = _getNotebookScoreSummarySafe();

        _setText('nb-summary-cw-risk', cwRisk);
        _setText('nb-summary-hw-pending', hwPending);
        _setText('nb-summary-notes-review', notesToReview);
        _setText('nb-summary-score', `${scoreSummary.score}%`);

        const scoreCard = _container?.querySelector('#nb-card-score');
        if (scoreCard) {
            const breakdown = `C.W. ${scoreSummary.cwScore}% · H.W. ${scoreSummary.hwScore}% · Notes ${scoreSummary.notesScore}%`;
            scoreCard.title = `${breakdown} | C.W. chapters: ${scoreSummary.completedCWChapters}/${scoreSummary.totalCWChapters}, H.W.: ${scoreSummary.completedHWTasks}/${scoreSummary.totalHWTasks}, Notes: ${scoreSummary.reviewedNotes}/${scoreSummary.totalNotes}`;
            scoreCard.dataset.scoreBreakdown = breakdown;
            scoreCard.dataset.scoreFormula = scoreSummary.formula;
        }
    }

    function _renderCopyTabs() {
        const tabCw = _container?.querySelector('#nbTabCw');
        const tabHw = _container?.querySelector('#nbTabHw');
        const tabNotes = _container?.querySelector('#nbTabNotes');
        const addBtn = _container?.querySelector('#nbAddCopyRow');
        const noteBtn = _container?.querySelector('#nbVaultAddNoteBtn');
        if (tabCw) tabCw.classList.toggle('active', _activeCopyTab === 'cw');
        if (tabHw) tabHw.classList.toggle('active', _activeCopyTab === 'hw');
        if (tabNotes) tabNotes.classList.toggle('active', _activeCopyTab === 'notes');
        if (addBtn) {
            addBtn.style.display = _activeCopyTab === 'notes' ? 'none' : '';
            addBtn.textContent = _activeCopyTab === 'hw' ? '+ ADD H.W. TASK' : '+ ADD C.W. COPY';
        }
        if (noteBtn) noteBtn.style.display = _activeCopyTab === 'notes' ? '' : 'none';
    }

    function _renderCommandEmpty(icon, title, text, actionHtml = '') {
        return `<div class="nb-empty-state sp-empty-state nb-command-empty"><span class="sp-empty-state-icon">${icon}</span><h3 class="sp-empty-state-title">${_escHtml(title)}</h3><p class="sp-empty-state-text">${_escHtml(text)}</p>${actionHtml}</div>`;
    }

    function _renderCwChapterIndex(row, rowIndex) {
        const chapters = _getCwChapters(row);
        const subject = String(row.subject || '').trim();
        if (chapters.length === 0) {
            const subjectPending = Number(row.delta || 0);
            return `
                <div class="nb-cw-index-panel">
                    <div class="nb-cw-index-panel-head">
                        <div><h4>Notebook Index</h4><p>Chapter-wise copy record</p></div>
                    </div>
                    <div class="nb-cw-index-empty-state">
                        <div class="nb-cw-index-empty-icon">📋</div>
                        <p>No chapter index created yet.</p>
                        <p class="nb-cw-index-empty-sub">Import chapters from your syllabus or add a custom chapter.</p>
                        <div class="nb-cw-index-empty-actions">
                            <button class="nb-btn nb-btn-primary" data-action="open-import-syllabus" data-index="${rowIndex}">Import from Syllabus</button>
                            <button class="nb-btn nb-btn-secondary" data-action="add-cw-chapter" data-index="${rowIndex}">+ Custom Chapter</button>
                        </div>
                    </div>
                </div>`;
        }

        const statusLabelMap = { complete: 'Complete', incomplete: 'Incomplete', current: 'Current', not_started: 'Not Started' };
        const statusClassMap = { complete: 'complete', incomplete: 'incomplete', current: 'current', not_started: 'not-started' };

        return `
            <div class="nb-cw-index-panel">
                <div class="nb-cw-index-panel-head">
                    <div><h4>Notebook Index</h4><p>Chapter-wise copy record</p></div>
                    <div class="nb-cw-index-head-actions">
                        <button class="nb-btn nb-btn-primary" data-action="open-import-syllabus" data-index="${rowIndex}">Import from Syllabus</button>
                        <button class="nb-btn nb-btn-secondary" data-action="add-cw-chapter" data-index="${rowIndex}">+ Custom</button>
                    </div>
                </div>
                <div class="nb-cw-index-list">
                    ${chapters.map((chapter, visibleIndex) => {
                        const statusKey = String(chapter.status || 'not_started').replace('_', '-');
                        const statusLabel = statusLabelMap[chapter.status] || 'Not Started';
                        const cssClass = statusClassMap[chapter.status] || 'not-started';
                        const orderNum = String(chapter.order || visibleIndex + 1).padStart(2, '0');
                        const eta = Number(chapter.estimatedMinutes || 0) > 0 ? `${Number(chapter.estimatedMinutes)} min` : '';
                        const pending = Number(chapter.pendingPages || 0);
                        const deadlineInfo = _getCwChapterDeadlineInfo(chapter);
                        const metaParts = [];
                        if (eta) metaParts.push(`ETA: ${eta}`);
                        if (pending > 0) metaParts.push(`Pending: ${pending} pg`);
                        if (deadlineInfo.status !== 'none') metaParts.push(deadlineInfo.shortLabel);
                        const sourceTag = chapter.source === 'syllabus_import' ? '<span class="nb-cw-index-source-badge">Syllabus</span>' : '';
                        return `
                        <div class="nb-cw-index-row ${cssClass}" data-action="update-cw-chapter" data-index="${rowIndex}" data-chapter-id="${_escHtml(chapter.id)}">
                            <div class="nb-cw-index-order">${orderNum}</div>
                            <div class="nb-cw-index-main">
                                <div class="nb-cw-index-title">${_escHtml(chapter.chapterName || 'Untitled chapter')}${sourceTag}</div>
                                <div class="nb-cw-index-meta">${metaParts.length ? metaParts.join(' · ') : 'No extra info'}</div>
                            </div>
                            <div class="nb-cw-index-status ${cssClass}">${statusLabel}</div>
                            <button class="nb-btn nb-btn-secondary nb-cw-index-update-btn">Update</button>
                        </div>`;
                    }).join('')}
                </div>
            </div>`;
    }

    function _renderClassworkCopyTab() {
        const items = _getValidClassworkItems();
        if (items.length === 0) {
            return _renderCommandEmpty('📘', 'No C.W. copies yet', 'Add classwork copies here to track pending pages, teacher checks, and notebook incidents.', '<button class="add-btn nb-btn nb-btn-primary" data-action="add-row">+ ADD C.W. COPY</button>');
        }

        return `
            <section class="nb-command-section">
                <div class="nb-section-head"><div><h2>C.W. Copy</h2><p>Digital classwork notebook index. Expand cards to manage chapters, deadlines, and backlog links.</p></div><button class="add-btn nb-btn nb-btn-primary" data-action="add-row">+ ADD C.W. COPY</button></div>
                <div class="nb-cw-grid">
                    ${items.map(({ row, index }) => {
                        const health = _getRowHealth(row);
                        const hTier = health?.tier;
                        const pendingPages = Math.max(0, Number(row.delta || 0));
                        const deadline = _getCwDeadlineInfo(row);
                        const risk = _getCwRiskInfo(row);
                        const indexSummary = _getCwIndexSummary(row);
                        const isExpanded = _expandedCWCardId === String(row.id || index);
                        const cwStatus = _getCWStatus(row);
                        const status = cwStatus.label;
                        const statusKey = cwStatus.key;
                        const subject = String(row.subject || '').trim();
                        const chapter = String(row.chapter || '').trim();
                        const spineColor = statusKey === 'complete' ? '#00ff9d' : (statusKey === 'incident' ? '#ff4c4c' : '#00d4ff');

                        // Collapsed cover content
                        const coverStats = indexSummary.total > 0
                            ? `${indexSummary.total} chapter${indexSummary.total !== 1 ? 's' : ''} indexed · ${indexSummary.completeCount} complete · ${indexSummary.incompleteCount} incomplete`
                            : 'Index not created yet';
                        const currentChapter = indexSummary.current ? _escHtml(indexSummary.current.chapterName) : '—';

                        return `
                            <article class="nb-cw-card ${statusKey} ${risk.cssClass} ${isExpanded ? 'expanded' : 'collapsed'}">
                                <div class="nb-cw-spine" style="background:${spineColor};"></div>
                                <button class="nb-cw-cover" data-action="toggle-cw-card" data-index="${index}" aria-expanded="${isExpanded ? 'true' : 'false'}">
                                    <div class="nb-cw-cover-top">
                                        <div class="nb-cw-cover-left">
                                            <span class="nb-cw-cover-type">C.W. COPY</span>
                                            <h3 class="nb-cw-cover-title">${_escHtml(subject || chapter || 'Classwork Copy')}</h3>
                                        </div>
                                        <div class="nb-cw-cover-right">
                                            <span class="nb-cw-status-badge nb-cw-status-${statusKey}">${status}</span>
                                            <span class="nb-cw-chevron">${isExpanded ? '⌃' : '⌄'}</span>
                                        </div>
                                    </div>
                                    <div class="nb-cw-cover-stats">
                                        <span class="nb-cw-stat">${coverStats}</span>
                                        ${indexSummary.current ? `<span class="nb-cw-stat nb-cw-stat-current">Current: ${currentChapter}</span>` : ''}
                                    </div>
                                    <div class="nb-cw-cover-badges">
                                        <span class="nb-deadline-pill ${deadline.cssClass}">${_escHtml(deadline.shortLabel)}</span>
                                        <span class="nb-risk-pill ${risk.cssClass}">${_escHtml(risk.label)}</span>
                                    </div>
                                </button>
                                <div class="nb-cw-card-body">
                                    ${_renderCwChapterIndex(row, index)}
                                    <div class="nb-cw-body-footer">
                                        <div class="nb-cw-body-meta">
                                            <span>Pending: <strong>${pendingPages} pg</strong></span>
                                            <span>Teacher: <strong>${row.teacherChecked ? 'Checked' : 'Not checked'}</strong></span>
                                            <span>Deadline: <strong>${_escHtml(deadline.label)}</strong></span>
                                            <span>ETA: <strong>${row.estimatedMinutes ? `${Number(row.estimatedMinutes)} min` : '—'}</strong></span>
                                        </div>
                                        <div class="nb-cw-body-actions">
                                            <button class="nb-btn nb-btn-primary" data-action="update-cw-copy" data-index="${index}">Update Copy Settings</button>
                                            ${!cwStatus.complete ? `<button class="nb-btn nb-btn-secondary" data-action="send-cw-backlog" data-index="${index}">Send Risk Items to Backlog</button>` : ''}
                                            <button class="nb-btn nb-btn-danger nb-btn-icon" data-action="delete-cw-copy" data-index="${index}" title="Delete C.W. Copy">Delete</button>
                                        </div>
                                    </div>
                                </div>
                            </article>`;
                    }).join('')}
                </div>
            </section>`;
    }

    function _getHomeworkRisk(status, priority, dueDate) {
        if (status === 'overdue' && priority === 'high') return 'Critical';
        if (status === 'overdue' || dueDate === _getLocalDateKey()) return 'High';
        if (_isDueTomorrow(dueDate) || priority === 'high') return 'Medium';
        return 'Safe';
    }

    function _getHomeworkDirectiveItem(items = _getHomeworkMissionItems()) {
        const active = items
            .filter(({ row }) => _getHomeworkStatus(row) !== 'done')
            .map(item => ({ ...item, status: _getHomeworkStatus(item.row), priority: String(item.row.priority || 'medium').toLowerCase() }));
        if (!active.length) return null;
        const rank = ({ row, status, priority }) => {
            if (status === 'overdue' && priority === 'high') return 1;
            if (status === 'overdue') return 2;
            if (row.dueDate === _getLocalDateKey()) return 3;
            if (_isDueTomorrow(row.dueDate) && priority === 'high') return 4;
            if (priority === 'high') return 5;
            if (priority === 'medium') return 6;
            return 7;
        };
        return active.sort((a, b) => rank(a) - rank(b) || String(a.row.dueDate || '9999-12-31').localeCompare(String(b.row.dueDate || '9999-12-31')))[0];
    }

    function _renderHomeworkBucket(label, count, tone) {
        return `<div class="nb-hw-bucket nb-hw-bucket-${tone}"><span>${_escHtml(label)}</span><strong>${Number(count || 0)}</strong></div>`;
    }

    function _renderHomeworkDirectiveCard(item) {
        if (!item) {
            return `<article class="nb-hw-directive nb-hw-directive-safe"><div><span class="nb-card-kicker">H.W. DIRECTIVE</span><h3>All homework clear.</h3><p>No pending homework found.</p></div><strong>Safe</strong></article>`;
        }
        const { row, index, status, priority } = item;
        const title = row.taskTitle || row.chapter || 'Homework task';
        const risk = _getHomeworkRisk(status, priority, row.dueDate);
        const why = `${_formatHomeworkDueText(row.dueDate)} · ${String(priority || 'medium')[0].toUpperCase() + String(priority || 'medium').slice(1)} priority · ${Number(row.estimatedMinutes || 0)} min`;
        return `<article class="nb-hw-directive nb-hw-directive-${risk.toLowerCase()}">
            <div class="nb-hw-directive-main"><span class="nb-card-kicker">H.W. DIRECTIVE</span><h3>${_escHtml(title)}</h3><p>${_escHtml(row.subject || 'Homework')}</p><div class="nb-hw-directive-why"><strong>Why:</strong> ${_escHtml(why)}</div></div>
            <div class="nb-hw-directive-side"><span>Estimated</span><strong>${Number(row.estimatedMinutes || 0)} min</strong><span>Risk</span><strong>${_escHtml(risk)}</strong></div>
            <div class="nb-hw-directive-actions"><button class="nb-btn nb-btn-primary" data-action="add-hw-to-missions" data-index="${index}" ${row.sentToBacklog ? 'disabled' : ''}>Start Work</button><button class="nb-btn nb-btn-secondary" data-action="mark-hw-done" data-index="${index}">Mark Done</button><button class="nb-btn nb-btn-ghost" data-action="add-hw-to-missions" data-index="${index}" ${row.sentToBacklog ? 'disabled' : ''}>Send to Backlog</button></div>
        </article>`;
    }

    function _renderHomeworkCard(row, index, bucketKey = '') {
        const status = _getHomeworkStatus(row);
        const priority = String(row.priority || 'medium').toLowerCase();
        const statusClass = status === 'done' ? 'rev-ontrack' : (status === 'overdue' ? 'rev-overdue' : 'rev-pending');
        const title = String(row.taskTitle || row.chapter || '').trim();
        const subject = String(row.subject || '').trim();
        return `
            <article class="nb-command-card nb-hw-card nb-hw-card-${_escHtml(bucketKey || status)} priority-${_escHtml(priority)} ${status === 'overdue' ? 'nb-card-overdue' : ''}">
                <div class="nb-card-topline">
                    <span class="nb-card-kicker">${_escHtml(row.hwType || 'Homework')}</span>
                    <span class="revision-badge ${statusClass}">${_escHtml(status)}</span>
                </div>
                <h3>${_escHtml(subject || 'Homework')}</h3>
                <p class="nb-card-subtext">${title ? _escHtml(title) : 'No task added'}</p>
                <div class="nb-card-facts">
                    <span>Due: <strong>${_escHtml(_formatHomeworkDueText(row.dueDate))}</strong></span>
                    <span>Priority: <strong>${_escHtml(priority)}</strong></span>
                    <span>Time: <strong>${Number(row.estimatedMinutes || 0)} min</strong></span>
                    <span>Backlog: <strong>${row.sentToBacklog ? 'Sent' : 'Not sent'}</strong></span>
                </div>
                <div class="nb-intel-card-actions nb-card-actions">
                    <button class="nb-btn nb-btn-primary" data-action="add-hw-to-missions" data-index="${index}" ${row.sentToBacklog ? 'disabled' : ''}>${row.sentToBacklog ? 'Backlog Sent' : 'Start Work'}</button>
                    <button class="nb-btn nb-btn-secondary" data-action="mark-hw-done" data-index="${index}" ${status === 'done' ? 'disabled' : ''}>Mark Done</button>
                    <button class="nb-btn nb-btn-ghost" data-action="edit-hw-task" data-index="${index}">Edit</button>
                    <button class="nb-btn nb-btn-ghost" data-action="add-hw-to-missions" data-index="${index}" ${row.sentToBacklog ? 'disabled' : ''}>Send to Backlog</button>
                    <button class="nb-btn nb-btn-danger" data-action="delete-hw-task" data-index="${index}">Delete</button>
                </div>
            </article>`;
    }

    function _renderHomeworkMissionsTab() {
        _syncHomeworkStatuses();
        const items = _getHomeworkMissionItems();
        const todayKey = _getLocalDateKey(new Date());
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        weekAgo.setHours(0, 0, 0, 0);
        const buckets = { overdue: [], today: [], tomorrow: [], upcoming: [], done: [] };

        items.forEach(item => {
            const status = _getHomeworkStatus(item.row);
            if (status === 'done') buckets.done.push(item);
            else if (status === 'overdue') buckets.overdue.push(item);
            else if (item.row.dueDate === todayKey) buckets.today.push(item);
            else if (_isDueTomorrow(item.row.dueDate)) buckets.tomorrow.push(item);
            else buckets.upcoming.push(item);
        });

        const doneThisWeek = buckets.done.filter(({ row }) => {
            const completed = new Date(row.completedAt || row.updatedAt || row.createdAt || 0);
            return !isNaN(completed.getTime()) && completed >= weekAgo;
        }).sort((a, b) => new Date(b.row.completedAt || b.row.updatedAt || 0) - new Date(a.row.completedAt || a.row.updatedAt || 0));

        const directive = _getHomeworkDirectiveItem(items);
        const sections = [
            { key: 'overdue', title: 'Overdue', icon: '🚨', items: buckets.overdue },
            { key: 'today', title: 'Due Today', icon: '🎯', items: buckets.today },
            { key: 'tomorrow', title: 'Due Tomorrow', icon: '⏳', items: buckets.tomorrow },
            { key: 'upcoming', title: 'Upcoming', icon: '📅', items: buckets.upcoming }
        ];

        return `
            <section class="nb-command-section nb-hw-command-board">
                <div class="nb-section-head nb-hw-head"><div><h2>H.W. Missions</h2><p>Capture, prioritize, and clear your homework.</p></div><div class="nb-hw-top-actions"><button class="add-btn nb-btn nb-btn-primary" data-action="add-row">+ Add H.W. Task</button><button class="nb-btn nb-btn-secondary" data-action="open-daily-homework-intake">Daily Intake</button></div></div>
                ${_renderHomeworkDirectiveCard(directive)}
                <div class="nb-hw-buckets">
                    ${_renderHomeworkBucket('Overdue', buckets.overdue.length, 'critical')}
                    ${_renderHomeworkBucket('Due Today', buckets.today.length, 'today')}
                    ${_renderHomeworkBucket('Due Tomorrow', buckets.tomorrow.length, 'tomorrow')}
                    ${_renderHomeworkBucket('Upcoming', buckets.upcoming.length, 'upcoming')}
                    ${_renderHomeworkBucket('Done This Week', doneThisWeek.length, 'done')}
                </div>
                <div class="nb-hw-board-title"><span>Pending Homework Cards</span><small>${buckets.overdue.length + buckets.today.length + buckets.tomorrow.length + buckets.upcoming.length} active</small></div>
                ${sections.map(section => `
                    <details class="nb-command-group nb-hw-group nb-hw-group-${section.key}" open>
                        <summary><span>${section.icon} ${section.title}</span><strong>${section.items.length}</strong></summary>
                        <div class="nb-command-grid nb-hw-grid">
                            ${section.items.length ? section.items.map(({ row, index }) => _renderHomeworkCard(row, index, section.key)).join('') : `<div class="nb-empty-mini">No ${_escHtml(section.title.toLowerCase())} homework.</div>`}
                        </div>
                    </details>`).join('')}
                <details class="nb-command-group nb-hw-history" ${doneThisWeek.length ? 'open' : ''}>
                    <summary><span>✅ Completed This Week / History</span><strong>${doneThisWeek.length}</strong></summary>
                    <div class="nb-hw-history-list">
                        ${doneThisWeek.length ? doneThisWeek.slice(0, 8).map(({ row }) => `<div class="nb-hw-history-row"><strong>${_escHtml(row.subject || 'Homework')}</strong><span>${_escHtml(row.taskTitle || row.chapter || 'Task')}</span><small>${_escHtml(row.hwType || 'homework')} · ${_escHtml((row.completedAt || row.updatedAt || '').slice(0, 10) || 'Done')}</small></div>`).join('') : '<div class="nb-empty-mini">No homework completed this week yet.</div>'}
                    </div>
                </details>
            </section>`;
    }

    function _renderNoteVaultCard(note, variant = '') {
        const health = Number(note.healthScore ?? _calculateNoteHealthScore(note));
        const status = String(note.revisionStatus || 'none').toLowerCase();
        const statusClass = status === 'overdue' ? 'rev-overdue' : (status === 'pending' ? 'rev-pending' : 'rev-ontrack');
        const tags = Array.isArray(note.tags) ? note.tags : [];
        return `
            <article class="nb-command-card nb-note-card ${variant}">
                <div class="nb-card-topline"><span class="nb-card-kicker">${_escHtml(note.subject || 'Note')}</span><span class="revision-badge ${statusClass}">${_escHtml(status)}</span></div>
                <h3>${_escHtml(note.title || 'Untitled Note')}</h3>
                <p class="nb-card-subtext">${note.chapter ? _escHtml(note.chapter) : 'No chapter linked'}</p>
                <div class="nb-card-meter"><span style="width:${Math.max(0, Math.min(100, health))}%;background:${health < 40 ? '#ef4444' : (health < 70 ? '#f59e0b' : '#22c55e')};"></span></div>
                <div class="nb-card-facts">
                    <span>Health: <strong>${health}</strong></span>
                    <span>Tags: <strong>${tags.length ? tags.map(_escHtml).join(', ') : '—'}</strong></span>
                </div>
                <div class="nb-intel-card-actions nb-card-actions">
                    <button class="nb-btn nb-btn-primary" data-action="mark-note-reviewed" data-note-id="${_escHtml(note.id)}">Review</button>
                    <button class="nb-btn nb-btn-ghost" data-action="edit-note" data-note-id="${_escHtml(note.id)}">Edit</button>
                    <button class="nb-btn nb-btn-danger" data-action="delete-note" data-note-id="${_escHtml(note.id)}">Delete</button>
                </div>
            </article>`;
    }

    function _renderNotesVaultTab() {
        const notes = _getNoteEntriesSafe();
        if (notes.length === 0) {
            return _renderCommandEmpty('🧠', 'Notes Vault is empty', 'Add useful notes here and Smart Padhai will track review health, weak notes, and recent updates.', '<button class="deploy-note-btn nb-btn nb-btn-ghost" data-action="deploy-note">+ DEPLOY NEW NOTE</button>');
        }

        const pending = notes.filter(note => ['pending', 'overdue'].includes(String(note.revisionStatus || '').toLowerCase()));
        const weak = notes.filter(note => Number(note.healthScore ?? _calculateNoteHealthScore(note)) < 40);
        const recent = [...notes].sort((a, b) => new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0)).slice(0, 8);
        const sections = [
            { title: 'Review Pending', icon: '⏳', items: pending },
            { title: 'Weak Notes', icon: '⚠️', items: weak },
            { title: 'Recent Notes', icon: '🗂️', items: recent }
        ];

        return `
            <section class="nb-command-section">
                <div class="nb-section-head"><div><h2>Notes Vault</h2><p>Review, strengthen, and reuse useful notes without clutter.</p></div><button class="deploy-note-btn nb-btn nb-btn-ghost" data-action="deploy-note">+ DEPLOY NEW NOTE</button></div>
                ${sections.map((section, idx) => `
                    <details class="nb-command-group" ${idx === 0 ? 'open' : ''}>
                        <summary><span>${section.icon} ${section.title}</span><strong>${section.items.length}</strong></summary>
                        <div class="nb-command-grid nb-notes-grid">
                            ${section.items.length ? section.items.map(note => _renderNoteVaultCard(note)).join('') : `<div class="nb-empty-mini">No ${_escHtml(section.title.toLowerCase())}.</div>`}
                        </div>
                    </details>`).join('')}
            </section>`;
    }

    function _renderCommandStyles() {
        return `<style id="nbCommandCenterStyles">
            .nb-command-center .add-btn,
            .nb-command-center .deploy-note-btn,
            .nb-command-center .sp-btn,
            .nb-command-center .mini-kill-btn{
                background:rgba(255,255,255,.035);
                color:rgba(255,255,255,.88);
                border:1px solid rgba(255,255,255,.10);
                box-shadow:none;
            }
            .nb-command-center .nb-note-modal-card{
                background:radial-gradient(circle at top left,rgba(0,212,255,.10),transparent 32%),linear-gradient(145deg,rgba(10,16,30,.96),rgba(3,7,18,.98));
                border:1px solid rgba(103,232,249,.16);
                box-shadow:0 26px 80px rgba(0,0,0,.55),0 0 34px rgba(0,212,255,.08);
                backdrop-filter:blur(18px);
            }
            .nb-command-center .nb-modal-header{border-bottom:1px solid rgba(148,163,184,.12);padding-bottom:14px;margin-bottom:4px;}
            .nb-command-center .nb-modal-header h2{letter-spacing:.08em;text-transform:uppercase;color:#e0faff;text-shadow:0 0 16px rgba(0,212,255,.14);}
            .nb-command-center .nb-modal-body{display:grid;gap:14px;padding-top:14px;}
            .nb-command-center .nb-field-row{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
            .nb-command-center .nb-field{position:relative;display:flex;flex-direction:column;gap:7px;}
            .nb-command-center .nb-field label{
                color:rgba(203,213,225,.78);
                font-size:.66rem;
                font-weight:900;
                letter-spacing:.11em;
                text-transform:uppercase;
            }
            .nb-command-center .nb-field input,
            .nb-command-center .nb-field select,
            .nb-command-center .nb-field textarea{
                width:100%;
                box-sizing:border-box;
                border:1px solid rgba(148,163,184,.18);
                background:linear-gradient(180deg,rgba(15,23,42,.86),rgba(2,6,23,.92));
                color:#e5f8ff;
                border-radius:13px;
                padding:12px 13px;
                min-height:44px;
                font-size:.9rem;
                outline:none;
                box-shadow:inset 0 1px 0 rgba(255,255,255,.035),0 10px 26px rgba(0,0,0,.18);
                transition:border-color .2s ease,box-shadow .2s ease,background .2s ease;
                caret-color:#67e8f9;
            }
            .nb-command-center .nb-field textarea{resize:vertical;line-height:1.45;}
            .nb-command-center .nb-field input::placeholder,
            .nb-command-center .nb-field textarea::placeholder{color:rgba(148,163,184,.55);}
            .nb-command-center .nb-field input:focus,
            .nb-command-center .nb-field select:focus,
            .nb-command-center .nb-field textarea:focus{
                border-color:rgba(34,211,238,.58);
                background:linear-gradient(180deg,rgba(15,23,42,.96),rgba(2,6,23,.96));
                box-shadow:0 0 0 3px rgba(34,211,238,.10),0 0 24px rgba(0,212,255,.14),inset 0 1px 0 rgba(255,255,255,.05);
            }
            .nb-command-center .nb-field select{
                appearance:none;
                -webkit-appearance:none;
                padding-right:42px;
                cursor:pointer;
                background-image:linear-gradient(180deg,rgba(15,23,42,.86),rgba(2,6,23,.92)),url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='%2367e8f9' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
                background-repeat:no-repeat,no-repeat;
                background-position:0 0,calc(100% - 13px) 50%;
                background-size:100% 100%,16px 16px;
            }
            .nb-command-center .nb-field select option{background:#07111f;color:#e5f8ff;}
            .nb-command-center .nb-field input[type="date"],
            .nb-command-center .nb-field input[type="number"]{color-scheme:dark;}
            .nb-command-center .nb-field input[type="date"]::-webkit-calendar-picker-indicator{
                filter:invert(78%) sepia(79%) saturate(1233%) hue-rotate(142deg) brightness(101%) contrast(101%);
                opacity:.82;
                cursor:pointer;
                border-radius:8px;
                padding:4px;
                background-color:rgba(34,211,238,.08);
            }
            .nb-command-center .nb-field input[type="date"]::-webkit-calendar-picker-indicator:hover{opacity:1;background-color:rgba(34,211,238,.16);}
            .nb-command-center .nb-field input[type="number"]::-webkit-outer-spin-button,
            .nb-command-center .nb-field input[type="number"]::-webkit-inner-spin-button{filter:invert(1);opacity:.55;}
            .nb-command-center .nb-modal-footer{border-top:1px solid rgba(148,163,184,.12);padding-top:14px;margin-top:6px;}
            .nb-command-center .nb-btn-save,
            .nb-command-center .nb-btn-cancel{
                border-radius:12px;
                padding:11px 16px;
                font-size:.72rem;
                font-weight:900;
                letter-spacing:.08em;
                text-transform:uppercase;
                cursor:pointer;
                transition:all .2s ease;
            }
            .nb-command-center .nb-btn-save{background:linear-gradient(135deg,rgba(0,212,255,.22),rgba(0,255,157,.14));color:#8ffcff;border:1px solid rgba(0,212,255,.45);box-shadow:0 0 18px rgba(0,212,255,.14),inset 0 1px 0 rgba(255,255,255,.06);}
            .nb-command-center .nb-btn-save:hover{transform:translateY(-1px);box-shadow:0 0 24px rgba(0,212,255,.24),0 10px 26px rgba(0,0,0,.24);}
            .nb-command-center .nb-btn-cancel{background:rgba(15,23,42,.78);color:#cbd5e1;border:1px solid rgba(148,163,184,.18);}
            .nb-command-center .nb-btn-cancel:hover{background:rgba(255,255,255,.06);border-color:rgba(203,213,225,.26);color:#fff;}
            .nb-btn{
                border:1px solid rgba(255,255,255,.10);
                background:rgba(255,255,255,.035);
                color:rgba(255,255,255,.88);
                border-radius:10px;
                padding:9px 12px;
                font-size:.68rem;
                font-weight:900;
                letter-spacing:.06em;
                text-transform:uppercase;
                cursor:pointer;
                transition:all .2s ease;
                line-height:1.05;
            }
            .nb-btn-primary{
                border-color:rgba(0,212,255,.45)!important;
                color:#00d4ff!important;
                background:linear-gradient(135deg,rgba(0,212,255,.12),rgba(0,255,157,.07))!important;
                box-shadow:0 0 14px rgba(0,212,255,.08)!important;
            }
            .nb-btn-primary:hover{background:rgba(0,212,255,.16)!important;box-shadow:0 0 20px rgba(0,212,255,.18)!important;transform:translateY(-1px);}
            .nb-btn-secondary{border-color:rgba(255,255,255,.12)!important;color:rgba(255,255,255,.74)!important;background:rgba(15,23,42,.74)!important;}
            .nb-btn-secondary:hover{border-color:rgba(255,255,255,.24)!important;background:rgba(255,255,255,.07)!important;color:#fff!important;}
            .nb-btn-danger{border-color:rgba(255,76,76,.45)!important;color:#ff4c4c!important;background:rgba(255,76,76,.06)!important;}
            .nb-btn-danger:hover{background:rgba(255,76,76,.14)!important;box-shadow:0 0 18px rgba(255,76,76,.16)!important;}
            .nb-btn-ghost{border-color:rgba(168,85,247,.32)!important;color:#c4b5fd!important;background:rgba(124,58,237,.07)!important;}
            .nb-btn-ghost:hover{border-color:rgba(34,211,238,.34)!important;color:#67e8f9!important;background:rgba(34,211,238,.08)!important;}
            .nb-btn:disabled{cursor:not-allowed;opacity:.48;background:rgba(75,85,99,.18)!important;color:#94a3b8!important;border-color:rgba(148,163,184,.12)!important;box-shadow:none!important;transform:none!important;}
            .nb-command-body{margin-top:18px;display:block;}
            .nb-copy-tab.active{box-shadow:0 0 0 1px rgba(34,211,238,.55),0 0 18px rgba(34,211,238,.22)!important;transform:translateY(-1px);}
            .nb-header-actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap;}
            .nb-section-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin:0 0 14px;flex-wrap:wrap;}
            .nb-section-head h2{margin:0;color:#f8fafc;font-size:1.28rem;}
            .nb-section-head p{margin:4px 0 0;color:#94a3b8;font-size:.9rem;}
            .nb-command-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;}
            .nb-command-card{position:relative;border:1px solid rgba(148,163,184,.16);background:linear-gradient(145deg,rgba(15,23,42,.92),rgba(2,6,23,.94));border-radius:18px;padding:16px;box-shadow:0 14px 40px rgba(0,0,0,.24);overflow:hidden;}
            .nb-command-card:before{content:"";position:absolute;inset:0 0 auto;height:1px;background:linear-gradient(90deg,transparent,rgba(34,211,238,.35),transparent);opacity:.65;}
            .nb-command-card h3{margin:8px 0 4px;color:#f8fafc;font-size:1.08rem;letter-spacing:.01em;}
            .nb-card-subtext{margin:0 0 12px;color:#94a3b8;font-size:.9rem;min-height:20px;}
            .nb-card-topline{display:flex;align-items:center;justify-content:space-between;gap:10px;position:relative;z-index:1;}
            .nb-card-kicker{font-size:.72rem;letter-spacing:.12em;text-transform:uppercase;color:#67e8f9;font-weight:900;}
            .nb-card-facts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin:12px 0;color:#cbd5e1;font-size:.83rem;}
            .nb-card-facts span{border:1px solid rgba(148,163,184,.10);border-radius:10px;padding:8px;background:rgba(15,23,42,.46);}
            .nb-card-facts strong{color:#f8fafc;}
            .nb-card-meter{height:8px;background:rgba(2,6,23,.72);border:1px solid rgba(148,163,184,.10);border-radius:999px;overflow:hidden;margin:12px 0;box-shadow:inset 0 1px 4px rgba(0,0,0,.45);}
            .nb-card-meter span{display:block;height:100%;border-radius:999px;transition:width .35s ease;box-shadow:0 0 16px currentColor;}
            .nb-cw-card{position:relative;border-radius:20px;padding:0;background:linear-gradient(145deg,rgba(11,17,32,.96),rgba(6,8,15,.98));border:1px solid rgba(255,255,255,.08);box-shadow:0 14px 34px rgba(0,0,0,.28);overflow:hidden;transition:transform .2s ease,border-color .2s ease,box-shadow .2s ease;}
            .nb-cw-spine{position:absolute;left:0;top:0;bottom:0;width:4px;border-radius:999px;z-index:3;box-shadow:0 0 14px currentColor;}
            .nb-cw-card:hover{transform:translateY(-3px);border-color:rgba(0,212,255,.24);box-shadow:0 18px 42px rgba(0,0,0,.36),0 0 24px rgba(0,212,255,.08);}
            .nb-cw-card.complete{border-color:rgba(0,255,157,.24);background:linear-gradient(145deg,rgba(7,22,19,.96),rgba(6,8,15,.98));}
            .nb-cw-card.incident{border-color:rgba(255,76,76,.32);background:linear-gradient(145deg,rgba(23,10,14,.92),rgba(6,8,15,.98));}
            .nb-cw-card.pending{border-color:rgba(245,158,11,.24);}
            .nb-cw-card.no-index{border-color:rgba(148,163,184,.18);}
            .nb-cw-cover{width:100%;display:flex;flex-direction:column;gap:10px;border:0;background:transparent;color:inherit;padding:18px 18px 14px 22px;text-align:left;cursor:pointer;font-family:inherit;}
            .nb-cw-cover-top{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;}
            .nb-cw-cover-left{flex:1;min-width:0;}
            .nb-cw-cover-type{font-size:.62rem;letter-spacing:.14em;text-transform:uppercase;color:#67e8f9;font-weight:900;display:block;margin-bottom:4px;}
            .nb-cw-cover-title{margin:0;color:#f8fafc;font-size:1.08rem;font-weight:800;letter-spacing:.01em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
            .nb-cw-cover-right{display:flex;align-items:center;gap:8px;flex-shrink:0;}
            .nb-cw-status-badge{display:inline-flex;align-items:center;border-radius:999px;padding:5px 9px;font-size:.64rem;font-weight:900;letter-spacing:.08em;text-transform:uppercase;border:1px solid rgba(255,255,255,.10);background:rgba(255,255,255,.045);}
            .nb-cw-status-complete{color:#00ff9d;border-color:rgba(0,255,157,.34);box-shadow:0 0 14px rgba(0,255,157,.08);}
            .nb-cw-status-incident{color:#ff7474;border-color:rgba(255,76,76,.38);box-shadow:0 0 14px rgba(255,76,76,.10);}
            .nb-cw-status-pending{color:#fbbf24;border-color:rgba(245,158,11,.34);box-shadow:0 0 14px rgba(245,158,11,.08);}
            .nb-cw-status-no-index{color:#94a3b8;border-color:rgba(148,163,184,.24);box-shadow:0 0 14px rgba(148,163,184,.06);}
            .nb-cw-chevron{display:inline-grid;place-items:center;width:26px;height:26px;border-radius:999px;border:1px solid rgba(103,232,249,.16);color:#67e8f9;background:rgba(8,13,24,.76);font-size:1rem;line-height:1;transition:transform .2s ease;}
            .nb-cw-card.expanded .nb-cw-chevron{transform:rotate(180deg);}
            .nb-cw-cover-stats{display:flex;flex-wrap:wrap;gap:6px;padding-left:0;}
            .nb-cw-stat{font-size:.72rem;color:#94a3b8;font-weight:700;}
            .nb-cw-stat-current{color:#67e8f9;}
            .nb-cw-cover-badges{display:flex;gap:6px;flex-wrap:wrap;}
            .nb-cw-card-body{display:grid;grid-template-rows:1fr;opacity:1;max-height:2000px;overflow:hidden;transition:max-height .28s ease,opacity .18s ease;}
            .nb-cw-card.collapsed .nb-cw-card-body{max-height:0;opacity:0;pointer-events:none;}
            .nb-cw-card.expanded{grid-column:span 2;}
            .nb-cw-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;}
            /* ── Index Panel ── */
            .nb-cw-index-panel{border:1px solid rgba(103,232,249,.10);border-radius:16px;background:rgba(2,6,23,.34);padding:14px;margin:0 18px 12px;}
            .nb-cw-index-panel-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px;}
            .nb-cw-index-panel-head h4{margin:0;color:#e0faff;font-size:.82rem;text-transform:uppercase;letter-spacing:.10em;}
            .nb-cw-index-panel-head p{margin:2px 0 0;color:#94a3b8;font-size:.68rem;}
            .nb-cw-index-list{display:flex;flex-direction:column;gap:7px;}
            .nb-cw-index-row{display:flex;align-items:center;gap:12px;width:100%;border:1px solid rgba(148,163,184,.12);border-radius:12px;background:rgba(15,23,42,.62);color:#cbd5e1;padding:10px 12px;text-align:left;cursor:pointer;transition:all .18s ease;}
            .nb-cw-index-row:hover{border-color:rgba(34,211,238,.34);background:rgba(15,23,42,.86);transform:translateY(-1px);}
            .nb-cw-index-order{width:28px;height:28px;display:grid;place-items:center;border-radius:8px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);font-size:.72rem;font-weight:900;color:#67e8f9;flex-shrink:0;}
            .nb-cw-index-main{flex:1;min-width:0;}
            .nb-cw-index-title{color:#f8fafc;font-weight:800;font-size:.88rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
            .nb-cw-index-meta{color:#94a3b8;font-size:.68rem;margin-top:2px;}
            .nb-cw-index-status{display:inline-flex;width:max-content;border-radius:999px;padding:4px 8px;font-size:.62rem;text-transform:uppercase;letter-spacing:.06em;border:1px solid rgba(255,255,255,.10);font-weight:800;flex-shrink:0;}
            .nb-cw-index-status.complete{color:#00ff9d;border-color:rgba(0,255,157,.34);background:rgba(0,255,157,.07);}
            .nb-cw-index-status.incomplete{color:#ffb86b;border-color:rgba(245,158,11,.34);background:rgba(245,158,11,.08);}
            .nb-cw-index-status.current{color:#67e8f9;border-color:rgba(34,211,238,.34);background:rgba(34,211,238,.08);}
            .nb-cw-index-status.not-started{color:#94a3b8;border-color:rgba(148,163,184,.20);background:rgba(148,163,184,.06);}
            .nb-cw-index-update-btn{flex-shrink:0;padding:6px 10px;font-size:.6rem;}
            .nb-cw-index-empty-state{text-align:center;padding:24px 12px;color:#94a3b8;}
            .nb-cw-index-empty-icon{font-size:1.8rem;margin-bottom:8px;}
            .nb-cw-index-empty-state p{margin:4px 0;font-size:.88rem;color:#cbd5e1;}
            .nb-cw-index-empty-sub{font-size:.76rem!important;color:#94a3b8!important;}
            .nb-cw-index-empty-state .nb-btn{margin-top:10px;}
            /* ── Chapter Command Sheet overrides ── */
            .nb-command-center .nb-chapter-sheet{background:radial-gradient(ellipse at top left,rgba(0,212,255,.07),transparent 40%),linear-gradient(165deg,rgba(8,14,28,.97),rgba(4,7,16,.99));border:1px solid rgba(0,212,255,.14);box-shadow:0 28px 80px rgba(0,0,0,.6),0 0 40px rgba(0,212,255,.06);}
            .nb-command-center .nb-chapter-sheet .nb-modal-header{border-bottom:1px solid rgba(103,232,249,.12);padding-bottom:14px;margin-bottom:4px;}
            .nb-command-center .nb-chapter-sheet .nb-modal-header h2{color:#e0faff;letter-spacing:.06em;text-shadow:0 0 18px rgba(0,212,255,.15);}
            .nb-command-center .nb-sheet-body{display:flex;flex-direction:column;gap:4px;padding-top:10px;}
            .nb-command-center .nb-sheet-section{background:rgba(15,23,42,.35);border:1px solid rgba(148,163,184,.08);border-radius:14px;padding:16px 18px;margin-bottom:4px;}
            .nb-command-center .nb-sheet-section-label{font-size:.58rem;font-weight:900;letter-spacing:.16em;text-transform:uppercase;color:rgba(103,232,249,.55);margin-bottom:14px;padding-bottom:8px;border-bottom:1px solid rgba(103,232,249,.08);}
            .nb-command-center .nb-sheet-readonly-value{background:rgba(15,23,42,.5);border:1px solid rgba(148,163,184,.1);border-radius:10px;padding:10px 13px;color:rgba(226,232,240,.6);font-size:.88rem;font-weight:600;font-style:italic;min-height:44px;display:flex;align-items:center;}
            .nb-command-center .nb-status-pills{display:flex;gap:6px;flex-wrap:wrap;}
            .nb-command-center .nb-status-pill{padding:8px 14px;border-radius:10px;font-size:.68rem;font-weight:900;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.03);color:rgba(148,163,184,.7);font-family:'Inter',sans-serif;transition:all .2s ease;user-select:none;}
            .nb-command-center .nb-status-pill:hover{border-color:rgba(255,255,255,.16);background:rgba(255,255,255,.06);}
            .nb-command-center .nb-status-pill.not_started.active{color:#94a3b8;border-color:rgba(148,163,184,.35);background:rgba(148,163,184,.1);box-shadow:0 0 12px rgba(148,163,184,.08);}
            .nb-command-center .nb-status-pill.current.active{color:#67e8f9;border-color:rgba(34,211,238,.4);background:rgba(34,211,238,.1);box-shadow:0 0 14px rgba(34,211,238,.12);}
            .nb-command-center .nb-status-pill.incomplete.active{color:#ffb86b;border-color:rgba(245,158,11,.4);background:rgba(245,158,11,.1);box-shadow:0 0 14px rgba(245,158,11,.1);}
            .nb-command-center .nb-status-pill.complete.active{color:#00ff9d;border-color:rgba(0,255,157,.4);background:rgba(0,255,157,.1);box-shadow:0 0 14px rgba(0,255,157,.12);}
            .nb-command-center .nb-eta-chips{display:flex;gap:5px;margin-top:6px;flex-wrap:wrap;}
            .nb-command-center .nb-eta-chip{padding:4px 10px;border-radius:7px;font-size:.58rem;font-weight:800;letter-spacing:.04em;cursor:pointer;border:1px solid rgba(103,232,249,.14);background:rgba(103,232,249,.04);color:rgba(103,232,249,.6);font-family:'Inter',sans-serif;transition:all .18s ease;user-select:none;}
            .nb-command-center .nb-eta-chip:hover{border-color:rgba(103,232,249,.35);background:rgba(103,232,249,.1);color:#67e8f9;transform:translateY(-1px);}
            .nb-command-center .nb-deadline-helper{margin-top:6px;font-size:.62rem;font-weight:700;letter-spacing:.04em;color:rgba(148,163,184,.5);padding:4px 8px;border-radius:6px;background:rgba(15,23,42,.3);border:1px solid rgba(148,163,184,.06);display:inline-block;}
            .nb-command-center .nb-deadline-helper.overdue{color:#ff7474;border-color:rgba(255,76,76,.25);background:rgba(255,76,76,.06);}
            .nb-command-center .nb-deadline-helper.today,.nb-command-center .nb-deadline-helper.soon{color:#fbbf24;border-color:rgba(245,158,11,.25);background:rgba(245,158,11,.06);}
            .nb-command-center .nb-deadline-helper.future{color:#67e8f9;border-color:rgba(34,211,238,.2);background:rgba(34,211,238,.04);}
            .nb-command-center .nb-field-toggle{display:flex;flex-direction:column;gap:7px;}
            .nb-command-center .nb-toggle-switch{display:flex;align-items:center;gap:12px;cursor:pointer;user-select:none;padding:4px 0;}
            .nb-command-center .nb-toggle-track{width:44px;height:24px;background:rgba(30,41,59,.8);border:1px solid rgba(148,163,184,.18);border-radius:12px;position:relative;transition:all .25s ease;flex-shrink:0;box-shadow:inset 0 1px 3px rgba(0,0,0,.3);}
            .nb-command-center .nb-toggle-thumb{width:18px;height:18px;background:rgba(148,163,184,.5);border-radius:50%;position:absolute;top:2px;left:2px;transition:all .25s cubic-bezier(.175,.885,.32,1.275);box-shadow:0 1px 4px rgba(0,0,0,.3);}
            .nb-command-center .nb-toggle-switch.active .nb-toggle-track{background:rgba(34,211,238,.2);border-color:rgba(34,211,238,.4);box-shadow:inset 0 1px 3px rgba(0,0,0,.2),0 0 10px rgba(0,212,255,.1);}
            .nb-command-center .nb-toggle-switch.active .nb-toggle-thumb{left:22px;background:#67e8f9;box-shadow:0 0 8px rgba(0,212,255,.4),0 1px 4px rgba(0,0,0,.2);}
            .nb-command-center .nb-toggle-switch.active[data-action="toggle-teacher-chapter"] .nb-toggle-track{background:rgba(0,255,157,.15);border-color:rgba(0,255,157,.35);}
            .nb-command-center .nb-toggle-switch.active[data-action="toggle-teacher-chapter"] .nb-toggle-thumb{background:#00ff9d;box-shadow:0 0 8px rgba(0,255,157,.35),0 1px 4px rgba(0,0,0,.2);}
            .nb-command-center .nb-toggle-label{font-size:.72rem;font-weight:600;color:rgba(148,163,184,.6);transition:color .2s;}
            .nb-command-center .nb-toggle-switch.active .nb-toggle-label{color:rgba(226,232,240,.85);}
            .nb-command-center .nb-chapter-summary{background:rgba(2,6,23,.45);border:1px solid rgba(103,232,249,.1);border-radius:12px;padding:14px 16px;display:grid;grid-template-columns:1fr 1fr;gap:8px 16px;}
            .nb-command-center .nb-summary-row{display:flex;justify-content:space-between;align-items:center;gap:8px;}
            .nb-command-center .nb-summary-risk-row{grid-column:1/-1;border-top:1px solid rgba(148,163,184,.08);padding-top:8px;margin-top:2px;}
            .nb-command-center .nb-summary-key{font-size:.6rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:rgba(148,163,184,.45);}
            .nb-command-center .nb-summary-val{font-size:.76rem;font-weight:800;color:rgba(148,163,184,.7);text-align:right;transition:color .2s;}
            .nb-command-center .nb-sheet-footer{display:flex;align-items:center;justify-content:space-between;gap:10px;border-top:1px solid rgba(148,163,184,.1);padding-top:14px;margin-top:6px;}
            .nb-command-center .nb-sheet-footer-right{display:flex;gap:10px;margin-left:auto;}
            .nb-command-center .nb-btn-delete-chapter{background:transparent;border:1px solid rgba(255,76,76,.18);color:rgba(255,76,76,.45);padding:9px 14px;border-radius:10px;font-weight:800;font-size:.62rem;letter-spacing:.08em;text-transform:uppercase;cursor:pointer;font-family:'Inter',sans-serif;transition:all .2s ease;}
            .nb-command-center .nb-btn-delete-chapter:hover{border-color:rgba(255,76,76,.4);color:#ff7474;background:rgba(255,76,76,.06);box-shadow:0 0 12px rgba(255,76,76,.08);}
            .nb-command-center .nb-chapter-sheet input:disabled{opacity:.35;cursor:not-allowed;}
            /* ── Body Footer ── */
            .nb-cw-body-footer{padding:0 18px 18px;}
            .nb-cw-body-meta{display:flex;flex-wrap:wrap;gap:8px 16px;color:#94a3b8;font-size:.78rem;margin-bottom:12px;}
            .nb-cw-body-meta strong{color:#f8fafc;}
            .nb-cw-body-actions{display:flex;flex-wrap:wrap;gap:8px;border-top:1px solid rgba(148,163,184,.10);padding-top:12px;}
            /* ── Pills ── */
            .nb-deadline-pill,.nb-risk-pill{display:inline-flex;align-items:center;border-radius:999px;padding:5px 8px;font-size:.64rem;font-weight:900;letter-spacing:.04em;text-transform:uppercase;border:1px solid rgba(255,255,255,.10);background:rgba(255,255,255,.045);color:#cbd5e1;}
            .nb-deadline-pill.overdue,.nb-risk-pill.overdue{color:#ff7474;border-color:rgba(255,76,76,.38);background:rgba(255,76,76,.08);}
            .nb-deadline-pill.today,.nb-deadline-pill.tomorrow,.nb-deadline-pill.soon,.nb-risk-pill.today,.nb-risk-pill.soon,.nb-risk-pill.warning{color:#fbbf24;border-color:rgba(245,158,11,.36);background:rgba(245,158,11,.08);}
            .nb-deadline-pill.future{color:#67e8f9;border-color:rgba(34,211,238,.30);background:rgba(34,211,238,.07);}
            .nb-deadline-pill.none,.nb-risk-pill.none{color:#94a3b8;border-color:rgba(148,163,184,.18);}
            .nb-risk-pill.complete{color:#00ff9d;border-color:rgba(0,255,157,.34);background:rgba(0,255,157,.07);}
            /* ── Responsive ── */
            @media(max-width:720px){.nb-cw-grid{grid-template-columns:1fr}.nb-cw-card.expanded{grid-column:span 1}.nb-cw-body-meta{flex-direction:column;gap:4px}.nb-cw-body-actions{flex-direction:column}.nb-cw-body-actions .nb-btn{width:100%}.nb-cw-index-row{flex-wrap:wrap;gap:8px}.nb-cw-index-update-btn{width:100%;justify-content:center}}
            .nb-hw-card .nb-card-actions,.nb-note-card .nb-card-actions{display:flex;flex-wrap:wrap;gap:8px;}
            .nb-hw-card,.nb-note-card{transition:transform .2s ease,border-color .2s ease,box-shadow .2s ease;}
            .nb-hw-card:hover,.nb-note-card:hover{transform:translateY(-2px);border-color:rgba(34,211,238,.20);box-shadow:0 16px 36px rgba(0,0,0,.32);}
            .nb-command-group{border:1px solid rgba(148,163,184,.14);border-radius:18px;margin:0 0 14px;background:rgba(15,23,42,.48);overflow:hidden;}
            .nb-command-group summary{cursor:pointer;padding:14px 16px;display:flex;align-items:center;justify-content:space-between;color:#e2e8f0;font-weight:900;list-style:none;letter-spacing:.02em;}
            .nb-command-group summary::-webkit-details-marker{display:none;}
            .nb-command-group .nb-command-grid{padding:0 14px 14px;}
            .nb-empty-mini{border:1px dashed rgba(148,163,184,.24);border-radius:14px;color:#94a3b8;padding:18px;text-align:center;grid-column:1/-1;}
            .nb-command-empty{border:1px dashed rgba(103,232,249,.3);border-radius:18px;padding:28px;background:rgba(15,23,42,.42);}
            @media(max-width:720px){.nb-command-center .nb-field-row{grid-template-columns:1fr}.nb-card-facts{grid-template-columns:1fr}.nb-header-actions{width:100%;justify-content:flex-start}.nb-command-grid{grid-template-columns:1fr}.nb-card-actions-secondary{grid-template-columns:1fr}.nb-hw-card .nb-card-actions,.nb-note-card .nb-card-actions{display:grid;grid-template-columns:1fr}.nb-btn{width:100%;}}
        </style>`;
    }

    function _render() {
        const body = _container?.querySelector('#nbCommandBody');
        if (!body) return;
        _renderCopyTabs();
        _updateCommandSummary();

        const styles = _renderCommandStyles();
        let content = '';
        if (_activeCopyTab === 'hw') content = _renderHomeworkMissionsTab();
        else if (_activeCopyTab === 'notes') content = _renderNotesVaultTab();
        else content = _renderClassworkCopyTab();
        body.innerHTML = `${styles}${content}`;
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {
        // Click delegation
        container.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) {
                document.querySelectorAll('.cloud-popup').forEach(p => p.remove());
                return;
            }

            const action = target.dataset.action;
            const index = parseInt(target.dataset.index);

            switch (action) {
                case 'add-row':
                    _addNewRow();
                    break;
                case 'switch-copy-tab':
                    _activeCopyTab = ['cw', 'hw', 'notes'].includes(target.dataset.tab) ? target.dataset.tab : 'cw';
                    _render();
                    _dispatchNotebookUpdated({ action: 'copy_tab_switched', tab: _activeCopyTab });
                    break;
                case 'edit-hw-task':
                    if (!isNaN(index)) _openHomeworkTaskModal(index);
                    break;
                case 'delete-hw-task':
                    if (!isNaN(index)) _deleteHomeworkTask(index);
                    break;
                case 'delete-current-hw-task':
                    _deleteCurrentHomeworkTask();
                    break;
                case 'open-daily-homework-intake':
                    _openDailyHomeworkIntakeModal();
                    break;
                case 'save-hw-task':
                    _saveHomeworkTaskFromModal();
                    break;
                case 'close-hw-modal':
                    _closeHomeworkTaskModal();
                    break;
                case 'add-hw-to-missions':
                    if (!isNaN(index)) _addHomeworkToMissions(index);
                    break;
                case 'mark-hw-done':
                    if (!isNaN(index)) _markHomeworkDone(index);
                    break;
                case 'add-homework-intake-task':
                    _addHomeworkIntakeDraft({ clearAfter: true });
                    break;
                case 'add-another-homework-intake-task':
                    _addHomeworkIntakeDraft({ clearAfter: true });
                    break;
                case 'remove-intake-draft':
                    if (!isNaN(index)) {
                        _homeworkIntakeDraft.splice(index, 1);
                        _renderHomeworkIntakeDraft();
                    }
                    break;
                case 'save-homework-intake':
                    _saveDailyHomeworkIntake();
                    break;
                case 'skip-homework-intake':
                    _skipDailyHomeworkIntake();
                    break;
                case 'toggle-done':
                    if (!isNaN(index)) _toggleDone(index);
                    break;
                case 'toggle-teacher-checked':
                    if (!isNaN(index)) _toggleTeacherChecked(index);
                    break;
                case 'toggle-cw-card':
                    if (!isNaN(index)) _toggleCwCard(index);
                    break;
                case 'update-cw-copy':
                    if (!isNaN(index)) _openCwUpdateModal(index);
                    break;
                case 'save-cw-update':
                    _saveCwUpdateFromModal();
                    break;
                case 'close-cw-update':
                    _closeCwUpdateModal();
                    break;
                case 'close-cw-create':
                    _closeCwCreateModal();
                    break;
                case 'save-cw-create':
                    _handleCwCreateSave();
                    break;
                case 'select-cw-create-start-mode':
                    _handleCwCreateStartModeSelect(target);
                    break;
                case 'toggle-cw-create-teacher':
                    _handleCwCreateTeacherToggle();
                    break;
                case 'cw-create-subject-change':
                    // handled via change event below, not click
                    break;
                case 'add-cw-chapter':
                    if (!isNaN(index)) _openCwChapterModal(index, null);
                    break;
                case 'open-import-syllabus':
                    if (!isNaN(index)) _openImportSyllabusModal(index);
                    break;
                case 'close-import-syllabus':
                    _closeImportSyllabusModal();
                    break;
                case 'confirm-import-syllabus':
                    _confirmImportSyllabus();
                    break;
                case 'update-cw-chapter':
                    if (!isNaN(index)) _openCwChapterModal(index, target.dataset.chapterId);
                    break;
                case 'select-chapter-status':
                    if (target.classList.contains('nb-ch-seg-btn')) {
                        const statusValue = target.dataset.value;
                        const hiddenInput = _container?.querySelector('#nbCwChapterStatus');
                        if (hiddenInput) hiddenInput.value = statusValue;
                        _container.querySelectorAll('#nbCwChapterStatusPills .nb-ch-seg-btn').forEach(btn => {
                            btn.classList.toggle('active', btn.dataset.value === statusValue);
                        });
                        _updateChapterSheetSummary();
                    }
                    break;
                case 'set-chapter-eta':
                    const etaMinutes = target.dataset.minutes;
                    const etaInput = _container?.querySelector('#nbCwChapterEstimatedMinutes');
                    if (etaInput && etaMinutes) {
                        etaInput.value = etaMinutes;
                        _updateChapterSheetSummary();
                    }
                    break;
                case 'toggle-teacher-chapter':
                    const teacherHidden = _container?.querySelector('#nbCwChapterTeacherChecked');
                    const teacherToggleEl = target.closest('.nb-ch-toggle') || target;
                    if (teacherHidden) {
                        const isYes = teacherHidden.value === 'yes';
                        teacherHidden.value = isYes ? 'no' : 'yes';
                        if (teacherToggleEl) teacherToggleEl.classList.toggle('active', !isYes);
                        const teacherLbl = _container?.querySelector('#nbCwChapterTeacherCheckedLabel');
                        if (teacherLbl) teacherLbl.textContent = !isYes ? 'Verified' : 'Not checked';
                        _updateChapterSheetSummary();
                    }
                    break;
                case 'toggle-backlog-chapter':
                    const backlogHidden = _container?.querySelector('#nbCwChapterSendBacklog');
                    const backlogToggleEl = target.closest('.nb-ch-toggle') || target;
                    if (backlogHidden) {
                        const isYes = backlogHidden.value === 'yes';
                        backlogHidden.value = isYes ? 'no' : 'yes';
                        if (backlogToggleEl) backlogToggleEl.classList.toggle('active', !isYes);
                        const backlogLbl = _container?.querySelector('#nbCwChapterBacklogLabel');
                        if (backlogLbl) backlogLbl.textContent = !isYes ? 'On' : 'Off';
                        _updateChapterSheetSummary();
                    }
                    break;
                case 'delete-cw-chapter-inline':
                    _deleteCwChapterInline();
                    break;
                case 'directive-action':
                    _executeDirectiveAction();
                    break;
                case 'directive-backlog':
                    _executeDirectiveBacklog();
                    break;
                case 'directive-done':
                    _executeDirectiveDone();
                    break;
                case 'save-cw-chapter':
                    _saveCwChapterFromModal();
                    break;
                case 'close-cw-chapter':
                    _closeCwChapterModal();
                    break;
                case 'send-cw-backlog':
                    if (!isNaN(index)) _sendClassworkToBacklog(index);
                    break;
                case 'edit-cw-copy':
                    if (!isNaN(index)) _editClassworkCopy(index);
                    break;
                case 'delete-cw-copy':
                    if (!isNaN(index)) _deleteClassworkCopy(index);
                    break;
                case 'show-popup':
                    e.stopPropagation();
                    if (!isNaN(index)) _showPopup(index);
                    break;
                case 'apply-incident':
                    if (!isNaN(index)) _applyIncident(index);
                    break;
                case 'deploy-note':
                    _openNoteModal(null);
                    break;
                case 'save-note':
                    _saveNote();
                    break;
                case 'edit-note':
                    _openNoteModal(target.dataset.noteId);
                    break;
                case 'delete-note':
                    _deleteNote(target.dataset.noteId);
                    break;
                case 'close-note-modal':
                    _closeNoteModal();
                    break;
                // Phase 7H-5: Quick actions
                case 'mark-note-reviewed':
                    _markNoteReviewed(target.dataset.noteId);
                    break;
                case 'mark-note-pending':
                    _markNotePending(target.dataset.noteId);
                    break;
                case 'mark-note-overdue':
                    _markNoteOverdue(target.dataset.noteId);
                    break;
                case 'strengthen-note':
                    _openNoteModal(target.dataset.noteId);
                    break;
            }
        }, { signal });

        // Change delegation (for subject input + type select + chapter sheet inputs)
        container.addEventListener('change', (e) => {
            const target = e.target;
            const action = target.dataset.action;
            const index = parseInt(target.dataset.index);

            // Chapter sheet live summary updates
            if (target.id === 'nbCwChapterPendingPages' || target.id === 'nbCwChapterEstimatedMinutes' || target.id === 'nbCwChapterDeadline') {
                _updateChapterSheetSummary();
            }

            // C.W. Create modal — subject dropdown change
            if (target.id === 'nbCwCreateSubject') {
                _handleCwCreateSubjectChange();
            }

            if (action === 'update-subject' && !isNaN(index)) {
                _updateRow(index, 'subject', target.value);
            } else if (action === 'update-type' && !isNaN(index)) {
                _updateRow(index, 'type', target.value);
            } else if (action === 'update-chapter' && !isNaN(index)) {
                _updateRow(index, 'chapter', target.value);
            } else if (action === 'update-task-title' && !isNaN(index)) {
                _updateRow(index, 'taskTitle', target.value);
            } else if (action === 'update-due-date' && !isNaN(index)) {
                _updateRow(index, 'dueDate', target.value);
            } else if (action === 'update-hw-type' && !isNaN(index)) {
                _updateRow(index, 'hwType', target.value);
            } else if (action === 'update-priority' && !isNaN(index)) {
                _updateRow(index, 'priority', target.value);
            } else if (action === 'update-status' && !isNaN(index)) {
                const row = _rows[index];
                if (!row) return;
                row.status = target.value;
                row.done = target.value === 'done';
                if (row.done) {
                    _completeLinkedNotebookBacklogs(row);
                } else {
                    _syncHomeworkBacklog(row);
                }
                _save();
                _fullSync();
                _dispatchNotebookUpdated({ action: 'homework_status_updated', rowId: row.id, status: row.status });
            }
        }, { signal });

        // Stop popup clicks from bubbling to document
        container.addEventListener('click', (e) => {
            if (e.target.closest('.cloud-popup')) {
                e.stopPropagation();
            }
        }, { signal });

        // Phase 7H-4: Click modal overlay to close
        container.addEventListener('click', (e) => {
            const overlay = e.target.closest('.nb-note-modal-overlay');
            if (overlay && e.target === overlay) {
                if (overlay.id === 'nbHwTaskModal') _closeHomeworkTaskModal();
                else if (overlay.id === 'nbCwUpdateModal') _closeCwUpdateModal();
                else if (overlay.id === 'nbCwChapterModal') _closeCwChapterModal();
                else if (overlay.id === 'nbCwCreateModal') _closeCwCreateModal();
                else if (overlay.id === 'nbCwImportModal') _closeImportSyllabusModal();
                else if (overlay.id === 'nbDailyHomeworkModal') _skipDailyHomeworkIntake();
                else _closeNoteModal();
            }
        }, { signal });

        // Phase 7H-4: Escape key to close modal
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                if (_editingNoteId !== null) _closeNoteModal();
                if (_editingHomeworkIndex !== null || _container?.querySelector('#nbHwTaskModal')?.style.display === 'flex') _closeHomeworkTaskModal();
                if (_editingCwCopyIndex !== null || _container?.querySelector('#nbCwUpdateModal')?.style.display === 'flex') _closeCwUpdateModal();
                if (_editingCwChapterContext !== null || _container?.querySelector('#nbCwChapterModal')?.style.display === 'flex') _closeCwChapterModal();
                if (_container?.querySelector('#nbCwCreateModal')?.style.display === 'flex') _closeCwCreateModal();
                if (_importSyllabusRowIndex !== null || _container?.querySelector('#nbCwImportModal')?.style.display === 'flex') _closeImportSyllabusModal();
                if (_container?.querySelector('#nbDailyHomeworkModal')?.style.display === 'flex') _skipDailyHomeworkIntake();
            }
        }, { signal });
    }

    // ════════════════════════════════════════════════════════
    //  TOAST
    // ════════════════════════════════════════════════════════

    function _showToast(message) {
        const toast = _container?.querySelector('#nbToast');
        if (!toast) return;
        toast.textContent = message;
        toast.classList.add('visible');
        setTimeout(() => toast.classList.remove('visible'), 2800);
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();

window.NotebooksRoute = NotebooksRoute;
