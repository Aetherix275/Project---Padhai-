/**
 * ═══════════════════════════════════════════════════════
 *  SMART PADHAI — PANIC PROTOCOL V2
 *  Module: window.PanicProtocolV2
 *  Phase: V2A (Plan Type Detector + Chapter Urgency + Dashboard Card)
 *
 *  CONSTRAINTS:
 *  - Reads from SafeStorage / localStorage only
 *  - Does NOT mutate any study data
 *  - Does NOT manipulate DOM directly
 *  - Returns pure plan object — DashboardRoute renders it
 *  - No API calls, no fake data, no notifications
 * ═══════════════════════════════════════════════════════
 */

(function () {
    'use strict';

    // ── Safe read helpers ──────────────────────────────────────────────────

    function safeGet(key, fallback) {
        try {
            if (typeof SafeStorage !== 'undefined' && SafeStorage.getItem) {
                const val = SafeStorage.getItem(key, fallback);
                return val !== null && val !== undefined ? val : fallback;
            }
            const raw = localStorage.getItem(key);
            if (!raw) return fallback;
            try { return JSON.parse(raw); } catch { return raw; }
        } catch {
            return fallback;
        }
    }

    function normalizeDate(dateLike) {
        if (!dateLike) return null;
        const d = new Date(dateLike);
        if (isNaN(d.getTime())) return null;
        d.setHours(0, 0, 0, 0);
        return d;
    }

    // ── collectContext ─────────────────────────────────────────────────────

    function collectContext() {
        const masterData   = safeGet('smartPadhaiData', {});
        const memoryDecay  = safeGet('smart_padhai_memory_decay', {});
        const autopsies    = safeGet('smart_padhai_exam_autopsies', []);
        const calendarData = safeGet('calendarStrategy', {});
        const pulseData    = safeGet('pulse_engine_data', {});

        // Chapter candidates
        const chapters = getChapterCandidates(masterData);

        // Completion stats
        const total     = chapters.length;
        const completed = chapters.filter(ch => ch.tasksDone === 3).length;
        const completionRate = total > 0 ? completed / total : 0;

        // Backlog = started but not completed
        const backlogCount = chapters.filter(ch => ch.tasksDone > 0 && ch.tasksDone < 3).length;

        // Nearest exam from calendar
        const nearestExam = getNearestExam(calendarData);
        const daysLeft    = nearestExam ? calculateDaysLeft(nearestExam.date) : null;

        // Weak chapters from autopsies
        const weakChapters = extractWeakChapters(autopsies);

        // Memory-critical chapters
        const memoryCriticalCount = Object.values(memoryDecay)
            .filter(m => (m.retention || 100) < 40).length;

        return {
            masterData,
            memoryDecay,
            weakChapters,
            calendarData,
            pulseData,
            chapters,
            total,
            completed,
            completionRate,
            backlogCount,
            nearestExam,
            daysLeft,
            memoryCriticalCount
        };
    }

    // ── getNearestExam ─────────────────────────────────────────────────────

    function getNearestExam(calendarData) {
        const today = normalizeDate(new Date());
        if (!today) return null;

        const exams = [];

        if (Array.isArray(calendarData)) {
            calendarData.forEach(ev => {
                if (ev?.type === 'exam' || ev?.mode === 'exam') {
                    const d = normalizeDate(ev.date || ev.examDate);
                    if (d && d >= today) exams.push({ subject: ev.subject || ev.title || 'Exam', date: d });
                }
            });
        } else if (calendarData && typeof calendarData === 'object') {
            Object.keys(calendarData).forEach(key => {
                const ev = calendarData[key];
                if (ev && (ev.type === 'exam' || ev.mode === 'exam' || (typeof ev === 'object' && key.toLowerCase().includes('exam')))) {
                    const d = normalizeDate(key) || normalizeDate(ev.date || ev.examDate);
                    if (d && d >= today) exams.push({ subject: ev.subject || ev.text || ev.title || 'Exam', date: d });
                }
            });
        }

        if (!exams.length) return null;
        exams.sort((a, b) => a.date - b.date);
        return exams[0];
    }

    function calculateDaysLeft(examDate) {
        if (!examDate) return null;
        const today = normalizeDate(new Date());
        const diffMs = examDate.getTime() - today.getTime();
        return Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
    }

    // ── extractWeakChapters ────────────────────────────────────────────────

    function extractWeakChapters(autopsies) {
        const weak = new Set();
        const list = Array.isArray(autopsies) ? autopsies : Object.values(autopsies || {});
        list.forEach(entry => {
            if (Array.isArray(entry?.weakChapters)) {
                entry.weakChapters.forEach(ch => {
                    const name = typeof ch === 'string' ? ch : ch?.chapter || ch?.name;
                    if (name) weak.add(name.toLowerCase().trim());
                });
            }
        });
        return weak;
    }

    // ── getChapterCandidates ───────────────────────────────────────────────

    function getChapterCandidates(masterData) {
        if (!masterData || typeof masterData !== 'object') return [];
        return Object.keys(masterData).map(chapterName => {
            const ch = masterData[chapterName] || {};
            const read  = ch.read  === true || ch.read  === 'true';
            const notes = ch.notes === true || ch.notes === 'true';
            const pyq   = ch.pyq   === true || ch.pyq   === 'true';
            const tasksDone = [read, notes, pyq].filter(Boolean).length;
            return {
                chapterName,
                subject:      ch.subject || 'General',
                tasksDone,
                read, notes, pyq,
                isSyllabus:   ch.isSyllabus !== false,
                memoryMeta:   ch.memoryMeta || null,
                marksWeight:  ch.marksWeight || null,
                lastUpdated:  ch.lastUpdated || null
            };
        });
    }

    // ── determinePlanType ─────────────────────────────────────────────────

    function determinePlanType(context) {
        const { daysLeft, completionRate, backlogCount, nearestExam } = context;

        if (nearestExam && typeof daysLeft === 'number') {
            if (daysLeft <= 3) {
                return {
                    planType: '3_DAY_RESCUE',
                    modeLabel: '3-Day Rescue',
                    reason: `Exam in ${daysLeft} day(s). Maximum urgency — prioritize PYQs and recall only.`,
                    daysLeft,
                    examSubject: nearestExam.subject,
                    severity: 'critical'
                };
            }
            if (daysLeft <= 7) {
                return {
                    planType: '7_DAY_BLITZ',
                    modeLabel: '7-Day Blitz',
                    reason: `Exam in ${daysLeft} days. Stabilize weak chapters with retrieval + PYQs.`,
                    daysLeft,
                    examSubject: nearestExam.subject,
                    severity: 'urgent'
                };
            }
            if (daysLeft <= 14) {
                return {
                    planType: '14_DAY_SIEGE',
                    modeLabel: '14-Day Siege',
                    reason: `Exam in ${daysLeft} days. Build systematic coverage with spaced retrieval.`,
                    daysLeft,
                    examSubject: nearestExam.subject,
                    severity: 'moderate'
                };
            }
            if (completionRate < 0.50) {
                return {
                    planType: 'FRESH_START',
                    modeLabel: 'Fresh Start',
                    reason: `Exam is ${daysLeft} days away but completion is low (${Math.round(completionRate * 100)}%). Build foundation now.`,
                    daysLeft,
                    examSubject: nearestExam.subject,
                    severity: 'moderate'
                };
            }
            return {
                planType: '14_DAY_SIEGE',
                modeLabel: '14-Day Siege',
                reason: `Exam in ${daysLeft} days. Maintain coverage and reinforce retention.`,
                daysLeft,
                examSubject: nearestExam.subject,
                severity: 'low'
            };
        }

        // No exam
        if (completionRate < 0.40 || backlogCount > 10) {
            return {
                planType: 'FRESH_START',
                modeLabel: 'Fresh Start',
                reason: `No upcoming exam. Completion is ${Math.round(completionRate * 100)}% — time to build momentum.`,
                daysLeft: null,
                examSubject: null,
                severity: 'moderate'
            };
        }

        return {
            planType: 'NORMAL',
            modeLabel: 'Normal Mode',
            reason: 'No urgent exam. Keep clearing tasks and reinforcing studied chapters.',
            daysLeft: null,
            examSubject: null,
            severity: 'low'
        };
    }

    // ── calcUrgencyScore ───────────────────────────────────────────────────

    function calcUrgencyScore(chapter, context) {
        const { memoryDecay, weakChapters, daysLeft } = context;

        const { chapterName, tasksDone, marksWeight } = chapter;
        const taskGap    = (3 - tasksDone) / 3;
        const weight     = Number(marksWeight) || 5;

        // Retention
        let retention = null;
        const decayEntry = memoryDecay[chapterName] || memoryDecay[chapterName?.toLowerCase()] || null;
        if (decayEntry?.retention != null) {
            retention = Number(decayEntry.retention);
        } else if (chapter.memoryMeta?.retention != null) {
            retention = Number(chapter.memoryMeta.retention);
        }
        if (retention === null) {
            if (tasksDone === 3) retention = 70;
            else if (tasksDone === 2) retention = 55;
            else if (tasksDone === 1) retention = 35;
            else retention = 20;
        }
        retention = Math.max(0, Math.min(100, retention));

        const decayPenalty = Math.max(0, (100 - retention) / 100);

        let urgency = weight * (decayPenalty * 0.5 + taskGap * 0.3);

        // Bonuses
        const chapLower = chapterName.toLowerCase().trim();
        if (weakChapters.has(chapLower)) urgency += 15;
        if (tasksDone === 2) urgency += 10;
        if (retention < 40) urgency += 8;
        if (tasksDone > 0 && tasksDone < 3) urgency += 5;

        // Time multiplier
        if (typeof daysLeft === 'number') {
            if (daysLeft <= 3) urgency *= 1.5;
            else if (daysLeft <= 7) urgency *= 1.2;
        }

        return {
            score:     Math.round(urgency * 10) / 10,
            retention,
            taskGap,
            tasksDone,
            reasonTags: buildReasonTags(chapter, retention, weakChapters)
        };
    }

    function buildReasonTags(chapter, retention, weakChapters) {
        const tags = [];
        const { tasksDone, chapterName } = chapter;
        if (weakChapters.has(chapterName.toLowerCase().trim())) tags.push('Autopsy Flag');
        if (tasksDone === 2)                                      tags.push('Quick Win');
        if (retention < 40)                                       tags.push('Memory Critical');
        if (tasksDone > 0 && tasksDone < 3)                       tags.push('Backlog');
        if (tasksDone === 0)                                       tags.push('Not Started');
        return tags;
    }

    // ── recommendSessionType ───────────────────────────────────────────────

    function recommendSessionType(chapter, planType, context) {
        const { tasksDone }   = chapter;
        const { memoryDecay } = context;

        const decayEntry = memoryDecay[chapter.chapterName] || {};
        const retention  = Number(decayEntry.retention ?? (tasksDone === 3 ? 70 : tasksDone === 2 ? 55 : tasksDone === 1 ? 35 : 20));

        const lastReview = decayEntry.lastReviewDate ? normalizeDate(decayEntry.lastReviewDate) : null;
        const today      = normalizeDate(new Date());
        const daysSince  = lastReview ? Math.floor((today - lastReview) / 86400000) : null;
        const reviewDue  = daysSince !== null && daysSince >= 3;

        if (planType === '3_DAY_RESCUE') {
            if (retention >= 40 || tasksDone >= 1) {
                return session('PYQ_PRACTICE', 'PYQ Practice',
                    'Attempt 10 questions without notes. Score yourself. Review wrong answers.', 35);
            }
            return session('TARGETED_RECALL_PATCH', 'Targeted Recall',
                'Read core points once. Close material. Recall on blank sheet. Focus on examinable facts only.', 25);
        }

        if (retention < 35) {
            return session('CONCEPT_RETRIEVAL', 'Concept Retrieval',
                'Read summary once, close material, then recall on blank sheet.', 30);
        }

        if (tasksDone >= 1 && retention >= 40) {
            return session('PYQ_PRACTICE', 'PYQ Practice',
                'Attempt 10 questions without notes. Score yourself. Review wrong answers.', 35);
        }

        if (reviewDue) {
            return session('SPACED_RETRIEVAL', 'Spaced Retrieval',
                'Write key formulas/concepts from memory before opening notes.', 25);
        }

        return session('MIXED_PRACTICE', 'Mixed Practice',
            'Alternate self-testing and problem solving. Avoid passive rereading.', 40);
    }

    function session(type, label, instruction, estimatedMinutes) {
        return { type, label, instruction, estimatedMinutes };
    }

    // ── getProtocolRules ───────────────────────────────────────────────────

    function getProtocolRules(planType) {
        const rules = {
            '3_DAY_RESCUE': {
                methodRatio: '80% PYQ / 20% targeted recall',
                doRule:      'Practice test first, study second.',
                dontRule:    'Do not start low-value new chapters.',
                maxChaptersToday: 4
            },
            '7_DAY_BLITZ': {
                methodRatio: '60% retrieval + PYQ / 40% concept stabilization',
                doRule:      'Review weak chapters with 24–72 hour spacing.',
                dontRule:    'Do not save PYQs for the final day.',
                maxChaptersToday: 5
            },
            '14_DAY_SIEGE': {
                methodRatio: '50% retrieval / 30% PYQ / 20% concept repair',
                doRule:      'Use spaced reviews every 3–5 days.',
                dontRule:    'Do not let critical chapters go stale.',
                maxChaptersToday: 6
            },
            'FRESH_START': {
                methodRatio: '40% recall / 40% completion / 20% review',
                doRule:      'Show only the next few targets. Build momentum.',
                dontRule:    'Do not stare at the full backlog.',
                maxChaptersToday: 4
            },
            'NORMAL': {
                methodRatio: 'Balanced study mode',
                doRule:      'Clear one high-value task today.',
                dontRule:    'Do not let backlog grow silently.',
                maxChaptersToday: 3
            }
        };
        return rules[planType] || rules['NORMAL'];
    }

    // ── generatePlan ───────────────────────────────────────────────────────

    function generatePlan() {
        const context = collectContext();

        // No data fallback
        if (!context.chapters || context.chapters.length === 0) {
            return {
                planType:            'NORMAL',
                modeLabel:           'Normal Mode',
                daysLeft:            null,
                examSubject:         null,
                severity:            'low',
                reason:              'Not enough study data yet. Complete syllabus/backlog tracking to unlock precise panic planning.',
                completionRate:      0,
                backlogCount:        0,
                memoryCriticalCount: 0,
                topChapters:         [],
                rules:               getProtocolRules('NORMAL'),
                alerts:              ['No chapter data found. Add subjects to your syllabus to activate V2 planning.'],
                _lowConfidence:      true
            };
        }

        const planMeta  = determinePlanType(context);
        const { planType, modeLabel, reason, daysLeft, examSubject, severity } = planMeta;
        const rules     = getProtocolRules(planType);

        // Score and sort all candidates that are relevant (not fully complete or memory-weak)
        const scoredChapters = context.chapters
            .filter(ch => {
                if (ch.tasksDone < 3) return true;
                const decay = context.memoryDecay[ch.chapterName];
                if (decay?.retention != null && Number(decay.retention) < 60) return true;
                return false;
            })
            .map(ch => {
                const scored = calcUrgencyScore(ch, context);
                const sessionType = recommendSessionType(ch, planType, context);
                return {
                    chapterName:   ch.chapterName,
                    subject:       ch.subject,
                    urgencyScore:  scored.score,
                    retention:     scored.retention,
                    tasksDone:     scored.tasksDone,
                    taskGap:       scored.taskGap,
                    reasonTags:    scored.reasonTags,
                    sessionType
                };
            })
            .sort((a, b) => b.urgencyScore - a.urgencyScore)
            .slice(0, 3);

        const alerts = [];
        if (context.memoryCriticalCount > 3) {
            alerts.push(`${context.memoryCriticalCount} chapters have critically low retention (<40%). Prioritize retrieval.`);
        }
        if (context.backlogCount > 8) {
            alerts.push(`${context.backlogCount} chapters are in backlog. Consider a focused backlog sprint.`);
        }

        return {
            planType,
            modeLabel,
            daysLeft,
            examSubject,
            severity,
            reason,
            completionRate:      context.completionRate,
            backlogCount:        context.backlogCount,
            memoryCriticalCount: context.memoryCriticalCount,
            topChapters:         scoredChapters,
            rules,
            alerts,
            _lowConfidence:      false
        };
    }

    // ── Public API ─────────────────────────────────────────────────────────

    window.PanicProtocolV2 = {
        generatePlan,
        determinePlanType,
        collectContext,
        getChapterCandidates,
        calcUrgencyScore,
        recommendSessionType,
        getProtocolRules
    };

    console.log('[PanicProtocolV2] Module loaded.');

})();
