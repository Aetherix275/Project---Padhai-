/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — BACKLOG ROUTE MODULE (Phase 8D-3)
 *  Full SPA conversion of Backlog Battle
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear timers
 *
 *  Backlog Calculation Rule (MANDATORY):
 *    started    = read || notes || pyq
 *    completed  = read && notes && pyq
 *    realBacklog = started && !completed
 *    Untouched chapters (all false) are NOT backlog.
 *
 *  Data: SafeStorage-first, SyncManager-debounced Supabase mirror second
 *  Events: All via event delegation + AbortController. Zero inline onclick.
 *  CSS: Loaded dynamically from styles/modules/backlog.css
 *
 *  Phase 8D-3: SyncManager Migration — replaced full-table fire-and-forget
 *  _syncToSupabase with per-chapter SyncManager.enqueue. Debounced 300ms
 *  per table. Conservative cloud merge. SafeStorage remains primary.
 *  smartPadhaiData format unchanged. PP and Syllabus untouched.
 *  Actual backlogs table columns: id, chapter, subject, read, notes, pyq,
 *  last_updated, user_key, user_id. Unique constraint: user_id, chapter.
 *
 *  Auto-Rank: Intelligent backlog prioritization panel that scores, sorts,
 *  and filters backlog items using inferred priority, due-date urgency,
 *  age penalty, subject importance, category weight, and effort logic.
 * ═══════════════════════════════════════════════════════════════════
 */

const BacklogRoute = (() => {

    // ── Private state ──
    let _container = null;
    let _abortController = null;
    let _missionTimer = null;
    let _isMissionRunning = false;
    let _toastTimeout = null;
    let _cssLinkEl = null;

    // ── Auto-Rank state ──
    let _rankSortType = 'score';   // 'score' | 'age' | 'effort' | 'subject'
    let _rankFilter = 'all';       // 'all' | 'Critical' | 'High' | 'Medium' | 'Low'
    let _rankSubject = 'all';      // 'all' | specific subject name

    const CSS_PATH = './styles/modules/backlog.css';
    const TIMELINE_KEY = 'backlog_timeline';
    const VICTORY_KEY = 'victoryList';
    const DAILY_STATS_KEY = 'dailyStats';
    const MASTER_KEY = 'smartPadhaiData';

    // ── Subject detection for Supabase mirror ──
    const _CHEMISTRY_CHAPTERS = [
        "Metals & Non-metals", "Carbon & its Compounds",
        "Acids, Bases & Salts", "Chemical Reactions",
        "Electricity", "Magnetic Effects"
    ];
    const _MATHS_CHAPTERS = [
        "Polynomials", "Real Numbers", "Real Number",
        "Quadratic Equations", "Trigonometry"
    ];

    function _detectSubject(chapter) {
        if (_CHEMISTRY_CHAPTERS.includes(chapter)) return "Chemistry";
        if (_MATHS_CHAPTERS.includes(chapter)) return "Maths";
        return "Unknown";
    }

    // ── Phase 8D-5A: SyncManager Naming Compatibility Helper ──
    // Resolves window.SPSyncManager (actual app sync manager)
    // Falls back to window.SyncManager (legacy), then null.
    // NEVER touches Aestra Ai/syncManager.js
    function _getSyncManager() {
        return window.SPSyncManager || window.SyncManager || null;
    }

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════

    async function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;
        _isMissionRunning = false;
        _missionTimer = null;

        // Reset Auto-Rank state
        _rankSortType = 'score';
        _rankFilter = 'all';
        _rankSubject = 'all';

        // 1. Load CSS
        _loadCSS();

        // 2. Try loading from cloud via SyncManager (best-effort merge)
        await _loadFromCloud();

        // 3. Render full UI
        container.innerHTML = renderFullUI();

        // 4. Auto-load today's schedule
        _autoLoadTodaySchedule();

        // 5. Render all sections
        _renderInventory();
        _syncCurrentBacklogInventory(); // Phase 8D-5C: mirror syllabus-created backlogs to Supabase
        renderBacklogAutoRank();        // Auto-Rank: initial render after inventory
        _renderVictories();
        _buildTimelineTabs();
        _updateDynamicCleanup();

        // 6. Bind events
        _bindEvents(container, _abortController.signal);

        console.log('[BacklogRoute] Initialized');
    }

    function cleanup() {
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }
        if (_missionTimer) {
            clearInterval(_missionTimer);
            _missionTimer = null;
        }
        if (_toastTimeout) {
            clearTimeout(_toastTimeout);
            _toastTimeout = null;
        }
        _isMissionRunning = false;

        // Reset Auto-Rank state
        _rankSortType = 'score';
        _rankFilter = 'all';
        _rankSubject = 'all';

        // Remove confirm overlays
        document.querySelectorAll('.bl-confirm-overlay').forEach(el => el.remove());
        // Remove toast elements
        document.querySelectorAll('.bl-toast').forEach(el => el.remove());
        _unloadCSS();
        _container = null;
        console.log('[BacklogRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.backlogCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-backlog-css]');
        if (el) { el.remove(); _cssLinkEl = null; }
    }

    // ════════════════════════════════════════════════════════
    //  SYNC MANAGER SYNC (Phase 8D-3)
    //  Actual backlogs schema:
    //    id, chapter, subject, read, notes, pyq, last_updated,
    //    user_key, user_id
    //  Unique constraint for upsert: user_id, chapter
    //  SyncManager injects user_id automatically on enqueue.
    // ════════════════════════════════════════════════════════

    // ── Canonical User ID Helper ── (Phase 8D-5A: uses _getSyncManager)
    // Priority: SyncManager → AppState → localStorage fallback
    // Returns null if no userId found (caller must guard)
    function _getUserId() {
        const sync = _getSyncManager();
        return sync?.getUserId?.()
            || window.AppState?.currentUser?.id
            || localStorage.getItem('_current_user_id')
            || null;
    }

    /**
     * Merge cloud rows into local smartPadhaiData.
     * Conservative: cloud-only chapters added, existing local progress
     * NEVER overwritten unless local has zero progress and cloud has some.
     * Preserves _scheduledFor, isSyllabus, and subject from local.
     * @param {array} rows - Rows from backlogs table
     */
    function _mergeCloudRows(rows) {
        const local = SafeStorage.getItem(MASTER_KEY, {});

        // Defensive: local must be a plain object
        if (typeof local !== 'object' || local === null || Array.isArray(local)) {
            console.warn('[BacklogRoute] Local masterData corrupted in cloud merge, resetting');
            return;
        }

        let merged = false;

        rows.forEach(row => {
            const chapter = row.chapter;
            if (!chapter) return;

            const localEntry = local[chapter];
            const cloudRead = !!row.read;
            const cloudNotes = !!row.notes;
            const cloudPyq = !!row.pyq;

            if (!localEntry || typeof localEntry !== 'object') {
                // Cloud-only chapter — add to local
                local[chapter] = {
                    read: cloudRead,
                    notes: cloudNotes,
                    pyq: cloudPyq,
                    subject: row.subject || 'Unknown',
                    lastUpdated: row.last_updated || new Date().toLocaleDateString(),
                    isSyllabus: true
                };
                merged = true;
            } else {
                // Both exist — SAFE MERGE: only accept cloud when local has ZERO progress
                // This prevents stale Supabase data from overwriting user's recent edits
                const localDone = [localEntry.read, localEntry.notes, localEntry.pyq].filter(Boolean).length;
                const cloudDone = [cloudRead, cloudNotes, cloudPyq].filter(Boolean).length;

                if (localDone === 0 && cloudDone > 0) {
                    local[chapter] = {
                        ...localEntry,  // preserve _scheduledFor, isSyllabus
                        read: cloudRead,
                        notes: cloudNotes,
                        pyq: cloudPyq,
                        subject: row.subject || localEntry.subject || 'Unknown',
                        isSyllabus: localEntry.isSyllabus !== false,
                        lastUpdated: row.last_updated || localEntry.lastUpdated
                    };
                    merged = true;
                }
            }
        });

        if (merged) {
            SafeStorage.setItem(MASTER_KEY, local);
            console.log(`[BacklogRoute] Merged ${rows.length} cloud rows. Local chapters: ${Object.keys(local).length}`);
        }
    }

    /**
     * Load backlog data from cloud via SyncManager.
     * Falls back to direct Supabase query if SyncManager unavailable.
     * Conservative merge: cloud-only rows added, local rows NEVER overwritten.
     */
    async function _loadFromCloud() {
        // ── Try SyncManager first (Phase 8D-5A: via _getSyncManager) ──
        const sync = _getSyncManager();
        if (sync && typeof sync.loadFromCloud === 'function') {
            try {
                const rows = await sync.loadFromCloud('backlogs', {
                    columns: '*',
                    statusKey: 'backlogs'
                });
                if (rows && rows.length > 0) {
                    _mergeCloudRows(rows);
                    return;
                }
                return; // No rows or empty — nothing to merge
            } catch (err) {
                console.warn('[BacklogRoute] SyncManager load failed, trying fallback:', err);
            }
        }

        // ── Fallback: direct Supabase query (legacy path) ──
        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) {
            console.warn('[BacklogRoute] Supabase load skipped — no userId available');
            return;
        }

        try {
            const { data, error } = await window.supabaseClient
                .from('backlogs')
                .select('*')
                .eq('user_id', userId);

            if (error || !data || data.length === 0) return;

            _mergeCloudRows(data);
        } catch (err) {
            console.warn('[BacklogRoute] Fallback Supabase load failed:', err);
        }
    }

    /**
     * Build a schema-safe row for the backlogs table from a local chapter entry.
     * Uses ONLY actual backlogs columns:
     *   chapter, subject, read, notes, pyq, last_updated, user_key
     * SyncManager injects user_id automatically.
     * Does NOT send: source_key, completed, progress, raw_data, updated_at
     * @param {string} chapterName - Chapter name (key in smartPadhaiData)
     * @returns {object|null} Row object or null if entry missing
     */
    function _buildBacklogRow(chapterName) {
        const masterData = SafeStorage.getItem(MASTER_KEY, {});
        const entry = masterData[chapterName];

        if (!entry || typeof entry !== 'object') return null;

        const userId = _getUserId();

        return {
            chapter: chapterName,
            subject: entry.subject || _detectSubject(chapterName),
            read: !!entry.read,
            notes: !!entry.notes,
            pyq: !!entry.pyq,
            last_updated: entry.lastUpdated || new Date().toISOString(),
            user_key: userId || ''   // legacy column, kept for backward compat
        };
    }

    /**
     * Enqueue a single chapter upsert via SyncManager.
     * conflictKey: 'user_id,chapter' — matches actual DB unique constraint.
     * Falls back to direct Supabase single-row upsert if SyncManager unavailable/rejected.
     * @param {string} chapterName - Chapter name (key in smartPadhaiData)
     */
    function _enqueueChapterUpsert(chapterName) {
        const row = _buildBacklogRow(chapterName);
        if (!row) return;

        const options = {
            conflictKey: 'user_id,chapter',
            statusKey: 'backlogs'
        };

        // Phase 8D-5A/5B: SPSyncManager.enqueue does not return a boolean.
        // If the function exists, call it and treat the operation as queued.
        const sync = _getSyncManager();
        if (sync && typeof sync.enqueue === 'function') {
            sync.enqueue('backlogs', row, options);
            console.log('[BacklogRoute] Enqueued backlog row via SyncManager:', chapterName);
            return;
        }

        // Fallback: direct single-row upsert using the same schema-safe row
        if (!window.supabaseClient) {
            console.warn('[BacklogRoute] No SyncManager and no Supabase client — sync skipped');
            return;
        }

        const userId = _getUserId();
        if (!userId) {
            console.warn('[BacklogRoute] Upsert skipped — no userId');
            return;
        }

        window.supabaseClient
            .from('backlogs')
            .upsert({ ...row, user_id: userId }, { onConflict: 'user_id,chapter' })
            .then(function (result) {
                if (result.error) {
                    console.warn('[BacklogRoute] Direct upsert failed:', result.error.message);
                } else {
                    console.log('[BacklogRoute] Direct upsert success for', chapterName);
                }
            })
            .catch(function (err) {
                console.warn('[BacklogRoute] Direct upsert error:', err);
            });
    }

    /**
     * Enqueue a single chapter delete via SyncManager.
     * SyncManager's _processBatchDelete already does:
     *   .eq('user_id', userId).eq(deleteFilter, deleteValue)
     * So deleteFilter='chapter' + deleteValue=chapterName produces:
     *   .eq('user_id', userId).eq('chapter', chapterName)
     * Falls back to direct Supabase delete if SyncManager unavailable/rejected.
     * @param {string} chapterName - Chapter name to delete from backlogs table
     */
    function _enqueueChapterDelete(chapterName) {
        const options = {
            operation: 'delete',
            deleteFilter: 'chapter',
            deleteValue: chapterName,
            statusKey: 'backlogs'
        };

        // Phase 8D-5A/5B: SPSyncManager.enqueue does not return a boolean.
        // If the function exists, call it and treat the delete as queued.
        const sync = _getSyncManager();
        if (sync && typeof sync.enqueue === 'function') {
            sync.enqueue('backlogs', {}, options);
            console.log('[BacklogRoute] Enqueued backlog delete via SyncManager:', chapterName);
            return;
        }

        // Fallback: direct Supabase delete
        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) {
            console.warn('[BacklogRoute] Delete skipped — no userId');
            return;
        }

        window.supabaseClient
            .from('backlogs')
            .delete()
            .eq('user_id', userId)
            .eq('chapter', chapterName)
            .then(function (result) {
                if (result.error) {
                    console.warn('[BacklogRoute] Delete failed:', result.error.message);
                } else {
                    console.log('[BacklogRoute] Deleted from Supabase:', chapterName);
                }
            })
            .catch(function (err) {
                console.warn('[BacklogRoute] Delete error:', err);
            });
    }

    // ════════════════════════════════════════════════════════
    //  BACKLOG CALCULATION (CRITICAL RULE)
    // ════════════════════════════════════════════════════════

    function _isStarted(entry) {
        if (!entry || typeof entry !== 'object') return false;
        return entry.read === true || entry.notes === true || entry.pyq === true;
    }

    function _isCompleted(entry) {
        if (!entry || typeof entry !== 'object') return false;
        return entry.read === true && entry.notes === true && entry.pyq === true;
    }

    function _isRealBacklog(entry) {
        return _isStarted(entry) && !_isCompleted(entry);
    }

    function _countDone(entry) {
        if (!entry || typeof entry !== 'object') return 0;
        let count = 0;
        if (entry.read === true) count++;
        if (entry.notes === true) count++;
        if (entry.pyq === true) count++;
        return count;
    }

    function _isScheduled(entry) {
        return entry && !!entry._scheduledFor;
    }

    // ════════════════════════════════════════════════════════
    //  HTML RENDERING
    // ════════════════════════════════════════════════════════

    function renderFullUI() {
        return `
        <div class="backlog-wrapper">
            <div class="backlog-stats-container">
                <div class="backlog-master-container sp-card">
                    <!-- TOP: Neutralization Stats -->
                    <div class="backlog-top-bar">
                        <div class="daily-target-card sp-card">
                            <div class="target-header">
                                <span class="label">BACKLOG NEUTRALIZATION</span>
                                <span id="completion-stats" class="status">0/0 CLEANED</span>
                            </div>
                            <div class="kill-counter-container" id="dynamic-slots"></div>
                        </div>
                    </div>

                    <!-- FOCUS MISSION ZONE (shows empty state by default, filled on Target) -->
                    <div class="focus-mission-zone" id="focusMissionZone">
                        <h2 class="zone-title">Current Objective</h2>
                        <div id="focusEmptyState" class="focus-empty-state sp-empty-state">
                            <span class="focus-empty-icon sp-empty-state-icon">\u{1F3AF}</span>
                            <h3 class="focus-empty-title sp-empty-state-title">No Active Target</h3>
                            <p class="focus-empty-subtitle sp-empty-state-text">Battlefield clean. No backlog tasks detected. Add one below to begin neutralization.</p>
                        </div>
                        <div id="focusActiveCard" class="main-focus-card sp-card-elevated" style="display:none;">
                            <div class="focus-info">
                                <div id="missionPriorityTag" class="priority-badge critical sp-badge">CRITICAL</div>
                                <h1 id="activeMissionName">---</h1>
                                <div class="mission-tasks" id="currentMissionTasks"></div>
                            </div>
                            <div class="action-zone">
                                <div class="timer-display" id="missionTimer">25:00</div>
                                <button class="launch-btn sp-btn" data-action="toggle-mission">START MISSION</button>
                            </div>
                        </div>
                    </div>

                    <!-- AUTO-RANK PANEL -->
                    <div class="auto-rank-section" id="autoRankSection">
                        <div class="rank-panel-header">
                            <div class="rank-panel-title-row">
                                <h3 class="rank-panel-title">BACKLOG PRIORITY AUTO-RANK</h3>
                                <span class="rank-scan-indicator"></span>
                            </div>
                            <p class="rank-panel-subtitle">Clear the dangerous tasks before they become disasters.</p>
                        </div>
                        <div class="auto-rank-summary" id="autoRankSummary"></div>
                        <div id="nextStrikeCard"></div>
                        <div class="auto-rank-controls">
                            <select class="sp-select auto-rank-select" id="rankFilter" data-action="rank-filter">
                                <option value="all">All Risk Levels</option>
                                <option value="Critical">Critical Only</option>
                                <option value="High">High Only</option>
                                <option value="Medium">Medium Only</option>
                                <option value="Low">Low Only</option>
                            </select>
                            <select class="sp-select auto-rank-select" id="rankSubjectFilter" data-action="rank-subject-filter">
                                <option value="all">All Subjects</option>
                            </select>
                            <select class="sp-select auto-rank-select" id="rankSort" data-action="rank-sort">
                                <option value="score">Sort: Auto Rank</option>
                                <option value="dueDate">Sort: Due Date</option>
                                <option value="age">Sort: Oldest</option>
                                <option value="subject">Sort: Subject</option>
                                <option value="manual">Sort: Manual Priority</option>
                            </select>
                        </div>
                        <div class="auto-rank-list" id="autoRankList"></div>
                    </div>

                    <!-- RECOVERY TIMELINE -->
                    <div class="timeline-section">
                        <h3>Recovery Timeline</h3>
                        <div class="timeline-scroll" id="timeline-tabs"></div>
                        <div id="timeline-content" class="timeline-day-view"></div>
                    </div>

                    <!-- INVENTORY -->
                    <div class="all-tasks-section">
                        <h3>Inventory (Pending)</h3>
                        <div id="backlogInventory" class="tasks-grid"></div>
                    </div>

                    <!-- FOOTER -->
                    <div class="footer-sections">
                        <div class="suggestions-box sp-card">
                            <h4>Alfred's Advice</h4>
                            <p id="alfredAdvice">"Select a target mission to begin neutralization."</p>
                        </div>
                        <div class="victory-zone sp-card" id="victoryZone">
                            <h4>Recent Victories</h4>
                            <div id="toast-container"></div>
                            <div class="victory-scroll" id="clearedList"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Toast -->
        <div class="bl-toast sp-toast" id="blToast"></div>`;
    }

    // ════════════════════════════════════════════════════════
    //  INVENTORY RENDERING
    // ════════════════════════════════════════════════════════

    /**
     * Phase 8D-5C: Mirror current real backlog inventory to Supabase.
     *
     * Why this exists:
     * SyllabusRoute creates backlog items by updating the shared
     * smartPadhaiData store. BacklogRoute renders those items from
     * local storage, but no BacklogRoute action has happened yet, so
     * nothing has been enqueued to the `backlogs` table.
     *
     * On Backlog page load, mirror every real backlog chapter once.
     * SyncManager debounces these into a single batch upsert.
     */
    function _syncCurrentBacklogInventory() {
        const masterData = SafeStorage.getItem(MASTER_KEY, {});

        if (typeof masterData !== 'object' || masterData === null || Array.isArray(masterData)) {
            console.warn('[BacklogRoute] masterData corrupted in _syncCurrentBacklogInventory, skipping sync');
            return;
        }

        const chaptersToSync = Object.entries(masterData)
            .filter(([chapter, entry]) => {
                if (typeof entry !== 'object' || entry === null) return false;
                return _isRealBacklog(entry);
            })
            .map(([chapter]) => chapter);

        chaptersToSync.forEach(chapter => _enqueueChapterUpsert(chapter));

        console.log(`[BacklogRoute] Inventory mirror queued: ${chaptersToSync.length} backlog row(s)`);
    }

    function _renderInventory() {
        const inventory = _container?.querySelector('#backlogInventory');
        if (!inventory) return;

        const masterData = SafeStorage.getItem(MASTER_KEY, {});

        // Defensive: masterData must be a plain object
        if (typeof masterData !== 'object' || masterData === null || Array.isArray(masterData)) {
            console.warn('[BacklogRoute] masterData corrupted in _renderInventory, skipping render');
            inventory.innerHTML = `<div class="bl-empty-state sp-empty-state">
                <div class="bl-empty-icon sp-empty-state-icon">\u26A0\uFE0F</div>
                <p class="sp-empty-state-text">Data error. Try refreshing.</p>
            </div>`;
            return;
        }

        // ── CRITICAL: Render ALL realBacklog chapters, not just the first one ──
        // Use Object.entries + filter + map to guarantee every matching chapter is rendered
        // No slice(0,1). No single selected item. No overwriting inside loop.
        const backlogItems = Object.entries(masterData)
            .filter(([name, entry]) => {
                if (typeof entry !== 'object' || entry === null) return false;
                if (_isScheduled(entry)) return false;
                if (!_isRealBacklog(entry)) return false;
                return true;
            })
            .map(([chap, status]) => {
                const doneCount = _countDone(status);
                let pTag = '', pClass = '';

                if (doneCount === 1) {
                    pTag = 'CRITICAL';
                    pClass = 'critical';
                } else if (doneCount === 2) {
                    pTag = 'QUICK WIN';
                    pClass = 'low';
                } else {
                    pTag = 'PENDING';
                    pClass = 'medium';
                }

                const chapId = chap.replace(/\s+/g, '_');
                const leftCount = 3 - doneCount;

                return `
                <div class="backlog-item-card ${pClass} sp-card"
                     draggable="true"
                     data-action="drag-start"
                     data-chapter="${chap}"
                     id="card-${chapId}">
                    <div class="info-side">
                        <span class="priority-badge ${pClass} sp-badge">${pTag}</span>
                        <h4>${chap}</h4>
                        <p>${leftCount} left</p>
                    </div>
                    <div class="action-side">
                        <button class="mini-kill-btn sp-btn" data-action="set-focus" data-chapter="${chap}">Target</button>
                        <button class="delete-mission-btn sp-btn sp-btn-danger" data-action="delete-mission" data-chapter="${chap}" title="Remove Mission">\uD83D\uDDD1\uFE0F</button>
                    </div>
                </div>`;
            });

        if (backlogItems.length === 0) {
            inventory.innerHTML = `<div class="bl-empty-state sp-empty-state">
                <div class="bl-empty-icon sp-empty-state-icon">\uD83C\uDFC6</div>
                <p class="sp-empty-state-text">No backlogs found! You're all caught up.</p>
            </div>`;
        } else {
            inventory.innerHTML = backlogItems.join('');
        }

        console.log(`[BacklogRoute] Inventory rendered: ${backlogItems.length} backlog items`);

        // Update Alfred's advice
        _updateAdvice();

        // Auto-Rank: refresh after inventory changes
        renderBacklogAutoRank();
    }

    function _updateAdvice() {
        const data = SafeStorage.getItem(MASTER_KEY, {});
        const adviceEl = _container?.querySelector('#alfredAdvice');
        if (!adviceEl) return;

        // Find a quick win (2 of 3 done)
        let quickWin = null;
        for (const chap in data) {
            const status = data[chap];
            if (typeof status !== 'object' || status === null) continue;
            if (_isScheduled(status) || !_isRealBacklog(status)) continue;
            if (_countDone(status) === 2) {
                quickWin = chap;
                break;
            }
        }

        if (quickWin) {
            adviceEl.textContent = `"Finish '${quickWin}' first — it's a Quick Win (1 task left)."`;
        } else {
            adviceEl.textContent = `"Select a target mission to begin neutralization."`;
        }
    }

    // ════════════════════════════════════════════════════════
    //  FOCUS MISSION
    // ════════════════════════════════════════════════════════

    function _setFocusMission(name) {
        const focusZone = _container?.querySelector('#focusMissionZone');
        const emptyState = _container?.querySelector('#focusEmptyState');
        const activeCard = _container?.querySelector('#focusActiveCard');
        if (!focusZone) return;

        // Show active card, hide empty state
        if (emptyState) emptyState.style.display = 'none';
        if (activeCard) activeCard.style.display = 'flex';
        _updateFocusCard(name);
        _container.querySelector('.backlog-wrapper')?.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function _updateFocusCard(name) {
        const data = SafeStorage.getItem(MASTER_KEY, {});
        const missionData = data[name];
        const taskContainer = _container?.querySelector('#currentMissionTasks');
        const focusTitle = _container?.querySelector('#activeMissionName');
        const priorityBadge = _container?.querySelector('#missionPriorityTag');

        if (!missionData || !taskContainer || !focusTitle) return;

        focusTitle.innerText = name;

        // Notebook variant
        if (missionData.isNotebook || name.includes('\u0394')) {
            taskContainer.innerHTML = `
                <div class="notebook-task-item">
                    Complete ${missionData.pagesToComplete || ''} Pending Pages \u2705
                </div>
                <p class="notebook-hint">Target: Physical Notebook Completion</p>
            `;
        } else {
            // Normal chapter
            taskContainer.innerHTML = `
                <div class="task-item ${missionData.read ? 'done' : ''}">Read Theory ${missionData.read ? '\u2705' : '\u274C'}</div>
                <div class="task-item ${missionData.notes ? 'done' : ''}">Short Notes ${missionData.notes ? '\u2705' : '\u274C'}</div>
                <div class="task-item ${missionData.pyq ? 'done' : ''}">PYQ Practice ${missionData.pyq ? '\u2705' : '\u274C'}</div>
            `;
        }

        if (priorityBadge) {
            const doneCount = _countDone(missionData);
            priorityBadge.innerText = doneCount === 2 ? 'QUICK WIN \u26A1' : 'CRITICAL \uD83D\uDEA9';
            priorityBadge.className = 'priority-badge sp-badge ' + (doneCount === 2 ? 'low' : 'critical');
        }
    }

    // ════════════════════════════════════════════════════════
    //  MISSION TIMER
    // ════════════════════════════════════════════════════════

    function _toggleMission() {
        const btn = _container?.querySelector('[data-action="toggle-mission"]');
        const focusCard = _container?.querySelector('#focusActiveCard');
        if (!btn) return;

        if (!_isMissionRunning) {
            _isMissionRunning = true;
            btn.textContent = 'ABORT MISSION';
            btn.style.background = '#444';
            if (focusCard) focusCard.classList.add('mission-running');
            _startCountdown(15 * 60); // 15 minutes
        } else {
            _stopMission('Mission Aborted!');
        }
    }

    function _startCountdown(durationSeconds) {
        let timer = durationSeconds;
        const display = _container?.querySelector('#missionTimer');

        _missionTimer = setInterval(() => {
            if (!_container) { clearInterval(_missionTimer); return; }

            const mins = Math.floor(timer / 60);
            const secs = timer % 60;
            if (display) {
                display.textContent = `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
            }

            if (--timer < 0) {
                _completeMission();
            }
        }, 1000);
    }

    function _completeMission() {
        clearInterval(_missionTimer);
        _missionTimer = null;
        _isMissionRunning = false;

        const nameEl = _container?.querySelector('#activeMissionName');
        if (!nameEl) return;

        const name = nameEl.innerText;
        if (!name) return;

        const timestamp = new Date().getTime();
        const today = new Date().toDateString();

        // 1. Mark all tasks complete — preserve existing fields
        let masterData = SafeStorage.getItem(MASTER_KEY, {});
        if (masterData[name]) {
            masterData[name] = {
                ...masterData[name],  // preserve isSyllabus, _scheduledFor
                read: true,
                notes: true,
                pyq: true,
                lastUpdated: today
            };
        }
        SafeStorage.setItem(MASTER_KEY, masterData);
        _enqueueChapterUpsert(name); // per-chapter debounced sync

        // 2. Record victory
        let victories = SafeStorage.getItem(VICTORY_KEY, []);
        victories.unshift({ name: name, time: timestamp, date: today });
        SafeStorage.setItem(VICTORY_KEY, victories);

        // 3. Daily stats
        let dailyStats = SafeStorage.getItem(DAILY_STATS_KEY, {});
        if (!dailyStats[today]) dailyStats[today] = 0;
        dailyStats[today] += 1;
        SafeStorage.setItem(DAILY_STATS_KEY, dailyStats);

        // 4. Notebook matrix connection
        if (name.includes('\u0394')) {
            let notebookData = SafeStorage.getItem('notebook_matrix_data', []);
            const subjectName = name.split(' (')[0];
            notebookData = notebookData.map(row => {
                if (row.subject === subjectName) {
                    return { ...row, done: true, incident: false, delta: 0 };
                }
                return row;
            });
            SafeStorage.setItem('notebook_matrix_data', notebookData);
        }

        // 5. PP Reward — unique rewardId prevents duplicates
        const victoryRewardId = `victory_${name.replace(/\s+/g, '_')}_${today.replace(/\s+/g, '_')}`;
        PulseEngine.addPoints(10, 'mission', { rewardId: victoryRewardId });

        // 6. Show empty state in focus zone (hide active card)
        const emptyState = _container?.querySelector('#focusEmptyState');
        const activeCard = _container?.querySelector('#focusActiveCard');
        if (emptyState) emptyState.style.display = '';
        if (activeCard) activeCard.style.display = 'none';

        // Reset timer display
        const timerEl = _container?.querySelector('#missionTimer');
        const btnEl = _container?.querySelector('[data-action="toggle-mission"]');
        const focusCard = _container?.querySelector('#focusActiveCard');
        if (timerEl) timerEl.textContent = '25:00';
        if (btnEl) { btnEl.textContent = 'START MISSION'; btnEl.style.background = ''; }
        if (focusCard) focusCard.classList.remove('mission-running');

        // 7. Refresh UI
        _renderInventory();
        _renderVictories();
        _updateDynamicCleanup();
        renderBacklogAutoRank(); // Auto-Rank: refresh after mission complete

        // 8. Toast instead of alert
        _showToast(`Mission Accomplished: ${name} Neutralized! \uD83C\uDFC6`);
    }

    function _stopMission(msg) {
        clearInterval(_missionTimer);
        _missionTimer = null;
        _isMissionRunning = false;

        const timerEl = _container?.querySelector('#missionTimer');
        const btnEl = _container?.querySelector('[data-action="toggle-mission"]');
        const focusCard = _container?.querySelector('#focusActiveCard');

        if (timerEl) timerEl.textContent = '25:00';
        if (btnEl) { btnEl.textContent = 'START MISSION'; btnEl.style.background = ''; }
        if (focusCard) focusCard.classList.remove('mission-running');

        _showToast(msg);
    }

    // ════════════════════════════════════════════════════════
    //  DELETE MISSION
    // ════════════════════════════════════════════════════════

    function _deleteMission(name) {
        _showConfirmDialog(
            `Remove "${name}" from inventory? This cannot be undone.`,
            () => {
                let data = SafeStorage.getItem(MASTER_KEY, {});
                delete data[name];
                SafeStorage.setItem(MASTER_KEY, data);
                _enqueueChapterDelete(name);

                // Show empty state if this was the active mission
                const activeName = _container?.querySelector('#activeMissionName')?.innerText;
                if (activeName === name) {
                    const emptyState = _container?.querySelector('#focusEmptyState');
                    const activeCard = _container?.querySelector('#focusActiveCard');
                    if (emptyState) emptyState.style.display = '';
                    if (activeCard) activeCard.style.display = 'none';
                }

                _renderInventory();
                _updateDynamicCleanup();
                renderBacklogAutoRank(); // Auto-Rank: refresh after delete
                _showToast(`"${name}" removed from inventory.`);
            }
        );
    }

    // ════════════════════════════════════════════════════════
    //  VICTORIES
    // ════════════════════════════════════════════════════════

    function _renderVictories() {
        const container = _container?.querySelector('#clearedList');
        if (!container) return;

        let victories = SafeStorage.getItem(VICTORY_KEY, []);
        const currentTime = new Date().getTime();
        const threeHoursMs = 3 * 60 * 60 * 1000;

        // Filter: only show last 3 hours
        const fresh = victories.filter(v => (currentTime - v.time) < threeHoursMs);

        // Clean old ones from storage
        SafeStorage.setItem(VICTORY_KEY, fresh);

        if (fresh.length === 0) {
            container.innerHTML = `<div class="bl-empty-state sp-empty-state" style="grid-column:1/-1;">
                <p class="sp-empty-state-text">No recent victories. Go kill some backlogs! \u2694\uFE0F</p>
            </div>`;
            return;
        }

        container.innerHTML = fresh.map(v => `
            <div class="victory-item slide-in sp-card">
                <div class="v-icon" style="font-size:1.3rem;">\uD83C\uDFC6</div>
                <div class="v-details">
                    <h5>${v.name || 'Mission'}</h5>
                    <span>ACCOMPLISHED</span>
                </div>
            </div>`).join('');
    }

    // ════════════════════════════════════════════════════════
    //  STATS BAR
    // ════════════════════════════════════════════════════════

    function _updateDynamicCleanup() {
        const data = SafeStorage.getItem(MASTER_KEY, {});
        const dailyStats = SafeStorage.getItem(DAILY_STATS_KEY, {});
        const today = new Date().toDateString();

        const todayKills = dailyStats[today] || 0;

        let pendingCount = 0;
        for (const chap in data) {
            const status = data[chap];
            if (typeof status !== 'object' || status === null) continue;
            if (_isRealBacklog(status) && !_isScheduled(status)) pendingCount++;
        }

        const totalSlots = todayKills + pendingCount;
        const container = _container?.querySelector('#dynamic-slots');
        const statsText = _container?.querySelector('#completion-stats');

        if (!container) return;
        container.innerHTML = '';

        for (let i = 0; i < totalSlots; i++) {
            const slot = document.createElement('div');
            slot.className = 'kill-slot' + (i < todayKills ? ' active' : '');
            container.appendChild(slot);
        }

        if (statsText) {
            statsText.innerText = `${todayKills}/${totalSlots} MISSIONS NEUTRALIZED`;
        }

        // Penalty check: >5 untouched syllabus chapters
        const ignoredCount = Object.values(data).filter(s => {
            if (typeof s !== 'object' || s === null) return false;
            return s.isSyllabus && !_isStarted(s);
        }).length;

        if (ignoredCount > 5) {
            const penaltyId = `backlog_penalty_${today.replace(/\s+/g, '_')}`;
            if (!PulseEngine.data.rewardLedger[penaltyId]) {
                PulseEngine.deductPoints(10);
                PulseEngine.data.rewardLedger[penaltyId] = true;
                PulseEngine.save();
                _showToast(`${ignoredCount} SYLLABUS CHAPTERS IGNORED: -10 PP`);
            }
        }
    }

    // ════════════════════════════════════════════════════════
    //  AUTO-RANK: INTELLIGENT BACKLOG PRIORITIZATION
    // ════════════════════════════════════════════════════════

    /**
     * Collect all real backlog entries from smartPadhaiData.
     * Excludes scheduled entries and completed entries.
     * Returns array of { chapterName, entry } objects.
     */
    function getBacklogData() {
        const masterData = SafeStorage.getItem(MASTER_KEY, {});

        if (typeof masterData !== 'object' || masterData === null || Array.isArray(masterData)) {
            return [];
        }

        return Object.entries(masterData)
            .filter(([name, entry]) => {
                if (typeof entry !== 'object' || entry === null) return false;
                if (_isScheduled(entry)) return false;
                if (!_isRealBacklog(entry)) return false;
                return true;
            })
            .map(([chapterName, entry]) => ({ chapterName, entry }));
    }

    /**
     * Normalize a raw backlog entry into a structured task object
     * with inferred priority, dueDate, age, estimatedMinutes,
     * category, subject, and source.
     *
     * Inference rules (no explicit priority/dueDate/estimatedMinutes in data):
     *   - Priority: doneCount === 2 → "High" (Quick Win),
     *               doneCount === 1 → "Medium",
     *               _scheduledFor in the past → "Critical"
     *   - Due date: entry._scheduledFor if present
     *   - Age: days since entry.lastUpdated
     *   - Estimated minutes: 1 task remaining → 30 min, 2 tasks → 60 min
     *   - Category: based on what's NOT done
     *       !pyq → "Test Practice", !notes → "Notes Pending",
     *       !read → "Lecture Pending"
     *       Multiple missing → first uncompleted in order [pyq, notes, read]
     *   - Subject: entry.subject first, then _detectSubject(chapterName) fallback
     *   - Source: "Syllabus Gap Analyzer" if entry.isSyllabus, else "Manual"
     */
    function normalizeBacklogTask(chapterName, entry) {
        if (!entry || typeof entry !== 'object') {
            return null;
        }

        const doneCount = _countDone(entry);
        const tasksLeft = 3 - doneCount;

        // ── Priority inference ──
        let priority = 'Low';
        const scheduledFor = entry._scheduledFor || null;

        if (scheduledFor) {
            const schedDate = new Date(scheduledFor);
            const now = new Date();
            if (!isNaN(schedDate.getTime()) && schedDate < now) {
                priority = 'Critical';
            }
        }

        if (priority === 'Low') {
            if (doneCount === 2) {
                priority = 'High'; // Quick Win — 1 task left
            } else if (doneCount === 1) {
                priority = 'Medium';
            }
        }

        // ── Due date ──
        const dueDate = scheduledFor || null;

        // ── Age (days since lastUpdated) ──
        let ageDays = 0;
        if (typeof entry.lastUpdated === 'string' && entry.lastUpdated) {
            const lastUpd = new Date(entry.lastUpdated);
            if (!isNaN(lastUpd.getTime())) {
                const diffMs = Date.now() - lastUpd.getTime();
                ageDays = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
            }
        }

        // ── Estimated minutes ──
        let estimatedMinutes = 60;
        if (tasksLeft === 1) {
            estimatedMinutes = 30;
        } else if (tasksLeft === 2) {
            estimatedMinutes = 60;
        } else {
            estimatedMinutes = 90;
        }

        // ── Category (based on what's NOT done) ──
        let category = 'Other';
        if (entry.pyq !== true) {
            category = 'Test Practice';
        } else if (entry.notes !== true) {
            category = 'Notes Pending';
        } else if (entry.read !== true) {
            category = 'Lecture Pending';
        }
        // If only pyq left and both read+notes done, it's a revision scenario
        if (doneCount === 2 && entry.pyq !== true) {
            category = 'Test Practice';
        } else if (doneCount === 2) {
            category = 'Revision';
        }

        // ── Subject ──
        const subject = (typeof entry.subject === 'string' && entry.subject)
            ? entry.subject
            : _detectSubject(chapterName);

        // ── Source ──
        const source = entry.isSyllabus ? 'Syllabus Gap Analyzer' : 'Manual';

        return {
            chapterName,
            priority,
            dueDate,
            ageDays,
            estimatedMinutes,
            category,
            subject,
            source,
            doneCount,
            tasksLeft,
            entry
        };
    }

    /**
     * Calculate the rank score for a normalized backlog task.
     *
     * Scoring logic:
     *   - Base risk: Critical +40, High +30, Medium +20, Low +10
     *   - Due date urgency: due today +40, overdue +35, due tomorrow +30,
     *     due within 3 days +20, due within 7 days +10
     *   - Age penalty: +5 per day in backlog, max +30
     *   - Subject importance: Physics/Maths/Chemistry +20,
     *     Biology/SST +15, English/Hindi/CS +10, unknown +5
     *   - Category weight: Test Practice +25, Revision +20,
     *     Notes Pending +20, Lecture Pending +15, Other +10
     *   - Effort logic: <=30 min +10, <=60 min +5, >180 min -10
     *   - Completed tasks: score = 0, rank = "Completed"
     *
     * Risk labels: 0-25 Low, 26-55 Medium, 56-85 High, 86+ Critical
     */
    function calculateBacklogRankScore(task) {
        if (!task || typeof task !== 'object') return 0;

        // Completed → score = 0
        if (task.priority === 'Completed' || _isCompleted(task.entry)) {
            return 0;
        }

        let score = 0;

        // ── Base risk ──
        switch (task.priority) {
            case 'Critical': score += 40; break;
            case 'High':     score += 30; break;
            case 'Medium':   score += 20; break;
            case 'Low':      score += 10; break;
            default:         score += 10; break;
        }

        // ── Due date urgency ──
        if (task.dueDate) {
            const dueDate = new Date(task.dueDate);
            if (!isNaN(dueDate.getTime())) {
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                dueDate.setHours(0, 0, 0, 0);

                const diffDays = Math.round((dueDate - today) / (1000 * 60 * 60 * 24));

                if (diffDays < 0) {
                    score += 35; // overdue
                } else if (diffDays === 0) {
                    score += 40; // due today
                } else if (diffDays === 1) {
                    score += 30; // due tomorrow
                } else if (diffDays <= 3) {
                    score += 20; // due within 3 days
                } else if (diffDays <= 7) {
                    score += 10; // due within 7 days
                }
            }
        }

        // ── Age penalty: +5 per day, max +30 ──
        score += Math.min(30, (task.ageDays || 0) * 5);

        // ── Subject importance ──
        const highSubjects = ['Physics', 'Maths', 'Chemistry'];
        const medSubjects = ['Biology', 'SST', 'Social Science', 'Social Studies'];
        const lowSubjects = ['English', 'Hindi', 'CS', 'Computer Science'];

        if (highSubjects.includes(task.subject)) {
            score += 20;
        } else if (medSubjects.includes(task.subject)) {
            score += 15;
        } else if (lowSubjects.includes(task.subject)) {
            score += 10;
        } else {
            score += 5; // unknown
        }

        // ── Category weight ──
        switch (task.category) {
            case 'Test Practice':   score += 25; break;
            case 'Revision':        score += 20; break;
            case 'Notes Pending':   score += 20; break;
            case 'Lecture Pending': score += 15; break;
            default:                score += 10; break;
        }

        // ── Effort logic ──
        if (task.estimatedMinutes <= 30) {
            score += 10; // Quick win bonus
        } else if (task.estimatedMinutes <= 60) {
            score += 5;
        } else if (task.estimatedMinutes > 180) {
            score -= 10; // Heavy task penalty
        }

        return Math.max(0, score);
    }

    /**
     * Get risk level label from a rank score.
     * 0-25 Low, 26-55 Medium, 56-85 High, 86+ Critical
     */
    function getBacklogRiskLevel(score) {
        if (typeof score !== 'number' || isNaN(score)) return 'Low';
        if (score >= 86) return 'Critical';
        if (score >= 56) return 'High';
        if (score >= 26) return 'Medium';
        return 'Low';
    }

    /**
     * Get a human-readable reason for why a task received its rank.
     * Explains the top contributing factor(s).
     */
    function getBacklogRankReason(task, score) {
        if (!task || typeof task !== 'object') return 'Unknown reason';
        if (score === 0) return 'Already completed';

        const reasons = [];

        if (task.priority === 'Critical') {
            reasons.push('Overdue schedule');
        } else if (task.priority === 'High') {
            reasons.push('Quick Win — only 1 task left');
        } else if (task.priority === 'Medium') {
            reasons.push('Partially done — needs attention');
        }

        if (task.dueDate) {
            const dueDate = new Date(task.dueDate);
            if (!isNaN(dueDate.getTime())) {
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                dueDate.setHours(0, 0, 0, 0);
                const diffDays = Math.round((dueDate - today) / (1000 * 60 * 60 * 24));
                if (diffDays < 0) {
                    reasons.push(`${Math.abs(diffDays)} day(s) overdue`);
                } else if (diffDays === 0) {
                    reasons.push('Due today');
                } else if (diffDays === 1) {
                    reasons.push('Due tomorrow');
                } else if (diffDays <= 3) {
                    reasons.push(`Due in ${diffDays} days`);
                }
            }
        }

        if (task.ageDays > 0) {
            reasons.push(`In backlog ${task.ageDays} day(s)`);
        }

        if (task.category === 'Test Practice') {
            reasons.push('PYQ pending — exam risk');
        }

        if (task.estimatedMinutes <= 30) {
            reasons.push('Under 30 min — easy win');
        }

        return reasons.length > 0 ? reasons.join(' | ') : 'Standard backlog item';
    }

    /**
     * Get a suggested action for a ranked backlog task.
     */
    function getBacklogSuggestedAction(task, score) {
        if (!task || typeof task !== 'object') return 'Review';
        if (score === 0) return 'Completed';

        const riskLevel = getBacklogRiskLevel(score);

        if (riskLevel === 'Critical') {
            if (task.estimatedMinutes <= 30) {
                return 'Do Now — Quick neutralization';
            }
            return 'Priority Target — Schedule today';
        }

        if (riskLevel === 'High') {
            if (task.tasksLeft === 1) {
                return 'Quick Win — Finish today';
            }
            return 'Schedule within 2 days';
        }

        if (riskLevel === 'Medium') {
            return 'Schedule this week';
        }

        return 'Backlog — Review when free';
    }

    /**
     * Get a summary of the current backlog state for the Auto-Rank panel.
     * Returns { total, critical, high, medium, low, avgScore, topSubject, quickWins }
     */
    function getBacklogSummary(rankedTasks) {
        if (!Array.isArray(rankedTasks)) {
            return { total: 0, critical: 0, high: 0, medium: 0, low: 0, avgScore: 0, topSubject: 'None', quickWins: 0 };
        }

        let critical = 0, high = 0, medium = 0, low = 0, totalScore = 0, quickWins = 0;
        const subjectCounts = {};

        rankedTasks.forEach(task => {
            const riskLevel = task.riskLevel || 'Low';
            switch (riskLevel) {
                case 'Critical': critical++; break;
                case 'High':     high++; break;
                case 'Medium':   medium++; break;
                default:         low++; break;
            }
            totalScore += (task.score || 0);

            if (task.tasksLeft === 1) quickWins++;

            const subj = task.subject || 'Unknown';
            subjectCounts[subj] = (subjectCounts[subj] || 0) + 1;
        });

        // Find top subject
        let topSubject = 'None';
        let maxCount = 0;
        for (const subj in subjectCounts) {
            if (subjectCounts[subj] > maxCount) {
                maxCount = subjectCounts[subj];
                topSubject = subj;
            }
        }

        const avgScore = rankedTasks.length > 0 ? Math.round(totalScore / rankedTasks.length) : 0;

        return {
            total: rankedTasks.length,
            critical,
            high,
            medium,
            low,
            avgScore,
            topSubject,
            quickWins
        };
    }

    /**
     * Sort ranked tasks by the current sort type.
     * 'score' → descending by risk score
     * 'age' → descending by age (oldest first)
     * 'effort' → ascending by estimated minutes (least effort first)
     * 'subject' → alphabetical by subject, then by score
     */
    function sortBacklogTasks(tasks, sortType) {
        if (!Array.isArray(tasks)) return [];

        const sorted = [...tasks];

        switch (sortType) {
            case 'score':
                sorted.sort((a, b) => (b.score || 0) - (a.score || 0));
                break;
            case 'dueDate':
                sorted.sort((a, b) => {
                    // Tasks with due dates come first, sorted by urgency
                    if (a.dueDate && !b.dueDate) return -1;
                    if (!a.dueDate && b.dueDate) return 1;
                    if (!a.dueDate && !b.dueDate) return (b.score || 0) - (a.score || 0);
                    const dateA = new Date(a.dueDate);
                    const dateB = new Date(b.dueDate);
                    if (!isNaN(dateA.getTime()) && !isNaN(dateB.getTime())) {
                        return dateA - dateB;
                    }
                    return (b.score || 0) - (a.score || 0);
                });
                break;
            case 'age':
                sorted.sort((a, b) => (b.ageDays || 0) - (a.ageDays || 0));
                break;
            case 'subject':
                sorted.sort((a, b) => {
                    const subjA = (a.subject || 'ZZZ').toLowerCase();
                    const subjB = (b.subject || 'ZZZ').toLowerCase();
                    if (subjA < subjB) return -1;
                    if (subjA > subjB) return 1;
                    return (b.score || 0) - (a.score || 0);
                });
                break;
            case 'manual':
                sorted.sort((a, b) => {
                    const priOrder = { 'Critical': 0, 'High': 1, 'Medium': 2, 'Low': 3, 'Completed': 4 };
                    const pa = priOrder[a.priority] ?? 5;
                    const pb = priOrder[b.priority] ?? 5;
                    if (pa !== pb) return pa - pb;
                    return (b.score || 0) - (a.score || 0);
                });
                break;
            default:
                sorted.sort((a, b) => (b.score || 0) - (a.score || 0));
                break;
        }

        return sorted;
    }

    /**
     * Filter ranked tasks by risk level and/or subject.
     * 'all' for either filter means no filtering on that dimension.
     */
    function filterBacklogTasks(tasks, riskFilter, subjectFilter) {
        if (!Array.isArray(tasks)) return [];

        return tasks.filter(task => {
            // Risk filter
            if (riskFilter && riskFilter !== 'all') {
                if ((task.riskLevel || 'Low') !== riskFilter) return false;
            }

            // Subject filter
            if (subjectFilter && subjectFilter !== 'all') {
                if ((task.subject || 'Unknown') !== subjectFilter) return false;
            }

            return true;
        });
    }

    /**
     * Render the Auto-Rank panel content.
     * Populates summary, subject filter options, and ranked task cards.
     */
    function renderBacklogAutoRank() {
        const listEl = _container?.querySelector('#autoRankList');
        const summaryEl = _container?.querySelector('#autoRankSummary');
        const subjectSelect = _container?.querySelector('#rankSubjectFilter');

        if (!listEl) return;

        // 1. Collect and normalize backlog data
        const backlogData = getBacklogData();
        const normalizedTasks = backlogData
            .map(({ chapterName, entry }) => normalizeBacklogTask(chapterName, entry))
            .filter(task => task !== null);

        // 2. Calculate scores and risk levels
        const rankedTasks = normalizedTasks.map(task => {
            const score = calculateBacklogRankScore(task);
            const riskLevel = score === 0 ? 'Completed' : getBacklogRiskLevel(score);
            return {
                ...task,
                score,
                riskLevel
            };
        });

        // 3. Populate subject filter options (preserve current selection)
        const uniqueSubjects = [...new Set(rankedTasks.map(t => t.subject || 'Unknown'))].sort();
        if (subjectSelect) {
            const currentSubjectVal = _rankSubject;
            subjectSelect.innerHTML = '<option value="all">All Subjects</option>' +
                uniqueSubjects.map(s => `<option value="${s}"${s === currentSubjectVal ? ' selected' : ''}>${s}</option>`).join('');
        }

        // 4. Filter and sort
        const filtered = filterBacklogTasks(rankedTasks, _rankFilter, _rankSubject);
        const sorted = sortBacklogTasks(filtered, _rankSortType);

        // 5. Render Next Strike card (highest-priority non-completed task)
        const nextStrikeEl = _container?.querySelector('#nextStrikeCard');
        const topTask = rankedTasks.filter(t => t.riskLevel !== 'Completed' && t.score > 0)
            .sort((a, b) => b.score - a.score)[0];
        if (nextStrikeEl) {
            if (topTask) {
                const strikeReason = getBacklogRankReason(topTask, topTask.score);
                nextStrikeEl.innerHTML = `
                <div class="next-strike-card">
                    <div class="next-strike-header">
                        <span class="next-strike-label">\u{1F3AF} NEXT STRIKE</span>
                    </div>
                    <h4 class="next-strike-name">${topTask.chapterName}</h4>
                    <p class="next-strike-reason">Reason: ${strikeReason}</p>
                    <button class="launch-btn sp-btn next-strike-btn" data-action="rank-set-focus" data-chapter="${topTask.chapterName}">Start First</button>
                </div>`;
            } else {
                nextStrikeEl.innerHTML = '';
            }
        }

        // 6. Render summary
        const summary = getBacklogSummary(rankedTasks);
        if (summaryEl) {
            summaryEl.innerHTML = `
                <div class="rank-summary-grid">
                    <div class="rank-summary-item rank-stat-critical">
                        <span class="rank-stat-count">${summary.critical}</span>
                        <span class="rank-stat-label">Critical</span>
                    </div>
                    <div class="rank-summary-item rank-stat-high">
                        <span class="rank-stat-count">${summary.high}</span>
                        <span class="rank-stat-label">High</span>
                    </div>
                    <div class="rank-summary-item rank-stat-medium">
                        <span class="rank-stat-count">${summary.medium}</span>
                        <span class="rank-stat-label">Medium</span>
                    </div>
                    <div class="rank-summary-item rank-stat-low">
                        <span class="rank-stat-count">${summary.low}</span>
                        <span class="rank-stat-label">Low</span>
                    </div>
                    <div class="rank-summary-item rank-stat-avg">
                        <span class="rank-stat-count">${summary.avgScore}</span>
                        <span class="rank-stat-label">Avg Score</span>
                    </div>
                    <div class="rank-summary-item rank-stat-quick">
                        <span class="rank-stat-count">${summary.quickWins}</span>
                        <span class="rank-stat-label">Quick Wins</span>
                    </div>
                </div>`;
        }

        // 6. Render ranked list
        if (sorted.length === 0) {
            listEl.innerHTML = `<div class="bl-empty-state sp-empty-state">
                <div class="bl-empty-icon sp-empty-state-icon">\u{1F4CA}</div>
                <p class="sp-empty-state-text">No backlog items match current filters.</p>
            </div>`;
            return;
        }

        listEl.innerHTML = sorted.map((task, idx) => {
            const riskClass = (task.riskLevel || 'Low').toLowerCase();
            const reason = getBacklogRankReason(task, task.score);
            const action = getBacklogSuggestedAction(task, task.score);
            const sourcePill = task.source === 'Syllabus Gap Analyzer'
                ? '<span class="rank-source-pill">From Gap Analyzer</span>'
                : '';

            return `
            <div class="rank-item-card ${riskClass} sp-card" data-chapter="${task.chapterName}">
                <div class="rank-item-header">
                    <span class="rank-position">#${idx + 1}</span>
                    <span class="priority-badge ${riskClass} sp-badge">${task.riskLevel || 'Low'}</span>
                    <span class="rank-score">${task.score}pts</span>
                </div>
                <div class="rank-item-body">
                    <h4 class="rank-chapter-name">${task.chapterName}</h4>
                    <div class="rank-meta">
                        <span class="rank-tag">${task.subject}</span>
                        <span class="rank-tag">${task.category}</span>
                        <span class="rank-tag">${task.estimatedMinutes} min</span>
                        ${task.ageDays > 0 ? `<span class="rank-tag rank-age">${task.ageDays}d old</span>` : ''}
                        ${sourcePill}
                    </div>
                    <p class="rank-reason">${reason}</p>
                    <p class="rank-action">\u{1F4A1} ${action}</p>
                </div>
                <div class="rank-item-actions">
                    <button class="mini-kill-btn sp-btn" data-action="rank-set-focus" data-chapter="${task.chapterName}">Target</button>
                    <button class="sp-btn sp-btn-secondary" data-action="rank-move-today" data-chapter="${task.chapterName}" title="Move to Today">Today</button>
                    <button class="sp-btn sp-btn-secondary" data-action="rank-mark-done" data-chapter="${task.chapterName}" title="Mark Done">\u2705</button>
                    <button class="sp-btn sp-btn-danger" data-action="rank-lower-priority" data-chapter="${task.chapterName}" title="Lower Priority">\u2B07\uFE0F</button>
                </div>
            </div>`;
        }).join('');
    }

    /**
     * Update the Auto-Rank panel — re-renders with current filter/sort state.
     * Called by event handlers when filter/sort changes.
     */
    function updateBacklogAutoRank() {
        renderBacklogAutoRank();
    }

    // ════════════════════════════════════════════════════════
    //  AUTO-RANK EVENT HANDLERS
    // ════════════════════════════════════════════════════════

    /**
     * Handle risk-level filter change.
     */
    function _handleRankFilter(value) {
        _rankFilter = value || 'all';
        updateBacklogAutoRank();
    }

    /**
     * Handle subject filter change.
     */
    function _handleRankSubjectFilter(value) {
        _rankSubject = value || 'all';
        updateBacklogAutoRank();
    }

    /**
     * Handle sort type change.
     */
    function _handleRankSort(value) {
        _rankSortType = value || 'score';
        updateBacklogAutoRank();
    }

    /**
     * Set the focused mission from an Auto-Rank card.
     * Delegates to existing _setFocusMission.
     */
    function _handleRankSetFocus(chapter) {
        if (typeof chapter === 'string' && chapter) {
            _setFocusMission(chapter);
        }
    }

    /**
     * Move a backlog chapter to today (unschedule it so it appears in inventory).
     * Removes _scheduledFor so the item moves back to the active backlog.
     */
    function _handleRankMoveToday(chapter) {
        if (typeof chapter !== 'string' || !chapter) return;

        let masterData = SafeStorage.getItem(MASTER_KEY, {});
        if (!masterData[chapter] || typeof masterData[chapter] !== 'object') return;

        // If scheduled, remove scheduling to bring it to today
        if (masterData[chapter]._scheduledFor) {
            delete masterData[chapter]._scheduledFor;
            masterData[chapter].lastUpdated = new Date().toDateString();
            SafeStorage.setItem(MASTER_KEY, masterData);
            _enqueueChapterUpsert(chapter);
        }

        _renderInventory();
        _updateDynamicCleanup();
        _showToast(`"${chapter}" moved to today's backlog.`);
    }

    /**
     * Mark a backlog chapter as fully done from the Auto-Rank panel.
     * Same logic as _completeMission but without the timer/trophy flow.
     */
    function _handleRankMarkDone(chapter) {
        if (typeof chapter !== 'string' || !chapter) return;

        _showConfirmDialog(
            `Mark "${chapter}" as complete?`,
            () => {
                const today = new Date().toDateString();
                let masterData = SafeStorage.getItem(MASTER_KEY, {});

                if (masterData[chapter] && typeof masterData[chapter] === 'object') {
                    masterData[chapter] = {
                        ...masterData[chapter],
                        read: true,
                        notes: true,
                        pyq: true,
                        lastUpdated: today
                    };
                    SafeStorage.setItem(MASTER_KEY, masterData);
                    _enqueueChapterUpsert(chapter);

                    // Record victory
                    let victories = SafeStorage.getItem(VICTORY_KEY, []);
                    victories.unshift({ name: chapter, time: Date.now(), date: today });
                    SafeStorage.setItem(VICTORY_KEY, victories);

                    // Daily stats
                    let dailyStats = SafeStorage.getItem(DAILY_STATS_KEY, {});
                    if (!dailyStats[today]) dailyStats[today] = 0;
                    dailyStats[today] += 1;
                    SafeStorage.setItem(DAILY_STATS_KEY, dailyStats);

                    // PP Reward
                    const rewardId = `rank_done_${chapter.replace(/\s+/g, '_')}_${today.replace(/\s+/g, '_')}`;
                    if (typeof PulseEngine !== 'undefined' && PulseEngine.addPoints) {
                        PulseEngine.addPoints(5, 'auto-rank', { rewardId });
                    }
                }

                // Clear focus if this was the active mission
                const activeName = _container?.querySelector('#activeMissionName')?.innerText;
                if (activeName === chapter) {
                    const emptyState = _container?.querySelector('#focusEmptyState');
                    const activeCard = _container?.querySelector('#focusActiveCard');
                    if (emptyState) emptyState.style.display = '';
                    if (activeCard) activeCard.style.display = 'none';
                }

                _renderInventory();
                _renderVictories();
                _updateDynamicCleanup();
                renderBacklogAutoRank();
                _showToast(`"${chapter}" marked as done! \u2705`);
            }
        );
    }

    /**
     * Lower the priority of a backlog chapter.
     * Resets one completed task to false, effectively making the chapter
     * less of a quick win and more of a longer-term item.
     * Only resets the last-done task (pyq → notes → read order).
     */
    function _handleRankLowerPriority(chapter) {
        if (typeof chapter !== 'string' || !chapter) return;

        let masterData = SafeStorage.getItem(MASTER_KEY, {});
        const entry = masterData[chapter];

        if (!entry || typeof entry !== 'object') return;
        if (!_isRealBacklog(entry)) return;

        // Reset the least important done task: pyq first, then notes, then read
        // This effectively increases tasksLeft and lowers the auto-rank score
        let changed = false;
        if (entry.pyq === true && entry.notes === true && entry.read === true) {
            // Already complete — shouldn't happen, but guard
            return;
        }

        // Reset the last completed task to lower effective priority
        // We reset pyq first (least core), then notes, then read
        if (entry.pyq === true) {
            entry.pyq = false;
            changed = true;
        } else if (entry.notes === true) {
            entry.notes = false;
            changed = true;
        } else if (entry.read === true) {
            entry.read = false;
            changed = true;
        }

        if (changed) {
            entry.lastUpdated = new Date().toDateString();
            masterData[chapter] = entry;
            SafeStorage.setItem(MASTER_KEY, masterData);
            _enqueueChapterUpsert(chapter);

            _renderInventory();
            _updateDynamicCleanup();
            renderBacklogAutoRank();
            _showToast(`"${chapter}" priority lowered.`);
        }
    }

    // ════════════════════════════════════════════════════════
    //  TIMELINE
    // ════════════════════════════════════════════════════════

    function _getTimeline() {
        try { return SafeStorage.getItem(TIMELINE_KEY, {}); }
        catch (e) { return {}; }
    }

    function _saveTimeline(data) {
        SafeStorage.setItem(TIMELINE_KEY, data);
    }

    function _buildTimelineTabs() {
        const container = _container?.querySelector('#timeline-tabs');
        if (!container) return;

        const today = new Date();
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

        container.innerHTML = '';

        for (let i = 0; i < 5; i++) {
            const date = new Date(today);
            date.setDate(today.getDate() + i);
            const label = i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : dayNames[date.getDay()];
            const dateStr = date.toDateString();

            const tab = document.createElement('div');
            tab.className = 'time-node' + (i === 0 ? ' active' : '');
            tab.textContent = label;
            tab.dataset.action = 'timeline-tab';
            tab.dataset.date = dateStr;
            tab.id = `tlnode-${dateStr.replace(/\s+/g, '_')}`;

            container.appendChild(tab);
        }

        // Render today's content
        _renderTimelineDay(today.toDateString());
    }

    function _assignToTimeline(chap, dateStr) {
        const today = new Date().toDateString();
        if (dateStr === today) return; // Can't schedule for today

        const timeline = _getTimeline();
        if (!timeline[dateStr]) timeline[dateStr] = [];

        if (!timeline[dateStr].includes(chap)) {
            timeline[dateStr].push(chap);
        }
        _saveTimeline(timeline);

        // Mark as scheduled in smartPadhaiData
        const data = SafeStorage.getItem(MASTER_KEY, {});
        if (data[chap]) {
            data[chap] = {
                ...data[chap],
                _scheduledFor: dateStr
            };
            SafeStorage.setItem(MASTER_KEY, data);
            _enqueueChapterUpsert(chap);
        }

        _renderInventory();
        _buildTimelineTabs();
        _updateDynamicCleanup();
        _showToast(`${chap} \u2192 Scheduled!`);
    }

    function _renderTimelineDay(dateStr) {
        const container = _container?.querySelector('#timeline-content');
        if (!container) return;

        const timeline = _getTimeline();
        const items = timeline[dateStr] || [];
        const data = SafeStorage.getItem(MASTER_KEY, {});

        if (items.length === 0) {
            container.innerHTML = `<div class="bl-empty-state sp-empty-state">
                <span class="sp-empty-state-icon">📅</span>
                <h3 class="sp-empty-state-title">No Missions Scheduled</h3>
                <p class="sp-empty-state-text">Drag a backlog task here to schedule it.</p>
            </div>`;
            return;
        }

        container.innerHTML = items.map(chap => {
            const status = data[chap];
            const isDone = status && _isCompleted(status);
            return `
            <div class="timeline-item ${isDone ? 'tl-done' : ''} sp-card">
                <span>${chap}</span>
                ${isDone ?
                    '<span class="tl-done-label">\u2713 Done</span>' :
                    `<button class="mini-kill-btn sp-btn" data-action="set-focus" data-chapter="${chap}">Target</button>`
                }
            </div>`;
        }).join('');
    }

    function _autoLoadTodaySchedule() {
        const today = new Date().toDateString();
        const timeline = _getTimeline();
        const todayItems = timeline[today] || [];
        if (todayItems.length === 0) return;

        const data = SafeStorage.getItem(MASTER_KEY, {});
        let changed = false;

        const changedChapters = [];
        todayItems.forEach(chap => {
            if (data[chap] && data[chap]._scheduledFor) {
                delete data[chap]._scheduledFor;
                changedChapters.push(chap);
                changed = true;
            }
        });

        if (changed) {
            SafeStorage.setItem(MASTER_KEY, data);
            // Enqueue each changed chapter individually (SyncManager debounces into one batch)
            changedChapters.forEach(chap => _enqueueChapterUpsert(chap));
        }
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING — Delegation + AbortController
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {
        // ── CLICK DELEGATION ──
        container.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;
            const chapter = target.dataset.chapter;

            switch (action) {
                case 'toggle-mission':
                    _toggleMission();
                    break;

                case 'set-focus':
                    if (chapter) _setFocusMission(chapter);
                    break;

                case 'delete-mission':
                    if (chapter) _deleteMission(chapter);
                    break;

                case 'timeline-tab': {
                    const dateStr = target.dataset.date;
                    if (dateStr) {
                        container.querySelectorAll('.time-node').forEach(t => t.classList.remove('active'));
                        target.classList.add('active');
                        _renderTimelineDay(dateStr);
                    }
                    break;
                }

                case 'drag-start':
                    // Handled by dragstart event, not click
                    break;

                // ── Auto-Rank event handlers ──
                case 'rank-set-focus':
                    _handleRankSetFocus(chapter);
                    break;

                case 'rank-move-today':
                    _handleRankMoveToday(chapter);
                    break;

                case 'rank-mark-done':
                    _handleRankMarkDone(chapter);
                    break;

                case 'rank-lower-priority':
                    _handleRankLowerPriority(chapter);
                    break;
            }
        }, { signal });

        // ── CHANGE DELEGATION for Auto-Rank selects ──
        container.addEventListener('change', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;
            const value = target.value;

            switch (action) {
                case 'rank-filter':
                    _handleRankFilter(value);
                    break;

                case 'rank-subject-filter':
                    _handleRankSubjectFilter(value);
                    break;

                case 'rank-sort':
                    _handleRankSort(value);
                    break;
            }
        }, { signal });

        // ── DRAG START ──
        container.addEventListener('dragstart', (e) => {
            const card = e.target.closest('.backlog-item-card');
            if (!card) return;
            const chapter = card.dataset.chapter;
            if (chapter) {
                e.dataTransfer.setData('chapterName', chapter);
                e.dataTransfer.effectAllowed = 'move';
                card.classList.add('dragging');
            }
        }, { signal });

        container.addEventListener('dragend', (e) => {
            const card = e.target.closest('.backlog-item-card');
            if (card) card.classList.remove('dragging');
        }, { signal });

        // ── DRAG OVER / DROP on timeline tabs ──
        container.addEventListener('dragover', (e) => {
            const tab = e.target.closest('.time-node');
            if (tab) {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
                tab.classList.add('drag-over');
            }
        }, { signal });

        container.addEventListener('dragleave', (e) => {
            const tab = e.target.closest('.time-node');
            if (tab) tab.classList.remove('drag-over');
        }, { signal });

        container.addEventListener('drop', (e) => {
            e.preventDefault();
            const tab = e.target.closest('.time-node');
            if (!tab) return;
            tab.classList.remove('drag-over');

            const chap = e.dataTransfer.getData('chapterName');
            const dateStr = tab.dataset.date;
            if (!chap || !dateStr) return;
            _assignToTimeline(chap, dateStr);
        }, { signal });
    }

    // ════════════════════════════════════════════════════════
    //  TOAST + CONFIRM DIALOG
    // ════════════════════════════════════════════════════════

    function _showToast(message) {
        const toast = _container?.querySelector('#blToast');
        if (!toast) return;

        toast.textContent = message;
        toast.classList.add('visible');

        if (_toastTimeout) clearTimeout(_toastTimeout);
        _toastTimeout = setTimeout(() => {
            toast.classList.remove('visible');
        }, 3000);
    }

    function _showConfirmDialog(message, onConfirm) {
        const overlay = document.createElement('div');
        overlay.className = 'bl-confirm-overlay sp-modal-overlay';
        overlay.innerHTML = `
            <div class="bl-confirm-box sp-modal-card">
                <div class="bl-confirm-text">${message}</div>
                <div class="bl-confirm-btns">
                    <button class="bl-confirm-no sp-btn sp-btn-secondary" data-action="confirm-cancel">Cancel</button>
                    <button class="bl-confirm-yes sp-btn sp-btn-danger" data-action="confirm-yes">Remove</button>
                </div>
            </div>`;

        document.body.appendChild(overlay);

        const yesBtn = overlay.querySelector('[data-action="confirm-yes"]');
        const noBtn = overlay.querySelector('[data-action="confirm-cancel"]');

        const cleanup = () => overlay.remove();

        yesBtn.addEventListener('click', () => { cleanup(); onConfirm(); });
        noBtn.addEventListener('click', cleanup);
        overlay.addEventListener('click', (e) => { if (e.target === overlay) cleanup(); });
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();

window.BacklogRoute = BacklogRoute;
