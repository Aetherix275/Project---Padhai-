/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — SYLLABUS ROUTE MODULE (Phase 7E-2B + Gap Analyzer)
 *  Full SPA conversion of Syllabus Tracker + Gap Analyzer
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear state
 *
 *  Data: SafeStorage-first, Supabase mirror second
 *  Events: All via event delegation + AbortController. Zero inline onclick.
 *  CSS: Loaded dynamically from styles/modules/syllabus.css
 *
 *  PP Safety:
 *    - Mastery (+20 PP) only when transitioning non-mastered → mastered
 *    - Unique rewardId prevents duplicate PP
 *    - Never calls loadPulseEngineFromSupabase() or syncPulseEngineToSupabase()
 *
 *  Gap Analyzer:
 *    - Analyzes syllabus chapters for weak/incomplete areas
 *    - Calculates gap scores and risk levels
 *    - Provides actionable suggestions
 *    - Supports risk-level and subject filtering
 *    - Optional safe backlog integration
 * ═══════════════════════════════════════════════════════════════════
 */

const SyllabusRoute = (() => {

    // ── Private state ──
    let _container = null;
    let _abortController = null;
    let _currentClass = 10;
    let _toastTimeout = null;
    let _cssLinkEl = null;

    // Gap Analyzer state
    let _gapFilter = 'all';
    let _gapSubject = 'all';
    let _gapChaptersCache = [];   // cached normalized chapters for current view

    // Memory Decay state
    let _memoryFilter = 'all';

    const CSS_PATH = './styles/modules/syllabus.css';
    const MASTER_KEY = 'smartPadhaiData';
    const TRACKER_KEY = 'syllabus_master_tracker';
    const CLASS_KEY = 'userClass';
    const BACKLOG_TIMELINE_KEY = 'backlog_timeline';
    const MEMORY_DECAY_KEY = 'smart_padhai_memory_decay';

    // ── Syllabus Data Map ──
    const _SYLLABUS_DATA = {
        9: {
            "Science": {
                "Physics": ["Motion", "Force & Laws of Motion", "Gravitation"],
                "Chemistry": ["Matter in our Surroundings", "Is Matter Around Us Pure"],
                "Biology": ["Cell - Basic Unit of Life", "Tissues"]
            }
        },
        10: {
            "Science": {
                "Physics": ["Light - Reflection & Refraction", "The Human Eye", "Electricity", "Magnetic Effects"],
                "Chemistry": ["Chemical Reactions", "Acids, Bases & Salts", "Metals & Non-metals", "Carbon & its Compounds"],
                "Biology": ["Life Processes", "Control & Coordination", "Reproduction", "Heredity"]
            },
            "Maths": {
                "Standard": ["Real Numbers", "Polynomials", "Quadratic Equations", "Trigonometry"]
            }
        }
    };

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════

    async function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;

        // 1. Load CSS
        _loadCSS();

        // 2. Try loading from Supabase (best-effort merge)
        await _loadFromSupabase();

        // 3. Render full UI
        container.innerHTML = renderFullUI();

        // 4. Check saved class preference
        const savedClass = SafeStorage.getItem(CLASS_KEY, null);
        if (savedClass && _SYLLABUS_DATA[savedClass]) {
            _currentClass = savedClass;
            _selectClass(savedClass, true); // true = skip saving again
        }

        // 5. Bind events
        _bindEvents(container, _abortController.signal);

        console.log('[SyllabusRoute] Initialized');
    }

    function cleanup() {
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }
        if (_toastTimeout) {
            clearTimeout(_toastTimeout);
            _toastTimeout = null;
        }
        // Remove confirm overlays
        document.querySelectorAll('.syl-confirm-overlay').forEach(el => el.remove());
        // Remove toast
        document.querySelectorAll('.syl-toast').forEach(el => el.remove());
        _unloadCSS();
        _container = null;
        _gapFilter = 'all';
        _gapSubject = 'all';
        _gapChaptersCache = [];
        _memoryFilter = 'all';
        console.log('[SyllabusRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.syllabusCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-syllabus-css]');
        if (el) { el.remove(); _cssLinkEl = null; }
    }

    // ════════════════════════════════════════════════════════
    //  SUPABASE SYNC
    // ════════════════════════════════════════════════════════

    function _getUserId() {
        return window.AppState?.currentUser?.id || localStorage.getItem('_current_user_id');
    }

    async function _loadFromSupabase() {
        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) return;

        try {
            const { data, error } = await window.supabaseClient
                .from('syllabus_progress')
                .select('*')
                .eq('user_id', userId);

            if (error || !data || data.length === 0) return;

            const local = SafeStorage.getItem(MASTER_KEY, {});

            // Defensive: local must be a plain object
            if (typeof local !== 'object' || local === null || Array.isArray(local)) {
                console.warn('[SyllabusRoute] Local masterData corrupted in Supabase merge, resetting');
                return;
            }

            let merged = false;

            // Merge ALL rows chapter-by-chapter — NEVER overwrite local with only one row
            data.forEach(row => {
                const chapter = row.chapter;
                if (!chapter) return;

                const localEntry = local[chapter];
                const cloudRead = !!row.read;
                const cloudNotes = !!row.notes;
                const cloudPyq = !!row.pyq;

                if (!localEntry || typeof localEntry !== 'object') {
                    // Cloud-only chapter — add to local
                    local[chapter] = {
                        read: cloudRead,
                        notes: cloudNotes,
                        pyq: cloudPyq,
                        revised: false,
                        lastUpdated: row.updated_at || new Date().toLocaleDateString(),
                        isSyllabus: true
                    };
                    merged = true;
                } else {
                    // Both exist — only take cloud if it has STRICTLY more progress
                    // AND local has zero progress (never overwrite user's recent changes)
                    const localDone = [localEntry.read, localEntry.notes, localEntry.pyq].filter(Boolean).length;
                    const cloudDone = [cloudRead, cloudNotes, cloudPyq].filter(Boolean).length;

                    // SAFE MERGE: Only accept cloud data when local has NO progress at all
                    // This prevents stale Supabase data from overwriting user's recent edits
                    if (localDone === 0 && cloudDone > 0) {
                        local[chapter] = {
                            ...localEntry,  // preserve _scheduledFor, isSyllabus, revised
                            read: cloudRead,
                            notes: cloudNotes,
                            pyq: cloudPyq,
                            isSyllabus: true,
                            lastUpdated: row.updated_at || localEntry.lastUpdated
                        };
                        merged = true;
                    }
                }
            });

            if (merged) {
                SafeStorage.setItem(MASTER_KEY, local);
                console.log(`[SyllabusRoute] Merged ${data.length} rows from Supabase. Local chapters: ${Object.keys(local).length}`);
            }
        } catch (err) {
            console.warn('[SyllabusRoute] Supabase load failed:', err);
        }
    }

    async function _syncToSupabase() {
        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) return;

        try {
            const masterData = SafeStorage.getItem(MASTER_KEY, {});
            const rows = [];

            for (const chapName in masterData) {
                const entry = masterData[chapName];
                if (typeof entry !== 'object' || entry === null) continue;

                rows.push({
                    user_id: userId,
                    subject: entry.isSyllabus ? 'General' : 'Backlog',
                    chapter: chapName,
                    read: !!entry.read,
                    notes: !!entry.notes,
                    pyq: !!entry.pyq,
                    completed: !!(entry.read && entry.notes && entry.pyq),
                    updated_at: new Date().toISOString()
                });
            }

            if (rows.length === 0) return;

            // Batch upsert
            const { error } = await window.supabaseClient
                .from('syllabus_progress')
                .upsert(rows, { onConflict: 'user_id,subject,chapter' });

            if (error) console.warn('[SyllabusRoute] Mirror sync failed:', error);
            else console.log('[SyllabusRoute] Synced to Supabase');
        } catch (err) {
            console.warn('[SyllabusRoute] Mirror error:', err);
        }
    }

    // ════════════════════════════════════════════════════════
    //  HTML RENDERING
    // ════════════════════════════════════════════════════════

    function renderFullUI() {
        return `
        <div class="syllabus-wrapper">
            <!-- PAGE HEADER -->
            <div class="syllabus-page-header">
                <h1 class="syllabus-page-title">Syllabus</h1>
                <p class="syllabus-page-subtitle">Strategic chapter mastery tracker</p>
            </div>

            <!-- CLASS SELECTOR -->
            <div id="classSelector" class="class-selection-overlay">
                <h2>Select Your Mission Level</h2>
                <p class="class-selection-subtitle">Choose your battlefield to begin mission tracking</p>
                <div class="class-cards">
                    <div class="class-card" data-action="select-class" data-class="9">
                        <span class="class-number">09</span>
                        <p class="class-label">Class 9th</p>
                        <p class="class-desc">Foundation year \u2014 build core concepts</p>
                    </div>
                    <div class="class-card" data-action="select-class" data-class="10">
                        <span class="class-number">10</span>
                        <p class="class-label">Class 10th</p>
                        <p class="class-desc">Board year \u2014 conquer every chapter</p>
                    </div>
                </div>
            </div>

            <!-- SUBJECT SECTION -->
            <div id="subjectSection" style="display:none;">
                <div class="section-header">
                    <button class="back-btn sp-btn" data-action="go-back-to-class">\u2190 Back</button>
                    <h2 id="classHeading">Class 10th Missions</h2>
                </div>

                <!-- GAP ANALYZER -->
                <div id="gapAnalyzerSection" class="gap-analyzer-section"></div>

                <div class="subject-grid" id="subjectGrid"></div>
            </div>

            <!-- CHECKLIST SECTION -->
            <div id="checklistSection" style="display:none;">
                <div class="section-header">
                    <button class="back-btn sp-btn" data-action="go-back-to-subjects">\u2190 Back to Subjects</button>
                    <h2 id="checklistTitle">Science - Mission List</h2>
                </div>
                <div id="bookTabs" class="book-tabs" style="display:none;"></div>
                <div class="chapter-list-container" id="chapterList"></div>
            </div>
        </div>
        <!-- Toast -->
        <div class="syl-toast" id="sylToast"></div>`;
    }

    // ════════════════════════════════════════════════════════
    //  CLASS SELECTION
    // ════════════════════════════════════════════════════════

    function _selectClass(classNum, skipSave) {
        _currentClass = classNum;

        // Show subjects, hide class selector
        const classSelector = _container?.querySelector('#classSelector');
        const subjectSection = _container?.querySelector('#subjectSection');
        const classHeading = _container?.querySelector('#classHeading');
        const checklistSection = _container?.querySelector('#checklistSection');

        // Mark selected class card visually
        _container?.querySelectorAll('.class-card').forEach(c => c.classList.remove('selected'));
        const selectedCard = _container?.querySelector(`.class-card[data-class="${classNum}"]`);
        if (selectedCard) selectedCard.classList.add('selected');

        if (classSelector) classSelector.style.display = 'none';
        if (subjectSection) subjectSection.style.display = 'block';
        if (checklistSection) checklistSection.style.display = 'none';
        if (classHeading) classHeading.innerText = `Class ${classNum}th Missions`;

        // Save preference
        if (!skipSave) {
            SafeStorage.setItem(CLASS_KEY, classNum);
        }

        // Register all chapters in smartPadhaiData
        let masterData = SafeStorage.getItem(MASTER_KEY, {});
        const subjects = _SYLLABUS_DATA[classNum];
        if (!subjects) return;

        for (const subj in subjects) {
            for (const book in subjects[subj]) {
                subjects[subj][book].forEach(chap => {
                    if (!masterData[chap]) {
                        masterData[chap] = { read: false, notes: false, pyq: false, revised: false, isSyllabus: true };
                    } else {
                        // Preserve existing data, just mark as syllabus
                        masterData[chap].isSyllabus = true;
                        // Add revised field if missing (backward compat)
                        if (typeof masterData[chap].revised === 'undefined') {
                            masterData[chap].revised = false;
                        }
                    }
                });
            }
        }
        SafeStorage.setItem(MASTER_KEY, masterData);

        // Sync progress tracker
        _syncProgressTracker(classNum);

        // Mirror to Supabase
        _syncToSupabase(); // fire-and-forget

        // Render subject cards
        _renderSubjectGrid();

        // Render Gap Analyzer
        _renderGapAnalyzer();
    }

    function _renderSubjectGrid() {
        const grid = _container?.querySelector('#subjectGrid');
        if (!grid) return;

        const subjects = _SYLLABUS_DATA[_currentClass];
        if (!subjects) { grid.innerHTML = '<p>No data found.</p>'; return; }

        const subjectMeta = {
            "Science":  { icon: "\uD83E\uDDEC", desc: "Phy, Chem, Bio", color: "#00d4ff" },
            "Maths":    { icon: "\uD83D\uDCD0", desc: "Calculations & Logic", color: "#ffcc00" },
            "SST":      { icon: "\uD83C\uDF0D", desc: "His, Geo, Civ, Eco", color: "#ff5e62" },
            "English":  { icon: "\uD83D\uDCD6", desc: "Literature & Grammar", color: "#a8ff78" },
            "Hindi":    { icon: "\u270D\uFE0F", desc: "Vyakaran & Sahitya", color: "#feb47b" },
            "IT":       { icon: "\uD83D\uDCBB", desc: "Digital Mastery", color: "#8e44ad" }
        };

        let html = '';
        for (const subj in subjects) {
            const meta = subjectMeta[subj] || { icon: "\uD83D\uDCDD", desc: "Subject", color: "#888" };
            html += `
            <div class="subject-card-box" data-action="show-chapters" data-subject="${subj}">
                <div class="sub-icon" style="color: ${meta.color};">${meta.icon}</div>
                <h3>${subj}</h3>
                <p>${meta.desc}</p>
            </div>`;
        }

        grid.innerHTML = html;
    }

    // ════════════════════════════════════════════════════════
    //  CHAPTERS
    // ════════════════════════════════════════════════════════

    function _showChapters(subjectName) {
        const subjectSection = _container?.querySelector('#subjectSection');
        const checklistSection = _container?.querySelector('#checklistSection');
        const checklistTitle = _container?.querySelector('#checklistTitle');

        if (subjectSection) subjectSection.style.display = 'none';
        if (checklistSection) checklistSection.style.display = 'block';
        if (checklistTitle) checklistTitle.innerText = `${subjectName} - Mission List`;

        const chapterList = _container?.querySelector('#chapterList');
        const bookTabsEl = _container?.querySelector('#bookTabs');
        if (!chapterList) return;

        const books = _SYLLABUS_DATA[_currentClass]?.[subjectName];
        const masterData = SafeStorage.getItem(MASTER_KEY, {});

        if (!books) {
            chapterList.innerHTML = `<div class="syl-empty-state sp-empty-state">
                <span class="syl-empty-icon sp-empty-state-icon">\uD83D\uDCCB</span>
                <h3 class="sp-empty-state-title">No Syllabus Data</h3>
                <p class="sp-empty-state-text">Add chapters to activate tracking for ${subjectName}.</p>
            </div>`;
            return;
        }

        // If multiple books, show tabs
        const bookNames = Object.keys(books);
        if (bookNames.length > 1 && bookTabsEl) {
            bookTabsEl.style.display = 'flex';
            bookTabsEl.innerHTML = bookNames.map((book, i) =>
                `<button class="back-btn sp-btn ${i === 0 ? 'active' : ''}" data-action="filter-book" data-book="${book}">${book}</button>`
            ).join('');
        } else if (bookTabsEl) {
            bookTabsEl.style.display = 'none';
        }

        let html = '';
        for (const book in books) {
            html += `<h3 class="book-title">${book}</h3>`;

            books[book].forEach(chapter => {
                const chapId = chapter.replace(/\s+/g, '');
                const saved = masterData[chapter] || { read: false, notes: false, pyq: false, revised: false };
                const isDone = saved.read && saved.notes && saved.pyq && saved.revised;

                html += `
                <div class="chapter-card ${isDone ? 'mastered' : ''}" id="chap-${chapId}" data-chapter="${chapter}">
                    <div class="chapter-main">
                        <div class="chapter-header">
                            <span class="diff-tag medium sp-badge">MEDIUM</span>
                            <h3 class="chapter-name ${isDone ? 'completed-task' : ''}">${chapter}</h3>
                        </div>
                        <div class="chapter-progress-container">
                            <div class="progress-track">
                                <div class="progress-fill" id="fill-${chapId}"
                                     style="width:${isDone ? '100%' : '0%'}; background:${isDone ? 'linear-gradient(90deg, #28a745, #20c997)' : ''}">
                                </div>
                            </div>
                            <span class="percentage" id="perc-${chapId}">${isDone ? '100%' : '0%'}</span>
                        </div>
                    </div>
                    <div class="chapter-actions">
                        <div class="check-group">
                            <label class="custom-check">
                                <input type="checkbox" data-action="update-progress" data-chapter="${chapter}" data-field="read" ${saved.read ? 'checked' : ''}>
                                <span class="check-label">Read</span>
                            </label>
                            <label class="custom-check">
                                <input type="checkbox" data-action="update-progress" data-chapter="${chapter}" data-field="notes" ${saved.notes ? 'checked' : ''}>
                                <span class="check-label">Notes</span>
                            </label>
                            <label class="custom-check">
                                <input type="checkbox" data-action="update-progress" data-chapter="${chapter}" data-field="revised" ${saved.revised ? 'checked' : ''}>
                                <span class="check-label">Revised</span>
                            </label>
                            <label class="custom-check">
                                <input type="checkbox" data-action="update-progress" data-chapter="${chapter}" data-field="pyq" ${saved.pyq ? 'checked' : ''}>
                                <span class="check-label">PYQ</span>
                            </label>
                        </div>
                    </div>
                    <div class="mastery-badge" id="badge-${chapId}" style="display:${isDone ? 'block' : 'none'};">\uD83C\uDFC6 MASTERED</div>
                </div>`;
            });
        }

        chapterList.innerHTML = html;
    }

    // ════════════════════════════════════════════════════════
    //  PROGRESS UPDATE
    // ════════════════════════════════════════════════════════

    function _updateProgress(chapter, field, isChecked) {
        const chapId = chapter.replace(/\s+/g, '');
        const card = _container?.querySelector(`#chap-${chapId}`);
        if (!card) return;

        // Read current state from all 4 checkboxes
        const readCb = card.querySelector('[data-field="read"]');
        const notesCb = card.querySelector('[data-field="notes"]');
        const revisedCb = card.querySelector('[data-field="revised"]');
        const pyqCb = card.querySelector('[data-field="pyq"]');

        const readVal = readCb ? readCb.checked : false;
        const notesVal = notesCb ? notesCb.checked : false;
        const revisedVal = revisedCb ? revisedCb.checked : false;
        const pyqVal = pyqCb ? pyqCb.checked : false;

        const checkedCount = [readVal, notesVal, revisedVal, pyqVal].filter(Boolean).length;
        const isMastered = checkedCount === 4;
        const wasMastered = card.classList.contains('mastered');

        // Update progress bar
        const fill = _container?.querySelector(`#fill-${chapId}`);
        const perc = _container?.querySelector(`#perc-${chapId}`);
        const badge = _container?.querySelector(`#badge-${chapId}`);
        const chapterName = card.querySelector('.chapter-name');

        const progress = Math.round((checkedCount / 4) * 100);

        if (fill) {
            fill.style.width = progress + '%';
            fill.style.background = isMastered ?
                'linear-gradient(90deg, #28a745, #20c997)' :
                'linear-gradient(90deg, #00d4ff, #0072ff)';
        }
        if (perc) perc.innerText = progress + '%';

        // Mastery logic
        if (isMastered && !wasMastered) {
            card.classList.add('mastered');
            if (badge) badge.style.display = 'block';
            if (chapterName) chapterName.classList.add('completed-task');

            // PP reward — ONLY on transition from non-mastered to mastered
            const rewardId = `mastered_${chapId}_${new Date().toDateString().replace(/\s+/g, '_')}`;
            PulseEngine.addPoints(20, 'mission', { rewardId });
            _showToast(`CHAPTER MASTERED: +20 PP \uD83C\uDFC6`);
        } else if (!isMastered) {
            card.classList.remove('mastered');
            if (badge) badge.style.display = 'none';
            if (chapterName) chapterName.classList.remove('completed-task');
        }

        // Save to smartPadhaiData — PRESERVE ALL existing chapters
        let masterData = SafeStorage.getItem(MASTER_KEY, {});

        // Defensive: masterData must be a plain object
        if (typeof masterData !== 'object' || masterData === null || Array.isArray(masterData)) {
            console.warn('[SyllabusRoute] masterData corrupted, resetting to {}');
            masterData = {};
        }

        const existing = masterData[chapter] || {};

        // Preserve ALL existing fields (_scheduledFor, isSyllabus, etc.)
        masterData[chapter] = {
            ...existing,
            read: readVal,
            notes: notesVal,
            revised: revisedVal,
            pyq: pyqVal,
            isSyllabus: true,
            lastUpdated: new Date().toLocaleDateString()
        };

        SafeStorage.setItem(MASTER_KEY, masterData);
        _syncToSupabase(); // fire-and-forget

        // Re-render Gap Analyzer with fresh data
        _renderGapAnalyzer();
    }

    // ════════════════════════════════════════════════════════
    //  PROGRESS TRACKER
    // ════════════════════════════════════════════════════════

    function _syncProgressTracker(classNum) {
        let progressTracker = SafeStorage.getItem(TRACKER_KEY, {});
        const subjects = _SYLLABUS_DATA[classNum];
        if (!subjects) return;

        for (const subj in subjects) {
            for (const book in subjects[subj]) {
                subjects[subj][book].forEach(chap => {
                    if (!progressTracker[chap]) {
                        progressTracker[chap] = { isRegistered: true };
                    }
                });
            }
        }
        SafeStorage.setItem(TRACKER_KEY, progressTracker);
    }

    // ════════════════════════════════════════════════════════
    //  KNOWLEDGE DECAY / MEMORY RETENTION SYSTEM
    // ════════════════════════════════════════════════════════

    const MEMORY_DECAY_STRENGTH = {
        BASE: 3,
        NOTES_BONUS: 2,
        REVISION_BONUS: 3,
        PYQ_BONUS: 4,
        REVIEW_BONUS: 2,
        MAX: 30
    };

    function getTodayDateKey() {
        const d = new Date();
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    }

    function getDaysSince(date) {
        if (!date) return null;
        const d = typeof date === 'string' ? new Date(date) : date;
        if (isNaN(d.getTime())) return null;
        const now = new Date();
        const diffMs = now.getTime() - d.getTime();
        return Math.floor(diffMs / (1000 * 60 * 60 * 24));
    }

    function getChapterMemoryKey(chapter) {
        const name = chapter.name || chapter;
        const subject = chapter.subject || '';
        return `${subject}__${name}`;
    }

    function getMemoryMeta(chapter) {
        const key = getChapterMemoryKey(chapter);
        const allMeta = SafeStorage.getItem(MEMORY_DECAY_KEY, {});
        if (typeof allMeta !== 'object' || allMeta === null || Array.isArray(allMeta)) return {};
        return allMeta[key] || {};
    }

    function saveMemoryMeta(chapter, meta) {
        const key = getChapterMemoryKey(chapter);
        let allMeta = SafeStorage.getItem(MEMORY_DECAY_KEY, {});
        if (typeof allMeta !== 'object' || allMeta === null || Array.isArray(allMeta)) allMeta = {};
        allMeta[key] = {
            ...allMeta[key],
            ...meta
        };
        SafeStorage.setItem(MEMORY_DECAY_KEY, allMeta);
    }

    function calculateMemoryStrength(chapter, meta) {
        let strength = MEMORY_DECAY_STRENGTH.BASE;
        if (chapter.notes) strength += MEMORY_DECAY_STRENGTH.NOTES_BONUS;
        if (chapter.revised) strength += MEMORY_DECAY_STRENGTH.REVISION_BONUS;
        if (chapter.pyq) strength += MEMORY_DECAY_STRENGTH.PYQ_BONUS;
        const reviewCount = meta.reviewCount || 0;
        strength += reviewCount * MEMORY_DECAY_STRENGTH.REVIEW_BONUS;
        return Math.min(strength, MEMORY_DECAY_STRENGTH.MAX);
    }

    function _getLastMeaningfulReviewDate(chapter, entry, meta) {
        // Priority: lastReviewedAt (from meta) > revisedAt/pyqDoneAt/notesDoneAt (from entry) > lastUpdated > null
        if (meta.lastReviewedAt) return meta.lastReviewedAt;

        // Check entry fields (defensive — various possible field names)
        if (entry && typeof entry === 'object') {
            if (entry.lastReviewedAt) return entry.lastReviewedAt;
            if (entry.revisedAt) return entry.revisedAt;
            if (entry.pyqDoneAt || entry.practiceDoneAt) return entry.pyqDoneAt || entry.practiceDoneAt;
            if (entry.notesDoneAt) return entry.notesDoneAt;
            if (entry.lastUpdated) {
                // Try to parse lastUpdated — it might be locale string or ISO
                const parsed = new Date(entry.lastUpdated);
                if (!isNaN(parsed.getTime())) return entry.lastUpdated;
            }
        }

        // If chapter has any completion status but no date, use a rough estimate
        const hasAnyProgress = chapter.read || chapter.notes || chapter.revised || chapter.pyq;
        if (hasAnyProgress && entry && entry.lastUpdated) {
            return entry.lastUpdated;
        }

        return null;
    }

    function calculateRetention(chapter, entry) {
        const meta = getMemoryMeta(chapter);
        const lastReviewDate = _getLastMeaningfulReviewDate(chapter, entry, meta);

        if (!lastReviewDate) {
            // No review date — check if chapter has any progress
            const hasAnyProgress = chapter.read || chapter.notes || chapter.revised || chapter.pyq;
            if (!hasAnyProgress) return null; // Unknown / Not started
            // Has progress but no date — can't calculate, return null
            return null;
        }

        const daysSince = getDaysSince(lastReviewDate);
        if (daysSince === null) return null;

        const strength = calculateMemoryStrength(chapter, meta);
        const retention = Math.round(100 * Math.exp(-daysSince / strength));
        return Math.max(0, Math.min(100, retention));
    }

    function getMemoryStatus(retention) {
        if (retention === null || retention === undefined) {
            return { status: 'Unknown', color: '#6b7280', cssClass: 'memory-unknown', message: 'No memory record yet.' };
        }
        if (retention >= 80) {
            return { status: 'Strong', color: '#00ff9d', cssClass: 'memory-strong', message: 'Memory stable.' };
        }
        if (retention >= 60) {
            return { status: 'Good', color: '#00bcd4', cssClass: 'memory-good', message: 'Light revision soon.' };
        }
        if (retention >= 40) {
            return { status: 'Fading', color: '#ff9f1a', cssClass: 'memory-fading', message: 'Review recommended.' };
        }
        if (retention >= 1) {
            return { status: 'Memory Critical', color: '#ff4c4c', cssClass: 'memory-critical', message: 'Revise immediately.' };
        }
        return { status: 'Not Started', color: '#6b7280', cssClass: 'memory-unknown', message: 'No memory record yet.' };
    }

    function getNextReviewDue(retention) {
        if (retention === null || retention === undefined) return 'Start chapter first';
        if (retention >= 80) return 'In 5-7 days';
        if (retention >= 60) return 'In 2-3 days';
        if (retention >= 40) return 'Tomorrow';
        return 'Today';
    }

    function getMemorySuggestion(retention) {
        if (retention === null || retention === undefined) return 'Start or mark first review to activate memory tracking.';
        if (retention < 40) return 'Revise this today. Memory has decayed below safe level.';
        if (retention < 60) return 'Do a quick revision and 10 questions.';
        if (retention < 80) return 'Light review soon to protect memory.';
        return 'Keep in spaced revision cycle.';
    }

    function getMemorySummary(chaptersWithRetention) {
        const summary = { memoryCritical: 0, fading: 0, strong: 0, good: 0, unknown: 0, reviewDueToday: 0 };
        chaptersWithRetention.forEach(ch => {
            const memInfo = ch.memoryInfo || {};
            const status = memInfo.status || 'Unknown';
            if (status === 'Memory Critical') summary.memoryCritical++;
            else if (status === 'Fading') summary.fading++;
            else if (status === 'Strong') summary.strong++;
            else if (status === 'Good') summary.good++;
            else summary.unknown++;

            // Review due today = retention < 40 OR nextReviewDue === 'Today'
            if (memInfo.nextReviewDue === 'Today') summary.reviewDueToday++;
        });
        return summary;
    }

    function filterByMemoryStatus(chaptersWithRetention, filter) {
        if (!filter || filter === 'all') return chaptersWithRetention;
        return chaptersWithRetention.filter(ch => {
            const memInfo = ch.memoryInfo || {};
            const status = memInfo.status || 'Unknown';
            switch (filter) {
                case 'memory-critical': return status === 'Memory Critical';
                case 'fading': return status === 'Fading';
                case 'review-due': return memInfo.nextReviewDue === 'Today';
                case 'strong': return status === 'Strong';
                case 'unknown': return status === 'Unknown' || status === 'Not Started';
                default: return true;
            }
        });
    }

    function _markChapterReviewed(chapterName) {
        const chapters = getSyllabusData();
        const chapter = chapters.find(ch => ch.name === chapterName);
        if (!chapter) return;

        const meta = getMemoryMeta(chapter);
        const now = new Date().toISOString();
        meta.lastReviewedAt = now;
        meta.reviewCount = (meta.reviewCount || 0) + 1;
        meta.strength = calculateMemoryStrength(chapter, meta);
        saveMemoryMeta(chapter, meta);

        // Dispatch events
        try {
            window.dispatchEvent(new CustomEvent('smartPadhai:syllabusUpdated'));
            window.dispatchEvent(new CustomEvent('smartPadhai:memoryUpdated'));
        } catch (e) { /* safe */ }

        _showToast(`${chapterName} marked reviewed. Memory strength increased.`);

        // Re-render Gap Analyzer
        _renderGapAnalyzer();
    }


    // ════════════════════════════════════════════════════════
    //  GAP ANALYZER — Data Helpers
    // ════════════════════════════════════════════════════════

    /**
     * Get all syllabus chapters for current class, normalized.
     * Returns array of normalized chapter objects.
     */
    function getSyllabusData() {
        const subjects = _SYLLABUS_DATA[_currentClass];
        if (!subjects) return [];

        const masterData = SafeStorage.getItem(MASTER_KEY, {});
        const chapters = [];

        for (const subj in subjects) {
            for (const book in subjects[subj]) {
                subjects[subj][book].forEach(chapName => {
                    const entry = masterData[chapName] || {};
                    chapters.push(_normalizeChapter(chapName, subj, book, entry));
                });
            }
        }

        return chapters;
    }

    /**
     * Normalize a raw chapter entry into a consistent structure.
     * Defensive: handles missing or differently-named fields.
     */
    function _normalizeChapter(chapterName, subject, book, entry) {
        if (!entry || typeof entry !== 'object') entry = {};

        return {
            name: chapterName,
            subject: subject || 'Unknown',
            book: book || 'General',
            read: !!(entry.read || entry.lecture || entry.lectureDone || entry.lectureWatched),
            notes: !!(entry.notes || entry.notesDone),
            revised: !!(entry.revised || entry.revision || entry.isRevised),
            pyq: !!(entry.pyq || entry.testPractice || entry.testPracticeDone || entry.practice),
            confidence: entry.confidence || null,
            priority: entry.priority || null,
            isSyllabus: entry.isSyllabus !== false,
            lastUpdated: entry.lastUpdated || null,
            _scheduledFor: entry._scheduledFor || null,
            _rawEntry: entry
        };
    }

    /**
     * Analyze a single chapter and compute gap score, risk level, gap type.
     */
    function analyzeChapterGap(chapter) {
        let gapScore = 0;
        const missingItems = [];

        if (!chapter.read) { gapScore += 30; missingItems.push('Lecture'); }
        if (!chapter.notes) { gapScore += 25; missingItems.push('Notes'); }
        if (!chapter.revised) { gapScore += 25; missingItems.push('Revision'); }
        if (!chapter.pyq) { gapScore += 20; missingItems.push('Test Practice'); }

        // Bonus penalties
        if (chapter.confidence === 'low') { gapScore += 15; }
        if (chapter.priority === 'high' || chapter.priority === 'critical') { gapScore += 10; }

        // Memory Decay penalty — add risk for low retention
        const retention = calculateRetention(chapter, chapter._rawEntry);
        if (retention !== null && retention !== undefined) {
            if (retention < 40) { gapScore += 30; }
            else if (retention < 60) { gapScore += 20; }
            else if (retention < 80) { gapScore += 10; }
            // retention >= 80: no penalty
        }

        // Bonus reduction: all core tasks done
        const allCoreDone = chapter.read && chapter.notes && chapter.revised && chapter.pyq;
        if (allCoreDone) { gapScore -= 20; }
        if (gapScore < 0) gapScore = 0;

        const riskLevel = getRiskLevel(gapScore);
        const gapType = getGapType(chapter, missingItems, retention);
        const suggestedAction = getSuggestedAction({ riskLevel, gapType, chapter, missingItems, retention });

        // Calculate memory info
        const memStatus = getMemoryStatus(retention);
        const nextReview = getNextReviewDue(retention);
        const memSuggestion = getMemorySuggestion(retention);
        const meta = getMemoryMeta(chapter);
        const lastReviewDate = _getLastMeaningfulReviewDate(chapter, chapter._rawEntry, meta);
        const daysSinceReview = getDaysSince(lastReviewDate);

        return {
            ...chapter,
            gapScore,
            riskLevel,
            gapType,
            missingItems,
            suggestedAction,
            allCoreDone,
            retention,
            memoryInfo: {
                retention: retention,
                status: memStatus.status,
                color: memStatus.color,
                cssClass: memStatus.cssClass,
                message: memStatus.message,
                nextReviewDue: nextReview,
                suggestion: memSuggestion,
                lastReviewedAt: meta.lastReviewedAt || null,
                daysSinceReview: daysSinceReview,
                reviewCount: meta.reviewCount || 0,
                strength: meta.strength || calculateMemoryStrength(chapter, meta)
            }
        };
    }

    /**
     * Get risk level from gap score.
     */
    function getRiskLevel(score) {
        if (score <= 20) return 'safe';
        if (score <= 45) return 'watch';
        if (score <= 70) return 'high';
        return 'critical';
    }

    /**
     * Determine gap type from which tasks are missing.
     */
    function getGapType(chapter, missingItems, retention) {
        if (!chapter.read) return 'Foundation Missing';
        if (missingItems.length > 1) {
            // If retention is also critical, include that in gap type
            if (retention !== null && retention !== undefined && retention < 40) return 'Multi-Gap + Memory Critical';
            return 'Multi-Gap';
        }

        if (!chapter.notes) return 'Notes Pending';
        if (!chapter.revised) return 'Revision Pending';
        if (!chapter.pyq) return 'Test Practice Missing';

        // All core done but memory is decaying
        if (retention !== null && retention !== undefined && retention < 40) return 'Memory Critical';
        if (retention !== null && retention !== undefined && retention < 60) return 'Memory Fading';

        return 'Complete';
    }

    /**
     * Generate rule-based suggested action (no AI, no API).
     */
    function getSuggestedAction(analysis) {
        const { riskLevel, gapType, chapter, missingItems, retention } = analysis;

        // Memory-based suggestion takes priority if retention is very low
        if (retention !== null && retention !== undefined && retention < 40) {
            return 'Retention is below 40%. Revise this before adding new chapters.';
        }

        if (riskLevel === 'safe') {
            return 'Keep this in light revision cycle.';
        }

        if (riskLevel === 'critical') {
            return 'Schedule this chapter in today\u2019s backlog or timetable. Urgent.';
        }

        // Gap-type specific
        if (gapType === 'Foundation Missing') {
            return 'Complete the lecture first. Foundation is missing.';
        }
        if (gapType === 'Notes Pending') {
            return 'Complete notes first. Without notes, revision will collapse.';
        }
        if (gapType === 'Revision Pending') {
            return 'Revise this chapter today and mark formulas/key points.';
        }
        if (gapType === 'Test Practice Missing') {
            return 'Solve practice questions to check actual command.';
        }
        if (gapType === 'Multi-Gap' || gapType === 'Multi-Gap + Memory Critical') {
            // Prioritize: lecture > notes > revision > practice
            if (!chapter.read) return 'Start with the lecture, then build notes and revision.';
            if (!chapter.notes) return 'Complete notes first, then revise and practice.';
            if (!chapter.revised) return 'Revise first, then solve practice questions.';
            return 'Solve practice questions to complete this chapter.';
        }
        if (gapType === 'Memory Critical') {
            return 'Retention is below 40%. Revise this before adding new chapters.';
        }
        if (gapType === 'Memory Fading') {
            return 'Memory is fading. Do a quick revision and 10 questions.';
        }

        return 'Keep working on this chapter.';
    }

    /**
     * Get summary counts from analyzed chapters.
     */
    function getGapSummary(analyzedChapters) {
        const summary = { critical: 0, high: 0, watch: 0, safe: 0, revisionPending: 0, notesPending: 0, practiceMissing: 0, foundationMissing: 0, multiGap: 0, memoryCritical: 0, memoryFading: 0, total: analyzedChapters.length };

        analyzedChapters.forEach(ch => {
            if (ch.riskLevel === 'critical') summary.critical++;
            if (ch.riskLevel === 'high') summary.high++;
            if (ch.riskLevel === 'watch') summary.watch++;
            if (ch.riskLevel === 'safe') summary.safe++;
            if (ch.gapType === 'Revision Pending') summary.revisionPending++;
            if (ch.gapType === 'Notes Pending') summary.notesPending++;
            if (ch.gapType === 'Test Practice Missing') summary.practiceMissing++;
            if (ch.gapType === 'Foundation Missing') summary.foundationMissing++;
            if (ch.gapType === 'Multi-Gap' || ch.gapType === 'Multi-Gap + Memory Critical') summary.multiGap++;
            // Memory decay counts
            if (ch.memoryInfo && ch.memoryInfo.status === 'Memory Critical') summary.memoryCritical++;
            if (ch.memoryInfo && ch.memoryInfo.status === 'Fading') summary.memoryFading++;
        });

        return summary;
    }

    // ════════════════════════════════════════════════════════
    //  GAP ANALYZER — Rendering
    // ════════════════════════════════════════════════════════

    function _renderGapAnalyzer() {
        const container = _container?.querySelector('#gapAnalyzerSection');
        if (!container) return;

        const chapters = getSyllabusData();
        const analyzed = chapters.map(ch => analyzeChapterGap(ch));
        _gapChaptersCache = analyzed;

        const summary = getGapSummary(analyzed);

        // Collect unique subjects for filter
        const uniqueSubjects = [...new Set(analyzed.map(ch => ch.subject))].sort();

        container.innerHTML = _buildGapAnalyzerHTML(analyzed, summary, uniqueSubjects);

        // Re-apply active filter button state
        _applyGapFilterState();
    }

    function _buildGapAnalyzerHTML(analyzed, summary, subjects) {
        if (analyzed.length === 0) {
            return `
            <div class="gap-analyzer-panel">
                <div class="gap-analyzer-header">
                    <h2 class="gap-analyzer-title">SYLLABUS GAP ANALYZER</h2>
                    <p class="gap-analyzer-subtitle">Find the weak links before the exam finds them.</p>
                </div>
                <div class="gap-empty-state sp-empty-state">
                    <span class="gap-empty-icon sp-empty-state-icon">\uD83D\uDD0D</span>
                    <h3 class="sp-empty-state-title">No Syllabus Data</h3>
                    <p class="sp-empty-state-text">Add chapters to activate Gap Analyzer and track weak links.</p>
                </div>
            </div>`;
        }

        // Filter chapters based on current filter state
        const filtered = _filterGapChapters(analyzed);

        // Risk color map
        const riskColors = {
            critical: '#ff4c4c',
            high: '#ff9f1a',
            watch: '#00bcd4',
            safe: '#00ff9d'
        };

        const riskLabels = {
            critical: 'Critical',
            high: 'High Risk',
            watch: 'Watch',
            safe: 'Safe'
        };

        // Build subject filter buttons
        const subjectButtons = ['All Subjects', ...subjects].map(s => {
            const isActive = (_gapSubject === 'all' && s === 'All Subjects') || _gapSubject === s;
            return `<button class="gap-filter-btn gap-subject-btn ${isActive ? 'active' : ''}"
                        data-action="gap-subject-filter" data-subject="${s === 'All Subjects' ? 'all' : s}">${s}</button>`;
        }).join('');

        // Build risk filter buttons
        const riskFilterDefs = [
            { key: 'all', label: 'All' },
            { key: 'critical', label: 'Critical' },
            { key: 'high', label: 'High Risk' },
            { key: 'revision', label: 'Revision Pending' },
            { key: 'notes', label: 'Notes Pending' },
            { key: 'practice', label: 'Test Practice Missing' },
            { key: 'memory-critical', label: 'Memory Critical' },
            { key: 'fading', label: 'Fading' },
            { key: 'review-due', label: 'Review Due' },
            { key: 'strong', label: 'Strong Memory' },
            { key: 'safe', label: 'Safe' }
        ];
        const riskButtons = riskFilterDefs.map(f => {
            return `<button class="gap-filter-btn ${_gapFilter === f.key ? 'active' : ''}"
                        data-action="gap-filter" data-filter="${f.key}">${f.label}</button>`;
        }).join('');

        // Build gap cards
        let gapCardsHTML = '';
        if (filtered.length === 0) {
            gapCardsHTML = `<div class="gap-no-results">
                <span class="gap-no-results-icon">\u2714\uFE0F</span>
                <p>No chapters match this filter. Try a different one.</p>
            </div>`;
        } else {
            gapCardsHTML = filtered.map(ch => _buildGapCardHTML(ch, riskColors, riskLabels)).join('');
        }

        return `
        <div class="gap-analyzer-panel">
            <div class="gap-analyzer-header">
                <div class="gap-analyzer-title-row">
                    <h2 class="gap-analyzer-title">SYLLABUS GAP ANALYZER</h2>
                    <span class="gap-scan-indicator"></span>
                </div>
                <p class="gap-analyzer-subtitle">Find the weak links before the exam finds them.</p>
            </div>

            <!-- Summary Cards -->
            <div class="gap-summary-grid">
                <div class="gap-summary-card gap-summary-critical">
                    <span class="gap-summary-count">${summary.critical}</span>
                    <span class="gap-summary-label">Critical Gaps</span>
                </div>
                <div class="gap-summary-card gap-summary-high">
                    <span class="gap-summary-count">${summary.high}</span>
                    <span class="gap-summary-label">High Risk</span>
                </div>
                <div class="gap-summary-card gap-summary-revision">
                    <span class="gap-summary-count">${summary.revisionPending}</span>
                    <span class="gap-summary-label">Revision Pending</span>
                </div>
                <div class="gap-summary-card gap-summary-safe">
                    <span class="gap-summary-count">${summary.safe}</span>
                    <span class="gap-summary-label">Safe</span>
                </div>
            </div>

            <!-- Memory Decay Summary Cards -->
            <div class="memory-summary-grid">
                <div class="gap-summary-card memory-summary-critical">
                    <span class="gap-summary-count">${summary.memoryCritical}</span>
                    <span class="gap-summary-label">Memory Critical</span>
                </div>
                <div class="gap-summary-card memory-summary-fading">
                    <span class="gap-summary-count">${summary.memoryFading}</span>
                    <span class="gap-summary-label">Fading</span>
                </div>
                <div class="gap-summary-card memory-summary-strong">
                    <span class="gap-summary-count">${(() => { const ms = getMemorySummary(analyzed); return ms.strong; })()}</span>
                    <span class="gap-summary-label">Strong</span>
                </div>
                <div class="gap-summary-card memory-summary-review-due">
                    <span class="gap-summary-count">${(() => { const ms = getMemorySummary(analyzed); return ms.reviewDueToday; })()}</span>
                    <span class="gap-summary-label">Review Due</span>
                </div>
            </div>

            <!-- Filters -->
            <div class="gap-filters">
                <div class="gap-filter-row">${riskButtons}</div>
                <div class="gap-filter-row gap-subject-row">${subjectButtons}</div>
            </div>

            <!-- Gap List -->
            <div class="gap-list">
                ${gapCardsHTML}
            </div>
        </div>`;
    }

    function _buildGapCardHTML(ch, riskColors, riskLabels) {
        const color = riskColors[ch.riskLevel] || '#888';
        const label = riskLabels[ch.riskLevel] || 'Unknown';
        const checkMark = (done) => done
            ? '<span class="gap-check gap-check-done">\u2713</span>'
            : '<span class="gap-check gap-check-missing">\u2717</span>';
        const checkLabel = (done, text) => done
            ? `<span class="gap-check-label gap-check-label-done">${text} Done</span>`
            : `<span class="gap-check-label gap-check-label-missing">${text} Pending</span>`;

        // Memory info
        const memInfo = ch.memoryInfo || {};
        const memColor = memInfo.color || '#6b7280';
        const memStatus = memInfo.status || 'Unknown';
        const memCssClass = memInfo.cssClass || 'memory-unknown';
        const retention = memInfo.retention;
        const nextReview = memInfo.nextReviewDue || 'Start chapter first';
        const memSuggestion = memInfo.suggestion || '';
        const daysSince = memInfo.daysSinceReview;
        const reviewCount = memInfo.reviewCount || 0;

        // Build retention bar HTML
        let retentionBarHTML = '';
        if (retention !== null && retention !== undefined) {
            retentionBarHTML = `
            <div class="memory-retention-strip ${memCssClass}">
                <div class="memory-retention-bar" style="width: ${retention}%; background: ${memColor};"></div>
                <span class="memory-retention-label">${retention}% Retention</span>
            </div>`;
        } else {
            retentionBarHTML = `
            <div class="memory-retention-strip memory-unknown">
                <div class="memory-retention-bar" style="width: 0%; background: #6b7280;"></div>
                <span class="memory-retention-label">No retention data yet</span>
            </div>`;
        }

        // Memory status line
        let memoryLineHTML = '';
        const lastReviewedText = daysSince !== null && daysSince !== undefined
            ? (daysSince === 0 ? 'Today' : daysSince === 1 ? '1 day ago' : `${daysSince} days ago`)
            : 'Never';
        memoryLineHTML = `
        <div class="memory-status-line">
            <span class="memory-status-badge ${memCssClass}" style="background: ${memColor}20; color: ${memColor}; border: 1px solid ${memColor}50;">${memStatus.toUpperCase()}</span>
            <span class="memory-meta-item">Last: ${lastReviewedText}</span>
            <span class="memory-meta-item">Next: ${nextReview}</span>
            ${reviewCount > 0 ? `<span class="memory-meta-item">Reviews: ${reviewCount}</span>` : ''}
        </div>`;

        // Determine which action buttons to show
        let actionButtonsHTML = '';

        if (!ch.notes && ch.read) {
            actionButtonsHTML += `<button class="gap-action-btn gap-action-notes" data-action="gap-mark-field" data-chapter="${ch.name}" data-field="notes">Mark Notes Done</button>`;
        }
        if (!ch.revised && ch.read && ch.notes) {
            actionButtonsHTML += `<button class="gap-action-btn gap-action-revised" data-action="gap-mark-field" data-chapter="${ch.name}" data-field="revised">Mark Revised</button>`;
        }
        if (!ch.pyq && ch.read && ch.notes && ch.revised) {
            actionButtonsHTML += `<button class="gap-action-btn gap-action-pyq" data-action="gap-mark-field" data-chapter="${ch.name}" data-field="pyq">Mark PYQ Done</button>`;
        }

        // Mark Reviewed button — always show if chapter has any progress
        const hasAnyProgress = ch.read || ch.notes || ch.revised || ch.pyq;
        if (hasAnyProgress) {
            actionButtonsHTML += `<button class="gap-action-btn gap-action-review" data-action="memory-mark-reviewed" data-chapter="${ch.name}">Mark Reviewed</button>`;
        }

        // Backlog button — check if SafeStorage and BACKLOG_TIMELINE_KEY are accessible
        const backlogBtn = ch.riskLevel === 'safe'
            ? ''
            : `<button class="gap-action-btn gap-action-backlog" data-action="gap-add-backlog" data-chapter="${ch.name}" data-subject="${ch.subject}">Add to Backlog</button>`;

        // Memory suggestion line (separate from gap suggestion)
        let memSuggestionHTML = '';
        if (memSuggestion) {
            memSuggestionHTML = `
            <div class="memory-suggestion-line">
                <span class="gap-action-icon">\uD83E\uDDE0</span>
                <span>${memSuggestion}</span>
            </div>`;
        }

        return `
        <div class="gap-card gap-risk-${ch.riskLevel}" style="border-left-color: ${color};">
            <div class="gap-card-header">
                <span class="gap-card-subject">${ch.subject} / ${ch.book}</span>
                <span class="gap-risk-badge" style="background: ${color}20; color: ${color}; border: 1px solid ${color}50;">${label}</span>
            </div>
            <h3 class="gap-card-chapter">${ch.name}</h3>
            ${retentionBarHTML}
            ${memoryLineHTML}
            <div class="gap-card-meta">
                <span class="gap-gap-type" style="color: ${color};">${ch.gapType}</span>
                <span class="gap-score">Score: ${ch.gapScore}</span>
            </div>
            <div class="gap-checklist">
                <div class="gap-check-item">${checkMark(ch.read)} ${checkLabel(ch.read, 'Read')}</div>
                <div class="gap-check-item">${checkMark(ch.notes)} ${checkLabel(ch.notes, 'Notes')}</div>
                <div class="gap-check-item">${checkMark(ch.revised)} ${checkLabel(ch.revised, 'Revision')}</div>
                <div class="gap-check-item">${checkMark(ch.pyq)} ${checkLabel(ch.pyq, 'PYQ')}</div>
            </div>
            <div class="gap-suggested-action">
                <span class="gap-action-icon">\uD83D\uDCA1</span>
                <span>${ch.suggestedAction}</span>
            </div>
            ${memSuggestionHTML}
            ${actionButtonsHTML || backlogBtn ? `<div class="gap-card-actions">${actionButtonsHTML}${backlogBtn}</div>` : ''}
        </div>`;
    }

    // ════════════════════════════════════════════════════════
    //  GAP ANALYZER — Filtering
    // ════════════════════════════════════════════════════════

    function _filterGapChapters(analyzed) {
        let result = analyzed;

        // Risk/filter filter
        if (_gapFilter === 'critical') {
            result = result.filter(ch => ch.riskLevel === 'critical');
        } else if (_gapFilter === 'high') {
            result = result.filter(ch => ch.riskLevel === 'high');
        } else if (_gapFilter === 'revision') {
            result = result.filter(ch => ch.gapType === 'Revision Pending' || (ch.missingItems && ch.missingItems.includes('Revision')));
        } else if (_gapFilter === 'notes') {
            result = result.filter(ch => ch.gapType === 'Notes Pending' || (ch.missingItems && ch.missingItems.includes('Notes')));
        } else if (_gapFilter === 'practice') {
            result = result.filter(ch => ch.gapType === 'Test Practice Missing' || (ch.missingItems && ch.missingItems.includes('Test Practice')));
        } else if (_gapFilter === 'memory-critical') {
            result = result.filter(ch => ch.memoryInfo && ch.memoryInfo.status === 'Memory Critical');
        } else if (_gapFilter === 'fading') {
            result = result.filter(ch => ch.memoryInfo && ch.memoryInfo.status === 'Fading');
        } else if (_gapFilter === 'review-due') {
            result = result.filter(ch => ch.memoryInfo && ch.memoryInfo.nextReviewDue === 'Today');
        } else if (_gapFilter === 'strong') {
            result = result.filter(ch => ch.memoryInfo && ch.memoryInfo.status === 'Strong');
        } else if (_gapFilter === 'safe') {
            result = result.filter(ch => ch.riskLevel === 'safe');
        }
        // 'all' — no filter

        // Subject filter
        if (_gapSubject !== 'all') {
            result = result.filter(ch => ch.subject === _gapSubject);
        }

        // Sort: highest risk first, then lowest retention first within same risk
        const riskOrder = { critical: 0, high: 1, watch: 2, safe: 3 };
        result.sort((a, b) => {
            const ro = (riskOrder[a.riskLevel] ?? 9) - (riskOrder[b.riskLevel] ?? 9);
            if (ro !== 0) return ro;
            // Secondary sort: lowest retention first
            const retA = a.memoryInfo && a.memoryInfo.retention !== null && a.memoryInfo.retention !== undefined ? a.memoryInfo.retention : 999;
            const retB = b.memoryInfo && b.memoryInfo.retention !== null && b.memoryInfo.retention !== undefined ? b.memoryInfo.retention : 999;
            if (retA !== retB) return retA - retB;
            return b.gapScore - a.gapScore;
        });

        return result;
    }

    function filterGapAnalyzer(filterType, subject) {
        if (filterType !== undefined) _gapFilter = filterType;
        if (subject !== undefined) _gapSubject = subject;
        _renderGapAnalyzer();
    }

    function _applyGapFilterState() {
        // No-op: filter state is baked into the HTML during render
        // This function exists for future extensibility
    }

    // ════════════════════════════════════════════════════════
    //  GAP ANALYZER — Actions
    // ════════════════════════════════════════════════════════

    /**
     * Mark a specific field as done for a chapter from the Gap Analyzer.
     * Safely writes to smartPadhaiData and re-renders.
     */
    function _gapMarkField(chapterName, field) {
        let masterData = SafeStorage.getItem(MASTER_KEY, {});
        if (typeof masterData !== 'object' || masterData === null || Array.isArray(masterData)) {
            masterData = {};
        }

        const existing = masterData[chapterName];
        if (!existing || typeof existing !== 'object') {
            // Chapter not in master data — skip safely
            console.warn(`[GapAnalyzer] Chapter "${chapterName}" not found in master data`);
            return;
        }

        // Map gap field names to data field names
        const fieldMap = {
            'read': 'read',
            'notes': 'notes',
            'revised': 'revised',
            'pyq': 'pyq'
        };

        const dataField = fieldMap[field];
        if (!dataField) return;

        // Only mark if not already done
        if (existing[dataField]) return;

        masterData[chapterName] = {
            ...existing,
            [dataField]: true,
            lastUpdated: new Date().toLocaleDateString()
        };

        SafeStorage.setItem(MASTER_KEY, masterData);
        _syncToSupabase();

        // Check if this triggers mastery
        const updated = masterData[chapterName];
        const allDone = updated.read && updated.notes && updated.revised && updated.pyq;
        if (allDone) {
            const chapId = chapterName.replace(/\s+/g, '');
            const rewardId = `mastered_${chapId}_${new Date().toDateString().replace(/\s+/g, '_')}`;
            PulseEngine.addPoints(20, 'mission', { rewardId });
            _showToast(`CHAPTER MASTERED: +20 PP \uD83C\uDFC6`);
        } else {
            const fieldLabel = { read: 'Lecture', notes: 'Notes', revised: 'Revision', pyq: 'Test Practice' };
            _showToast(`${fieldLabel[dataField] || dataField} marked done for ${chapterName}`);
        }

        // Re-render Gap Analyzer
        _renderGapAnalyzer();
    }

    /**
     * Add a chapter to the Backlog (safe integration via shared localStorage).
     * Uses the same BACKLOG_TIMELINE_KEY and _scheduledFor field that BacklogRoute reads.
     */
    function _gapAddToBacklog(chapterName, subject) {
        try {
            // 1. Add to backlog timeline for tomorrow
            const tomorrow = new Date(Date.now() + 86400000);
            const tomorrowStr = tomorrow.toDateString();

            let timeline = {};
            try {
                timeline = SafeStorage.getItem(BACKLOG_TIMELINE_KEY, {});
            } catch (e) {
                timeline = {};
            }
            if (typeof timeline !== 'object' || timeline === null || Array.isArray(timeline)) {
                timeline = {};
            }
            if (!timeline[tomorrowStr]) timeline[tomorrowStr] = [];
            if (!timeline[tomorrowStr].includes(chapterName)) {
                timeline[tomorrowStr].push(chapterName);
            }
            SafeStorage.setItem(BACKLOG_TIMELINE_KEY, timeline);

            // 2. Set _scheduledFor on the chapter entry in smartPadhaiData
            let masterData = SafeStorage.getItem(MASTER_KEY, {});
            if (typeof masterData !== 'object' || masterData === null || Array.isArray(masterData)) {
                masterData = {};
            }

            if (masterData[chapterName] && typeof masterData[chapterName] === 'object') {
                masterData[chapterName] = {
                    ...masterData[chapterName],
                    _scheduledFor: tomorrowStr
                };
                SafeStorage.setItem(MASTER_KEY, masterData);
            }

            _showToast(`${chapterName} added to backlog for tomorrow`);
        } catch (err) {
            console.warn('[GapAnalyzer] Failed to add to backlog:', err);
            _showToast('Could not add to backlog. Try again.');
        }
    }

    // ════════════════════════════════════════════════════════
    //  NAVIGATION
    // ════════════════════════════════════════════════════════

    function _goBackToClass() {
        const classSelector = _container?.querySelector('#classSelector');
        const subjectSection = _container?.querySelector('#subjectSection');
        const checklistSection = _container?.querySelector('#checklistSection');

        if (classSelector) classSelector.style.display = 'flex';
        if (subjectSection) subjectSection.style.display = 'none';
        if (checklistSection) checklistSection.style.display = 'none';

        // Reset gap state
        _gapFilter = 'all';
        _gapSubject = 'all';
    }

    function _goBackToSubjects() {
        const subjectSection = _container?.querySelector('#subjectSection');
        const checklistSection = _container?.querySelector('#checklistSection');

        if (subjectSection) subjectSection.style.display = 'block';
        if (checklistSection) checklistSection.style.display = 'none';

        // Re-render Gap Analyzer in case data changed
        _renderGapAnalyzer();
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING — Delegation + AbortController
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {
        // ── CLICK DELEGATION ──
        container.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;

            switch (action) {
                case 'select-class': {
                    const classNum = parseInt(target.dataset.class);
                    if (!isNaN(classNum)) _selectClass(classNum);
                    break;
                }

                case 'show-chapters': {
                    const subject = target.dataset.subject;
                    if (subject) _showChapters(subject);
                    break;
                }

                case 'go-back-to-class':
                    _goBackToClass();
                    break;

                case 'go-back-to-subjects':
                    _goBackToSubjects();
                    break;

                case 'filter-book': {
                    // Toggle active tab and scroll to book section
                    const book = target.dataset.book;
                    if (book) {
                        // Toggle active class on book tabs
                        container.querySelectorAll('.book-tabs .back-btn').forEach(b => b.classList.remove('active'));
                        target.classList.add('active');
                        // Scroll to book title
                        const headings = container.querySelectorAll('.book-title');
                        headings.forEach(h => {
                            if (h.textContent === book) {
                                h.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            }
                        });
                    }
                    break;
                }

                // ── Gap Analyzer Filters ──
                case 'gap-filter': {
                    const filter = target.dataset.filter;
                    if (filter) filterGapAnalyzer(filter, undefined);
                    break;
                }

                case 'gap-subject-filter': {
                    const subject = target.dataset.subject;
                    if (subject !== undefined) filterGapAnalyzer(undefined, subject);
                    break;
                }

                // ── Gap Analyzer Actions ──
                case 'gap-mark-field': {
                    const chapter = target.dataset.chapter;
                    const field = target.dataset.field;
                    if (chapter && field) _gapMarkField(chapter, field);
                    break;
                }

                case 'gap-add-backlog': {
                    const chapter = target.dataset.chapter;
                    const subject = target.dataset.subject;
                    if (chapter) _gapAddToBacklog(chapter, subject);
                    break;
                }

                // ── Memory Decay Actions ──
                case 'memory-mark-reviewed': {
                    const chapter = target.dataset.chapter;
                    if (chapter) _markChapterReviewed(chapter);
                    break;
                }
            }
        }, { signal });

        // ── CHANGE DELEGATION (checkboxes) ──
        container.addEventListener('change', (e) => {
            const target = e.target;
            const action = target.dataset.action;

            if (action === 'update-progress') {
                const chapter = target.dataset.chapter;
                const field = target.dataset.field;
                if (chapter && field) {
                    _updateProgress(chapter, field, target.checked);
                }
            }
        }, { signal });
    }

    // ════════════════════════════════════════════════════════
    //  TOAST
    // ════════════════════════════════════════════════════════

    function _showToast(message) {
        const toast = _container?.querySelector('#sylToast');
        if (!toast) return;

        toast.textContent = message;
        toast.classList.add('visible');

        if (_toastTimeout) clearTimeout(_toastTimeout);
        _toastTimeout = setTimeout(() => {
            toast.classList.remove('visible');
        }, 3000);
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();

window.SyllabusRoute = SyllabusRoute;
