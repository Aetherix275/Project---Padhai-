/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — NOTEBOOKS ROUTE MODULE (Phase 6E + 7H-1..7H-5)
 *  Full SPA conversion of Notebook Matrix
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear state
 *
 *  Data: SafeStorage-first, Supabase mirror second
 *  Events: All via event delegation + AbortController. Zero inline onclick.
 *
 *  Phase 7H-1: Data Bridge + Audit
 *    - Added nb_notes_v1 storage key alongside existing notebook_matrix_data
 *    - Added _notes state, note ID generation, health score calculation
 *    - Health score: deterministic local formula (0-100), no AI/API calls
 *    - Backward compatible: notebook_matrix_data structure is NEVER changed
 *    - Dashboard/Backlog/AESTRA continue to read notebook_matrix_data as-is
 *
 *  Phase 7H-2: Hero Metrics + Health Meter
 *    - Upgraded page identity: NOTEBOOK INTELLIGENCE
 *    - Hero metrics strip: Total Subjects, Verified Rate, Pending, Avg Health
 *    - Full-width health meter with tier label
 *    - Metrics auto-update on every data mutation
 *
 *  Phase 7H-3: Matrix Table Upgrade
 *    - Added Health column per row (notes-based or matrix fallback)
 *    - Added Revision column per row (notes-based or matrix fallback)
 *    - Premium row styling: health-based left accent, type pills, improved toggles
 *    - All existing data-actions preserved exactly
 *
 *  Phase 7H-4: Note Entry CRUD
 *    - Deploy New Note button in hero area
 *    - Note modal with full field set (Title, Subject, Chapter, Content, Summary, Tags, Revision, Gold)
 *    - Create/Edit/Delete operations on nb_notes_v1.entries
 *    - Notes list section below matrix with intelligence cards
 *    - Full metrics sync after every CRUD operation
 *    - New data-actions: deploy-note, save-note, edit-note, delete-note, close-note-modal
 *
 *  Phase 7H-5: Notebook Intelligence Sections
 *    - Subject Overview: per-subject health cards with linked notes, verified/incident status
 *    - Revision Pending: overdue/pending note cards sorted by urgency + weakest health
 *    - Weak Notes: healthScore < 40 with missing-reason diagnostics
 *    - Recent Notes: upgraded to show latest 5 with health tier dot, subject/chapter, edit action
 *    - Quick Actions: Mark Reviewed, Mark Pending, Mark Overdue, Strengthen/Edit
 *    - Missing Reasons diagnostic for weak notes
 *    - Clean empty states for all sections
 *    - New data-actions: mark-note-reviewed, mark-note-pending, mark-note-overdue, strengthen-note
 *    - All existing data-actions and identifiers preserved exactly
 * ═══════════════════════════════════════════════════════════════════
 */

const NotebooksRoute = (() => {

    // ── Private state ──
    let _container = null;
    let _abortController = null;
    let _rows = [];
    let _notes = null; // Phase 7H-1: nb_notes_v1 data object { version, entries }
    let _editingNoteId = null; // Phase 7H-4: null = creating new, 'nbe_xxx' = editing existing
    let _cssLinkEl = null;

    const STORAGE_KEY = 'notebook_matrix_data'; // Phase 6E: existing matrix — NEVER restructure
    const NOTES_STORAGE_KEY = 'nb_notes_v1';    // Phase 7H-1: new notes entries — additive only
    const CSS_PATH = './styles/modules/notebooks.css';

    // ── Phase 8D-5A: SyncManager Naming Compatibility Helpers ──
    // Resolves window.SPSyncManager (actual app sync manager)
    // Falls back to window.SyncManager (legacy), then null.
    // NEVER touches Aestra Ai/syncManager.js
    function _getSyncManager() {
        return window.SPSyncManager || window.SyncManager || null;
    }

    // ── Canonical User ID Helper ── (Phase 8D-5A)
    // Priority: SyncManager → AppState → localStorage fallback
    function _getUserId() {
        const sync = _getSyncManager();
        return sync?.getUserId?.()
            || window.AppState?.currentUser?.id
            || localStorage.getItem('_current_user_id')
            || null;
    }

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════

    async function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;

        // Load CSS
        _loadCSS();

        // Load data from SafeStorage
        _rows = SafeStorage.getItem(STORAGE_KEY, [
            { id: 1, subject: 'Physics', type: 'CLASSWORK', done: false, incident: false, delta: 0 }
        ]);

        // Try loading from cloud via SyncManager (best-effort merge)
        await _loadFromCloud();

        // Phase 7H-1: Load notes data (additive, separate from matrix)
        _notes = _loadNotesData();

        // Phase 7H-1: Recalculate health scores on every load (catches stale scores)
        const healthChanged = _recalcAllHealthScores();
        if (healthChanged) {
            _saveNotesData(_notes);
        }

        // Render
        container.innerHTML = renderFullUI();
        _render();

        // Phase 7H-2: Update metrics + health meter after initial render
        _updateNotebookMetricsUI();

        // Phase 7H-5: Render all intelligence sections
        _renderIntelligenceSections();

        // Bind events
        _bindEvents(container, _abortController.signal);

        console.log('[NotebooksRoute] Initialized');
    }

    function cleanup() {
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }
        // Remove any open popups
        document.querySelectorAll('.cloud-popup').forEach(p => p.remove());
        _unloadCSS();
        _container = null;
        _rows = [];
        _notes = null; // Phase 7H-1: clear notes state
        _editingNoteId = null; // Phase 7H-4: clear edit state
        console.log('[NotebooksRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.notebooksCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-notebooks-css]');
        if (el) { el.remove(); _cssLinkEl = null; }
    }

    // ════════════════════════════════════════════════════════
    //  SYNC MANAGER SYNC (Phase 8D-5A)
    //  Uses _getSyncManager() to resolve window.SPSyncManager.
    //  Falls back to direct Supabase if SyncManager unavailable.
    //  Row mapping and conflict keys unchanged.
    // ════════════════════════════════════════════════════════

    /**
     * Load notebook data from cloud via SyncManager.
     * Falls back to direct Supabase query if SyncManager unavailable.
     * Conservative merge: cloud-only rows added, local rows never overwritten.
     */
    async function _loadFromCloud() {
        // ── Try SyncManager first (Phase 8D-5A: via _getSyncManager) ──
        const sync = _getSyncManager();
        if (sync && typeof sync.loadFromCloud === 'function') {
            try {
                const rows = await sync.loadFromCloud('notebooks', {
                    columns: '*',
                    statusKey: 'notebooks'
                });
                if (rows && rows.length > 0) {
                    _mergeCloudRows(rows);
                    return;
                }
                return; // No rows — nothing to merge
            } catch (err) {
                console.warn('[NotebooksRoute] SyncManager load failed, trying fallback:', err);
            }
        }

        // ── Fallback: direct Supabase query (legacy path) ──
        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) {
            console.warn('[NotebooksRoute] Supabase load skipped — no userId available');
            return;
        }

        try {
            const { data, error } = await window.supabaseClient
                .from('notebooks')
                .select('*')
                .eq('user_id', userId);

            if (error || !data || data.length === 0) return;

            _mergeCloudRows(data);
        } catch (err) {
            console.warn('[NotebooksRoute] Fallback Supabase load failed:', err);
        }
    }

    /**
     * Merge cloud rows into local notebook_matrix_data.
     * Conservative: cloud-only rows added, existing local rows never overwritten.
     * @param {array} rows - Rows from notebooks table
     */
    function _mergeCloudRows(rows) {
        const local = SafeStorage.getItem(STORAGE_KEY, []);
        let merged = false;

        rows.forEach(row => {
            const raw = (row.raw_data && typeof row.raw_data === 'object') ? row.raw_data : {};
            const rawId = raw.id;
            const sourceId = row.source_key ? String(row.source_key).replace(/^nb_/, '') : rawId;
            const id = Number(sourceId);
            if (!id) return;

            const existing = local.find(r => Number(r.id) === id);
            if (!existing) {
                local.push({
                    id,
                    subject: row.subject || raw.subject || '',
                    type: row.notebook_type || raw.type || 'CLASSWORK',
                    done: row.completed === true || raw.done === true,
                    incident: raw.incident === true,
                    delta: Number(row.delta_pages ?? raw.delta ?? 0)
                });
                merged = true;
            }
        });

        if (merged) {
            SafeStorage.setItem(STORAGE_KEY, local);
            _rows = local;
            console.log(`[NotebooksRoute] Merged ${rows.length} cloud rows. Local rows: ${local.length}`);
        }
    }

    /**
     * Build a row for the notebooks table from a local notebook entry.
     * Row mapping unchanged from previous implementation.
     * SyncManager injects user_id automatically on enqueue.
     * @param {object} row - Local notebook row from _rows
     * @returns {object} Row object for Supabase upsert
     */
    function _buildNotebookRow(row) {
        if (!row || typeof row !== 'object') return null;

        const deltaPages = Number(row.delta || 0);
        const notebookType = row.type || 'CLASSWORK';
        const subject = row.subject || '';

        return {
            source_key: `nb_${row.id}`,
            subject: subject,
            notebook_type: notebookType,
            title: subject,
            completed: !!row.done,
            delta_pages: deltaPages,
            raw_data: {
                id: row.id,
                subject: subject,
                type: notebookType,
                done: !!row.done,
                incident: !!row.incident,
                delta: deltaPages
            },
            last_updated: new Date().toISOString(),
            user_key: _getUserId() || ''
        };
    }

    /**
     * Enqueue all notebook rows for upsert via SyncManager.
     * Falls back to direct Supabase upsert if SyncManager unavailable/rejected.
     * Row mapping and conflict keys unchanged.
     */
    function _enqueueAllRowsUpsert() {
        const sync = _getSyncManager();

        if (sync && typeof sync.enqueue === 'function') {
            for (const row of _rows) {
                const supabaseRow = _buildNotebookRow(row);
                if (!supabaseRow) continue;
                sync.enqueue('notebooks', supabaseRow, {
                    conflictKey: 'user_id,source_key',
                    statusKey: 'notebooks'
                });
            }
            console.log('[NotebooksRoute] Enqueued rows via SyncManager');
            return;
        }

        // Fallback: direct Supabase upsert using ONLY real notebooks table columns.
        if (!window.supabaseClient) {
            console.warn('[NotebooksRoute] No SyncManager and no Supabase client — sync skipped');
            return;
        }

        const userId = _getUserId();
        if (!userId) {
            console.warn('[NotebooksRoute] Upsert skipped — no userId');
            return;
        }

        for (const row of _rows) {
            const supabaseRow = _buildNotebookRow(row);
            if (!supabaseRow) continue;

            window.supabaseClient
                .from('notebooks')
                .upsert({ ...supabaseRow, user_id: userId }, { onConflict: 'user_id,source_key' })
                .then(function (result) {
                    if (result.error) {
                        console.warn('[NotebooksRoute] Direct upsert failed:', result.error.message);
                    }
                })
                .catch(function (err) {
                    console.warn('[NotebooksRoute] Direct upsert error:', err);
                });
        }
        console.log('[NotebooksRoute] Direct upsert queued for', _rows.length, 'rows');
    }

    // ════════════════════════════════════════════════════════
    //  DATA OPERATIONS
    // ════════════════════════════════════════════════════════

    function _save() {
        SafeStorage.setItem(STORAGE_KEY, _rows);
        _enqueueAllRowsUpsert(); // Phase 8D-5A: via SyncManager
    }

    /**
     * _fullSync — single function to re-render matrix, metrics, and all sections
     * Called after any mutation that changes note data or matrix state
     */
    function _fullSync() {
        _render();
        _updateNotebookMetricsUI();
        _renderIntelligenceSections();
    }

    function _updateRow(index, field, value) {
        _rows[index][field] = value;
        _save();
        _recalcAllHealthScores();
        _saveNotesData(_notes);
        _fullSync();
    }

    function _toggleDone(index) {
        const item = _rows[index];
        item.done = !item.done;
        if (item.done) {
            item.incident = false;
            item.delta = 0;
        }
        _save();
        _fullSync();
    }

    function _showPopup(index) {
        document.querySelectorAll('.cloud-popup').forEach(p => p.remove());

        const cell = _container.querySelector(`#inc-cell-${index}`);
        if (!cell) return;

        const popup = document.createElement('div');
        popup.className = 'cloud-popup';
        popup.innerHTML = `
            <h4>REPORT DELTA PAGES</h4>
            <input type="number" id="delta-input-${index}" placeholder="0" value="${_rows[index].delta || ''}">
            <button data-action="apply-incident" data-index="${index}">TRANSMIT</button>
        `;
        cell.appendChild(popup);

        const input = popup.querySelector(`#delta-input-${index}`);
        if (input) input.focus();
    }

    function _applyIncident(index) {
        const input = _container.querySelector(`#delta-input-${index}`);
        if (!input) return;

        const val = parseInt(input.value) || 0;
        const subjectName = _rows[index].subject || 'Untitled Subject';

        if (val > 0) {
            _rows[index].incident = true;
            _rows[index].done = false;
            _rows[index].delta = val;
            _save();

            // Backlog connection
            try {
                let masterData = SafeStorage.getItem('smartPadhaiData', {});
                const entryName = `${subjectName} (Δ ${val} PG)`;
                masterData[entryName] = {
                    read: false,
                    notes: true,
                    pyq: true,
                    lastUpdated: new Date().toDateString()
                };
                SafeStorage.setItem('smartPadhaiData', masterData);
            } catch (err) {
                console.warn('[NotebooksRoute] Backlog sync error:', err);
            }

            _fullSync();
        } else {
            _showToast('Enter Delta Pages first!');
        }
    }

    function _addNewRow() {
        const newId = _rows.length > 0 ? Math.max(..._rows.map(r => r.id)) + 1 : 1;
        _rows.push({ id: newId, subject: '', type: 'CLASSWORK', done: false, incident: false, delta: 0 });
        _save();
        _fullSync();

        // Auto-focus new input
        setTimeout(() => {
            const inputs = _container.querySelectorAll('.subject-input');
            if (inputs.length > 0) inputs[inputs.length - 1].focus();
        }, 100);
    }

    // ════════════════════════════════════════════════════════
    //  NOTES DATA BRIDGE (Phase 7H-1)
    //  Separate storage key: nb_notes_v1
    //  Additive only — never touches notebook_matrix_data
    // ════════════════════════════════════════════════════════

    function generateNoteId() {
        return 'nbe_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
    }

    function _createEmptyNotesData() {
        return { version: 1, entries: [] };
    }

    function _loadNotesData() {
        try {
            const existing = SafeStorage.getItem(NOTES_STORAGE_KEY, null);
            if (existing && existing.version === 1 && Array.isArray(existing.entries)) {
                return existing;
            }
            const fresh = _createEmptyNotesData();
            SafeStorage.setItem(NOTES_STORAGE_KEY, fresh);
            console.log('[NotebooksRoute] Created fresh nb_notes_v1');
            return fresh;
        } catch (err) {
            console.warn('[NotebooksRoute] Notes data load failed, creating fresh:', err);
            const fresh = _createEmptyNotesData();
            try { SafeStorage.setItem(NOTES_STORAGE_KEY, fresh); } catch (e) { /* ignore */ }
            return fresh;
        }
    }

    function _saveNotesData(data) {
        try {
            SafeStorage.setItem(NOTES_STORAGE_KEY, data);
        } catch (err) {
            console.warn('[NotebooksRoute] Notes data save failed:', err);
        }
    }

    // ── Formula/Example detection keywords ──
    const _FORMULA_KEYWORDS = ['=', 'formula', 'equation', 'eq.', 'eq:', '∴', '→', '×', '÷', '±', '≈', '≠', '≤', '≥', '∝', '∑', '∫', 'π', 'θ', 'α', 'β', 'γ', 'Δ', '√'];
    const _EXAMPLE_KEYWORDS = ['example', 'ex:', 'ex.', 'e.g.', 'eg:', 'sample', 'illustration', 'demo', 'for instance', 'such as', 'like:'];

    function _calculateHealthScore(entry) {
        if (!entry) return 0;
        let score = 0;

        if (entry.title && entry.title.trim().length > 0) score += 15;

        const contentLen = (entry.content && typeof entry.content === 'string') ? entry.content.trim().length : 0;
        if (contentLen >= 200) score += 25;
        else if (contentLen >= 50) score += 15;
        else if (contentLen > 0) score += 5;

        if (entry.summary && entry.summary.trim().length > 0) score += 15;

        if (entry.content && typeof entry.content === 'string') {
            const lowerContent = entry.content.toLowerCase();
            if (_FORMULA_KEYWORDS.some(kw => lowerContent.includes(kw.toLowerCase()))) score += 8;
            if (_EXAMPLE_KEYWORDS.some(kw => lowerContent.includes(kw.toLowerCase()))) score += 7;
        }

        if (entry.lastReviewedAt) {
            try {
                const reviewedDate = new Date(entry.lastReviewedAt);
                const daysSinceReview = (Date.now() - reviewedDate.getTime()) / (1000 * 60 * 60 * 24);
                if (daysSinceReview <= 7) score += 15;
            } catch (e) { /* invalid date */ }
        }

        if (entry.subject && entry.subject.trim().length > 0) {
            if (_rows.some(r => r.subject && r.subject.trim().toLowerCase() === entry.subject.trim().toLowerCase())) {
                score += 10;
            }
        }

        if (entry.revisionStatus !== 'overdue') score += 5;

        return Math.min(100, Math.max(0, score));
    }

    function _recalcAllHealthScores() {
        if (!_notes || !Array.isArray(_notes.entries)) return false;
        let changed = false;
        _notes.entries.forEach(entry => {
            const newScore = _calculateHealthScore(entry);
            if (newScore !== entry.healthScore) {
                entry.healthScore = newScore;
                changed = true;
            }
        });
        return changed;
    }

    function _getHealthTier(score) {
        if (score >= 80) return { tier: 'strong',   label: 'COMBAT READY',       color: '#00ff9d' };
        if (score >= 60) return { tier: 'adequate', label: 'NEEDS POLISH',       color: '#00d4ff' };
        if (score >= 40) return { tier: 'weak',     label: 'UNDER-ARMED',        color: '#f59e0b' };
        return               { tier: 'critical', label: 'REQUIRES DEPLOYMENT', color: '#FF4C4C' };
    }

    // ════════════════════════════════════════════════════════
    //  PER-ROW HEALTH + REVISION (Phase 7H-3)
    // ════════════════════════════════════════════════════════

    function _getLinkedNotesForSubject(subjectName) {
        if (!_notes || !Array.isArray(_notes.entries) || !subjectName || !subjectName.trim()) return [];
        const lowerName = subjectName.trim().toLowerCase();
        return _notes.entries.filter(e => e.subject && e.subject.trim().toLowerCase() === lowerName);
    }

    function _getRowHealth(row) {
        const linkedNotes = _getLinkedNotesForSubject(row.subject);
        if (linkedNotes.length > 0) {
            const sum = linkedNotes.reduce((acc, e) => acc + (e.healthScore || 0), 0);
            const avgScore = Math.round(sum / linkedNotes.length);
            return { score: avgScore, tier: _getHealthTier(avgScore), hasIntel: true };
        }
        if (!row.subject || !row.subject.trim()) return { score: null, tier: null, hasIntel: false };
        let fallbackScore = 50;
        if (row.done) fallbackScore = 75;
        else if (row.incident) fallbackScore = Math.max(15, 35 - (row.delta || 0) * 2);
        return { score: fallbackScore, tier: _getHealthTier(fallbackScore), hasIntel: true };
    }

    function _getRowRevision(row) {
        const linkedNotes = _getLinkedNotesForSubject(row.subject);
        if (linkedNotes.length > 0) {
            const hasOverdue = linkedNotes.some(e => e.revisionStatus === 'overdue');
            const hasPending = linkedNotes.some(e => e.revisionStatus === 'pending');
            if (hasOverdue) return { status: 'OVERDUE',   cssClass: 'rev-overdue',   color: '#FF4C4C' };
            if (hasPending) return { status: 'PENDING',    cssClass: 'rev-pending',   color: '#f59e0b' };
            return { status: 'ON TRACK', cssClass: 'rev-ontrack', color: '#00ff9d' };
        }
        if (!row.subject || !row.subject.trim()) return { status: 'NO INTEL', cssClass: 'rev-nointel', color: '#444' };
        if (row.incident) return { status: 'PENDING',    cssClass: 'rev-pending',   color: '#f59e0b' };
        if (row.done) return { status: 'ON TRACK', cssClass: 'rev-ontrack', color: '#00ff9d' };
        return { status: 'PENDING', cssClass: 'rev-pending', color: '#f59e0b' };
    }

    // ════════════════════════════════════════════════════════
    //  NOTEBOOK METRICS (Phase 7H-2)
    // ════════════════════════════════════════════════════════

    function _computeNotebookMetrics() {
        const totalSubjects = _rows.length;
        const verifiedCount = _rows.filter(r => r.done).length;
        const incidentCount = _rows.filter(r => r.incident).length;
        const verifiedRate = totalSubjects > 0 ? Math.round((verifiedCount / totalSubjects) * 100) : 0;

        let avgHealth = null;
        let healthTier = null;

        if (_notes && Array.isArray(_notes.entries) && _notes.entries.length > 0) {
            const sum = _notes.entries.reduce((acc, e) => acc + (e.healthScore || 0), 0);
            avgHealth = Math.round(sum / _notes.entries.length);
        } else if (totalSubjects > 0) {
            let fallbackSum = 0;
            _rows.forEach(r => {
                if (r.done) fallbackSum += 75;
                else if (r.incident) fallbackSum += 25;
                else fallbackSum += 50;
            });
            avgHealth = Math.round(fallbackSum / totalSubjects);
        }

        if (avgHealth !== null) healthTier = _getHealthTier(avgHealth);

        return { totalSubjects, verifiedRate, incidentCount, avgHealth, healthTier };
    }

    function _updateNotebookMetricsUI() {
        if (!_container) return;
        const m = _computeNotebookMetrics();

        const totalEl = _container.querySelector('#nb-metric-total');
        if (totalEl) totalEl.textContent = m.totalSubjects;

        const verifiedEl = _container.querySelector('#nb-metric-verified');
        if (verifiedEl) verifiedEl.textContent = m.verifiedRate + '%';

        const incidentEl = _container.querySelector('#nb-metric-incident');
        if (incidentEl) incidentEl.textContent = m.incidentCount;

        const healthEl = _container.querySelector('#nb-metric-health');
        if (healthEl) healthEl.textContent = m.avgHealth !== null ? m.avgHealth : 'N/A';

        const verifiedCard = _container.querySelector('#nb-card-verified');
        if (verifiedCard) {
            verifiedCard.classList.remove('metric-accent-green', 'metric-accent-yellow', 'metric-accent-red');
            if (m.totalSubjects === 0) verifiedCard.classList.add('metric-accent-yellow');
            else if (m.verifiedRate >= 50) verifiedCard.classList.add('metric-accent-green');
            else if (m.verifiedRate >= 25) verifiedCard.classList.add('metric-accent-yellow');
            else verifiedCard.classList.add('metric-accent-red');
        }

        const incidentCard = _container.querySelector('#nb-card-incident');
        if (incidentCard) {
            incidentCard.classList.remove('metric-accent-green', 'metric-accent-red');
            incidentCard.classList.add(m.incidentCount === 0 ? 'metric-accent-green' : 'metric-accent-red');
        }

        const healthCard = _container.querySelector('#nb-card-health');
        if (healthCard) {
            healthCard.classList.remove('metric-accent-green', 'metric-accent-cyan', 'metric-accent-yellow', 'metric-accent-red');
            if (m.avgHealth === null) healthCard.classList.add('metric-accent-yellow');
            else if (m.avgHealth >= 80) healthCard.classList.add('metric-accent-green');
            else if (m.avgHealth >= 60) healthCard.classList.add('metric-accent-cyan');
            else if (m.avgHealth >= 40) healthCard.classList.add('metric-accent-yellow');
            else healthCard.classList.add('metric-accent-red');
        }

        const meterFill = _container.querySelector('#nb-health-fill');
        const meterScore = _container.querySelector('#nb-health-score-text');
        const meterTier = _container.querySelector('#nb-health-tier');
        const meterBar = _container.querySelector('#nb-health-bar');

        if (m.avgHealth !== null && m.healthTier) {
            if (meterFill) { meterFill.style.width = m.avgHealth + '%'; meterFill.style.background = `linear-gradient(90deg, ${m.healthTier.color}, ${m.healthTier.color}88)`; meterFill.style.boxShadow = `0 0 20px ${m.healthTier.color}55`; }
            if (meterScore) { meterScore.textContent = m.avgHealth; meterScore.style.color = m.healthTier.color; }
            if (meterTier) { meterTier.textContent = m.healthTier.label; meterTier.style.color = m.healthTier.color; meterTier.classList.remove('tier-strong', 'tier-adequate', 'tier-weak', 'tier-critical'); meterTier.classList.add('tier-' + m.healthTier.tier); }
            if (meterBar) { meterBar.style.borderColor = m.healthTier.color + '33'; }
        } else {
            if (meterFill) meterFill.style.width = '0%';
            if (meterScore) { meterScore.textContent = '--'; meterScore.style.color = '#555'; }
            if (meterTier) { meterTier.textContent = 'AWAITING DATA'; meterTier.style.color = '#555'; meterTier.classList.remove('tier-strong', 'tier-adequate', 'tier-weak', 'tier-critical'); }
        }
    }

    // ════════════════════════════════════════════════════════
    //  NOTE ENTRY CRUD (Phase 7H-4)
    // ════════════════════════════════════════════════════════

    function _openNoteModal(noteId) {
        const modal = _container?.querySelector('#nbNoteModal');
        if (!modal) return;

        _editingNoteId = noteId || null;

        const titleEl = _container.querySelector('#nbModalTitle');
        const saveBtnEl = _container.querySelector('#nbBtnSave');
        const editIdEl = _container.querySelector('#nbEditNoteId');

        _populateSubjectSelect();

        if (_editingNoteId) {
            const entry = _notes.entries.find(e => e.id === _editingNoteId);
            if (!entry) { _showToast('Note not found!'); return; }

            if (titleEl) titleEl.textContent = 'EDIT NOTE INTEL';
            if (saveBtnEl) saveBtnEl.textContent = 'UPDATE NOTE';
            if (editIdEl) editIdEl.value = _editingNoteId;

            const f = (id) => _container.querySelector('#' + id);
            if (f('nbNoteTitle')) f('nbNoteTitle').value = entry.title || '';
            if (f('nbNoteSubject')) f('nbNoteSubject').value = entry.subjectRowId || '';
            if (f('nbNoteChapter')) f('nbNoteChapter').value = entry.chapter || '';
            if (f('nbNoteContent')) f('nbNoteContent').value = entry.content || '';
            if (f('nbNoteSummary')) f('nbNoteSummary').value = entry.summary || '';
            if (f('nbNoteTags')) f('nbNoteTags').value = (entry.tags || []).join(', ');
            if (f('nbNoteRevision')) f('nbNoteRevision').value = entry.revisionStatus || 'none';
            if (f('nbNoteGold')) f('nbNoteGold').checked = entry.isGold || false;
        } else {
            if (titleEl) titleEl.textContent = 'DEPLOY NEW NOTE';
            if (saveBtnEl) saveBtnEl.textContent = 'DEPLOY NOTE';
            if (editIdEl) editIdEl.value = '';

            ['nbNoteTitle', 'nbNoteChapter', 'nbNoteContent', 'nbNoteSummary', 'nbNoteTags'].forEach(id => {
                const el = _container.querySelector('#' + id);
                if (el) el.value = '';
            });

            const subjectInput = _container.querySelector('#nbNoteSubject');
            if (subjectInput) subjectInput.value = '';
            const revisionInput = _container.querySelector('#nbNoteRevision');
            if (revisionInput) revisionInput.value = 'none';
            const goldInput = _container.querySelector('#nbNoteGold');
            if (goldInput) goldInput.checked = false;
        }

        modal.style.display = 'flex';
        setTimeout(() => { const t = _container?.querySelector('#nbNoteTitle'); if (t) t.focus(); }, 120);
    }

    function _closeNoteModal() {
        const modal = _container?.querySelector('#nbNoteModal');
        if (modal) modal.style.display = 'none';
        _editingNoteId = null;
    }

    function _populateSubjectSelect() {
        const select = _container?.querySelector('#nbNoteSubject');
        if (!select) return;
        select.innerHTML = '<option value="">— Select Subject —</option>';
        _rows.forEach(row => {
            if (row.subject && row.subject.trim()) {
                const opt = document.createElement('option');
                opt.value = row.id;
                opt.textContent = row.subject;
                select.appendChild(opt);
            }
        });
    }

    function _saveNote() {
        if (!_notes || !Array.isArray(_notes.entries)) return;

        const title = (_container.querySelector('#nbNoteTitle')?.value || '').trim();
        const subjectRowIdStr = _container.querySelector('#nbNoteSubject')?.value || '';
        const chapter = (_container.querySelector('#nbNoteChapter')?.value || '').trim();
        const content = _container.querySelector('#nbNoteContent')?.value || '';
        const summary = (_container.querySelector('#nbNoteSummary')?.value || '').trim();
        const tagsStr = (_container.querySelector('#nbNoteTags')?.value || '').trim();
        const revisionStatus = _container.querySelector('#nbNoteRevision')?.value || 'none';
        const isGold = _container.querySelector('#nbNoteGold')?.checked || false;

        if (!title) { _showToast('Title is required!'); _container.querySelector('#nbNoteTitle')?.focus(); return; }

        const tags = tagsStr ? tagsStr.split(',').map(t => t.trim()).filter(t => t.length > 0) : [];
        const subjectRowId = subjectRowIdStr ? parseInt(subjectRowIdStr) : null;
        const subjectRow = subjectRowId ? _rows.find(r => r.id === subjectRowId) : null;
        const subjectName = subjectRow ? subjectRow.subject : '';

        const lowerContent = content.toLowerCase();
        const hasFormulas = _FORMULA_KEYWORDS.some(kw => lowerContent.includes(kw.toLowerCase()));
        const hasExamples = _EXAMPLE_KEYWORDS.some(kw => lowerContent.includes(kw.toLowerCase()));

        if (_editingNoteId) {
            const entry = _notes.entries.find(e => e.id === _editingNoteId);
            if (!entry) { _showToast('Note not found!'); return; }

            entry.title = title;
            entry.subjectRowId = subjectRowId;
            entry.subject = subjectName;
            entry.chapter = chapter;
            entry.content = content;
            entry.summary = summary;
            entry.tags = tags;
            entry.revisionStatus = revisionStatus;
            entry.isGold = isGold;
            entry.hasFormulas = hasFormulas;
            entry.hasExamples = hasExamples;
            entry.type = subjectRow ? subjectRow.type : (entry.type || 'CLASSWORK');
            entry.updatedAt = new Date().toISOString();
            entry.healthScore = _calculateHealthScore(entry);

            _saveNotesData(_notes);
            _closeNoteModal();
            _fullSync();
            _showToast('Note intel updated!');
        } else {
            const newEntry = {
                id: generateNoteId(),
                subjectRowId: subjectRowId,
                title: title,
                subject: subjectName,
                chapter: chapter,
                content: content,
                summary: summary,
                tags: tags,
                type: subjectRow ? subjectRow.type : 'CLASSWORK',
                healthScore: 0,
                revisionStatus: revisionStatus,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
                lastReviewedAt: null,
                isGold: isGold,
                hasFormulas: hasFormulas,
                hasExamples: hasExamples
            };

            newEntry.healthScore = _calculateHealthScore(newEntry);
            _notes.entries.push(newEntry);
            _saveNotesData(_notes);
            _closeNoteModal();
            _fullSync();
            _showToast('Note deployed!');
        }
    }

    function _deleteNote(noteId) {
        if (!noteId || !_notes || !Array.isArray(_notes.entries)) return;
        if (!confirm('Delete this note? This action cannot be undone.')) return;

        const idx = _notes.entries.findIndex(e => e.id === noteId);
        if (idx === -1) { _showToast('Note not found!'); return; }

        _notes.entries.splice(idx, 1);
        _saveNotesData(_notes);
        if (_editingNoteId === noteId) _closeNoteModal();
        _fullSync();
        _showToast('Note deleted.');
    }

    // ════════════════════════════════════════════════════════
    //  QUICK ACTIONS (Phase 7H-5)
    //  Mark Reviewed / Pending / Overdue / Strengthen
    // ════════════════════════════════════════════════════════

    function _markNoteReviewed(noteId) {
        const entry = _notes?.entries?.find(e => e.id === noteId);
        if (!entry) return;
        entry.lastReviewedAt = new Date().toISOString();
        entry.revisionStatus = 'none';
        entry.updatedAt = new Date().toISOString();
        entry.healthScore = _calculateHealthScore(entry);
        _saveNotesData(_notes);
        _fullSync();
        _showToast('Marked as reviewed!');
    }

    function _markNotePending(noteId) {
        const entry = _notes?.entries?.find(e => e.id === noteId);
        if (!entry) return;
        entry.revisionStatus = 'pending';
        entry.updatedAt = new Date().toISOString();
        entry.healthScore = _calculateHealthScore(entry);
        _saveNotesData(_notes);
        _fullSync();
        _showToast('Marked as pending.');
    }

    function _markNoteOverdue(noteId) {
        const entry = _notes?.entries?.find(e => e.id === noteId);
        if (!entry) return;
        entry.revisionStatus = 'overdue';
        entry.updatedAt = new Date().toISOString();
        entry.healthScore = _calculateHealthScore(entry);
        _saveNotesData(_notes);
        _fullSync();
        _showToast('Marked as overdue.');
    }

    // ════════════════════════════════════════════════════════
    //  MISSING REASONS DIAGNOSTIC (Phase 7H-5)
    //  Returns array of reason strings for why a note is weak
    // ════════════════════════════════════════════════════════

    function _getMissingReasons(entry) {
        if (!entry) return [];
        const reasons = [];

        // No summary
        if (!entry.summary || !entry.summary.trim()) {
            reasons.push('No summary');
        }

        // Content too short
        const contentLen = (entry.content && typeof entry.content === 'string') ? entry.content.trim().length : 0;
        if (contentLen < 50) {
            reasons.push('Content too short');
        }

        // No formulas
        if (!entry.hasFormulas) {
            const hasFormula = entry.content && typeof entry.content === 'string' &&
                _FORMULA_KEYWORDS.some(kw => entry.content.toLowerCase().includes(kw.toLowerCase()));
            if (!hasFormula) reasons.push('No formulas');
        }

        // No examples
        if (!entry.hasExamples) {
            const hasExample = entry.content && typeof entry.content === 'string' &&
                _EXAMPLE_KEYWORDS.some(kw => entry.content.toLowerCase().includes(kw.toLowerCase()));
            if (!hasExample) reasons.push('No examples');
        }

        // Not reviewed
        if (!entry.lastReviewedAt) {
            reasons.push('Not reviewed');
        } else {
            try {
                const daysSinceReview = (Date.now() - new Date(entry.lastReviewedAt).getTime()) / (1000 * 60 * 60 * 24);
                if (daysSinceReview > 7) reasons.push('Not reviewed recently');
            } catch (e) { reasons.push('Not reviewed'); }
        }

        // No subject link
        if (!entry.subject || !entry.subject.trim()) {
            reasons.push('No subject link');
        } else {
            const linked = _rows.some(r => r.subject && r.subject.trim().toLowerCase() === entry.subject.trim().toLowerCase());
            if (!linked) reasons.push('Subject not in matrix');
        }

        return reasons;
    }

    // ════════════════════════════════════════════════════════
    //  INTELLIGENCE SECTIONS RENDERING (Phase 7H-5)
    // ════════════════════════════════════════════════════════

    /**
     * _renderIntelligenceSections — master render for all intelligence sections
     */
    function _renderIntelligenceSections() {
        _renderSubjectOverview();
        _renderRevisionPending();
        _renderWeakNotes();
        _renderRecentNotes();
    }

    /**
     * _renderSubjectOverview — per-subject health cards
     */
    function _renderSubjectOverview() {
        const grid = _container?.querySelector('#nbSubjectGrid');
        if (!grid) return;

        if (_rows.length === 0) {
            grid.innerHTML = `<div class="nb-empty-state sp-empty-state"><span class="sp-empty-state-icon">📓</span><h3 class="sp-empty-state-title">No Notebooks Tracked</h3><p class="sp-empty-state-text">Add a subject notebook to begin intelligence tracking.</p></div>`;
            return;
        }

        grid.innerHTML = _rows.map(row => {
            const linked = _getLinkedNotesForSubject(row.subject);
            const health = _getRowHealth(row);
            const subjectName = row.subject && row.subject.trim() ? _escHtml(row.subject) : 'Unnamed';

            if (!row.subject || !row.subject.trim()) {
                return `
                <div class="nb-subject-card nb-subject-empty">
                    <div class="nb-subject-name">${subjectName}</div>
                    <div class="nb-subject-no-intel">NO INTEL</div>
                </div>`;
            }

            const noteCount = linked.length;
            const avgHealth = health.hasIntel && health.score !== null ? health.score : null;
            const tier = health.tier;
            const verifiedBadge = row.done ? '<span class="nb-subject-verified">VERIFIED</span>' : '';
            const incidentBadge = row.incident ? '<span class="nb-subject-incident">INCIDENT</span>' : '';

            let healthBarHTML = '';
            if (avgHealth !== null && tier) {
                healthBarHTML = `
                    <div class="nb-subject-health">
                        <div class="nb-subject-health-bar">
                            <div class="nb-subject-health-fill" style="width:${avgHealth}%; background:${tier.color};"></div>
                        </div>
                        <span class="nb-subject-health-score" style="color:${tier.color};">${avgHealth}</span>
                    </div>`;
            } else {
                healthBarHTML = `<div class="nb-subject-health"><span class="nb-subject-no-notes">NO NOTES</span></div>`;
            }

            return `
            <div class="nb-subject-card">
                <div class="nb-subject-header">
                    <span class="nb-subject-name">${subjectName}</span>
                    <div class="nb-subject-badges">
                        ${verifiedBadge}${incidentBadge}
                    </div>
                </div>
                <div class="nb-subject-meta">
                    <span class="nb-subject-note-count">${noteCount} note${noteCount !== 1 ? 's' : ''}</span>
                    <span class="nb-subject-type">${row.type || 'CLASSWORK'}</span>
                </div>
                ${healthBarHTML}
            </div>`;
        }).join('');
    }

    /**
     * _renderRevisionPending — overdue + pending notes, sorted by urgency then weakest health
     */
    function _renderRevisionPending() {
        const grid = _container?.querySelector('#nbRevisionGrid');
        const countEl = _container?.querySelector('#nbRevisionCount');
        if (!grid) return;

        const entries = _notes?.entries || [];
        const pending = entries.filter(e => e.revisionStatus === 'overdue' || e.revisionStatus === 'pending');

        if (countEl) countEl.textContent = pending.length;

        if (pending.length === 0) {
            grid.innerHTML = `<div class="nb-empty-state sp-empty-state"><span class="sp-empty-state-icon">✅</span><h3 class="sp-empty-state-title">All Notes On Track</h3><p class="sp-empty-state-text">No revision pending. Everything is combat-ready.</p></div>`;
            return;
        }

        // Sort: overdue first, then weakest health first
        const sorted = [...pending].sort((a, b) => {
            if (a.revisionStatus === 'overdue' && b.revisionStatus !== 'overdue') return -1;
            if (a.revisionStatus !== 'overdue' && b.revisionStatus === 'overdue') return 1;
            return (a.healthScore || 0) - (b.healthScore || 0);
        });

        grid.innerHTML = sorted.map(entry => {
            const tier = _getHealthTier(entry.healthScore || 0);
            const revClass = entry.revisionStatus === 'overdue' ? 'rev-overdue' : 'rev-pending';
            const revLabel = entry.revisionStatus === 'overdue' ? 'OVERDUE' : 'PENDING';
            const timeAgo = _formatTimeAgo(entry.updatedAt);
            const reviewedInfo = entry.lastReviewedAt ? `Reviewed ${_formatTimeAgo(entry.lastReviewedAt)}` : 'Never reviewed';

            return `
            <div class="nb-intel-card">
                <div class="nb-intel-card-top">
                    <span class="nb-intel-card-title">${_escHtml(entry.title || 'Untitled')}</span>
                    <span class="revision-badge ${revClass}">${revLabel}</span>
                </div>
                <div class="nb-intel-card-meta">
                    <span class="nb-intel-card-subject">${_escHtml(entry.subject || 'No Subject')}</span>
                    ${entry.chapter ? `<span class="nb-intel-card-chapter">${_escHtml(entry.chapter)}</span>` : ''}
                </div>
                <div class="nb-intel-card-stats">
                    <span class="nb-intel-card-health" style="color:${tier.color};">${entry.healthScore || 0} ${tier.label}</span>
                    <span class="nb-intel-card-time">${reviewedInfo}</span>
                </div>
                <div class="nb-intel-card-actions">
                    <button class="nb-quick-btn nb-quick-reviewed" data-action="mark-note-reviewed" data-note-id="${entry.id}">MARK REVIEWED</button>
                    <button class="nb-quick-btn nb-quick-edit" data-action="edit-note" data-note-id="${entry.id}">EDIT</button>
                </div>
            </div>`;
        }).join('');
    }

    /**
     * _renderWeakNotes — health < 40 with missing reason diagnostics
     */
    function _renderWeakNotes() {
        const grid = _container?.querySelector('#nbWeakGrid');
        const countEl = _container?.querySelector('#nbWeakCount');
        if (!grid) return;

        const entries = _notes?.entries || [];
        const weak = entries.filter(e => (e.healthScore || 0) < 40);

        if (countEl) countEl.textContent = weak.length;

        if (weak.length === 0) {
            grid.innerHTML = `<div class="nb-empty-state sp-empty-state"><span class="sp-empty-state-icon">💪</span><h3 class="sp-empty-state-title">No Weak Notes</h3><p class="sp-empty-state-text">All notes are combat-ready or adequate. Stay sharp.</p></div>`;
            return;
        }

        // Sort by weakest first
        const sorted = [...weak].sort((a, b) => (a.healthScore || 0) - (b.healthScore || 0));

        grid.innerHTML = sorted.map(entry => {
            const tier = _getHealthTier(entry.healthScore || 0);
            const reasons = _getMissingReasons(entry);
            const reasonsHTML = reasons.length > 0
                ? `<div class="nb-missing-reasons">${reasons.map(r => `<span class="nb-missing-tag">${r}</span>`).join('')}</div>`
                : '';

            return `
            <div class="nb-intel-card nb-weak-card">
                <div class="nb-intel-card-top">
                    <span class="nb-intel-card-title">${_escHtml(entry.title || 'Untitled')}</span>
                    <span class="nb-intel-card-health" style="color:${tier.color};">${entry.healthScore || 0}</span>
                </div>
                <div class="nb-intel-card-meta">
                    <span class="nb-intel-card-subject">${_escHtml(entry.subject || 'No Subject')}</span>
                </div>
                <div class="nb-intel-card-tier" style="color:${tier.color};">${tier.label}</div>
                ${reasonsHTML}
                <div class="nb-intel-card-actions">
                    <button class="nb-quick-btn nb-quick-strengthen" data-action="strengthen-note" data-note-id="${entry.id}">STRENGTHEN</button>
                    <button class="nb-quick-btn nb-quick-edit" data-action="edit-note" data-note-id="${entry.id}">EDIT</button>
                </div>
            </div>`;
        }).join('');
    }

    /**
     * _renderRecentNotes — latest 5 notes with health tier dot, subject/chapter, edit
     */
    function _renderRecentNotes() {
        const grid = _container?.querySelector('#nbRecentGrid');
        const countEl = _container?.querySelector('#nbRecentCount');
        if (!grid) return;

        const entries = _notes?.entries || [];
        if (countEl) countEl.textContent = entries.length;

        if (entries.length === 0) {
            grid.innerHTML = `<div class="nb-empty-state sp-empty-state"><span class="sp-empty-state-icon">📝</span><h3 class="sp-empty-state-title">No Notes Deployed</h3><p class="sp-empty-state-text">Deploy your first note to begin intelligence tracking.</p></div>`;
            return;
        }

        // Sort by updatedAt descending, take latest 5
        const sorted = [...entries].sort((a, b) => {
            const da = a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
            const db = b.updatedAt ? new Date(b.updatedAt).getTime() : 0;
            return db - da;
        }).slice(0, 5);

        grid.innerHTML = sorted.map(entry => {
            const tier = _getHealthTier(entry.healthScore || 0);
            const timeAgo = _formatTimeAgo(entry.updatedAt);

            return `
            <div class="nb-recent-item">
                <div class="nb-recent-dot" style="background:${tier.color}; box-shadow:0 0 6px ${tier.color}55;"></div>
                <div class="nb-recent-info">
                    <span class="nb-recent-title">${_escHtml(entry.title || 'Untitled')}</span>
                    <span class="nb-recent-meta">${_escHtml(entry.subject || 'No Subject')}${entry.chapter ? ' / ' + _escHtml(entry.chapter) : ''}</span>
                </div>
                <span class="nb-recent-time">${timeAgo}</span>
                <button class="nb-quick-btn nb-quick-edit nb-quick-edit-sm" data-action="edit-note" data-note-id="${entry.id}">EDIT</button>
            </div>`;
        }).join('');
    }

    // ════════════════════════════════════════════════════════
    //  UTILITY
    // ════════════════════════════════════════════════════════

    function _formatTimeAgo(isoString) {
        if (!isoString) return 'Unknown';
        try {
            const date = new Date(isoString);
            const diffMs = Date.now() - date.getTime();
            const diffMin = Math.floor(diffMs / 60000);
            const diffHr = Math.floor(diffMs / 3600000);
            const diffDay = Math.floor(diffMs / 86400000);
            if (diffMin < 1) return 'Just now';
            if (diffMin < 60) return diffMin + 'm ago';
            if (diffHr < 24) return diffHr + 'h ago';
            if (diffDay < 30) return diffDay + 'd ago';
            return date.toLocaleDateString();
        } catch (e) { return 'Unknown'; }
    }

    function _escHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    // ════════════════════════════════════════════════════════
    //  HTML RENDERING
    // ════════════════════════════════════════════════════════

    function renderFullUI() {
        return `
        <div class="notebook-container">
            <div class="matrix-header">
                <div>
                    <h1 class="nb-page-title">NOTEBOOK INTELLIGENCE</h1>
                    <p class="nb-page-subtitle">TRACK. MEASURE. MASTER YOUR NOTES.</p>
                </div>
                <div class="nb-header-actions">
                    <button class="deploy-note-btn" data-action="deploy-note">+ DEPLOY NEW NOTE</button>
                    <button class="add-btn" data-action="add-row">+ ADD SUBJECT</button>
                </div>
            </div>

            <!-- Phase 7H-2: Hero Metrics Strip -->
            <div class="nb-metrics-strip">
                <div class="nb-metric-card metric-accent-yellow" id="nb-card-total">
                    <span class="nb-metric-label">Total Subjects</span>
                    <span class="nb-metric-value" id="nb-metric-total">0</span>
                </div>
                <div class="nb-metric-card metric-accent-yellow" id="nb-card-verified">
                    <span class="nb-metric-label">Verified Rate</span>
                    <span class="nb-metric-value" id="nb-metric-verified">0%</span>
                </div>
                <div class="nb-metric-card metric-accent-green" id="nb-card-incident">
                    <span class="nb-metric-label">Pending / Incident</span>
                    <span class="nb-metric-value" id="nb-metric-incident">0</span>
                </div>
                <div class="nb-metric-card metric-accent-yellow" id="nb-card-health">
                    <span class="nb-metric-label">Avg Health</span>
                    <span class="nb-metric-value" id="nb-metric-health">N/A</span>
                </div>
            </div>

            <!-- Phase 7H-2: Health Meter -->
            <div class="nb-health-meter" id="nb-health-bar">
                <div class="nb-health-meter-left">
                    <span class="nb-health-label">NOTEBOOK HEALTH</span>
                    <span class="nb-health-score" id="nb-health-score-text">--</span>
                </div>
                <div class="nb-health-track">
                    <div class="nb-health-fill" id="nb-health-fill"></div>
                </div>
                <span class="nb-health-tier" id="nb-health-tier">AWAITING DATA</span>
            </div>

            <!-- Phase 7H-3: Upgraded Matrix Table -->
            <table class="notebook-matrix">
                <thead>
                    <tr>
                        <th class="th-id">#</th>
                        <th class="th-subject">Subject Identification</th>
                        <th class="th-type">Type</th>
                        <th class="th-center">Verification</th>
                        <th class="th-center">Incident</th>
                        <th class="th-center">Health</th>
                        <th class="th-center">Revision</th>
                    </tr>
                </thead>
                <tbody id="matrixBody"></tbody>
            </table>

            <!-- ═══ Phase 7H-5: Intelligence Sections ═══ -->

            <!-- 1. Subject Overview -->
            <div class="nb-intel-section">
                <div class="nb-intel-section-header">
                    <div class="nb-intel-section-left">
                        <h2 class="nb-section-title">SUBJECT OVERVIEW</h2>
                    </div>
                </div>
                <div class="nb-intel-section-grid nb-subject-grid" id="nbSubjectGrid">
                    <!-- rendered by _renderSubjectOverview() -->
                </div>
            </div>

            <!-- 2. Revision Pending -->
            <div class="nb-intel-section">
                <div class="nb-intel-section-header">
                    <div class="nb-intel-section-left">
                        <h2 class="nb-section-title">REVISION PENDING</h2>
                        <span class="nb-notes-count" id="nbRevisionCount">0</span>
                    </div>
                </div>
                <div class="nb-intel-section-grid" id="nbRevisionGrid">
                    <!-- rendered by _renderRevisionPending() -->
                </div>
            </div>

            <!-- 3. Weak Notes -->
            <div class="nb-intel-section">
                <div class="nb-intel-section-header">
                    <div class="nb-intel-section-left">
                        <h2 class="nb-section-title">WEAK NOTES</h2>
                        <span class="nb-notes-count nb-weak-count" id="nbWeakCount">0</span>
                    </div>
                </div>
                <div class="nb-intel-section-grid" id="nbWeakGrid">
                    <!-- rendered by _renderWeakNotes() -->
                </div>
            </div>

            <!-- 4. Recent Notes -->
            <div class="nb-intel-section">
                <div class="nb-intel-section-header">
                    <div class="nb-intel-section-left">
                        <h2 class="nb-section-title">RECENT NOTES</h2>
                        <span class="nb-notes-count" id="nbRecentCount">0</span>
                    </div>
                </div>
                <div class="nb-recent-list" id="nbRecentGrid">
                    <!-- rendered by _renderRecentNotes() -->
                </div>
            </div>

            <!-- Phase 7H-4: Note Modal -->
            <div class="nb-note-modal-overlay" id="nbNoteModal" style="display:none;">
                <div class="nb-note-modal">
                    <div class="nb-modal-header">
                        <h2 id="nbModalTitle">DEPLOY NEW NOTE</h2>
                        <button class="nb-modal-close" data-action="close-note-modal">&times;</button>
                    </div>
                    <div class="nb-modal-body">
                        <input type="hidden" id="nbEditNoteId" value="">

                        <div class="nb-field">
                            <label for="nbNoteTitle">Title</label>
                            <input type="text" id="nbNoteTitle" placeholder="Note title..." autocomplete="off">
                        </div>

                        <div class="nb-field-row">
                            <div class="nb-field nb-field-half">
                                <label for="nbNoteSubject">Subject</label>
                                <select id="nbNoteSubject">
                                    <option value="">— Select Subject —</option>
                                </select>
                            </div>
                            <div class="nb-field nb-field-half">
                                <label for="nbNoteChapter">Chapter</label>
                                <input type="text" id="nbNoteChapter" placeholder="e.g. Ch 7" autocomplete="off">
                            </div>
                        </div>

                        <div class="nb-field">
                            <label for="nbNoteContent">Content</label>
                            <textarea id="nbNoteContent" rows="6" placeholder="Your notes..."></textarea>
                        </div>

                        <div class="nb-field">
                            <label for="nbNoteSummary">Summary</label>
                            <textarea id="nbNoteSummary" rows="3" placeholder="Brief summary..."></textarea>
                        </div>

                        <div class="nb-field">
                            <label for="nbNoteTags">Tags (comma-separated)</label>
                            <input type="text" id="nbNoteTags" placeholder="formula, important, exam" autocomplete="off">
                        </div>

                        <div class="nb-field-row">
                            <div class="nb-field nb-field-half">
                                <label for="nbNoteRevision">Revision Status</label>
                                <select id="nbNoteRevision">
                                    <option value="none">None</option>
                                    <option value="pending">Pending</option>
                                    <option value="overdue">Overdue</option>
                                </select>
                            </div>
                            <div class="nb-field nb-field-half nb-field-check">
                                <label for="nbNoteGold">Gold Note</label>
                                <div class="nb-checkbox-wrap">
                                    <input type="checkbox" id="nbNoteGold">
                                    <span class="nb-checkbox-label">Mark as priority</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="nb-modal-footer">
                        <button class="nb-btn-cancel" data-action="close-note-modal">CANCEL</button>
                        <button class="nb-btn-save" id="nbBtnSave" data-action="save-note">DEPLOY NOTE</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="nb-toast" id="nbToast"></div>`;
    }

    function _render() {
        const tbody = _container?.querySelector('#matrixBody');
        if (!tbody) return;

        tbody.innerHTML = _rows.map((row, index) => {
            const doneClass = row.done ? 'active-green' : '';
            const incidentClass = row.incident ? 'active-red' : '';
            const rowDoneClass = row.done ? 'row-done' : '';
            const rowIncClass = row.incident ? 'row-incident' : '';

            const health = _getRowHealth(row);
            const revision = _getRowRevision(row);

            let healthHTML = '';
            if (health.hasIntel && health.score !== null) {
                const hTier = health.tier;
                healthHTML = `
                    <div class="health-cell">
                        <div class="health-bar-mini">
                            <div class="health-bar-fill" style="width:${health.score}%; background:${hTier.color}; box-shadow:0 0 8px ${hTier.color}55;"></div>
                        </div>
                        <span class="health-score" style="color:${hTier.color};">${health.score}</span>
                    </div>`;
            } else {
                healthHTML = `<div class="health-cell"><span class="health-no-intel">NO INTEL</span></div>`;
            }

            const revHTML = `<span class="revision-badge ${revision.cssClass}">${revision.status}</span>`;

            let rowHealthClass = '';
            if (health.hasIntel && health.tier) {
                rowHealthClass = 'row-health-' + health.tier.tier;
            }

            return `
            <tr class="matrix-row ${rowDoneClass} ${rowIncClass} ${rowHealthClass}">
                <td class="td-id">${String(index + 1).padStart(2, '0')}</td>
                <td class="td-subject">
                    <input type="text" class="subject-input" value="${row.subject}"
                           data-action="update-subject" data-index="${index}"
                           placeholder="Enter Subject...">
                </td>
                <td class="td-type">
                    <span class="type-pill type-${(row.type || 'CLASSWORK').toLowerCase()}">${row.type || 'CLASSWORK'}</span>
                    <select class="log-select" data-action="update-type" data-index="${index}">
                        <option value="CLASSWORK" ${row.type === 'CLASSWORK' ? 'selected' : ''}>CLASSWORK</option>
                        <option value="HOMEWORK" ${row.type === 'HOMEWORK' ? 'selected' : ''}>HOMEWORK</option>
                    </select>
                </td>
                <td class="status-cell ${doneClass}" data-action="toggle-done" data-index="${index}">
                    <span class="status-icon">✓</span>
                </td>
                <td class="status-cell ${incidentClass}" data-action="show-popup" data-index="${index}" id="inc-cell-${index}">
                    <span class="status-icon">✕</span>
                    ${row.incident && row.delta > 0 ? `<div class="delta-badge">-${row.delta} PG</div>` : ''}
                </td>
                <td class="td-health">${healthHTML}</td>
                <td class="td-revision">${revHTML}</td>
            </tr>`;
        }).join('');
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {
        // Click delegation
        container.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) {
                document.querySelectorAll('.cloud-popup').forEach(p => p.remove());
                return;
            }

            const action = target.dataset.action;
            const index = parseInt(target.dataset.index);

            switch (action) {
                case 'add-row':
                    _addNewRow();
                    break;
                case 'toggle-done':
                    if (!isNaN(index)) _toggleDone(index);
                    break;
                case 'show-popup':
                    e.stopPropagation();
                    if (!isNaN(index)) _showPopup(index);
                    break;
                case 'apply-incident':
                    if (!isNaN(index)) _applyIncident(index);
                    break;
                case 'deploy-note':
                    _openNoteModal(null);
                    break;
                case 'save-note':
                    _saveNote();
                    break;
                case 'edit-note':
                    _openNoteModal(target.dataset.noteId);
                    break;
                case 'delete-note':
                    _deleteNote(target.dataset.noteId);
                    break;
                case 'close-note-modal':
                    _closeNoteModal();
                    break;
                // Phase 7H-5: Quick actions
                case 'mark-note-reviewed':
                    _markNoteReviewed(target.dataset.noteId);
                    break;
                case 'mark-note-pending':
                    _markNotePending(target.dataset.noteId);
                    break;
                case 'mark-note-overdue':
                    _markNoteOverdue(target.dataset.noteId);
                    break;
                case 'strengthen-note':
                    _openNoteModal(target.dataset.noteId);
                    break;
            }
        }, { signal });

        // Change delegation (for subject input + type select)
        container.addEventListener('change', (e) => {
            const target = e.target;
            const action = target.dataset.action;
            const index = parseInt(target.dataset.index);

            if (action === 'update-subject' && !isNaN(index)) {
                _updateRow(index, 'subject', target.value);
            } else if (action === 'update-type' && !isNaN(index)) {
                _updateRow(index, 'type', target.value);
            }
        }, { signal });

        // Stop popup clicks from bubbling to document
        container.addEventListener('click', (e) => {
            if (e.target.closest('.cloud-popup')) {
                e.stopPropagation();
            }
        }, { signal });

        // Phase 7H-4: Click modal overlay to close
        container.addEventListener('click', (e) => {
            const overlay = e.target.closest('.nb-note-modal-overlay');
            if (overlay && e.target === overlay) {
                _closeNoteModal();
            }
        }, { signal });

        // Phase 7H-4: Escape key to close modal
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && _editingNoteId !== null) {
                _closeNoteModal();
            }
        }, { signal });
    }

    // ════════════════════════════════════════════════════════
    //  TOAST
    // ════════════════════════════════════════════════════════

    function _showToast(message) {
        const toast = _container?.querySelector('#nbToast');
        if (!toast) return;
        toast.textContent = message;
        toast.classList.add('visible');
        setTimeout(() => toast.classList.remove('visible'), 2800);
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();

window.NotebooksRoute = NotebooksRoute;
