/**
 * PULSE ENGINE v2.0 — SMART PADHAI (ARCHITECT EDITION)
 * Refactored by Claude (Senior Engineer, Super-Squad)
 *
 * CHANGES FROM v1:
 *  1. addPoints() — Natural Tasks now sync to localStorage reliably.
 *     "Silent rejections" are gone; every rejection logs a reason.
 *  2. Smart Validation — missing/null rewardId is auto-generated.
 *     All guard exits now print a console reason via _reject().
 *  3. Daily Cap raised from 50 PP → 200 PP for Natural Tasks.
 *  4. Legacy Protection — triggerArchitectAscension() and Alfred are
 *     untouched. UI / Progress Bar logic is pixel-perfect as before.
 */

/* ─────────────────────────────────────────────
   RANK LOGOS  (unchanged from original)
───────────────────────────────────────────── */
const rankLogos = {
    "Initiate":    `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 5px #888);"><path d="M12 2L4 5V11C4 16.07 7.41 20.84 12 22C16.59 20.84 20 16.07 20 11V5L12 2Z" stroke="#888" stroke-width="2" fill="rgba(136,136,136,0.2)"/></svg>`,
    "Operator":    `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 8px #00ccff);"><path d="M13 2L3 14H12L11 22L21 10H12L13 2Z" fill="#00ccff"/></svg>`,
    "War Machine": `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 8px #00ff9d);"><path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" fill="#00ff9d"/><path d="M19.4 15V9L17.6 7.2L14.8 7.7L12 5L9.2 7.7L6.4 7.2L4.6 9V15L6.4 16.8L9.2 16.3L12 19L14.8 16.3L17.6 16.8L19.4 15Z" stroke="#00ff9d" stroke-width="2"/></svg>`,
    "Commander":   `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 10px #ffd700);"><path d="M12 2L2 7L12 12L22 7L12 2Z" fill="#ffd700"/><path d="M2 17L12 22L22 17M2 12L12 17L22 12" stroke="#ffd700" stroke-width="2"/></svg>`,
    "Architect":   `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 12px #cc00ff);"><path d="M12 5C7 5 2.73 8.11 1 12.5C2.73 16.89 7 20 12 20C17 20 21.27 16.89 23 12.5C21.27 8.11 17 5 12 5ZM12 17.5C9.24 17.5 7 15.26 7 12.5C7 9.74 9.24 7.5 12 7.5C14.76 7.5 17 9.74 17 12.5C17 15.26 14.76 17.5 12 17.5ZM12 9.5C10.34 9.5 9 10.84 9 12.5C9 14.16 10.34 15.5 12 15.5C13.66 15.5 15 14.16 15 12.5C15 10.84 13.66 9.5 12 9.5Z" fill="#cc00ff"/></svg>`
};

/* ─────────────────────────────────────────────
   PULSE ENGINE v2.0
───────────────────────────────────────────── */
const PulseEngine = {

    DAILY_CAP: 10000000,
    STORAGE_KEY: 'pulse_engine_data',

    // P2 Fix 4: Account-switch protection flag
    // Must be true before syncPulseEngineToSupabase() can write.
    // Prevents default PulseEngine data from overwriting existing Supabase data.
    hasLoadedFromSupabase: false,

    data: (() => {
        let legacy = SafeStorage.getItem(this?.STORAGE_KEY || 'pulse_engine_data') || {};
        return {
            totalPP:       Number(legacy.totalPP    ?? 500),
            level:         legacy.level             || "Initiate",
            hasAscended:   !!legacy.hasAscended,
            shields:       Number(legacy.shields    ?? 1),
            streak:        Number(legacy.streak     ?? 0),
            lastActivity:  legacy.lastActivity      || new Date().toDateString(),
            multiplier:    Number(legacy.multiplier ?? 1.0),
            inventory:     legacy.inventory         || [],
            dailyDate:     legacy.dailyDate         || new Date().toDateString(),
            dailyEarned:   Number(legacy.dailyEarned ?? legacy.dailyEarnedPP ?? 0),
            dailyEarnedPP: Number(legacy.dailyEarnedPP ?? legacy.dailyEarned ?? 0),
            rewardLedger:  legacy.rewardLedger      || {},
            priorityTasks: legacy.priorityTasks     || {}
        };
    })(),

save() {
    SafeStorage.setItem("pulse_engine_data", this.data);

    // P2 Fix 4: Only sync to Supabase if pulse state has been loaded first.
    // This prevents default data (500 PP, Initiate) from overwriting
    // real user data during the race between init and Supabase load.
    if (this.hasLoadedFromSupabase && typeof syncPulseEngineToSupabase === "function") {
        syncPulseEngineToSupabase().catch(err => {
            console.error("[Pulse] Background sync failed:", err);
        });
    } else if (!this.hasLoadedFromSupabase) {
        console.warn("[Pulse] save() called before Supabase load — skipping Supabase sync to prevent data overwrite.");
    }
},

    _reject(reason, context = {}) {
        console.warn(`[PulseEngine] Points rejected — ${reason}`, context);
        if (typeof Alfred !== 'undefined') Alfred.show(`BLOCKED: ${reason}`, 'penalty', 0);
    },

    _resolveRewardId(meta, type) {
        if (meta?.rewardId) return meta.rewardId.trim();
        return `auto_${type}_${new Date().toDateString().replace(/\s+/g, '_')}`;
    },

    dailyCheck() {
        const today = new Date().toDateString();
        if (this.data.dailyDate === today) return;

        const hadIncomplete = Object.values(this.data.priorityTasks || {}).some(v => v === false);
        if (hadIncomplete) {
            this.data.totalPP = Math.max(0, this.data.totalPP - 10);
            Alfred?.show("PRIORITY MISS: -10 PP", 'penalty', 10);
        }

        this.data.dailyDate = today;
        this.data.dailyEarned = 0;
        this.data.dailyEarnedPP = 0;
        this.data.rewardLedger = {};
        this.data.priorityTasks = {};
        this.calculateLevel();
        this.save();
    },
    /* ── Priority task tracker ── */
    setPriorityTask(taskId, isCompleted) {
        if (!taskId) {
            this._reject('setPriorityTask called without a taskId');
            return;
        }
        this.data.priorityTasks[taskId] = !!isCompleted;
        this.save();
    },

    /* ── CORE: addPoints  [FIX #1, #2, #3] ─────────────────────────────
     *
     *  Parameters
     *    amount   {number|null}  PP to award; null = use baseRates default
     *    type     {string}       'task' | 'mission' | 'timer' | 'checkin'
     *    meta     {object}
     *      .rewardId  {string}   Idempotency key (auto-generated if missing)
     *      .isDev     {boolean}  Bypass daily cap for dev boosts
     *
     *  Returns   {number}  actual PP granted (0 if rejected)
     *
     * ─────────────────────────────────────────────────────────────────── */
    addPoints(amount, type = "task", meta = {}) {
        this.dailyCheck();

        const isDev = meta?.isDev === true;
        const baseRates = { timer: 10, task: 5, mission: 15, checkin: 2 };

        if (amount === null || amount === undefined || isNaN(Number(amount))) {
            amount = baseRates[type] ?? 5;
        }
        amount = Number(amount);
        
        if (amount <= 0) {
            this._reject('amount must be > 0', { amount, type });
            return 0;
        }

        if (!baseRates.hasOwnProperty(type)) {
            this._reject(`unknown type "${type}" — use task/mission/timer/checkin`, { type });
            return 0;
        }

        let rewardId = null;
        if (!isDev && (type === 'task' || type === 'mission')) {
            rewardId = this._resolveRewardId(meta, type);
            if (this.data.rewardLedger[rewardId]) {
                this._reject(`duplicate rewardId "${rewardId}" already claimed today`, { rewardId, type });
                return 0;
            }
        }

        // Timer/checkin: also dedup if caller explicitly provides a rewardId
        // (prevents double-award on page refresh or rapid clicks)
        if (!isDev && (type === 'timer' || type === 'checkin') && meta?.rewardId) {
            const explicitId = String(meta.rewardId);
            if (this.data.rewardLedger[explicitId]) {
                this._reject(`duplicate rewardId "${explicitId}" already claimed`, { rewardId: explicitId, type });
                return 0;
            }
            rewardId = explicitId;
        }

        if (!isDev && this.data.dailyEarned >= this.DAILY_CAP) {
            this._reject(`daily cap reached (${this.DAILY_CAP} PP)`, { dailyEarned: this.data.dailyEarned });
            return 0;
        }

        let m = 1.0;
        if      (this.data.streak >= 30) m = 2.0;
        else if (this.data.streak >= 15) m = 1.5;
        else if (this.data.streak >= 7)  m = 1.2;
        this.data.multiplier = m;

        const finalPoints = Math.floor(amount * m);
        const remaining = isDev ? Infinity : Math.max(0, this.DAILY_CAP - this.data.dailyEarned);
        const granted   = isDev ? finalPoints : Math.min(finalPoints, remaining);

        if (granted <= 0) {
            this._reject('no headroom left under daily cap', { remaining, finalPoints });
            return 0;
        }

        // COMMIT POINTS
        this.data.totalPP += granted;
        if (!isDev) {
            this.data.dailyEarned += granted;
            this.data.dailyEarnedPP += granted;
            if (rewardId) this.data.rewardLedger[rewardId] = true;
        }

        this.calculateLevel();
        this.save(); 

        // UI Feedback
        if (typeof showPPToast === 'function') {
            showPPToast(granted, type, m);
        }

        const multDisplay = document.getElementById('multiplier-tag');
        if (multDisplay) multDisplay.innerText = m + "x";

logPulseTransaction({
    transactionType: "reward",
    reason: type || "PP reward",
    source: type || "unknown",
    rewardId,
    ppChange: granted,
    multiplier: this.data.multiplier,
    finalPP: this.data.totalPP,
    metadata: meta || {}
});

console.info(`[PulseEngine] +${granted} PP | Total: ${this.data.totalPP}`);
return granted;
    },
    /* ── Deduct points ── */
    deductPoints(amount) {
        this.dailyCheck();
        const n = Math.abs(Number(amount || 0));
        if (n <= 0) return;
        this.data.totalPP = Math.max(0, this.data.totalPP - n);
        this.calculateLevel();
        this.save();
    },


    /* ── Rank calculation ── */
    calculateLevel() {
        const pp       = this.data.totalPP;
        const oldLevel = this.data.level;
        let   newLevel = "Initiate";

        if      (pp >= 30000) newLevel = "Architect";
        else if (pp >= 15000) newLevel = "Commander";
        else if (pp >= 5000)  newLevel = "War Machine";
        else if (pp >= 1000)  newLevel = "Operator";

        if (pp < 30000) this.data.hasAscended = false;

        if (newLevel !== oldLevel) {
            if (newLevel === "Architect" && !this.data.hasAscended) {
                this.data.hasAscended = true;
                setTimeout(() => {
                    if (typeof triggerArchitectAscension === 'function') triggerArchitectAscension();
                }, 800);
            }
            this.data.level = newLevel;
            if (typeof Alfred !== 'undefined') Alfred.show(`RANK UPGRADED: ${newLevel}`, 'reward', 0);
        }
        this.syncThemeClasses();
    },

    /* ── Theme sync ── */
    syncThemeClasses() {
        const header = document.querySelector('.master-header');
        if (!header) return;
        const rankClass = `theme-${this.data.level.replace(/\s+/g, '')}`;
        header.classList.remove(
            'theme-Initiate', 'theme-Operator', 'theme-WarMachine', 'theme-Commander', 'theme-Architect'
        );
        header.classList.add(rankClass);
    },

    /* ── UI render (unchanged logic, unchanged element IDs) ── */
    updateUI() {
        const ppValue     = this.data.totalPP;
        const currentRank = this.data.level;

        const elements = {
            level:      document.getElementById('global-level-display'),
            ppDisplay:  document.getElementById('global-pp-display'),
            xpNeeded:   document.getElementById('xp-needed'),
            pulseFill:  document.getElementById('global-pulse-fill'),
            trophy:     document.getElementById('trophy-pp-display'),
            mainBadge:  document.getElementById('main-shard-badge'),
            rankName:   document.getElementById('rank-name')
        };

        // Rank display with logo
        if (elements.level) {
            elements.level.innerHTML = `<div style="display:flex; align-items:center; gap:8px;">${rankLogos[currentRank]} <span>${currentRank}</span></div>`;
            const colors = {
                "Initiate": "#888", "Operator": "#00ccff",
                "War Machine": "#00ff9d", "Commander": "#ffd700", "Architect": "#cc00ff"
            };
            elements.level.style.color = colors[currentRank];
        }

        if (elements.ppDisplay) elements.ppDisplay.innerText = ppValue.toLocaleString();
        if (elements.trophy)    elements.trophy.innerText    = ppValue.toLocaleString();

        // PROGRESS BAR — relative logic (untouched)
        if (elements.pulseFill) {
            const brackets = {
                "Initiate":    { min: 0,     max: 1000,  img: "assets/Iniate rank.png",         color: "#808080" },
                "Operator":    { min: 1000,  max: 5000,  img: "assets/Operator.png",             color: "#00eeff" },
                "War Machine": { min: 5000,  max: 15000, img: "assets/war machine.png",          color: "#39ff14" },
                "Commander":   { min: 15000, max: 30000, img: "assets/commander rank.png",       color: "#ffcc00" },
                "Architect":   { min: 30000, max: 50000, img: "assets/The all seeing Eye.png",   color: "#bc13fe" }
            };

            const config = brackets[currentRank];
            if (elements.xpNeeded) elements.xpNeeded.innerText = `${config.max.toLocaleString()} PP`;

            const relativePP = ppValue - config.min;
            const range      = config.max - config.min;
            const progress   = Math.min(Math.max((relativePP / range) * 100, 0), 100);
            elements.pulseFill.style.width = progress + "%";

            if (elements.mainBadge && elements.mainBadge.getAttribute('src') !== config.img) {
                elements.mainBadge.style.opacity = '0';
                setTimeout(() => {
                    elements.mainBadge.src          = config.img;
                    elements.mainBadge.style.opacity = '0.7';
                }, 300);
            }
            if (elements.rankName) elements.rankName.innerText = currentRank;

            document.documentElement.style.setProperty('--accent-color', config.color);
            document.documentElement.style.setProperty('--accent-glow',  config.color + "66");
        }

        this.syncThemeClasses();
        if (typeof updateTimelinePath === 'function') updateTimelinePath();
    }
};
window.PulseEngine = PulseEngine;
/* ─────────────────────────────────────────────
   LEGACY PRESERVED — DO NOT MODIFY
   triggerArchitectAscension + Alfred
───────────────────────────────────────────── */
function triggerArchitectAscension() {
    const overlay = document.getElementById('ascension-overlay');
    if (!overlay) return;
    overlay.style.display  = 'flex';
    overlay.style.opacity  = '1';
    overlay.classList.add('flash-active');
    setTimeout(() => overlay.classList.add('show-content'), 500);
    setTimeout(() => {
        overlay.style.transition = "opacity 3s cubic-bezier(0.4, 0, 0.2, 1)";
        overlay.style.opacity    = '0';
        setTimeout(() => {
            overlay.style.display = 'none';
            overlay.classList.remove('flash-active', 'show-content');
            overlay.style.opacity = '1';
        }, 3000);
    }, 9000);
}

const Alfred = {
    show(message, type = 'reward', cost = 0) {
        const card  = document.getElementById('alfred-card');
        const text  = document.getElementById('alfred-text');
        const badge = document.getElementById('alfred-badge');
        if (!card) return;
        card.className = type + '-mode active';
        const headers = {
            'reward':  'SYST_AUTH // SUCCESS',
            'penalty': 'SYST_WARN // PENALTY',
            'jar':     'NEURAL_SYNC // COOKIE_JAR'
        };
        badge.innerHTML = `<span>${headers[type]}</span>`;
        text.style.opacity = '0';
        text.innerText     = message;
        setTimeout(() => { text.style.transition = "opacity 0.5s ease"; text.style.opacity = '1'; }, 300);
        setTimeout(() => card.classList.remove('active'), 7000);
    }
};
function showPPToast(granted, type, multiplier) {
  const typeColors = {
    task: '#7F77DD', mission: '#cc00ff',
    timer: '#00ff9d', checkin: '#00ccff'
  };
  const color = typeColors[type] || '#cc00ff';
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'pp-toast';
  toast.innerHTML =
    `<span style="color:${color};font-size:18px">+${granted} PP</span>` +
    `<span style="font-size:12px;opacity:0.6">${type}</span>` +
    (multiplier > 1 ? `<span class="pp-mult">${multiplier}x</span>` : '');

  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}
/* ─────────────────────────────────────────────
   UTILITY FUNCTIONS (unchanged)
───────────────────────────────────────────── */
function openCookieJar() {
    const victories = [
        "Remember when you crushed that Physics backlog?",
        "You stop when you're DONE.",
        "Stay Hard!"
    ];
    PulseEngine.deductPoints(10);
    Alfred.show(victories[Math.floor(Math.random() * victories.length)], 'jar', 10);
}
function showRankDetail(rankName) {
    const detailPanel = document.getElementById('rank-detail-panel');
    if (!detailPanel) {
        console.error("Panel element 'rank-detail-panel' missing!");
        return;
    }

    const rank = rankData.find(r => r.name === rankName);
    if (!rank) return;

    const currentPP = PulseEngine.data.totalPP;
    
    // Status logic
    const statusText = currentPP >= rank.points ? 
        `<span style="color:${rank.color}">[ COMPLETED ]</span>` : 
        `<span style="color:#ff4d4d">[ LOCKED ]</span>`;

    // HTML Update
    detailPanel.innerHTML = `
        <div class="rank-detail-wrapper" style="display:flex; justify-content: space-between; align-items: flex-start; text-align: left;">
            <div class="detail-main">
                <h4 style="color:${rank.color}; margin:0; font-size: 16px; letter-spacing: 2px;">
                    ${rank.name.toUpperCase()} STATUS: ${statusText}
                </h4>
                <p style="color:#eee; margin:10px 0; font-size: 13px; font-style: italic; max-width: 400px;">
                    "${rank.desc}"
                </p>
            </div>
            <div class="detail-stats" style="border-left: 1px solid rgba(255,255,255,0.1); padding-left: 20px;">
                <p style="margin:0; font-size: 11px; color: #888;">REQUIREMENT: <span style="color:#fff">${rank.points} PP</span></p>
                <p style="margin:5px 0 0; font-size: 11px; color: #888;">UNLOCKED PERKS: <span style="color:${rank.color}">Standard Protocol</span></p>
            </div>
        </div>
    `;
    
    console.log("Panel updated for:", rankName); // Debugging ke liye
}
const rankData = [
    { name: "Initiate",    points: 0,     icon: "🛡️", desc: "The journey begins.",    color: "#888"     },
    { name: "Operator",    points: 1000,  icon: "⚡", desc: "Breaking the cycle.",    color: "#00ccff"  },
    { name: "War Machine", points: 5000,  icon: "⚙️", desc: "Unstoppable force.",      color: "#00ff9d"  },
    { name: "Commander",   points: 15000, icon: "🦅", desc: "Tactical genius.",        color: "#ffd700"  },
    { name: "Architect",   points: 30000, icon: "👁️", desc: "You create the rules.",   color: "#cc00ff"  }
];

function openRankModal() {
    const container = document.getElementById('rank-list-container');
    const pp = PulseEngine.data.totalPP;
    const currentRank = PulseEngine.data.level;
    
    // 1. Rank Nodes generate karo
    container.innerHTML = rankData.map(rank => `
        <div class="rank-node ${pp >= rank.points ? 'unlocked' : ''} ${currentRank === rank.name ? 'current' : ''}" 
             onclick="showRankDetail('${rank.name}')">
            <div class="node-circle">${rank.icon}</div>
            <div class="node-name">${rank.name.toUpperCase()}</div>
        </div>`).join('');

    // 2. Default detail load karo (Architect level details)
    showRankDetail(currentRank);

    // 3. Modal show karo
    const modal = document.getElementById('rank-modal');
    modal.style.display = 'flex';

    // 4. FIX: Agar "x" button kaam nahi kar raha, toh modal ke bahar click karne par close ho jaye
    modal.onclick = function(event) {
        if (event.target === modal) {
            closeRankModal();
        }
    }
}
// Modal band karne ka function jo missing tha
function closeRankModal() {
    const modal = document.getElementById('rank-modal');
    if (modal) {
        modal.style.display = 'none';
        console.log("Ranking Protocol v2.0: Modal Closed Safely.");
    }
}
function updateTimelinePath() {
    const trackFill = document.querySelector('.timeline-track-fill');
    if (!trackFill) return;
    const pp = PulseEngine.data.totalPP;
    const fill = pp >= 30000 ? 100 : pp >= 15000 ? 75 : pp >= 5000 ? 50 : pp >= 1000 ? 25 : 0;
    setTimeout(() => { trackFill.style.width = fill + "%"; }, 300);
}
function triggerDevPoints() {
    console.log("🛠️ DEV_PROTOCOL: Initiating 1000 PP Boost...");
    
    // Claude ke engine ke hisaab se sahi injection:
    const granted = PulseEngine.addPoints(1000, 'mission', { 
        rewardId: 'dev_boost_' + Date.now(), 
        isDev: true 
    });

}
async function loadPulseEngineFromSupabase() {
    const user = await getCurrentUserOrRedirect();
    if (!user) return null;

    try {
        const { data, error } = await supabaseClient
            .from("pulse_engine_state")
            .select("*")
            .eq("user_id", user.id)
            .maybeSingle();

        if (error) {
            console.error("[Pulse] Load failed:", error);
            // Even on error, mark as loaded so we don't block forever.
            // Default data will be used as fallback.
            PulseEngine.hasLoadedFromSupabase = true;
            return null;
        }

        if (!data) {
            // NEW USER: No pulse row exists yet. Create default state in Supabase.
            console.warn("[Pulse] No pulse state found for user. Creating default state.");
            PulseEngine.hasLoadedFromSupabase = true; // Allow sync for new user
            const syncResult = await syncPulseEngineToSupabase();
            return syncResult;
        }

        // EXISTING USER: Restore pulse state from Supabase (source of truth)
        // P6G Patch: daily earned PP is highly UI-sensitive and can lag in Supabase.
        // If the current user's local SafeStorage has a higher daily value for today,
        // preserve it instead of allowing a stale cloud 0 to wipe the dashboard circle.
        const localPulse = SafeStorage.getItem("pulse_engine_data", {}) || {};
        const todayStr = new Date().toDateString();
        const cloudDailyEarned = Number(
            data.daily_earned_pp ??
            data.dailyEarnedPP ??
            data.dailyEarned ??
            0
        );
        const localDailyEarned = Number(
            localPulse.dailyEarnedPP ??
            localPulse.dailyEarned ??
            0
        );
        const localDailyDate = localPulse.dailyDate || localPulse.lastActivity || null;
        const mergedDailyEarned =
            localDailyDate === todayStr
                ? Math.max(cloudDailyEarned, localDailyEarned)
                : cloudDailyEarned;

        const pulseData = {
            totalPP: data.total_pp || 0,

            dailyEarnedPP: mergedDailyEarned,
            dailyEarned: mergedDailyEarned,

            level: data.level || data.rank || "Initiate",
            rank: data.rank || data.level || "Initiate",
            hasAscended: !!data.has_ascended,
            streak: data.streak_days || 0,
            bestStreak: data.best_streak || 0,
            multiplier: Number(data.multiplier || 1),

            lastActiveDate: data.last_active_date || null,
            lastResetDate: data.last_reset_date || null,

            rewardLedger: data.reward_ledger || {},
            penaltyLedger: data.penalty_ledger || {},

            // Preserve fields not in Supabase but in local state
            shields: PulseEngine.data.shields || 1,
            inventory: PulseEngine.data.inventory || [],
            lastActivity: data.last_active_date || PulseEngine.data.lastActivity || todayStr,
            dailyDate: localDailyDate === todayStr ? localDailyDate : todayStr,
            priorityTasks: PulseEngine.data.priorityTasks || {}
        };

        SafeStorage.setItem("pulse_engine_data", pulseData);

        // OVERWRITE default data with real Supabase data
        PulseEngine.data = {
            ...PulseEngine.data,
            ...pulseData
        };

        // P2 Fix 4: Mark as loaded — now sync is allowed
        PulseEngine.hasLoadedFromSupabase = true;

        console.log("[Pulse] Loaded from Supabase (source of truth):", {
            totalPP: pulseData.totalPP,
            level: pulseData.level,
            streak: pulseData.streak
        });
        return pulseData;
    } catch (err) {
        console.error("[Pulse] Load exception:", err);
        PulseEngine.hasLoadedFromSupabase = true; // Unblock on exception
        return null;
    }
}
async function syncPulseEngineToSupabase() {
    // P2 Fix 4: Block sync until pulse state has loaded from Supabase.
    // This prevents default PulseEngine data from overwriting real user data.
    if (!PulseEngine.hasLoadedFromSupabase) {
        console.warn("[Pulse] syncPulseEngineToSupabase BLOCKED — pulse not loaded from Supabase yet.");
        return null;
    }

    const user = await getCurrentUserOrRedirect();
    if (!user) return null;

    const pulse = SafeStorage.getItem("pulse_engine_data", PulseEngine?.data || {});

    const row = {
        user_id: user.id,

        total_pp: Number(pulse.totalPP || pulse.pp || 0),
        daily_earned_pp: Number(
            pulse.dailyEarnedPP ??
            pulse.dailyEarned ??
            pulse.daily_earned_pp ??
            0
        ),

        rank: pulse.rank || pulse.level || "Initiate",
        level: pulse.level || pulse.rank || "Initiate",

        streak_days: Number(pulse.streak || pulse.streakDays || 0),
        best_streak: Number(pulse.bestStreak || 0),
        multiplier: Number(pulse.multiplier || 1),

        last_active_date: pulse.lastActiveDate || null,
        last_reset_date: pulse.lastResetDate || null,

        reward_ledger: pulse.rewardLedger || {},
        penalty_ledger: pulse.penaltyLedger || {},
        raw_data: pulse,

        updated_at: new Date().toISOString()
    };

    const { data, error } = await supabaseClient
        .from("pulse_engine_state")
        .upsert(row, {
            onConflict: "user_id"
        })
        .select()
        .single();

    if (error) {
        console.error("[Pulse] Sync failed:", error);
        return null;
    }

    await syncPulseSummaryToProfile(row);

    console.log("[Pulse] Synced:", data);
    return data;


}
async function syncPulseSummaryToProfile(pulseRow) {
    const user = await getCurrentUserOrRedirect();
    if (!user) return null;

    const { data, error } = await supabaseClient
        .from("student_profile")
        .upsert({
            user_id: user.id,
            user_key: user.id,
            email: user.email,

            total_pp: pulseRow.total_pp,
            daily_earned_pp: pulseRow.daily_earned_pp,
            rank: pulseRow.rank,
            level: pulseRow.level,
            streak_days: pulseRow.streak_days,
            best_streak: pulseRow.best_streak,
            multiplier: pulseRow.multiplier,

            updated_at: new Date().toISOString()
        }, {
            onConflict: "user_id"
        })
        .select()
        .single();

    if (error) {
        console.error("[Pulse/Profile] Sync failed:", error);
        return null;
    }

    return data;
}
async function logPulseTransaction({
    transactionType = "reward",
    reason = "",
    source = "",
    rewardId = null,
    ppChange = 0,
    multiplier = 1,
    finalPP = 0,
    metadata = {}
}) {
    const user = await getCurrentUserOrRedirect();
    if (!user) return null;

    const { data, error } = await supabaseClient
        .from("pulse_transactions")
        .insert({
            user_id: user.id,
            transaction_type: transactionType,
            reason,
            source,
            reward_id: rewardId,
            pp_change: ppChange,
            multiplier,
            final_pp: finalPP,
            metadata
        })
        .select()
        .single();

    if (error) {
        if (String(error.message).includes("duplicate")) {
            console.warn("[Pulse] Duplicate reward blocked:", rewardId);
            return null;
        }

        console.error("[Pulse] Transaction log failed:", error);
        return null;
    }

    return data;
}
/* ─────────────────────────────────────────────
   PP BREAKDOWN LOG SYSTEM (Sprint 9 — Discipline Economy)
   Tracks where PP comes from so the dashboard can show a breakdown tooltip.
   Uses SafeStorage for account-scoped persistence.
───────────────────────────────────────────── */
const PPLogSystem = (() => {
    const LOG_KEY = 'smart_padhai_pp_logs';
    const WEEKLY_GOAL_KEY = 'smart_padhai_weekly_pp_goal';
    const CELEBRATION_KEY = 'smart_padhai_celebration_log';

    function _getDateKey(date) {
        const d = date || new Date();
        return d.toISOString().split('T')[0]; // "YYYY-MM-DD"
    }

    function _getWeekKey(date) {
        const d = date || new Date();
        const start = new Date(d);
        start.setHours(0, 0, 0, 0);
        start.setDate(start.getDate() - start.getDay()); // Sunday
        const weekNum = Math.ceil((start.getDate()) / 7);
        return `${start.getFullYear()}_W${String(weekNum).padStart(2, '0')}`;
    }

    function _getLogs() {
        try {
            const logs = SafeStorage.getItem(LOG_KEY, []);
            return Array.isArray(logs) ? logs : [];
        } catch { return []; }
    }

    function _saveLogs(logs) {
        try { SafeStorage.setItem(LOG_KEY, logs); } catch (e) { console.warn('[PPLog] Save failed:', e); }
    }

    // ── Get today's date key ──
    function getTodayDateKey() { return _getDateKey(); }

    // ── Get current week key ──
    function getCurrentWeekKey() { return _getWeekKey(); }

    // ── Get today's total PP from logs ──
    function getTodayPP() {
        const today = _getDateKey();
        const logs = _getLogs();
        return logs
            .filter(l => l.date === today)
            .reduce((sum, l) => sum + (l.type === 'positive' ? Math.abs(l.points) : -Math.abs(l.points)), 0);
    }

    // ── Get today's PP logs ──
    function getTodayLogs() {
        const today = _getDateKey();
        return _getLogs().filter(l => l.date === today);
    }

    // ── Get weekly total PP ──
    function getWeeklyPP() {
        const now = new Date();
        const startOfWeek = new Date(now);
        startOfWeek.setHours(0, 0, 0, 0);
        startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
        const logs = _getLogs();
        return logs
            .filter(l => {
                try {
                    const ld = new Date(l.date + 'T00:00:00');
                    return ld >= startOfWeek && ld <= now;
                } catch { return false; }
            })
            .reduce((sum, l) => sum + (l.type === 'positive' ? Math.abs(l.points) : -Math.abs(l.points)), 0);
    }

    // ── Weekly goal ──
    function getWeeklyGoal() {
        try {
            const g = SafeStorage.getItem(WEEKLY_GOAL_KEY, null);
            return (g !== null && g !== undefined) ? Number(g) : 700;
        } catch { return 700; }
    }

    function setWeeklyGoal(value) {
        try { SafeStorage.setItem(WEEKLY_GOAL_KEY, Math.max(100, Math.min(5000, Number(value) || 700))); }
        catch (e) { console.warn('[PPLog] Set weekly goal failed:', e); }
    }

    // ── Add a PP log entry (deduped by unique action ID) ──
    function addLog(source, points, type, uniqueId) {
        const logs = _getLogs();
        const today = _getDateKey();

        // Dedup: if uniqueId provided, check if already logged
        if (uniqueId) {
            const exists = logs.find(l => l.uniqueId === uniqueId && l.date === today);
            if (exists) {
                console.info('[PPLog] Duplicate blocked:', uniqueId);
                return false;
            }
        }

        const entry = {
            id: 'pplog_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
            date: today,
            source: source || 'Unknown',
            points: type === 'negative' ? -Math.abs(points) : Math.abs(points),
            type: type === 'negative' ? 'negative' : 'positive',
            uniqueId: uniqueId || null,
            timestamp: new Date().toISOString()
        };

        logs.push(entry);

        // Prune old logs (keep last 30 days)
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        const pruned = logs.filter(l => {
            try { return new Date(l.date + 'T00:00:00') >= thirtyDaysAgo; } catch { return true; }
        });

        _saveLogs(pruned);
        return true;
    }

    // ── Celebration system ──
    function isCelebrationShown(key) {
        try {
            const log = SafeStorage.getItem(CELEBRATION_KEY, {});
            return !!(log && typeof log === 'object' && log[key]);
        } catch { return false; }
    }

    function markCelebrationShown(key) {
        try {
            const log = SafeStorage.getItem(CELEBRATION_KEY, {}) || {};
            log[key] = true;
            SafeStorage.setItem(CELEBRATION_KEY, log);
        } catch (e) { console.warn('[PPLog] Mark celebration failed:', e); }
    }

    return {
        getTodayDateKey,
        getCurrentWeekKey,
        getTodayPP,
        getTodayLogs,
        getWeeklyPP,
        getWeeklyGoal,
        setWeeklyGoal,
        addLog,
        isCelebrationShown,
        markCelebrationShown
    };
})();

window.PPLogSystem = PPLogSystem;

/* ─────────────────────────────────────────────
   STREAK SYSTEM — Real-data-based streak tracking
   Reads from smart_padhai_pp_logs to determine active study days.
   No fake data. No random data. All from real PP activity.
───────────────────────────────────────────── */
window.StreakSystem = (() => {
    const STREAK_KEY = 'smart_padhai_streak_data';
    const PP_LOG_KEY = 'smart_padhai_pp_logs';

    // ── Default streak data structure ──
    function _defaultStreakData() {
        return {
            currentStreak: 0,
            bestStreak: 0,
            lastActiveDate: null,
            activeDates: [],
            updatedAt: null
        };
    }

    // ── Today in YYYY-MM-DD using local time ──
    function getTodayDateKey() {
        const d = new Date();
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    }

    // ── Yesterday in YYYY-MM-DD using local time ──
    function getYesterdayDateKey() {
        const d = new Date();
        d.setDate(d.getDate() - 1);
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    }

    // ── Read PP logs safely ──
    function getPPLogs() {
        try {
            const logs = SafeStorage.getItem(PP_LOG_KEY, []);
            return Array.isArray(logs) ? logs : [];
        } catch (e) {
            console.warn('[StreakSystem] Failed to read PP logs:', e);
            return [];
        }
    }

    // ── Get active dates from PP logs ──
    // Groups by date, sums points per date, returns sorted unique dates where total > 0
    function getActiveDatesFromPPLogs() {
        const logs = getPPLogs();
        if (!logs.length) return [];

        const dailyTotals = {};
        logs.forEach(log => {
            try {
                // Defensive: extract date from log.date or log.timestamp
                const dateKey = log.date || (log.timestamp ? log.timestamp.split('T')[0] : null);
                if (!dateKey || !/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return;
                const pts = Number(log.points);
                if (isNaN(pts)) return;
                dailyTotals[dateKey] = (dailyTotals[dateKey] || 0) + pts;
            } catch (e) { /* skip invalid entries */ }
        });

        // Return only dates where total points > 0
        const activeDates = Object.keys(dailyTotals)
            .filter(d => dailyTotals[d] > 0)
            .sort();

        return activeDates;
    }

    // ── Calculate current streak ──
    // Counts backwards from today (or yesterday if today not yet active)
    function calculateCurrentStreak(activeDates) {
        if (!Array.isArray(activeDates) || activeDates.length === 0) return 0;

        const uniqueDates = [...new Set(activeDates)].sort();
        const today = getTodayDateKey();
        const yesterday = getYesterdayDateKey();

        // Determine starting point
        // If today is active, start from today
        // If today is not active but yesterday is, start from yesterday
        // (prevents streak showing 0 early in the day before user studies)
        let startDate;
        if (uniqueDates.includes(today)) {
            startDate = today;
        } else if (uniqueDates.includes(yesterday)) {
            startDate = yesterday;
        } else {
            return 0; // Neither today nor yesterday is active — streak broken
        }

        let streak = 0;
        let checkDate = new Date(startDate + 'T12:00:00'); // noon to avoid DST issues
        const dateSet = new Set(uniqueDates);

        // Walk backwards day by day
        while (true) {
            const dateKey = `${checkDate.getFullYear()}-${String(checkDate.getMonth() + 1).padStart(2, '0')}-${String(checkDate.getDate()).padStart(2, '0')}`;
            if (dateSet.has(dateKey)) {
                streak++;
                checkDate.setDate(checkDate.getDate() - 1);
            } else {
                break;
            }
        }

        return streak;
    }

    // ── Calculate best streak ──
    // Finds longest continuous chain in activeDates
    function calculateBestStreak(activeDates) {
        if (!Array.isArray(activeDates) || activeDates.length === 0) return 0;

        const sorted = [...new Set(activeDates)].sort();
        if (sorted.length === 0) return 0;

        let best = 1;
        let current = 1;

        for (let i = 1; i < sorted.length; i++) {
            const prev = new Date(sorted[i - 1] + 'T12:00:00');
            const curr = new Date(sorted[i] + 'T12:00:00');
            const diffMs = curr.getTime() - prev.getTime();
            const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));

            if (diffDays === 1) {
                current++;
                best = Math.max(best, current);
            } else {
                current = 1;
            }
        }

        return best;
    }

    // ── Get streak data from localStorage ──
    function getStreakData() {
        try {
            const data = SafeStorage.getItem(STREAK_KEY, null);
            if (data && typeof data === 'object') {
                return {
                    currentStreak: Number(data.currentStreak ?? 0),
                    bestStreak: Number(data.bestStreak ?? 0),
                    lastActiveDate: data.lastActiveDate || null,
                    activeDates: Array.isArray(data.activeDates) ? data.activeDates : [],
                    updatedAt: data.updatedAt || null
                };
            }
            return _defaultStreakData();
        } catch (e) {
            console.warn('[StreakSystem] Failed to read streak data:', e);
            return _defaultStreakData();
        }
    }

    // ── Save streak data to localStorage ──
    function saveStreakData(data) {
        try {
            SafeStorage.setItem(STREAK_KEY, data);
        } catch (e) {
            console.warn('[StreakSystem] Failed to save streak data:', e);
        }
    }

    // ── Refresh streak from real PP logs ──
    function refreshStreak() {
        try {
            const activeDates = getActiveDatesFromPPLogs();
            const currentStreak = calculateCurrentStreak(activeDates);
            const bestStreak = calculateBestStreak(activeDates);
            const lastActiveDate = activeDates.length > 0 ? activeDates[activeDates.length - 1] : null;

            const streakData = {
                currentStreak,
                bestStreak,
                lastActiveDate,
                activeDates,
                updatedAt: new Date().toISOString()
            };

            saveStreakData(streakData);

            // Dispatch custom event for other features to listen
            try {
                window.dispatchEvent(new CustomEvent('smartPadhai:streakUpdated', {
                    detail: streakData
                }));
            } catch (e) { /* silent — event dispatch failure is non-critical */ }

            return streakData;
        } catch (e) {
            console.warn('[StreakSystem] refreshStreak failed:', e);
            return getStreakData();
        }
    }

    // ── Mark today active (refreshes from PP logs, does not fake data) ──
    function markTodayActive() {
        // This simply refreshes streak from real PP logs.
        // It does NOT manually add today unless a PP log exists for today.
        // This prevents fake streak creation.
        return refreshStreak();
    }

    // ── Check if a specific date is active ──
    function isDateActive(dateKey) {
        if (!dateKey) return false;
        const data = getStreakData();
        return Array.isArray(data.activeDates) && data.activeDates.includes(dateKey);
    }

    // ── Get streak summary ──
    function getStreakSummary() {
        const data = getStreakData();
        const now = new Date();
        const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        const activeDaysThisMonth = (data.activeDates || []).filter(d => {
            try { return typeof d === 'string' && d.startsWith(currentMonth); } catch { return false; }
        }).length;

        return {
            currentStreak: data.currentStreak,
            bestStreak: data.bestStreak,
            lastActiveDate: data.lastActiveDate,
            activeDaysThisMonth,
            activeDates: data.activeDates
        };
    }

    // ── Initialize ──
    function init() {
        try {
            // Migrate old streak data if present (backward compatibility)
            try {
                const oldData = SafeStorage.getItem(STREAK_KEY, null);
                if (oldData && typeof oldData === 'object' && !oldData.activeDates && (oldData.streak || oldData.best)) {
                    // Old format: { streak: N, best: M } — will be recalculated from PP logs
                    console.info('[StreakSystem] Migrating old streak data format');
                }
            } catch (e) { /* ignore migration check errors */ }

            // Refresh from real PP logs — this is the source of truth
            const streakData = refreshStreak();

            console.info('[StreakSystem] Initialized:', {
                currentStreak: streakData.currentStreak,
                bestStreak: streakData.bestStreak,
                lastActiveDate: streakData.lastActiveDate,
                activeDays: streakData.activeDates.length
            });
        } catch (e) {
            console.warn('[StreakSystem] Init failed:', e);
            // Ensure default data exists even on failure
            saveStreakData(_defaultStreakData());
        }
    }

    return {
        init,
        getStreakData,
        saveStreakData,
        getPPLogs,
        getActiveDatesFromPPLogs,
        calculateCurrentStreak,
        calculateBestStreak,
        refreshStreak,
        markTodayActive,
        isDateActive,
        getTodayDateKey,
        getYesterdayDateKey,
        getStreakSummary
    };
})();

/* ── Hook into PulseEngine.addPoints to auto-log breakdown ── */
(function _hookPulseEngineLogging() {
    const _origAddPoints = PulseEngine.addPoints.bind(PulseEngine);
    PulseEngine.addPoints = function(amount, type, meta) {
        const result = _origAddPoints(amount, type, meta);
        if (result > 0 && typeof PPLogSystem !== 'undefined') {
            const sourceMap = { timer: 'Focus Session', task: 'Task Complete', mission: 'Mission Completed', checkin: 'Check-in Bonus' };
            const source = sourceMap[type] || type || 'Unknown';
            const uniqueId = meta?.rewardId || `${type}_${new Date().toDateString()}`;
            PPLogSystem.addLog(source, result, 'positive', uniqueId);

            // ── Refresh StreakSystem after PP activity ──
            // Safe: only runs if StreakSystem exists, never throws
            try {
                if (window.StreakSystem) {
                    window.StreakSystem.refreshStreak();
                }
            } catch (e) { /* StreakSystem refresh failure must not break PP flow */ }
        }
        return result;
    };
})();

/* ─────────────────────────────────────────────
   AUTH-SAFE INIT — called from protected pages after userSession is ready
───────────────────────────────────────────── */
PulseEngine.loadFromSupabase = loadPulseEngineFromSupabase;
PulseEngine.syncToSupabase = syncPulseEngineToSupabase;
window.PulseEngine = PulseEngine;
window.loadPulseEngineFromSupabase = loadPulseEngineFromSupabase;
window.syncPulseEngineToSupabase = syncPulseEngineToSupabase;

window.initPulseEngineAfterAuth = async function initPulseEngineAfterAuth() {
    try {
        const user = await getCurrentUserOrRedirect();
        if (!user) return null;

        await loadPulseEngineFromSupabase();
        PulseEngine.dailyCheck();
        PulseEngine.updateUI();

        // ── Initialize StreakSystem after PulseEngine is ready ──
        // Runs safely: reads real PP logs, does not create fake data
        try {
            if (window.StreakSystem) {
                window.StreakSystem.init();
            }
        } catch (e) {
            console.warn('[Init] StreakSystem init failed (non-critical):', e);
        }

        console.info("[PulseEngine] Initialized after auth:", {
            user_id: user.id,
            totalPP: PulseEngine.data.totalPP,
            level: PulseEngine.data.level,
            dailyEarned: PulseEngine.data.dailyEarned
        });
        return PulseEngine.data;
    } catch (err) {
        console.error("[PulseEngine] Auth-safe init failed:", err);
        return null;
    }
};
