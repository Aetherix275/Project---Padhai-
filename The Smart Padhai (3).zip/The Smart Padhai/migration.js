// =====================================================
// SMART PADHAI → SUPABASE CORE MIGRATION SCRIPT
// FIXED: Per-user data isolation
// =====================================================
const MIG_SUPABASE_URL = "https://jgkohrwpyjlfywvqsozj.supabase.co";
const MIG_SUPABASE_ANON_KEY = "sb_publishable_OkDNIEJg0BDU9dx3aqcm8A_uFqb5jd6";

function safeParseLS(baseKey, fallback = null) {
    try {
        const uid = localStorage.getItem('_current_user_id');
        
        // Pehle user-specific key try karo
        if (uid) {
            const specificKey = `${baseKey}_${uid}`;
            const specificRaw = localStorage.getItem(specificKey);
            if (specificRaw) return JSON.parse(specificRaw);
        }
        
        // Fallback — purani generic key
        const raw = localStorage.getItem(baseKey);
        if (!raw) return fallback;
        return JSON.parse(raw);

    } catch (err) {
        console.warn(`[Migration] Failed to parse ${baseKey}`, err);
        return fallback;
    }
}

async function clearSupabaseTable(tableName, userKey, token) {
    try {
        const response = await fetch(
            `${MIG_SUPABASE_URL}/rest/v1/${tableName}?user_key=eq.${userKey}`,
            {
                method: "DELETE",
                headers: {
            "apikey": MIG_SUPABASE_ANON_KEY,
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "application/json",
                    "Prefer": "return=minimal"
                }
            }
        );
        if (!response.ok) {
            const result = await response.json();
            console.error(`[Migration] Failed to clear ${tableName}:`, result);
            return false;
        }
        console.log(`[Migration] ✅ Cleared ${tableName}`);
        return true;
    } catch (err) {
        console.error(`[Migration] Clear error:`, err);
        return false;
    }
}

async function supabaseInsert(tableName, rows, token) {
    if (!Array.isArray(rows) || rows.length === 0) {
        console.warn(`[Migration] No rows for ${tableName}`);
        return [];
    }
    const response = await fetch(
`${MIG_SUPABASE_URL}/rest/v1/${tableName}`,

        {
            method: "POST",
            headers: {
"apikey": MIG_SUPABASE_ANON_KEY,
                "Authorization": `Bearer ${token}`,
                "Content-Type": "application/json",
                "Prefer": "return=representation"
            },
            body: JSON.stringify(rows)
        }
    );
    const result = await response.json();
    if (!response.ok) {
        console.error(`[Migration] ${tableName} failed:`, result);
        return null;
    }
    console.log(`[Migration] ✅ ${tableName} inserted:`, result.length, "rows");
    return result;
}

// ------------------------------
// BUILD FUNCTIONS
// ------------------------------
function buildSyllabusRows(userKey) {
    const tracker = safeParseLS("syllabus_master_tracker", {});
    const progressData = safeParseLS("smartPadhaiData", {});
    const rows = [];
    if (!tracker || typeof tracker !== "object") return rows;
    Object.keys(tracker).forEach((chapter) => {
        const progress = progressData[chapter] || {};
        const read = progress.read === true;
        const notes = progress.notes === true;
        const pyq = progress.pyq === true;
        const completedCount = [read, notes, pyq].filter(Boolean).length;
        rows.push({
            user_key: userKey,
            subject: progress.subject || "Unknown",
            chapter: chapter,
            completed: completedCount === 3,
            progress: Math.round((completedCount / 3) * 100),
            raw_data: { registry: tracker[chapter], progress },
            last_updated: progress.lastUpdated || null
        });
    });
    return rows;
}

function buildNotebookRows(userKey) {
    const data = safeParseLS("notebook_matrix_data", {});
    const rows = [];
    if (!data || typeof data !== "object") return rows;
    Object.entries(data).forEach(([key, value]) => {
        if (value && typeof value === "object" && !Array.isArray(value)) {
            rows.push({
                user_key: userKey,
                subject: value.subject || key,
                notebook_type: value.type || value.notebook_type || "general",
                title: value.title || key,
                completed: value.completed === true || value.done === true || value.status === "completed",
                delta_pages: Number(value.delta_pages || value.deltaPages || value.pages || 0),
                raw_data: value,
                last_updated: value.lastUpdated || value.last_updated || null
            });
        } else {
            rows.push({
                user_key: userKey,
                subject: "Unknown",
                notebook_type: "general",
                title: key,
                completed: value === true,
                delta_pages: 0,
                raw_data: value,
                last_updated: null
            });
        }
    });
    return rows;
}

function buildCalendarRows(userKey) {
    const data = safeParseLS("calendarStrategy", {});
    const rows = [];
    if (!data || typeof data !== "object") return rows;
    Object.entries(data).forEach(([date, eventData]) => {
        rows.push({
            user_key: userKey,
            event_date: date,
            mode: eventData?.mode || "general",
            title: eventData?.text || eventData?.title || eventData?.name || "Untitled Event",
            description: eventData?.description || eventData?.note || null,
            event_type: eventData?.type || eventData?.mode || "general",
            raw_data: eventData
        });
    });
    return rows;
}

function buildMissionRows(userKey) {
    const data = safeParseLS("commanderMissions", {});
    const rows = [];
    if (!data || typeof data !== "object") return rows;
    Object.entries(data).forEach(([slot, missions]) => {
        if (Array.isArray(missions)) {
            missions.forEach((mission) => {
                rows.push({
                    user_key: userKey,
                    slot: slot,
                    title: mission?.title || mission?.name || "Untitled Mission",
                    status: mission?.status || (mission?.completed ? "completed" : "pending"),
                    priority: mission?.priority || mission?.level || null,
                    reward_pp: Number(mission?.reward_pp || mission?.pp || mission?.reward || 0),
                    mission_date: mission?.date || mission?.mission_date || null,
                    raw_data: mission
                });
            });
        }
    });
    return rows;
}

// ------------------------------
// SYNC FUNCTIONS
// ------------------------------
async function syncSyllabusMirror(userKey, token) {
    const rows = buildSyllabusRows(userKey);
    await clearSupabaseTable("syllabus_progress", userKey, token);
    if (rows.length > 0) await supabaseInsert("syllabus_progress", rows, token);
    console.log("✅ Syllabus sync done —", rows.length, "rows");
}

async function syncNotebooksMirror(userKey, token) {
    const rows = buildNotebookRows(userKey);
    await clearSupabaseTable("notebooks", userKey, token);
    if (rows.length > 0) await supabaseInsert("notebooks", rows, token);
    console.log("✅ Notebooks sync done —", rows.length, "rows");
}

async function syncCalendarMirror(userKey, token) {
    const rows = buildCalendarRows(userKey);
    await clearSupabaseTable("calendar_events", userKey, token);
    if (rows.length > 0) await supabaseInsert("calendar_events", rows, token);
    console.log("✅ Calendar sync done —", rows.length, "rows");
}

async function syncMissionsMirror(userKey, token) {
    const rows = buildMissionRows(userKey);
    await clearSupabaseTable("missions", userKey, token);
    if (rows.length > 0) await supabaseInsert("missions", rows, token);
    console.log("✅ Missions sync done —", rows.length, "rows");
}

// ------------------------------
// MAIN — ye index.html call karta hai
// ------------------------------
async function migrateCoreLocalStorageToSupabase() {
    console.log("========== SMART PADHAI MIRROR SYNC STARTED ==========");

    // userSession.js ne pehle se save kar diya hai
    const userKey = localStorage.getItem('_current_user_id');
    const token = localStorage.getItem('_current_user_token');

    if (!userKey || !token) {
        console.error("[Migration] ❌ No user session — aborting.");
        return;
    }

    console.log("[Migration] ✅ Syncing for:", userKey);

    await syncSyllabusMirror(userKey, token);
    await syncNotebooksMirror(userKey, token);
    await syncCalendarMirror(userKey, token);
    await syncMissionsMirror(userKey, token);

    console.log("========== SMART PADHAI MIRROR SYNC FINISHED ==========");
}