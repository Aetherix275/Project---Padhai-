/**
 * AESTRA AI - Tactical Decision Engine (Phase 4)
 *
 * Strategic commander layer that generates behavior-aware tactical plans,
 * balancing pressure, recovery, risk prevention, and priority attack.
 */
(function attachTacticalEngine(global) {
  const DEBUG_PREFIX = '[AESTRA TacticalEngine]';

  function getBus() {
    return global.AESTRA_EVENT_BUS || null;
  }

  function collectInputs(context = {}) {
    const telemetry = global.TelemetryStore?.latestSnapshot?.() || null;
    const state = global.StateEngine?.getCurrentState?.() || null;
    const behavior = global.MemoryCore?.getBehaviorProfile?.() || {};
    const weakness = global.MemoryCore?.getWeaknessProfile?.() || {};
    const recovery = global.MemoryCore?.getRecoveryProfile?.() || {};

    return {
      telemetry,
      currentState: state,
      behavior: { ...behavior, recoveryBehavior: recovery.recoveryBehavior },
      weakness,
      backlogSize: Number(context.backlogSize ?? 0),
      upcomingDeadlines: Number(context.upcomingDeadlines ?? 0)
    };
  }

  /**
   * Weighted, stackable tactical planner.
   * - Scores all strategy profiles
   * - Selects top stack (not single rigid branch)
   * - Creates tactical confidence from signal quality + score separation
   */
  function generateTacticalPlan(context = {}) {
    if (!global.AESTRA_TACTICAL_RULES || !global.AESTRA_TACTICAL_STRATEGIES) return null;

    const payload = collectInputs(context);
    if (!payload.telemetry) {
      console.debug(`${DEBUG_PREFIX} No telemetry yet; tactical plan skipped.`);
      return null;
    }

    const signals = global.AESTRA_TACTICAL_RULES.normalizeInputs(payload);
    const { STRATEGIES, scoreStrategy } = global.AESTRA_TACTICAL_STRATEGIES;

    const ranked = Object.entries(STRATEGIES).map(([id, strategy]) => ({
      id,
      title: strategy.title,
      category: strategy.category,
      score: scoreStrategy(strategy, signals),
      actions: strategy.actions
    })).sort((a, b) => b.score - a.score);

    const primary = ranked[0];
    const secondary = ranked[1];
    const stacked = ranked.filter((r) => r.score >= 45).slice(0, 3);

    const distinctActions = [...new Set(stacked.flatMap((s) => s.actions))];
    const confidence = Math.max(0, Math.min(100,
      Math.round((primary.score * 0.6) + ((primary.score - (secondary?.score || 0)) * 0.4))
    ));

    const tacticalPlan = {
      generatedAt: new Date().toISOString(),
      currentState: payload.currentState,
      signals,
      primaryStrategy: primary,
      stackedStrategies: stacked,
      recommendations: distinctActions,
      confidence,
      meta: {
        backlogSize: payload.backlogSize,
        upcomingDeadlines: payload.upcomingDeadlines,
        strategyCount: stacked.length
      }
    };

    getBus()?.emit?.('TACTICAL_PLAN_UPDATED', tacticalPlan);
    console.info(`${DEBUG_PREFIX} TACTICAL_PLAN_UPDATED`, tacticalPlan);
    return tacticalPlan;
  }

  const TacticalEngine = {
    init() {
      // Rebuild plan whenever states/memory are updated for adaptive behavior.
      getBus()?.on?.('STATE_CHANGED', () => generateTacticalPlan());
      getBus()?.on?.('MEMORY_UPDATED', () => generateTacticalPlan());
      generateTacticalPlan();
      console.info(`${DEBUG_PREFIX} Initialized.`);
    },
    generateTacticalPlan
  };

  global.TacticalEngine = TacticalEngine;
  document.addEventListener('DOMContentLoaded', () => {
    try {
      TacticalEngine.init();
    } catch (error) {
      console.error(`${DEBUG_PREFIX} Init failed`, error);
    }
  });
})(window);
