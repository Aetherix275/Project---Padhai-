/**
 * AESTRA Core - System Priority Arbitration
 * Assigns weighted priority scores to subsystem outputs for conflict prevention.
 */
(function attachSystemPriority(global) {
  const PRIORITY_WEIGHTS = {
    pressure: 1.0,
    tactical: 0.8,
    personality: 0.55,
    memory: 0.45,
    state: 0.65,
    observer: 0.35
  };

  function computePriority(packet) {
    const channel = packet.channel || 'observer';
    const base = PRIORITY_WEIGHTS[channel] ?? 0.4;
    const urgencyBoost = packet.urgencyLevel === 'CRITICAL' ? 0.45 : packet.urgencyLevel === 'HIGH' ? 0.25 : 0;
    const confidenceBoost = ((Number(packet.confidence) || 0) / 100) * 0.30;
    return Math.round((base + urgencyBoost + confidenceBoost) * 100);
  }

  function comparePriority(a, b) {
    return computePriority(b) - computePriority(a);
  }

  global.AESTRA_SYSTEM_PRIORITY = { PRIORITY_WEIGHTS, computePriority, comparePriority };
})(window);
