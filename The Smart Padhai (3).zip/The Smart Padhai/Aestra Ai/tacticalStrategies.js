/**
 * AESTRA AI - Tactical Strategy Profiles
 *
 * Strategy stacking model:
 * Multiple tactical recommendations can co-exist.
 * Each strategy has weighted drivers and action payload templates.
 */
(function attachTacticalStrategies(global) {
  const STRATEGIES = {
    reduce_workload: {
      title: 'Reduce Workload Intensity',
      category: 'anti_burnout',
      weights: { inactivityLoad: 0.30, riskBand: 0.25, collapseExposure: 0.20, focusLevel: -0.15, backlogPressure: 0.10 },
      actions: ['reduce workload', 'suggest recovery session', 'assign quick-win tasks']
    },
    increase_focus_pressure: {
      title: 'Increase Focus Pressure',
      category: 'discipline_push',
      weights: { focusLevel: -0.25, completionRate: -0.20, backlogPressure: 0.25, deadlinePressure: 0.20, streakStrength: -0.10 },
      actions: ['increase focus pressure', 'assign quick-win tasks']
    },
    push_high_weightage_subjects: {
      title: 'Push High-Weightage Subjects',
      category: 'priority_attack',
      weights: { deadlinePressure: 0.35, backlogPressure: 0.25, completionRate: -0.10, focusLevel: 0.10, streakStrength: 0.10, riskBand: 0.10 },
      actions: ['push high-weightage subjects']
    },
    suggest_recovery_session: {
      title: 'Recovery Protocol',
      category: 'recovery',
      weights: { recoveryStrength: -0.25, inactivityLoad: 0.25, riskBand: 0.20, focusLevel: -0.15, collapseExposure: 0.15 },
      actions: ['suggest recovery session', 'reduce workload']
    },
    activate_emergency_mode: {
      title: 'Emergency Mode',
      category: 'collapse_prevention',
      weights: { riskBand: 0.35, collapseExposure: 0.25, deadlinePressure: 0.20, focusLevel: -0.10, completionRate: -0.10 },
      actions: ['activate emergency mode', 'assign quick-win tasks', 'reduce workload']
    }
  };

  function scoreStrategy(strategy, signals) {
    const raw = Object.entries(strategy.weights).reduce((acc, [k, w]) => acc + ((signals[k] || 0) * w), 0);
    return Math.max(0, Math.min(100, Math.round(raw)));
  }

  global.AESTRA_TACTICAL_STRATEGIES = { STRATEGIES, scoreStrategy };
})(window);
