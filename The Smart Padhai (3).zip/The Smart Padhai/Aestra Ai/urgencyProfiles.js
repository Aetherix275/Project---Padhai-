/**
 * AESTRA AI - Urgency Profiles (Phase 6)
 * Pressure posture presets used by Psychological Pressure Engine.
 */
(function attachUrgencyProfiles(global) {
  const URGENCY_PROFILES = {
    LOW: { label: 'Low', color: '#4caf50', signalWeight: 0.25, narration: 'subtle' },
    GUARDED: { label: 'Guarded', color: '#8bc34a', signalWeight: 0.45, narration: 'measured' },
    ELEVATED: { label: 'Elevated', color: '#ffc107', signalWeight: 0.65, narration: 'firm' },
    HIGH: { label: 'High', color: '#ff9800', signalWeight: 0.80, narration: 'sharp' },
    CRITICAL: { label: 'Critical', color: '#f44336', signalWeight: 1.00, narration: 'command' }
  };

  global.AESTRA_URGENCY_PROFILES = URGENCY_PROFILES;
})(window);
