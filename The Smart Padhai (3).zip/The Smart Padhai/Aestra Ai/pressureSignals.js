/**
 * AESTRA AI - Pressure Signals
 * Converts cross-engine context into normalized pressure signals.
 */
(function attachPressureSignals(global) {
  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

  function extractSignals(input) {
    const telemetry = input.telemetry || {};
    const metrics = telemetry.metrics || {};
    const tactical = input.tactical || {};
    const state = input.state || 'UNKNOWN';
    const weakness = input.weakness || {};
    const behavior = input.behavior || {};

    const risk = telemetry.riskLevel === 'high' ? 100 : telemetry.riskLevel === 'medium' ? 60 : 25;
    const focusDrop = clamp(100 - (Number(telemetry.focusLevel) || 0), 0, 100);
    const inactivityLoad = clamp(((Number(metrics.mouseInactivityMs) || 0) / (35 * 60000)) * 100, 0, 100);
    const backlogPressure = clamp(((Number(tactical.meta?.backlogSize) || 0) / 25) * 100, 0, 100);
    const deadlinePressure = clamp(((Number(tactical.meta?.upcomingDeadlines) || 0) / 8) * 100, 0, 100);
    const tacticalUncertainty = clamp(100 - (Number(tactical.confidence) || 0), 0, 100);
    const narrativeUncertainty = clamp(100 - (Number(input.narrativeConfidence) || 0), 0, 100);
    const collapseExposure = clamp((Number((weakness.commonCollapsePatterns || []).length) || 0) * 5, 0, 100);
    const streak = Number((behavior.streakHistory || []).slice(-1)[0]?.streak || 0);
    const streakFragility = clamp(100 - (streak * 8), 0, 100);

    const collapseStatePenalty = (state === 'COLLAPSING' || state === 'GHOSTING') ? 100 : 0;
    const recoveryMomentum = clamp((Number(behavior.averageFocusTrends?.weeklyAverageFocus) || 0), 0, 100);

    return {
      risk,
      focusDrop,
      inactivityLoad,
      backlogPressure,
      deadlinePressure,
      tacticalUncertainty,
      narrativeUncertainty,
      collapseExposure,
      streakFragility,
      collapseStatePenalty,
      recoveryMomentum
    };
  }

  global.AESTRA_PRESSURE_SIGNALS = { extractSignals, clamp };
})(window);
