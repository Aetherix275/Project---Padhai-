/**
 * AESTRA AI - Pressure Rules
 * Weighted escalation model for adaptive pressure intensity.
 */
(function attachPressureRules(global) {
  const WEIGHTS = {
    risk: 0.16,
    focusDrop: 0.12,
    inactivityLoad: 0.12,
    backlogPressure: 0.10,
    deadlinePressure: 0.10,
    tacticalUncertainty: 0.08,
    narrativeUncertainty: 0.07,
    collapseExposure: 0.10,
    streakFragility: 0.07,
    collapseStatePenalty: 0.08,
    recoveryMomentum: -0.10
  };

  function computeIntensity(signals) {
    const raw = Object.entries(WEIGHTS).reduce((acc, [key, w]) => acc + ((signals[key] || 0) * w), 0);
    return Math.max(0, Math.min(100, Math.round(raw)));
  }

  function mapUrgencyLevel(intensity) {
    if (intensity >= 85) return 'CRITICAL';
    if (intensity >= 70) return 'HIGH';
    if (intensity >= 55) return 'ELEVATED';
    if (intensity >= 35) return 'GUARDED';
    return 'LOW';
  }

  global.AESTRA_PRESSURE_RULES = { WEIGHTS, computeIntensity, mapUrgencyLevel };
})(window);
