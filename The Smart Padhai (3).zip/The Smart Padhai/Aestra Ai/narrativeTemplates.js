/**
 * AESTRA AI - Narrative Templates
 * Dynamic sentence blocks by intent and tone.
 */
(function attachNarrativeTemplates(global) {
  const NARRATIVE_TEMPLATES = {
    observation: [
      'Focus vector at {focusLevel}% with {riskLevel} risk pressure.',
      'Behavior scan: state={state}, confidence={stateConfidence}%.',
      'Telemetry reads momentum={energyPattern}, task completion={completionRate}%.',
      'Strategic status: {state} posture with {tacticalConfidence}% tactical confidence.'
    ],
    tactical: [
      'Primary directive: {primaryAction}.',
      'Stacked protocol: {stackedActions}.',
      'Priority lane: backlog={backlogSize}, deadlines={upcomingDeadlines}.',
      'Action package: execute {primaryAction} before context drift expands.'
    ],
    pressure: [
      'Distraction debt detected; tighten execution window now.',
      'Delay tax is increasing. Immediate discipline response recommended.',
      'Current signal spread indicates potential collapse escalation.',
      'Commitment lag detected: convert intention into a completed action.'
    ],
    recovery: [
      'Recovery lane open: stabilize rhythm with one quick-win cycle.',
      'You are not resetting from zero; resume from the last stable checkpoint.',
      'Reduce cognitive load, then rebuild pressure with short focus intervals.',
      'Recovery protocol: protect consistency first, intensity second.'
    ],
    briefing: [
      'Command brief: {state} -> {primaryAction} with confidence {tacticalConfidence}%.',
      'Operational brief: preserve momentum and neutralize drift vectors.',
      'System brief: execute top stack, monitor risk, reassess after one cycle.',
      'Mission brief: high-value tasks first, noise channels suppressed.'
    ]
  };

  global.AESTRA_NARRATIVE_TEMPLATES = NARRATIVE_TEMPLATES;
})(window);
