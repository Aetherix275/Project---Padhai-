/**
 * AESTRA Core - Sync Manager
 * Coordinates batching, timing, cooldowns, and unified snapshot assembly.
 */
(function attachSyncManager(global) {
  const CORE_COOLDOWN_MS = 5000;

  function createSyncManager() {
    let lastCoreEmitAt = 0;
    let tickCount = 0;

    const unified = {
      telemetry: null,
      state: null,
      tactical: null,
      pressure: null,
      narrative: null,
      memory: null,
      health: {
        subsystemFreshnessMs: {},
        contradictorySignalsBlocked: 0,
        batchedUpdates: 0,
        cooldownBlocks: 0,
        tickCount: 0
      },
      diagnostics: {
        lastEvents: [],
        droppedNarratives: 0,
        arbitrationDecisions: []
      },
      updatedAt: null
    };

    const freshness = {};

    function markFresh(channel) {
      freshness[channel] = Date.now();
      const now = Date.now();
      Object.keys(freshness).forEach((key) => {
        unified.health.subsystemFreshnessMs[key] = now - freshness[key];
      });
    }

    function canEmit() {
      const now = Date.now();
      const remain = CORE_COOLDOWN_MS - (now - lastCoreEmitAt);
      if (remain > 0) {
        unified.health.cooldownBlocks += 1;
        return false;
      }
      lastCoreEmitAt = now;
      return true;
    }

    return {
      unified,
      markFresh,
      onBatch(events) {
        tickCount += 1;
        unified.health.tickCount = tickCount;
        unified.health.batchedUpdates += 1;
        unified.diagnostics.lastEvents = events.slice(-12).map((e) => ({ name: e.eventName, at: e.receivedAt }));
      },
      shouldEmit: canEmit
    };
  }

  global.AESTRA_SYNC_MANAGER_FACTORY = { createSyncManager };
})(window);
