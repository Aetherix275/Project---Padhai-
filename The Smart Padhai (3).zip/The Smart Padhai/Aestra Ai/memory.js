/**
 * AESTRA AI - Memory Core (Phase 3)
 *
 * Persistent behavioral memory layer:
 * - builds daily/weekly summaries
 * - detects collapse/comeback patterns
 * - stores long-term fingerprints (habits, weaknesses, recoveries)
 */
(function attachMemoryCore(global) {
  const DEBUG_PREFIX = '[AESTRA MemoryCore]';

  function getBus() {
    if (global.AESTRA_EVENT_BUS && typeof global.AESTRA_EVENT_BUS.emit === 'function') return global.AESTRA_EVENT_BUS;
    return null;
  }

  function getSnapshots() {
    return global.TelemetryStore?.loadSnapshots?.() || [];
  }

  function getStateHistory(memory) {
    return Array.isArray(memory.historicalStates) ? memory.historicalStates : [];
  }

  function appendStateRecord(stateData) {
    const patterns = global.AESTRA_MEMORY_PATTERNS;
    if (!patterns) return;
    const memory = patterns.loadMemory();
    memory.historicalStates = getStateHistory(memory).concat({
      state: stateData.state,
      previousState: stateData.previousState || null,
      sourceTimestamp: stateData.sourceTimestamp || null,
      evaluatedAt: stateData.evaluatedAt || new Date().toISOString(),
      score: stateData.score || 0,
      confidence: stateData.confidence || 0
    }).slice(-500);
    memory.updatedAt = new Date().toISOString();
    patterns.saveMemory(memory);
  }

  function runSummaries() {
    const patterns = global.AESTRA_MEMORY_PATTERNS;
    if (!patterns) return null;
    const snapshots = getSnapshots();
    if (!snapshots.length) {
      console.debug(`${DEBUG_PREFIX} No telemetry snapshots yet.`);
      return null;
    }

    const memory = patterns.loadMemory();
    const states = getStateHistory(memory);
    const today = new Date().toISOString().slice(0, 10);
    const currentWeek = patterns.weekKey(new Date().toISOString());

    // Daily summary interval: once per UTC day.
    if (memory.meta.lastDailySummaryDate !== today) {
      const hourly = patterns.summarizeHourlyWindows(snapshots);
      memory.strongestStudyHours = hourly.strongest;
      memory.weakestProductivityPeriods = hourly.weakest;
      memory.averageFocusTrends = patterns.computeFocusTrend(snapshots);

      const latestDaily = memory.averageFocusTrends.daily[memory.averageFocusTrends.daily.length - 1] || { avgFocus: 0 };
      patterns.updateStreakHistory(memory, {
        date: today,
        avgFocus: latestDaily.avgFocus,
        stateQuality: patterns.summarizeStateQuality(states, today)
      });

      memory.meta.lastDailySummaryDate = today;
      console.info(`${DEBUG_PREFIX} Daily summary updated`, { today });
    }

    // Weekly summary interval: once per week key.
    if (memory.meta.lastWeeklySummaryWeekKey !== currentWeek) {
      memory.commonCollapsePatterns = patterns.detectCollapsePatterns(snapshots, states);
      memory.recoveryBehavior = patterns.detectRecoveryBehavior(states);
      memory.meta.lastWeeklySummaryWeekKey = currentWeek;
      console.info(`${DEBUG_PREFIX} Weekly summary updated`, { currentWeek });
    }

    // Comeback + collapse detection on latest state transition window.
    const latestStates = states.slice(-6);
    const collapseDetected = latestStates.some((s) => s.state === 'COLLAPSING' || s.state === 'GHOSTING');
    const comebackDetected = latestStates.some((s) => s.state === 'REBORN' || s.state === 'OVERDRIVE');

    memory.updatedAt = new Date().toISOString();
    patterns.saveMemory(memory);

    const memoryData = {
      ...memory,
      detections: { collapseDetected, comebackDetected }
    };

    getBus()?.emit('MEMORY_UPDATED', memoryData);
    console.info(`${DEBUG_PREFIX} MEMORY_UPDATED`, {
      strongestStudyHours: memory.strongestStudyHours,
      weakestProductivityPeriods: memory.weakestProductivityPeriods,
      detections: memoryData.detections
    });

    return memoryData;
  }

  const MemoryCore = {
    init() {
      getBus()?.on?.('STATE_CHANGED', appendStateRecord);
      runSummaries();
      // Memory summarization runs every hour; daily/weekly guards prevent over-writing noise.
      setInterval(runSummaries, 60 * 60 * 1000);
      console.info(`${DEBUG_PREFIX} Initialized.`);
    },
    updateNow() {
      return runSummaries();
    },
    getBehaviorProfile() {
      const m = global.AESTRA_MEMORY_PATTERNS?.loadMemory?.();
      return {
        strongestStudyHours: m?.strongestStudyHours || [],
        averageFocusTrends: m?.averageFocusTrends || { daily: [], weeklyAverageFocus: 0 },
        streakHistory: m?.streakHistory || []
      };
    },
    getWeaknessProfile() {
      const m = global.AESTRA_MEMORY_PATTERNS?.loadMemory?.();
      return {
        weakestProductivityPeriods: m?.weakestProductivityPeriods || [],
        commonCollapsePatterns: m?.commonCollapsePatterns || []
      };
    },
    getRecoveryProfile() {
      const m = global.AESTRA_MEMORY_PATTERNS?.loadMemory?.();
      return {
        recoveryBehavior: m?.recoveryBehavior || { avgRecoveryMinutes: 0, successfulRecoveries: 0, recoveryWindows: [] },
        historicalStates: (m?.historicalStates || []).slice(-30)
      };
    }
  };

  global.MemoryCore = MemoryCore;
  document.addEventListener('DOMContentLoaded', () => {
    try {
      MemoryCore.init();
    } catch (error) {
      console.error(`${DEBUG_PREFIX} Init failed`, error);
    }
  });
})(window);
