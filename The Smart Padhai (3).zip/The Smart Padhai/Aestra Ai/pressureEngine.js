/**
 * AESTRA AI - Psychological Pressure Engine (Phase 6)
 *
 * Behavioral pressure framework (not motivation spam):
 * - escalates urgency from measurable risk
 * - supports silent pressure posture
 * - reinforces identity via tactical narration cues
 * - cooldown gate prevents notification fatigue
 */
(function attachPressureEngine(global) {
  const DEBUG_PREFIX = '[AESTRA PressureEngine]';
  const COOLDOWN_MS = 8 * 60 * 1000;
  let lastNotificationAt = 0;

  function getBus() {
    return global.AESTRA_EVENT_BUS || null;
  }

  function gatherContext() {
    return {
      telemetry: global.TelemetryStore?.latestSnapshot?.() || null,
      state: global.StateEngine?.getCurrentState?.() || null,
      tactical: global.TacticalEngine?.generateTacticalPlan?.() || null,
      behavior: global.MemoryCore?.getBehaviorProfile?.() || {},
      weakness: global.MemoryCore?.getWeaknessProfile?.() || {},
      narrativeConfidence: global.PersonalityEngine?.generateNarrative?.()?.confidence || 0
    };
  }

  function buildMessages(level, state) {
    const identityLine = state === 'OVERDRIVE'
      ? 'Identity lock: operator-grade execution must remain uncompromised.'
      : 'Identity lock: discipline is proven through immediate action, not intent.';

    const momentumLine = level === 'LOW' || level === 'GUARDED'
      ? 'Momentum reinforcement: maintain cadence and close one task now.'
      : 'Momentum reinforcement: eliminate drift and execute the next high-value step.';

    const warningLine = level === 'CRITICAL'
      ? 'Collapse momentum is accelerating. Emergency containment recommended.'
      : 'Pressure vector detected. Stay inside tactical lane.';

    return { identityLine, momentumLine, warningLine };
  }

  /**
   * Escalation logic:
   * - weighted pressure intensity (0..100)
   * - urgency level mapping
   * - silent pressure mode for mid bands (subtle UI over noisy notifications)
   */
  function generatePressureState() {
    if (!global.AESTRA_PRESSURE_SIGNALS || !global.AESTRA_PRESSURE_RULES || !global.AESTRA_URGENCY_PROFILES) return null;

    const context = gatherContext();
    if (!context.telemetry || !context.tactical) {
      console.debug(`${DEBUG_PREFIX} Missing context; pressure generation skipped.`);
      return null;
    }

    const signals = global.AESTRA_PRESSURE_SIGNALS.extractSignals(context);
    const intensity = global.AESTRA_PRESSURE_RULES.computeIntensity(signals);
    const urgencyLevel = global.AESTRA_PRESSURE_RULES.mapUrgencyLevel(intensity);
    const urgencyProfile = global.AESTRA_URGENCY_PROFILES[urgencyLevel];

    const silentMode = intensity >= 35 && intensity < 70;
    const messages = buildMessages(urgencyLevel, context.state);
    const recommendations = [];

    if (intensity >= 80) recommendations.push('activate emergency mode');
    if (intensity >= 65) recommendations.push('reduce workload');
    if (intensity >= 55) recommendations.push('increase focus pressure');
    if (intensity < 55) recommendations.push('assign quick-win tasks');
    if (context.state === 'REBORN') recommendations.push('suggest recovery session');

    // Cooldown behavior:
    // - prevents repetitive alert spam during volatile windows.
    const now = Date.now();
    const cooldownRemainingMs = Math.max(0, COOLDOWN_MS - (now - lastNotificationAt));
    const canNotify = cooldownRemainingMs === 0;
    const shouldNotify = canNotify && (urgencyLevel === 'HIGH' || urgencyLevel === 'CRITICAL');
    if (shouldNotify) lastNotificationAt = now;

    const pressureData = {
      generatedAt: new Date().toISOString(),
      intensity,
      urgencyLevel,
      urgencyProfile,
      silentMode,
      adaptiveWarningLevel: urgencyLevel,
      subtleUIState: {
        accentColor: urgencyProfile.color,
        pulse: urgencyProfile.signalWeight,
        mode: silentMode ? 'silent-pressure' : 'active-pressure'
      },
      recommendations: [...new Set(recommendations)],
      momentumReinforcementMessages: [messages.identityLine, messages.momentumLine],
      pressureAlerts: shouldNotify ? [messages.warningLine] : [],
      cooldown: {
        canNotify,
        cooldownRemainingMs
      },
      signals
    };

    getBus()?.emit?.('PRESSURE_STATE_UPDATED', pressureData);
    console.info(`${DEBUG_PREFIX} PRESSURE_STATE_UPDATED`, pressureData);
    return pressureData;
  }

  const PressureEngine = {
    init() {
      // Evolve pressure whenever tactical/state/memory/narrative context changes.
      getBus()?.on?.('TACTICAL_PLAN_UPDATED', () => generatePressureState());
      getBus()?.on?.('STATE_CHANGED', () => generatePressureState());
      getBus()?.on?.('MEMORY_UPDATED', () => generatePressureState());
      getBus()?.on?.('NARRATIVE_UPDATED', () => generatePressureState());
      generatePressureState();
      console.info(`${DEBUG_PREFIX} Initialized.`);
    },
    generatePressureState
  };

  global.PressureEngine = PressureEngine;
  document.addEventListener('DOMContentLoaded', () => {
    try {
      PressureEngine.init();
    } catch (error) {
      console.error(`${DEBUG_PREFIX} Init failed`, error);
    }
  });
})(window);
