/**
 * AESTRA AI - State Engine Rules
 * Weighted scoring profiles for behavior-state interpretation.
 */
(function attachStateRules(global) {
  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

  // Normalize raw telemetry metrics to 0..100 scales for weighted math.
  function normalizeTelemetry(snapshot) {
    const safe = snapshot || {};
    const metrics = safe.metrics || {};

    const focusLevel = clamp(Number(safe.focusLevel) || 0, 0, 100);
    const inactivityMin = Math.max(0, (Number(metrics.mouseInactivityMs) || 0) / 60000);
    const tabSwitches = Math.max(0, Number(metrics.tabSwitches) || 0);
    const completionRate = clamp(Math.round((Number(metrics.taskCompletionRate) || 0) * 100), 0, 100);
    const focusModeMin = Math.max(0, (Number(metrics.focusModeDurationMs) || 0) / 60000);
    const studyMin = Math.max(0, (Number(metrics.studySessionDurationMs) || 0) / 60000);

    return {
      focusLevel,
      inactivityLoad: clamp((inactivityMin / 25) * 100, 0, 100),
      tabNoise: clamp((tabSwitches / 12) * 100, 0, 100),
      completionRate,
      focusModeConsistency: clamp((focusModeMin / 90) * 100, 0, 100),
      sessionDepth: clamp((studyMin / 180) * 100, 0, 100)
    };
  }

  // Positive means signal helps the state, negative means it harms the state.
  const STATE_PROFILES = {
    LOCKED_IN: {
      description: 'High concentration, low distraction, stable execution.',
      weights: { focusLevel: 0.30, completionRate: 0.25, focusModeConsistency: 0.20, sessionDepth: 0.15, tabNoise: -0.05, inactivityLoad: -0.05 }
    },
    FRACTURED: {
      description: 'Attention split across tabs/tasks, momentum unstable.',
      weights: { tabNoise: 0.35, inactivityLoad: 0.20, focusLevel: -0.20, completionRate: -0.15, focusModeConsistency: -0.05, sessionDepth: 0.05 }
    },
    COLLAPSING: {
      description: 'Energy and output trending down with inactivity spikes.',
      weights: { inactivityLoad: 0.40, focusLevel: -0.25, completionRate: -0.20, sessionDepth: -0.05, tabNoise: 0.05, focusModeConsistency: -0.05 }
    },
    GHOSTING: {
      description: 'Present in session but behavior indicates disengagement.',
      weights: { inactivityLoad: 0.35, completionRate: -0.25, focusLevel: -0.15, focusModeConsistency: -0.10, sessionDepth: 0.10, tabNoise: 0.05 }
    },
    REBORN: {
      description: 'Recovery pattern: focus and task execution climbing again.',
      weights: { focusLevel: 0.30, completionRate: 0.30, sessionDepth: 0.15, focusModeConsistency: 0.15, inactivityLoad: -0.05, tabNoise: -0.05 }
    },
    OVERDRIVE: {
      description: 'Very high sustained output and strong control state.',
      weights: { focusLevel: 0.35, completionRate: 0.25, focusModeConsistency: 0.20, sessionDepth: 0.15, inactivityLoad: -0.03, tabNoise: -0.02 }
    }
  };

  function scoreState(profile, signals, previousState) {
    const scoreRaw = Object.entries(profile.weights).reduce((acc, [signal, weight]) => {
      return acc + ((signals[signal] || 0) * weight);
    }, 0);

    // Stateful bias: REBORN favors transitions out of degraded states.
    const reboundBonus = (previousState === 'COLLAPSING' || previousState === 'GHOSTING') ? 7 : 0;
    const rebornAdjusted = profile === STATE_PROFILES.REBORN ? scoreRaw + reboundBonus : scoreRaw;

    return clamp(Math.round(rebornAdjusted), 0, 100);
  }

  global.AESTRA_STATE_RULES = {
    normalizeTelemetry,
    STATE_PROFILES,
    scoreState
  };
})(window);
