/**
 * AESTRA AI - Memory Pattern Library (Phase 3)
 *
 * This module transforms raw telemetry/state traces into durable behavioral memory.
 * It intentionally summarizes patterns instead of storing every low-level event.
 */
(function attachMemoryPatterns(global) {
  const MEMORY_KEY = 'aestra_memory_core_v1';

  const DEFAULT_MEMORY = {
    updatedAt: null,
    strongestStudyHours: [],
    weakestProductivityPeriods: [],
    commonCollapsePatterns: [],
    recoveryBehavior: { avgRecoveryMinutes: 0, successfulRecoveries: 0, recoveryWindows: [] },
    streakHistory: [],
    historicalStates: [],
    averageFocusTrends: { daily: [], weeklyAverageFocus: 0 },
    meta: { lastDailySummaryDate: null, lastWeeklySummaryWeekKey: null }
  };

  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

  function safeParse(raw) {
    try { return JSON.parse(raw); } catch (_) { return null; }
  }

  function loadMemory() {
    const parsed = safeParse(localStorage.getItem(MEMORY_KEY));
    return parsed && typeof parsed === 'object' ? { ...DEFAULT_MEMORY, ...parsed } : { ...DEFAULT_MEMORY };
  }

  function saveMemory(memory) {
    localStorage.setItem(MEMORY_KEY, JSON.stringify(memory));
    return memory;
  }

  function weekKey(isoDate) {
    const d = new Date(isoDate);
    const jan1 = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const dayOfYear = Math.floor((d - jan1) / 86400000) + 1;
    const week = Math.ceil(dayOfYear / 7);
    return `${d.getUTCFullYear()}-W${week}`;
  }

  /**
   * Summarization logic:
   * - buckets snapshots by hour
   * - scores hour quality using focus + completion + low tab noise
   * - returns top/bottom behavioral windows
   */
  function summarizeHourlyWindows(snapshots) {
    const hourly = new Map();
    snapshots.forEach((s) => {
      const ts = new Date(s.timestamp);
      if (Number.isNaN(ts.getTime())) return;
      const hour = ts.getUTCHours();
      const m = s.metrics || {};
      const focus = Number(s.focusLevel) || 0;
      const completion = (Number(m.taskCompletionRate) || 0) * 100;
      const tabNoise = clamp(((Number(m.tabSwitches) || 0) / 10) * 100, 0, 100);
      const score = clamp((focus * 0.6) + (completion * 0.3) + ((100 - tabNoise) * 0.1), 0, 100);

      if (!hourly.has(hour)) hourly.set(hour, { hour, totalScore: 0, count: 0 });
      const bucket = hourly.get(hour);
      bucket.totalScore += score;
      bucket.count += 1;
    });

    const ranked = [...hourly.values()].map((h) => ({
      hour: h.hour,
      avgScore: Math.round(h.totalScore / Math.max(1, h.count)),
      samples: h.count
    })).sort((a, b) => b.avgScore - a.avgScore);

    return {
      strongest: ranked.slice(0, 3),
      weakest: ranked.slice(-3).reverse()
    };
  }

  /**
   * Behavioral reasoning:
   * Collapse pattern is a pre-collapse telemetry fingerprint where
   * high inactivity and distraction co-occur before degraded states.
   */
  function detectCollapsePatterns(snapshots, states) {
    const byTs = new Map(snapshots.map((s) => [s.timestamp, s]));
    const collapseEvents = states.filter((s) => s.state === 'COLLAPSING' || s.state === 'GHOSTING');

    const patterns = collapseEvents.map((event) => {
      const snap = byTs.get(event.sourceTimestamp);
      const m = (snap && snap.metrics) || {};
      return {
        state: event.state,
        hourUTC: new Date(event.sourceTimestamp).getUTCHours(),
        inactivityMinutes: Math.round((Number(m.mouseInactivityMs) || 0) / 60000),
        tabSwitches: Number(m.tabSwitches) || 0,
        focusLevel: Number(snap?.focusLevel) || 0
      };
    });

    return patterns.slice(-20);
  }

  function detectRecoveryBehavior(states) {
    const transitions = [];
    for (let i = 1; i < states.length; i += 1) {
      const prev = states[i - 1];
      const curr = states[i];
      const prevBad = prev.state === 'COLLAPSING' || prev.state === 'GHOSTING';
      const currGood = curr.state === 'REBORN' || curr.state === 'LOCKED_IN' || curr.state === 'OVERDRIVE';
      if (!prevBad || !currGood) continue;
      const deltaMin = Math.max(0, Math.round((new Date(curr.evaluatedAt) - new Date(prev.evaluatedAt)) / 60000));
      transitions.push({ from: prev.state, to: curr.state, recoveryMinutes: deltaMin });
    }

    const avgRecoveryMinutes = transitions.length
      ? Math.round(transitions.reduce((a, b) => a + b.recoveryMinutes, 0) / transitions.length)
      : 0;

    return {
      avgRecoveryMinutes,
      successfulRecoveries: transitions.length,
      recoveryWindows: transitions.slice(-10)
    };
  }

  function computeFocusTrend(snapshots) {
    const daily = new Map();
    snapshots.forEach((s) => {
      const day = String(s.timestamp || '').slice(0, 10);
      if (!day) return;
      if (!daily.has(day)) daily.set(day, { sum: 0, count: 0 });
      const bucket = daily.get(day);
      bucket.sum += Number(s.focusLevel) || 0;
      bucket.count += 1;
    });

    const dailyTrend = [...daily.entries()].map(([date, v]) => ({
      date,
      avgFocus: Math.round(v.sum / Math.max(1, v.count))
    })).sort((a, b) => a.date.localeCompare(b.date));

    const weeklyAverageFocus = dailyTrend.length
      ? Math.round(dailyTrend.reduce((a, b) => a + b.avgFocus, 0) / dailyTrend.length)
      : 0;

    return { daily: dailyTrend.slice(-30), weeklyAverageFocus };
  }

  function updateStreakHistory(memory, todaySummary) {
    const prev = memory.streakHistory[memory.streakHistory.length - 1];
    const strongDay = todaySummary.avgFocus >= 65 && todaySummary.stateQuality >= 60;
    const streak = strongDay ? ((prev?.streak || 0) + 1) : 0;
    memory.streakHistory.push({ date: todaySummary.date, streak, strongDay });
    memory.streakHistory = memory.streakHistory.slice(-60);
  }

  function summarizeStateQuality(states, day) {
    const sameDay = states.filter((s) => String(s.evaluatedAt || '').slice(0, 10) === day);
    if (!sameDay.length) return 0;
    const scoreByState = { OVERDRIVE: 95, LOCKED_IN: 85, REBORN: 75, FRACTURED: 45, GHOSTING: 25, COLLAPSING: 15 };
    const total = sameDay.reduce((acc, s) => acc + (scoreByState[s.state] || 40), 0);
    return Math.round(total / sameDay.length);
  }

  global.AESTRA_MEMORY_PATTERNS = {
    MEMORY_KEY,
    loadMemory,
    saveMemory,
    weekKey,
    summarizeHourlyWindows,
    detectCollapsePatterns,
    detectRecoveryBehavior,
    computeFocusTrend,
    updateStreakHistory,
    summarizeStateQuality
  };
})(window);
