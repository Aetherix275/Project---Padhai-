/**
 * AESTRA AI - Telemetry Store
 * Handles persistence and timed snapshot writes for observer telemetry.
 */
(function attachTelemetryStore(global) {
  const STORAGE_KEY = 'aestra_observer_snapshots_v1';
  const MAX_SNAPSHOTS = 288; // Keep last 24h if sampled every 5 min.

  function safeParse(raw) {
    if (!raw) return [];
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      console.warn('[TelemetryStore] Corrupt snapshot data, resetting.', error);
      return [];
    }
  }

  const TelemetryStore = {
    loadSnapshots() {
      return safeParse(localStorage.getItem(STORAGE_KEY));
    },

    saveSnapshot(snapshot) {
      const current = this.loadSnapshots();
      current.push(snapshot);

      // Bounded list prevents unbounded localStorage growth.
      const trimmed = current.slice(-MAX_SNAPSHOTS);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
      return trimmed;
    },

    latestSnapshot() {
      const current = this.loadSnapshots();
      return current.length ? current[current.length - 1] : null;
    }
  };

  global.TelemetryStore = TelemetryStore;
})(window);
