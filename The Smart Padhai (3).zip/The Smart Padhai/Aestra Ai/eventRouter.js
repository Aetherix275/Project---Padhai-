/**
 * AESTRA Core - Event Router
 * Centralized routing + buffering to avoid direct subsystem coupling.
 */
(function attachEventRouter(global) {
  function createRouter() {
    const inbox = [];
    const handlers = {};

    return {
      route(eventName, payload) {
        inbox.push({ eventName, payload, receivedAt: new Date().toISOString() });
      },
      drain() {
        const batch = inbox.splice(0, inbox.length);
        batch.forEach((evt) => {
          (handlers[evt.eventName] || []).forEach((handler) => {
            try { handler(evt.payload, evt); } catch (error) { console.error('[AESTRA EventRouter] handler error', error); }
          });
        });
        return batch;
      },
      on(eventName, handler) {
        if (!handlers[eventName]) handlers[eventName] = [];
        handlers[eventName].push(handler);
      }
    };
  }

  global.AESTRA_EVENT_ROUTER_FACTORY = { createRouter };
})(window);
