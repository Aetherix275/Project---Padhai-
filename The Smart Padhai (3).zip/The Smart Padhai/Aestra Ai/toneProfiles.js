/**
 * AESTRA AI - Tone Profiles (Phase 5)
 * Defines voice modulation knobs for the Personality Engine.
 */
(function attachToneProfiles(global) {
  const TONE_PROFILES = {
    Tactical: { directness: 0.9, warmth: 0.2, pressure: 0.7, cadence: 'brief' },
    Cold: { directness: 0.95, warmth: 0.05, pressure: 0.8, cadence: 'short' },
    Mentor: { directness: 0.65, warmth: 0.75, pressure: 0.35, cadence: 'guided' },
    Brutal: { directness: 1.0, warmth: 0.0, pressure: 1.0, cadence: 'sharp' },
    Recovery: { directness: 0.55, warmth: 0.85, pressure: 0.25, cadence: 'calm' },
    Elite: { directness: 0.85, warmth: 0.3, pressure: 0.9, cadence: 'command' }
  };

  global.AESTRA_TONE_PROFILES = TONE_PROFILES;
})(window);
