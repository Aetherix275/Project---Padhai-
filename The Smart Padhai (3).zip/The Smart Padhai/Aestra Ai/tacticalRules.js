/**
 * AESTRA AI - Tactical Rules (Phase 4)
 *
 * Converts mixed behavioral inputs into normalized tactical signals.
 * This keeps Tactical Engine scoring composable and expansion-friendly.
 */
(function attachTacticalRules(global) {
  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

  function normalizeInputs(payload) {
    const telemetry = payload.telemetry || {};
    const metrics = telemetry.metrics || {};
    const memory = payload.memory || {};
    const behavior = payload.behavior || {};

    const focusLevel = clamp(Number(telemetry.focusLevel) || 0, 0, 100);
    const riskBand = telemetry.riskLevel === 'high' ? 100 : telemetry.riskLevel === 'medium' ? 60 : 25;
    const completionRate = clamp(Math.round((Number(metrics.taskCompletionRate) || 0) * 100), 0, 100);
    const inactivityLoad = clamp(((Number(metrics.mouseInactivityMs) || 0) / (30 * 60000)) * 100, 0, 100);
    const backlogPressure = clamp(((Number(payload.backlogSize) || 0) / 25) * 100, 0, 100);
    const deadlinePressure = clamp(((Number(payload.upcomingDeadlines) || 0) / 8) * 100, 0, 100);
    const streakStrength = clamp(Number((behavior.streakHistory || []).slice(-1)[0]?.streak || 0) * 10, 0, 100);
    const recoveryStrength = clamp(100 - Number(behavior.recoveryBehavior?.avgRecoveryMinutes || 0), 0, 100);
    const collapseExposure = clamp(Number((payload.weakness?.commonCollapsePatterns || []).length || 0) * 5, 0, 100);

    return {
      focusLevel,
      riskBand,
      completionRate,
      inactivityLoad,
      backlogPressure,
      deadlinePressure,
      streakStrength,
      recoveryStrength,
      collapseExposure
    };
  }

  global.AESTRA_TACTICAL_RULES = { normalizeInputs, clamp };
})(window);
