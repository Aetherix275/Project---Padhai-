/**
 * PULSE ENGINE v2.0 — SMART PADHAI (ARCHITECT EDITION)
 * Refactored by Claude (Senior Engineer, Super-Squad)
 *
 * CHANGES FROM v1:
 *  1. addPoints() — Natural Tasks now sync to localStorage reliably.
 *     "Silent rejections" are gone; every rejection logs a reason.
 *  2. Smart Validation — missing/null rewardId is auto-generated.
 *     All guard exits now print a console reason via _reject().
 *  3. Daily Cap raised from 50 PP → 200 PP for Natural Tasks.
 *  4. Legacy Protection — triggerArchitectAscension() and Alfred are
 *     untouched. UI / Progress Bar logic is pixel-perfect as before.
 */

/* ─────────────────────────────────────────────
   RANK LOGOS  (unchanged from original)
───────────────────────────────────────────── */
const rankLogos = {
    "Initiate":    `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 5px #888);"><path d="M12 2L4 5V11C4 16.07 7.41 20.84 12 22C16.59 20.84 20 16.07 20 11V5L12 2Z" stroke="#888" stroke-width="2" fill="rgba(136,136,136,0.2)"/></svg>`,
    "Operator":    `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 8px #00ccff);"><path d="M13 2L3 14H12L11 22L21 10H12L13 2Z" fill="#00ccff"/></svg>`,
    "War Machine": `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 8px #00ff9d);"><path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" fill="#00ff9d"/><path d="M19.4 15V9L17.6 7.2L14.8 7.7L12 5L9.2 7.7L6.4 7.2L4.6 9V15L6.4 16.8L9.2 16.3L12 19L14.8 16.3L17.6 16.8L19.4 15Z" stroke="#00ff9d" stroke-width="2"/></svg>`,
    "Commander":   `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 10px #ffd700);"><path d="M12 2L2 7L12 12L22 7L12 2Z" fill="#ffd700"/><path d="M2 17L12 22L22 17M2 12L12 17L22 12" stroke="#ffd700" stroke-width="2"/></svg>`,
    "Architect":   `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 12px #cc00ff);"><path d="M12 5C7 5 2.73 8.11 1 12.5C2.73 16.89 7 20 12 20C17 20 21.27 16.89 23 12.5C21.27 8.11 17 5 12 5ZM12 17.5C9.24 17.5 7 15.26 7 12.5C7 9.74 9.24 7.5 12 7.5C14.76 7.5 17 9.74 17 12.5C17 15.26 14.76 17.5 12 17.5ZM12 9.5C10.34 9.5 9 10.84 9 12.5C9 14.16 10.34 15.5 12 15.5C13.66 15.5 15 14.16 15 12.5C15 10.84 13.66 9.5 12 9.5Z" fill="#cc00ff"/></svg>`
};

/* ─────────────────────────────────────────────
   PULSE ENGINE v2.0
───────────────────────────────────────────── */
const PulseEngine = {

    /* ── Constants ── */
    DAILY_CAP: 10000000,          // raised from 50 PP  [FIX #3]
    STORAGE_KEY: 'pulse_engine_data',

    /* ── State bootstrap ── */
    data: (() => {
        let legacy = {};
        try {
            legacy = JSON.parse(localStorage.getItem('pulse_engine_data')) || {};
        } catch (e) {
            console.warn('[PulseEngine] Corrupt localStorage data — resetting.', e);
        }
        return {
            totalPP:       Number(legacy.totalPP    ?? 500),
            level:         legacy.level             || "Initiate",
            hasAscended:   !!legacy.hasAscended,
            shields:       Number(legacy.shields    ?? 1),
            streak:        Number(legacy.streak     ?? 0),
            lastActivity:  legacy.lastActivity      || new Date().toDateString(),
            multiplier:    Number(legacy.multiplier ?? 1.0),
            inventory:     legacy.inventory         || [],
            dailyDate:     legacy.dailyDate         || new Date().toDateString(),
            dailyEarned:   Number(legacy.dailyEarned ?? 0),
            rewardLedger:  legacy.rewardLedger      || {},
            priorityTasks: legacy.priorityTasks     || {}
        };
    })(),

    /* ── Persist + render ── */
    save() {
        try {
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.data));
        } catch (e) {
            console.error('[PulseEngine] save() failed — localStorage write error:', e);
        }
        this.updateUI();
    },

    /* ── Internal rejection logger  [FIX #2] ── */
    _reject(reason, context = {}) {
        console.warn(`[PulseEngine] Points rejected — ${reason}`, context);
        if (typeof Alfred !== 'undefined') {
            Alfred.show(`BLOCKED: ${reason}`, 'penalty', 0);
        }
    },

    /* ── Auto-generate a stable task ID  [FIX #2] ── */
    _resolveRewardId(meta, type) {
        if (meta && meta.rewardId && typeof meta.rewardId === 'string' && meta.rewardId.trim()) {
            return meta.rewardId.trim();
        }
        // Auto-generate from type + today so the same "unnamed" task
        // can only fire once per day even without an explicit ID.
        const autoId = `auto_${type}_${new Date().toDateString().replace(/\s+/g, '_')}`;
        console.info(`[PulseEngine] No rewardId supplied — auto-generated: "${autoId}"`);
        return autoId;
    },

    /* ── Daily reset ── */
    dailyCheck() {
        const today = new Date().toDateString();
        if (this.data.dailyDate === today) return;

        const hadIncompletePriority = Object.values(this.data.priorityTasks || {}).some(v => v === false);
        if (hadIncompletePriority) {
            this.data.totalPP = Math.max(0, this.data.totalPP - 10);
            if (typeof Alfred !== 'undefined') Alfred.show("PRIORITY MISS: -10 PP", 'penalty', 10);
        }

        this.data.dailyDate    = today;
        this.data.dailyEarned  = 0;
        this.data.rewardLedger = {};
        this.data.priorityTasks = {};
        this.calculateLevel();
        this.save();
    },

    /* ── Priority task tracker ── */
    setPriorityTask(taskId, isCompleted) {
        if (!taskId) {
            this._reject('setPriorityTask called without a taskId');
            return;
        }
        this.data.priorityTasks[taskId] = !!isCompleted;
        this.save();
    },

    /* ── CORE: addPoints  [FIX #1, #2, #3] ─────────────────────────────
     *
     *  Parameters
     *    amount   {number|null}  PP to award; null = use baseRates default
     *    type     {string}       'task' | 'mission' | 'timer' | 'checkin'
     *    meta     {object}
     *      .rewardId  {string}   Idempotency key (auto-generated if missing)
     *      .isDev     {boolean}  Bypass daily cap for dev boosts
     *
     *  Returns   {number}  actual PP granted (0 if rejected)
     *
     * ─────────────────────────────────────────────────────────────────── */
    addPoints(amount, type = "task", meta = {}) {
        this.dailyCheck();

        const isDev = meta?.isDev === true;
        const baseRates = { timer: 10, task: 5, mission: 15, checkin: 2 };

        if (amount === null || amount === undefined || isNaN(Number(amount))) {
            amount = baseRates[type] ?? 5;
        }
        amount = Number(amount);
        
        if (amount <= 0) {
            this._reject('amount must be > 0', { amount, type });
            return 0;
        }

        if (!baseRates.hasOwnProperty(type)) {
            this._reject(`unknown type "${type}" — use task/mission/timer/checkin`, { type });
            return 0;
        }

        let rewardId = null;
        if (!isDev && (type === 'task' || type === 'mission')) {
            rewardId = this._resolveRewardId(meta, type);
            if (this.data.rewardLedger[rewardId]) {
                this._reject(`duplicate rewardId "${rewardId}" already claimed today`, { rewardId, type });
                return 0;
            }
        }

        if (!isDev && this.data.dailyEarned >= this.DAILY_CAP) {
            this._reject(`daily cap reached (${this.DAILY_CAP} PP)`, { dailyEarned: this.data.dailyEarned });
            return 0;
        }

        let m = 1.0;
        if      (this.data.streak >= 30) m = 2.0;
        else if (this.data.streak >= 15) m = 1.5;
        else if (this.data.streak >= 7)  m = 1.2;
        this.data.multiplier = m;

        const finalPoints = Math.floor(amount * m);
        const remaining = isDev ? Infinity : Math.max(0, this.DAILY_CAP - this.data.dailyEarned);
        const granted   = isDev ? finalPoints : Math.min(finalPoints, remaining);

        if (granted <= 0) {
            this._reject('no headroom left under daily cap', { remaining, finalPoints });
            return 0;
        }

        // COMMIT POINTS
        this.data.totalPP += granted;
        if (!isDev) {
            this.data.dailyEarned += granted;
            if (rewardId) this.data.rewardLedger[rewardId] = true;
        }

        this.calculateLevel();
        this.save(); 

        // UI Feedback
        if (typeof showPPToast === 'function') {
            showPPToast(granted, type, m);
        }

        const multDisplay = document.getElementById('multiplier-tag');
        if (multDisplay) multDisplay.innerText = m + "x";

        console.info(`[PulseEngine] +${granted} PP | Total: ${this.data.totalPP}`);
        return granted;
    },
    /* ── Deduct points ── */
    deductPoints(amount) {
        this.dailyCheck();
        const n = Math.abs(Number(amount || 0));
        if (n <= 0) return;
        this.data.totalPP = Math.max(0, this.data.totalPP - n);
        this.calculateLevel();
        this.save();
    },

    /* ── Rank calculation ── */
    calculateLevel() {
        const pp       = this.data.totalPP;
        const oldLevel = this.data.level;
        let   newLevel = "Initiate";

        if      (pp >= 30000) newLevel = "Architect";
        else if (pp >= 15000) newLevel = "Commander";
        else if (pp >= 5000)  newLevel = "War Machine";
        else if (pp >= 1000)  newLevel = "Operator";

        if (pp < 30000) this.data.hasAscended = false;

        if (newLevel !== oldLevel) {
            if (newLevel === "Architect" && !this.data.hasAscended) {
                this.data.hasAscended = true;
                setTimeout(() => {
                    if (typeof triggerArchitectAscension === 'function') triggerArchitectAscension();
                }, 800);
            }
            this.data.level = newLevel;
            if (typeof Alfred !== 'undefined') Alfred.show(`RANK UPGRADED: ${newLevel}`, 'reward', 0);
        }
        this.syncThemeClasses();
    },

    /* ── Theme sync ── */
    syncThemeClasses() {
        const header = document.querySelector('.master-header');
        if (!header) return;
        const rankClass = `theme-${this.data.level.replace(/\s+/g, '')}`;
        header.classList.remove(
            'theme-Initiate', 'theme-Operator', 'theme-WarMachine', 'theme-Commander', 'theme-Architect'
        );
        header.classList.add(rankClass);
    },

    /* ── UI render (unchanged logic, unchanged element IDs) ── */
    updateUI() {
        const ppValue     = this.data.totalPP;
        const currentRank = this.data.level;

        const elements = {
            level:      document.getElementById('global-level-display'),
            ppDisplay:  document.getElementById('global-pp-display'),
            xpNeeded:   document.getElementById('xp-needed'),
            pulseFill:  document.getElementById('global-pulse-fill'),
            trophy:     document.getElementById('trophy-pp-display'),
            mainBadge:  document.getElementById('main-shard-badge'),
            rankName:   document.getElementById('rank-name')
        };

        // Rank display with logo
        if (elements.level) {
            elements.level.innerHTML = `<div style="display:flex; align-items:center; gap:8px;">${rankLogos[currentRank]} <span>${currentRank}</span></div>`;
            const colors = {
                "Initiate": "#888", "Operator": "#00ccff",
                "War Machine": "#00ff9d", "Commander": "#ffd700", "Architect": "#cc00ff"
            };
            elements.level.style.color = colors[currentRank];
        }

        if (elements.ppDisplay) elements.ppDisplay.innerText = ppValue.toLocaleString();
        if (elements.trophy)    elements.trophy.innerText    = ppValue.toLocaleString();

        // PROGRESS BAR — relative logic (untouched)
        if (elements.pulseFill) {
            const brackets = {
                "Initiate":    { min: 0,     max: 1000,  img: "assets/Iniate rank.png",         color: "#808080" },
                "Operator":    { min: 1000,  max: 5000,  img: "assets/Operator.png",             color: "#00eeff" },
                "War Machine": { min: 5000,  max: 15000, img: "assets/war machine.png",          color: "#39ff14" },
                "Commander":   { min: 15000, max: 30000, img: "assets/commander rank.png",       color: "#ffcc00" },
                "Architect":   { min: 30000, max: 50000, img: "assets/The all seeing Eye.png",   color: "#bc13fe" }
            };

            const config = brackets[currentRank];
            if (elements.xpNeeded) elements.xpNeeded.innerText = `${config.max.toLocaleString()} PP`;

            const relativePP = ppValue - config.min;
            const range      = config.max - config.min;
            const progress   = Math.min(Math.max((relativePP / range) * 100, 0), 100);
            elements.pulseFill.style.width = progress + "%";

            if (elements.mainBadge && elements.mainBadge.getAttribute('src') !== config.img) {
                elements.mainBadge.style.opacity = '0';
                setTimeout(() => {
                    elements.mainBadge.src          = config.img;
                    elements.mainBadge.style.opacity = '0.7';
                }, 300);
            }
            if (elements.rankName) elements.rankName.innerText = currentRank;

            document.documentElement.style.setProperty('--accent-color', config.color);
            document.documentElement.style.setProperty('--accent-glow',  config.color + "66");
        }

        this.syncThemeClasses();
        if (typeof updateTimelinePath === 'function') updateTimelinePath();
    }
};

/* ─────────────────────────────────────────────
   LEGACY PRESERVED — DO NOT MODIFY
   triggerArchitectAscension + Alfred
───────────────────────────────────────────── */
function triggerArchitectAscension() {
    const overlay = document.getElementById('ascension-overlay');
    if (!overlay) return;
    overlay.style.display  = 'flex';
    overlay.style.opacity  = '1';
    overlay.classList.add('flash-active');
    setTimeout(() => overlay.classList.add('show-content'), 500);
    setTimeout(() => {
        overlay.style.transition = "opacity 3s cubic-bezier(0.4, 0, 0.2, 1)";
        overlay.style.opacity    = '0';
        setTimeout(() => {
            overlay.style.display = 'none';
            overlay.classList.remove('flash-active', 'show-content');
            overlay.style.opacity = '1';
        }, 3000);
    }, 9000);
}

const Alfred = {
    show(message, type = 'reward', cost = 0) {
        const card  = document.getElementById('alfred-card');
        const text  = document.getElementById('alfred-text');
        const badge = document.getElementById('alfred-badge');
        if (!card) return;
        card.className = type + '-mode active';
        const headers = {
            'reward':  'SYST_AUTH // SUCCESS',
            'penalty': 'SYST_WARN // PENALTY',
            'jar':     'NEURAL_SYNC // COOKIE_JAR'
        };
        badge.innerHTML = `<span>${headers[type]}</span>`;
        text.style.opacity = '0';
        text.innerText     = message;
        setTimeout(() => { text.style.transition = "opacity 0.5s ease"; text.style.opacity = '1'; }, 300);
        setTimeout(() => card.classList.remove('active'), 7000);
    }
};
function showPPToast(granted, type, multiplier) {
  const typeColors = {
    task: '#7F77DD', mission: '#cc00ff',
    timer: '#00ff9d', checkin: '#00ccff'
  };
  const color = typeColors[type] || '#cc00ff';
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'pp-toast';
  toast.innerHTML =
    `<span style="color:${color};font-size:18px">+${granted} PP</span>` +
    `<span style="font-size:12px;opacity:0.6">${type}</span>` +
    (multiplier > 1 ? `<span class="pp-mult">${multiplier}x</span>` : '');

  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}
/* ─────────────────────────────────────────────
   UTILITY FUNCTIONS (unchanged)
───────────────────────────────────────────── */
function openCookieJar() {
    const victories = [
        "Remember when you crushed that Physics backlog?",
        "You stop when you're DONE.",
        "Stay Hard!"
    ];
    PulseEngine.deductPoints(10);
    Alfred.show(victories[Math.floor(Math.random() * victories.length)], 'jar', 10);
}
function showRankDetail(rankName) {
    const detailPanel = document.getElementById('rank-detail-panel');
    if (!detailPanel) {
        console.error("Panel element 'rank-detail-panel' missing!");
        return;
    }

    const rank = rankData.find(r => r.name === rankName);
    if (!rank) return;

    const currentPP = PulseEngine.data.totalPP;
    
    // Status logic
    const statusText = currentPP >= rank.points ? 
        `<span style="color:${rank.color}">[ COMPLETED ]</span>` : 
        `<span style="color:#ff4d4d">[ LOCKED ]</span>`;

    // HTML Update
    detailPanel.innerHTML = `
        <div class="rank-detail-wrapper" style="display:flex; justify-content: space-between; align-items: flex-start; text-align: left;">
            <div class="detail-main">
                <h4 style="color:${rank.color}; margin:0; font-size: 16px; letter-spacing: 2px;">
                    ${rank.name.toUpperCase()} STATUS: ${statusText}
                </h4>
                <p style="color:#eee; margin:10px 0; font-size: 13px; font-style: italic; max-width: 400px;">
                    "${rank.desc}"
                </p>
            </div>
            <div class="detail-stats" style="border-left: 1px solid rgba(255,255,255,0.1); padding-left: 20px;">
                <p style="margin:0; font-size: 11px; color: #888;">REQUIREMENT: <span style="color:#fff">${rank.points} PP</span></p>
                <p style="margin:5px 0 0; font-size: 11px; color: #888;">UNLOCKED PERKS: <span style="color:${rank.color}">Standard Protocol</span></p>
            </div>
        </div>
    `;
    
    console.log("Panel updated for:", rankName); // Debugging ke liye
}
const rankData = [
    { name: "Initiate",    points: 0,     icon: "🛡️", desc: "The journey begins.",    color: "#888"     },
    { name: "Operator",    points: 1000,  icon: "⚡", desc: "Breaking the cycle.",    color: "#00ccff"  },
    { name: "War Machine", points: 5000,  icon: "⚙️", desc: "Unstoppable force.",      color: "#00ff9d"  },
    { name: "Commander",   points: 15000, icon: "🦅", desc: "Tactical genius.",        color: "#ffd700"  },
    { name: "Architect",   points: 30000, icon: "👁️", desc: "You create the rules.",   color: "#cc00ff"  }
];

function openRankModal() {
    const container = document.getElementById('rank-list-container');
    const pp = PulseEngine.data.totalPP;
    const currentRank = PulseEngine.data.level;
    
    // 1. Rank Nodes generate karo
    container.innerHTML = rankData.map(rank => `
        <div class="rank-node ${pp >= rank.points ? 'unlocked' : ''} ${currentRank === rank.name ? 'current' : ''}" 
             onclick="showRankDetail('${rank.name}')">
            <div class="node-circle">${rank.icon}</div>
            <div class="node-name">${rank.name.toUpperCase()}</div>
        </div>`).join('');

    // 2. Default detail load karo (Architect level details)
    showRankDetail(currentRank);

    // 3. Modal show karo
    const modal = document.getElementById('rank-modal');
    modal.style.display = 'flex';

    // 4. FIX: Agar "x" button kaam nahi kar raha, toh modal ke bahar click karne par close ho jaye
    modal.onclick = function(event) {
        if (event.target === modal) {
            closeRankModal();
        }
    }
}
// Modal band karne ka function jo missing tha
function closeRankModal() {
    const modal = document.getElementById('rank-modal');
    if (modal) {
        modal.style.display = 'none';
        console.log("Ranking Protocol v2.0: Modal Closed Safely.");
    }
}
function updateTimelinePath() {
    const trackFill = document.querySelector('.timeline-track-fill');
    if (!trackFill) return;
    const pp = PulseEngine.data.totalPP;
    const fill = pp >= 30000 ? 100 : pp >= 15000 ? 75 : pp >= 5000 ? 50 : pp >= 1000 ? 25 : 0;
    setTimeout(() => { trackFill.style.width = fill + "%"; }, 300);
}
function triggerDevPoints() {
    console.log("🛠️ DEV_PROTOCOL: Initiating 1000 PP Boost...");
    
    // Claude ke engine ke hisaab se sahi injection:
    const granted = PulseEngine.addPoints(1000, 'mission', { 
        rewardId: 'dev_boost_' + Date.now(), 
        isDev: true 
    });

}
/* ─────────────────────────────────────────────
   INIT
───────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
    PulseEngine.dailyCheck();
    PulseEngine.updateUI();
});