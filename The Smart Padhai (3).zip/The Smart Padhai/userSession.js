// =====================================================
// USER SESSION MANAGER
// Ye file har page pe load hoti hai
// userId ko localStorage mein store karti hai
// Taaki migration.js use kar sake
// =====================================================

const SUPABASE_URL = "https://jgkohrwpyjlfywvqsozj.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_OkDNIEJg0BDU9dx3aqcm8A_uFqb5jd6";

// Global userId — poori site use karegi
window.CURRENT_USER_ID = null;

async function initUserSession() {
    try {
        const client = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        const { data } = await client.auth.getSession();
        
        if (!data?.session?.user) {
            console.warn("[Session] No user logged in");
            // Login page pe redirect karo agar protected page hai
            const publicPages = ['login.html', 'authcallback.html', 'reset-password.html'];
            const currentPage = window.location.pathname.split('/').pop();
            if (!publicPages.includes(currentPage)) {
                window.location.href = './login.html';
            }
            return;
        }

        const user = data.session.user;
        const userId = user.id;

        // Global variable set karo
        window.CURRENT_USER_ID = userId;
        window.CURRENT_USER_TOKEN = data.session.access_token;

        // localStorage mein bhi save karo — migration.js ke liye
        localStorage.setItem('_current_user_id', userId);
        localStorage.setItem('_current_user_token', data.session.access_token);
        localStorage.setItem('_current_user_email', user.email);

        console.log("[Session] ✅ User ready:", userId);

    } catch (err) {
        console.error("[Session] Failed:", err);
    }
}

// Helper — user-specific localStorage key banao
function userKey(baseKey) {
    const uid = window.CURRENT_USER_ID || localStorage.getItem('_current_user_id');
    if (!uid) return baseKey; // fallback
    return `${baseKey}_${uid}`;
}

// Page load pe chalao
initUserSession();