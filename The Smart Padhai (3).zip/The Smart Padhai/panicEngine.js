(function () {
    const MANUAL_OVERRIDE_KEY = 'panicProtocolExamDate';
    const CALENDAR_KEY = 'calendarStrategy';
    const ONE_HOUR_MS = 60 * 60 * 1000;

    const MODE_DEFINITIONS = {
        BLITZ: {
            label: 'Blitz Mode',
            className: 'mode-blitz',
            difficulty: 'HIGH INTENSITY',
            alert: '⚠️ BLITZ MODE ACTIVATED'
        },
        SIEGE: {
            label: 'Siege Mode',
            className: 'mode-siege',
            difficulty: 'MEDIUM-HIGH',
            alert: '🛡️ SIEGE MODE ACTIVE'
        },
        FRESH: {
            label: 'Fresh Start Mode',
            className: 'mode-fresh',
            difficulty: 'FOUNDATION',
            alert: '✅ FRESH START MODE'
        }
    };

    const MODE_TASKS = {
        BLITZ: [
            '2 high-yield chapters revision (timed blocks)',
            '1 full-length mock test + error log',
            'Rapid recall drill (40 min) from weak topics',
            'Past-year questions sprint (minimum 25 questions)'
        ],
        SIEGE: [
            '1 core chapter deep study + summary notes',
            '1 mini test (45-60 min) + 20 min analysis',
            'Backlog rescue block (1 targeted pending topic)',
            'Spaced revision of yesterday\'s key formulas'
        ],
        FRESH: [
            'Syllabus mapping: pick 2 topics + checkpoints',
            'Focused learning block (90 min) on concept clarity',
            'Light backlog cleanup (1 micro-task)',
            'Revision capsule + tomorrow planning (15 min)'
        ]
    };

    function normalizeDate(dateLike) {
        if (!dateLike) return null;
        const date = new Date(dateLike);
        if (Number.isNaN(date.getTime())) return null;
        date.setHours(0, 0, 0, 0);
        return date;
    }

    function toISODate(date) {
        return date ? date.toISOString().split('T')[0] : null;
    }

    // Optional override only; system remains autonomous without this.
    function getManualOverrideExam() {
        const override = localStorage.getItem(MANUAL_OVERRIDE_KEY);
        const date = normalizeDate(override);
        if (!date) return null;

        return {
            subject: 'Manual Override',
            date,
            source: 'manual'
        };
    }

    function parseCalendarStrategy() {
        const raw = localStorage.getItem(CALENDAR_KEY);
        if (!raw) return [];

        try {
            const parsed = JSON.parse(raw);

            // Format: [{ type: 'exam', date: '2026-05-20', subject: 'Physics' }]
            if (Array.isArray(parsed)) {
                return parsed
                    .filter((event) => {
                        const type = String(event?.type || event?.mode || '').toLowerCase();
                        return type === 'exam';
                    })
                    .map((event) => ({
                        subject: event.subject || event.title || event.name || 'General Exam',
                        date: normalizeDate(event.date || event.examDate || event.day),
                        source: 'calendar'
                    }))
                    .filter((event) => event.date);
            }

            // Format: { '2026-05-20': { mode: 'exam', subject: 'Physics' } }
            if (parsed && typeof parsed === 'object') {
                return Object.keys(parsed)
                    .map((key) => {
                        const event = parsed[key];
                        const type = String(event?.type || event?.mode || '').toLowerCase();
                        if (type !== 'exam') return null;
const p = key.split('-').map(Number);
const parsedKey = (p.length === 3 && !isNaN(p[0]) && !isNaN(p[1]) && !isNaN(p[2]))
    ? new Date(p[0], p[1] - 1, p[2])
    : normalizeDate(key);
return {
    subject: event.text || event.subject || event.title || event.name || 'Exam',
    date: parsedKey,
    source: 'calendar'
};
                    })
                    .filter(Boolean)
                    .filter((event) => event.date);
            }

            return [];
        } catch (error) {
            return [];
        }
    }

    // REQUIRED: autonomous nearest exam resolver.
    function getNearestExam() {
        const today = normalizeDate(new Date());

        const manual = getManualOverrideExam();
        if (manual && manual.date >= today) {
            return manual;
        }

        const exams = parseCalendarStrategy();
        const futureExams = exams.filter((exam) => exam.date >= today);
        if (!futureExams.length) return null;

        futureExams.sort((a, b) => a.date - b.date);
        return futureExams[0];
    }

    // REQUIRED: pure days-left calculator.
    function calculateDaysLeft(examDate) {
        if (!examDate) return null;
        const today = normalizeDate(new Date());
        const diffMs = examDate.getTime() - today.getTime();
        return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    }

    // REQUIRED: mode derived only from daysLeft.
    function getMode(daysLeft) {
        if (typeof daysLeft !== 'number') return 'FRESH';
        if (daysLeft <= 7) return 'BLITZ';
        if (daysLeft <= 14) return 'SIEGE';
        return 'FRESH';
    }

    function updateTaskList(modeKey) {
        const taskList = document.getElementById('panicTaskList');
        if (!taskList) return;

        const modeTasks = MODE_TASKS[modeKey] || MODE_TASKS.FRESH;
        const difficulty = MODE_DEFINITIONS[modeKey].difficulty;

        taskList.innerHTML = modeTasks
            .map((task, index) => `<li>${index + 1}. ${task}<small>Difficulty: ${difficulty}</small></li>`)
            .join('');
    }

    // REQUIRED: render all panic UI from computed state.
    function renderUI(state) {
        const indicator = document.getElementById('panicModeIndicator');
        const toast = document.getElementById('panicActivationToast');

        const modeDef = MODE_DEFINITIONS[state.mode] || MODE_DEFINITIONS.FRESH;

        if (indicator) {
            indicator.textContent = modeDef.label;
            indicator.classList.remove('mode-blitz', 'mode-siege', 'mode-fresh');
            indicator.classList.add(modeDef.className);
        }

        if (toast) {
            const timelineText = typeof state.daysLeft === 'number'
                ? `${state.subject} | Exam in ${Math.max(state.daysLeft, 0)} day(s)`
                : 'No upcoming exam detected in calendarStrategy.';

            toast.textContent = `${modeDef.alert} | ${timelineText}`;
            toast.style.color = state.mode === 'BLITZ'
                ? '#FF4C4C'
                : state.mode === 'SIEGE'
                    ? '#00d1ff'
                    : '#28A745';

            toast.classList.remove('panic-animate');
            void toast.offsetWidth;
            toast.classList.add('panic-animate');
        }

        updateTaskList(state.mode);
    }

    function computeState() {
        const nearestExam = getNearestExam();
        const daysLeft = calculateDaysLeft(nearestExam ? nearestExam.date : null);
        const mode = getMode(daysLeft);

        return {
            subject: nearestExam ? nearestExam.subject : 'No Upcoming Exam',
            examDate: nearestExam ? toISODate(nearestExam.date) : null,
            daysLeft,
            mode
        };
    }

    function execute() {
        const state = computeState();
        window.PanicProtocolEngineState = state;
        renderUI(state);
    }

    function bindManualOverrideInput() {
        const input = document.getElementById('panicExamDateInput');
        const saveBtn = document.getElementById('panicSaveDateBtn');
        if (!input || !saveBtn) return;

        const currentOverride = getManualOverrideExam();
        if (currentOverride) input.value = toISODate(currentOverride.date);

        const persistOverride = () => {
            if (!input.value) {
                localStorage.removeItem(MANUAL_OVERRIDE_KEY);
            } else {
                localStorage.setItem(MANUAL_OVERRIDE_KEY, input.value);
            }
            execute();
        };

        input.addEventListener('change', persistOverride);
        saveBtn.addEventListener('click', persistOverride);
    }

    function bindAutoExecution() {
        // Run every hour with no refresh required.
        setInterval(execute, ONE_HOUR_MS);

        // React to localStorage updates in other tabs/windows.
        window.addEventListener('storage', (event) => {
            if (event.key === CALENDAR_KEY || event.key === MANUAL_OVERRIDE_KEY) {
                execute();
            }
        });
    }

    window.PanicProtocolEngine = {
        run: execute,
        refresh: execute,
        getState: () => window.PanicProtocolEngineState || null,
        clearManualOverride: () => {
            localStorage.removeItem(MANUAL_OVERRIDE_KEY);
            execute();
        }
    };

    document.addEventListener('DOMContentLoaded', () => {
        bindManualOverrideInput();
        bindAutoExecution();
        execute();
    });
})();
