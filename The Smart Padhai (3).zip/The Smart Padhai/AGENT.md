# AESTRA OS — Project Architecture

## Project Identity
AESTRA OS is a futuristic student productivity and discipline system.

This is NOT a chatbot project.
This is a behavioral operating system.

Core philosophy:
"Understand behavior. Then shape it."

---

# Core Systems

1. Dashboard System
2. Pulse Engine
3. Backlog System
4. Tactical Time Grid
5. Study Vault
6. AESTRA AI

---

# AESTRA AI Philosophy

The AI must feel adaptive, observant, contextual, and psychologically aware.

DO NOT build:
- generic chatbot
- fake GPT clone
- random dialogue spam

DO build:
- behavior-based intelligence
- state systems
- memory systems
- tactical decision logic

---

# Architecture Rules

- Keep code modular
- Maximum 300-400 lines per file
- No giant files
- No duplicated logic
- Separate AI logic from UI logic
- Use event-driven architecture where possible

---

# Preferred Stack

Frontend:
- HTML
- CSS
- Vanilla JavaScript

Storage:
- localStorage
- IndexedDB

Future Expansion:
- local lightweight ML models

---

# Folder Structure

/aestra-core
/aestra-ai
/pulse-engine
/ui
/utils

---

# AI Modules

observer.js
states.js
memory.js
dialogueEngine.js
tacticalEngine.js
pressureEngine.js
evolution.js

---

# Coding Standards

- Use readable naming
- Avoid deeply nested conditions
- Use pure functions where possible
- Comment complex systems clearly
- Never rewrite unrelated files

---

# UI Style

- Dark futuristic UI
- Glassmorphism
- Neon tactical aesthetics
- Minimal and premium

---

# IMPORTANT

Do NOT destroy existing UI.
Do NOT refactor entire project unless explicitly requested.
Always explain:
- what changed
- why it changed
- which files were modified

---

# Current Priority

Phase 1:
Observer Engine
State Engine
Memory Core

These systems must become stable before higher-level AI behavior is added.