// =====================================================
// SMART PADHAI → SUPABASE CORE MIGRATION SCRIPT
// Migrates:
// syllabus_master_tracker  → syllabus_progress
// notebook_matrix_data     → notebooks
// calendarStrategy         → calendar_events
// commanderMissions        → missions
// tacticalSchedule         → tactical_schedule
// =====================================================
const SUPABASE_URL = "https://jgkohrwpyjlfywvqsozj.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_OkDNIEJg0BDU9dx3aqcm8A_uFqb5jd6";

function safeParseLS(key, fallback = null) {
    try {
        const raw = localStorage.getItem(key);
        if (!raw) return fallback;
        return JSON.parse(raw);
    } catch (err) {
        console.warn(`[Migration] Failed to parse ${key}`, err);
        return fallback;
    }
}

async function supabaseInsert(tableName, rows) {
    if (!Array.isArray(rows) || rows.length === 0) {
        console.warn(`[Migration] No rows to insert for ${tableName}`);
        return [];
    }
async function clearSupabaseTable(tableName) {
    try {
        const response = await fetch(
            `${SUPABASE_URL}/rest/v1/${tableName}?id=not.is.null`,
            {
                method: "DELETE",
                headers: {
                    "apikey": SUPABASE_ANON_KEY,
                    "Content-Type": "application/json",
                    "Prefer": "return=minimal"
                }
            }
        );

        if (!response.ok) {
            const result = await response.json();
            console.error(`[Sync] Failed to clear ${tableName}:`, result);
            return false;
        }

        console.log(`[Sync] Cleared ${tableName}`);
        return true;

    } catch (err) {
        console.error(`[Sync] Clear error for ${tableName}:`, err);
        return false;
    }
}
    const response = await fetch(
        `${SUPABASE_URL}/rest/v1/${tableName}`,
        {
            method: "POST",
            headers: {
                "apikey": SUPABASE_ANON_KEY,
                "Content-Type": "application/json",
                "Prefer": "return=representation"
            },
            body: JSON.stringify(rows)
        }
    );

    const result = await response.json();

    if (!response.ok) {
        console.error(`[Migration] ${tableName} failed:`, result);
        return null;
    }

    console.log(`[Migration] ${tableName} success:`, result);
    return result;
}
async function clearSupabaseTable(tableName) {
    const response = await fetch(
        `${SUPABASE_URL}/rest/v1/${tableName}?id=not.is.null`,
        {
            method: "DELETE",
            headers: {
                "apikey": SUPABASE_ANON_KEY,
                "Content-Type": "application/json",
                "Prefer": "return=minimal"
            }
        }
    );

    if (!response.ok) {
        const result = await response.json();
        console.error(`[Migration] Failed to clear ${tableName}:`, result);
        return false;
    }

    console.log(`[Migration] Cleared ${tableName}`);
    return true;
}
// ------------------------------
// 1. Syllabus Migration
// ------------------------------
function buildSyllabusRows() {
    const tracker = safeParseLS("syllabus_master_tracker", {});
    const progressData = safeParseLS("smartPadhaiData", {});
    const rows = [];

    if (!tracker || typeof tracker !== "object") return rows;

    Object.keys(tracker).forEach((chapter) => {
        const progress = progressData[chapter] || {};

        const read = progress.read === true;
        const notes = progress.notes === true;
        const pyq = progress.pyq === true;

        const completedCount = [read, notes, pyq].filter(Boolean).length;
        const progressPercent = Math.round((completedCount / 3) * 100);

        rows.push({
            subject: progress.subject || "Unknown",
            chapter: chapter,
            completed: completedCount === 3,
            progress: progressPercent,
            raw_data: {
                registry: tracker[chapter],
                progress: progress
            },
            last_updated: progress.lastUpdated || null
        });
    });

    return rows;
}
// ------------------------------
// 2. Notebook Migration
// ------------------------------
function buildNotebookRows() {
    const data = safeParseLS("notebook_matrix_data", {});
    const rows = [];

    if (!data || typeof data !== "object") return rows;

    Object.entries(data).forEach(([key, value]) => {
        if (value && typeof value === "object" && !Array.isArray(value)) {
            rows.push({
                subject: value.subject || key,
                notebook_type: value.type || value.notebook_type || "general",
                title: value.title || key,
                completed:
                    value.completed === true ||
                    value.done === true ||
                    value.status === "completed",
                delta_pages:
                    Number(value.delta_pages || value.deltaPages || value.pages || 0),
                raw_data: value,
                last_updated:
                    value.lastUpdated ||
                    value.last_updated ||
                    null
            });
        } else {
            rows.push({
                subject: "Unknown",
                notebook_type: "general",
                title: key,
                completed: value === true,
                delta_pages: 0,
                raw_data: value,
                last_updated: null
            });
        }
    });

    return rows;
}

// ------------------------------
// 3. Calendar Migration
// ------------------------------
function buildCalendarRows() {
    const data = safeParseLS("calendarStrategy", {});
    const rows = [];

    if (!data || typeof data !== "object") return rows;

    Object.entries(data).forEach(([date, eventData]) => {
        rows.push({
            event_date: date,
            mode: eventData?.mode || "general",
            title:
                eventData?.text ||
                eventData?.title ||
                eventData?.name ||
                "Untitled Event",
            description:
                eventData?.description ||
                eventData?.note ||
                null,
            event_type:
                eventData?.type ||
                eventData?.mode ||
                "general",
            raw_data: eventData
        });
    });

    return rows;
}

// ------------------------------
// 4. Commander Missions Migration
// ------------------------------
function buildMissionRows() {
    const data = safeParseLS("commanderMissions", {});
    const rows = [];

    if (!data || typeof data !== "object") return rows;

    Object.entries(data).forEach(([slot, missions]) => {
        if (Array.isArray(missions)) {
            missions.forEach((mission) => {
                rows.push({
                    slot: slot,
                    title:
                        mission?.title ||
                        mission?.name ||
                        "Untitled Mission",
                    status:
                        mission?.status ||
                        (mission?.completed ? "completed" : "pending"),
                    priority:
                        mission?.priority ||
                        mission?.level ||
                        null,
                    reward_pp:
                        Number(mission?.reward_pp || mission?.pp || mission?.reward || 0),
                    mission_date:
                        mission?.date ||
                        mission?.mission_date ||
                        null,
                    raw_data: mission
                });
            });
        }
    });

    return rows;
}

// ------------------------------
// 5. Tactical Schedule Migration
// ------------------------------
function buildTacticalScheduleRows() {
    const data = safeParseLS("tacticalSchedule", {});
    const rows = [];

    if (!data) return rows;

    if (Array.isArray(data)) {
        data.forEach((block) => {
            rows.push({
                block_name:
                    block?.block_name ||
                    block?.name ||
                    block?.title ||
                    "Unnamed Block",
                start_time:
                    block?.start_time ||
                    block?.start ||
                    block?.time ||
                    null,
                end_time:
                    block?.end_time ||
                    block?.end ||
                    null,
                subject:
                    block?.subject ||
                    null,
                task:
                    block?.task ||
                    block?.title ||
                    block?.description ||
                    null,
                status:
                    block?.status ||
                    (block?.completed ? "completed" : "pending"),
                raw_data: block
            });
        });
    } else if (typeof data === "object") {
        Object.entries(data).forEach(([blockName, block]) => {
            rows.push({
                block_name: blockName,
                start_time:
                    block?.start_time ||
                    block?.start ||
                    block?.time ||
                    null,
                end_time:
                    block?.end_time ||
                    block?.end ||
                    null,
                subject:
                    block?.subject ||
                    null,
                task:
                    block?.task ||
                    block?.title ||
                    block?.description ||
                    null,
                status:
                    block?.status ||
                    (block?.completed ? "completed" : "pending"),
                raw_data: block
            });
        });
    }

    return rows;
}
async function syncMissionsMirror() {
    const rows = buildMissionRows();

    await clearSupabaseTable("missions");

    if (rows.length > 0) {
        await supabaseInsert("missions", rows);
    }

    console.log("Missions mirror sync complete.");
}
async function syncSyllabusMirror() {
    const rows = buildSyllabusRows();

    await clearSupabaseTable("syllabus_progress");

    if (rows.length > 0) {
        await supabaseInsert("syllabus_progress", rows);
    }

    console.log("Syllabus mirror sync complete.");
}
async function syncNotebooksMirror() {
    const rows = buildNotebookRows();

    await clearSupabaseTable("notebooks");

    if (rows.length > 0) {
        await supabaseInsert("notebooks", rows);
    }

    console.log("Notebooks mirror sync complete.");
}
async function syncCalendarMirror() {
    const rows = buildCalendarRows();

    await clearSupabaseTable("calendar_events");

    if (rows.length > 0) {
        await supabaseInsert("calendar_events", rows);
    }

    console.log("Calendar mirror sync complete.");
}

// ------------------------------
// MAIN MIGRATION FUNCTION
// ------------------------------
async function migrateCoreLocalStorageToSupabase() {
    console.log("========== SMART PADHAI CORE MIGRATION STARTED ==========");
    console.log("========== SMART PADHAI MIRROR SYNC STARTED ==========");

    await syncSyllabusMirror();
    await syncNotebooksMirror();
    await syncCalendarMirror();
    await syncMissionsMirror();

    console.log("========== SMART PADHAI MIRROR SYNC FINISHED ==========");
    // const syllabusRows = buildSyllabusRows();
    // const notebookRows = buildNotebookRows();
    // const calendarRows = buildCalendarRows();
    // const missionRows = buildMissionRows();
    // const scheduleRows = buildTacticalScheduleRows();

    console.log("Prepared syllabus rows:", syllabusRows);
    console.log("Prepared notebook rows:", notebookRows);
    console.log("Prepared calendar rows:", calendarRows);
    console.log("Prepared mission rows:", missionRows);
    console.log("Prepared schedule rows:", scheduleRows);

    // await supabaseInsert("syllabus_progress", syllabusRows);
    // await supabaseInsert("notebooks", notebookRows);
    // await supabaseInsert("calendar_events", calendarRows);
    // await supabaseInsert("missions", missionRows);
    // await supabaseInsert("tactical_schedule", scheduleRows);

    console.log("========== SMART PADHAI CORE MIGRATION FINISHED ==========");
}