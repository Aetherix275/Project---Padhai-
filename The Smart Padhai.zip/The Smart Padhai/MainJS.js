/**
 * PULSE ENGINE - WAVE 1 CORE
 * Built for Master SJ | Refined by Alfred
 */
const rankLogos = {
    "Initiate": `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 5px #888);"><path d="M12 2L4 5V11C4 16.07 7.41 20.84 12 22C16.59 20.84 20 16.07 20 11V5L12 2Z" stroke="#888" stroke-width="2" fill="rgba(136,136,136,0.2)"/></svg>`,
    
    "Operator": `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 8px #00ccff);"><path d="M13 2L3 14H12L11 22L21 10H12L13 2Z" fill="#00ccff"/></svg>`,
    
    "War Machine": `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 8px #00ff9d);"><path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" fill="#00ff9d"/><path d="M19.4 15V9L17.6 7.2L14.8 7.7L12 5L9.2 7.7L6.4 7.2L4.6 9V15L6.4 16.8L9.2 16.3L12 19L14.8 16.3L17.6 16.8L19.4 15Z" stroke="#00ff9d" stroke-width="2"/></svg>`,
    
    "Commander": `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 10px #ffd700);"><path d="M12 2L2 7L12 12L22 7L12 2Z" fill="#ffd700"/><path d="M2 17L12 22L22 17M2 12L12 17L22 12" stroke="#ffd700" stroke-width="2"/></svg>`,
    
    "Architect": `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 12px #cc00ff);"><path d="M12 5C7 5 2.73 8.11 1 12.5C2.73 16.89 7 20 12 20C17 20 21.27 16.89 23 12.5C21.27 8.11 17 5 12 5ZM12 17.5C9.24 17.5 7 15.26 7 12.5C7 9.74 9.24 7.5 12 7.5C14.76 7.5 17 9.74 17 12.5C17 15.26 14.76 17.5 12 17.5ZM12 9.5C10.34 9.5 9 10.84 9 12.5C9 14.16 10.34 15.5 12 15.5C13.66 15.5 15 14.16 15 12.5C15 10.84 13.66 9.5 12 9.5Z" fill="#cc00ff"/></svg>`
};
const PulseEngine = {
    // 1. Initial State
    data: JSON.parse(localStorage.getItem('pulse_engine_data')) || {
    totalPP: 500,
    level: "Initiate",
    hasAscended: false,
        shields: 1,
        streak: 0,
        lastActivity: new Date().toDateString(),
        multiplier: 1.0,
        inventory: []
    },

    // 2. Save & Sync System
    save() {
        localStorage.setItem('pulse_engine_data', JSON.stringify(this.data));
        this.updateUI();
    },

    // 3. Earning Logic (Wave 1: Refined)
    addPoints(amount, type = "task") {
    // Multiplier Calculation based on Streak
    let m = 1.0;
    if (this.data.streak >= 30) m = 2.0;
    else if (this.data.streak >= 15) m = 1.5;
    else if (this.data.streak >= 7) m = 1.2;

    this.data.multiplier = m; // Update current multiplier
    
    const finalPoints = Math.floor(amount * m);
    this.data.totalPP += finalPoints;

    console.log(`Earned: ${finalPoints} PP (Base: ${amount} x Multiplier: ${m})`);
    
    this.calculateLevel();
    this.save();
    
    // UI par multiplier dikhane ke liye (Optional)
    const multDisplay = document.getElementById('multiplier-tag');
    if(multDisplay) multDisplay.innerText = m + "x";

    return finalPoints;
},

    // 4. Penalty Logic (Safe Version)
    deductPoints(amount) {
        if (this.data.shields > 0 && amount >= 50) {
            this.data.shields--;
            this.showRoast("SHIELD ACTIVATED! Penalty Blocked.", true);
        } else {
            // Precise deduction to avoid instant-zero glitch
            this.data.totalPP = Math.max(0, this.data.totalPP - amount);
        }
        this.calculateLevel();
        this.save();
    },

    // 5. Level & Multiplier Calculation
   // ... tumhare PulseEngine code ke andar calculateLevel update karo
calculateLevel() {
    const pp = this.data.totalPP;
    const oldLevel = this.data.level;
    let newLevel = "Initiate";
    
    // 1. Rank Logic
    if (pp >= 30000) newLevel = "Architect";
    else if (pp >= 15000) newLevel = "Commander";
    else if (pp >= 5000) newLevel = "War Machine";
    else if (pp >= 1000) newLevel = "Operator";

    // --- NEW: THE RESET LOGIC ---
    // Agar points 30k se neeche gaye (Cookie Jar ki wajah se), 
    // toh hasAscended ko wapas false kar do taaki dobara animation aa sake.
    if (pp < 30000) {
        this.data.hasAscended = false;
    }
    // ----------------------------

    if (newLevel !== oldLevel) {
        // Architect Ascension Trigger
        if (newLevel === "Architect" && !this.data.hasAscended) {
            this.data.hasAscended = true;
            this.save();
            
            setTimeout(() => {
                if (typeof triggerArchitectAscension === 'function') {
                    triggerArchitectAscension();
                }
            }, 800);
        }

        this.data.level = newLevel;
        if (typeof Alfred !== 'undefined') {
            Alfred.show(`RANK UPGRADED: ${newLevel}`, 'reward', 0);
        }
        this.save();
    }

    this.syncThemeClasses(); 
},
// Naya Helper Function PulseEngine ke andar hi daal do
syncThemeClasses() {
    const header = document.querySelector('.master-header');
    if (!header) return;

    const rankClass = `theme-${this.data.level.replace(/\s+/g, '')}`;
    
    // Purani saari themes ek saath saaf
    header.classList.remove('theme-Initiate', 'theme-Operator', 'theme-WarMachine', 'theme-Commander', 'theme-Architect');
    
    // Nayi dedicated theme apply
    header.classList.add(rankClass);
},

    // 6. Universal UI Sync (Safe from crashing other pages)
updateUI() {
    const ppValue = this.data.totalPP;
    const currentRank = this.data.level;

    // A. Elements ko safe tareeke se pakdo
    const elements = {
        level: document.getElementById('global-level-display'),
        ppDisplay: document.getElementById('global-pp-display'),
        xpNeeded: document.getElementById('xp-needed'),
        pulseFill: document.getElementById('global-pulse-fill'),
        trophy: document.getElementById('trophy-pp-display')
    };

    // B. Rank + SVG Logo Update (THE NEW STUFF)
    if (elements.level) {
        const logo = rankLogos[currentRank] || '';
        elements.level.innerHTML = `
            <div style="display:flex; align-items:center; gap:8px;">
                ${logo} <span>${currentRank}</span>
            </div>
        `;
        
        // Rank colors set karo
        const colors = { "Initiate": "#888", "Operator": "#00ccff", "War Machine": "#00ff9d", "Commander": "#ffd700", "Architect": "#cc00ff" };
        elements.level.style.color = colors[currentRank];
    }

    // C. Numerator Update (e.g. 450)
    if (elements.ppDisplay) elements.ppDisplay.innerText = ppValue.toLocaleString();
    if (elements.trophy) elements.trophy.innerText = ppValue.toLocaleString();

    // D. Denominator & Bar Update
    if (elements.pulseFill) {
        const rankGoals = { "Initiate": 1000, "Operator": 5000, "War Machine": 15000, "Commander": 30000, "Architect": 50000 };
        const targetXP = rankGoals[currentRank] || 50000;

        if (elements.xpNeeded) elements.xpNeeded.innerText = `${targetXP.toLocaleString()} PP`;

        const progress = Math.min((ppValue / targetXP) * 100, 100);
        elements.pulseFill.style.width = progress + "%";
    }

    let rankConfig = { name: "Initiate", img: "assets/Iniate rank.png", color: "#808080" };

    // Use ppValue instead of totalPP
    if (ppValue >= 30000) {
        rankConfig = { name: "Architect", img: "assets/The all seeing Eye.png", color: "#bc13fe" };
    } else if (ppValue >= 15000) {
        rankConfig = { name: "Commander", img: "assets/commander rank.png", color: "#ffcc00" };
    } else if (ppValue >= 5000) {
        rankConfig = { name: "War Machine", img: "assets/war machine.png", color: "#39ff14" };
    } else if (ppValue >= 1000) {
        rankConfig = { name: "Operator", img: "assets/Operator.png", color: "#00eeff" };
    }

    const mainBadge = document.getElementById('main-shard-badge');
    const rankNameDisplay = document.getElementById('rank-name');

    if (mainBadge) {
        // Image change logic with paths check
        // TIP: Make sure your filenames exactly match these strings!
        if (mainBadge.getAttribute('src') !== rankConfig.img) {
            mainBadge.style.opacity = '0'; 
            setTimeout(() => {
                mainBadge.src = rankConfig.img;
                mainBadge.style.opacity = '0.7'; 
            }, 300);
        }
    }

    if (rankNameDisplay) rankNameDisplay.innerText = rankConfig.name;

    // Theme Colors Update
    document.documentElement.style.setProperty('--accent-color', rankConfig.color);
    document.documentElement.style.setProperty('--accent-glow', rankConfig.color + "66"); 
    // --- LOGO SWAP MAGIC END ---

    // E. Global Syncs
    this.syncThemeClasses();
    if (typeof updateTimelinePath === 'function') updateTimelinePath();
},

};

// Ise PulseEngine object ke BAHAR ya updateUI ke khatam hone ke baad rakho
function triggerArchitectAscension() {
    const overlay = document.getElementById('ascension-overlay');
    if (!overlay) return;

    // Phase 1: Sudden White Flash
    overlay.style.display = 'flex';
    overlay.style.opacity = '1';
    overlay.classList.add('flash-active');
    
    // Phase 2: Fade in Logo and Text smoothly
    setTimeout(() => {
        overlay.classList.add('show-content');
    }, 500);

    // Phase 3: Ultra Smooth Exit
    setTimeout(() => {
    overlay.style.transition = "opacity 3s cubic-bezier(0.4, 0, 0.2, 1)"; // Longer & smoother
    overlay.style.opacity = '0';
    
    setTimeout(() => {
        overlay.style.display = 'none';
        overlay.classList.remove('flash-active', 'show-content');
        overlay.style.opacity = '1'; // Reset for next time
    }, 3000);
}, 9000);
}
   /**
 * REBUILT ALFRED NOTIFICATION SYSTEM
 */
const Alfred = {
    show(message, type = 'reward', cost = 0) {
        const card = document.getElementById('alfred-card');
        const text = document.getElementById('alfred-text');
        const badge = document.getElementById('alfred-badge');

        if (!card) return;

        // Mode switch
        card.className = ''; 
        card.classList.add(type + '-mode');

        const headers = {
            'reward': 'SYST_AUTH // SUCCESS',
            'penalty': 'SYST_WARN // PENALTY',
            'jar': 'NEURAL_SYNC // COOKIE_JAR'
        };

        badge.innerHTML = `<span>${headers[type]}</span>`;
        
        // Instant Text but with a fade-in for smoothness
        text.style.opacity = '0';
        text.innerText = message;
        
        card.classList.add('active');
        
        setTimeout(() => {
            text.style.transition = "opacity 0.5s ease";
            text.style.opacity = '1';
        }, 300);

        // Auto Hide
        setTimeout(() => card.classList.remove('active'), 7000);
    }
};


// Rebuilt Cookie Jar Function
// Ye function tumhare button ko trigger karega
function openCookieJar() {
    // 1. Goggins-style mental cookies
    const victories = [
        "Remember when you crushed that Physics backlog? Do it again!",
        "You don't stop when you're tired. You stop when you're DONE.",
        "The person who started this journey is counting on you, Master SJ.",
        "Yaad hai wo 3 baje tak ki padhai? You're a War Machine!",
        "Don't let your inner bitch win today. Stay Hard!"
    ];

    const randomWin = victories[Math.floor(Math.random() * victories.length)];
    
    // 2. Points Logic (Jar kholne ka mental tax)
    const cost = 1000;
    if (typeof PulseEngine !== 'undefined') {
        PulseEngine.deductPoints(cost);
        PulseEngine.updateUI(); // UI update karna mat bhoolna
    }

    // 3. Trigger Alfred Rebuilt
    // Alfred.show(message, type, cost)
    if (typeof Alfred !== 'undefined') {
        Alfred.show(randomWin, 'jar', cost);
    } else {
        console.error("Alfred Object missing! Make sure the rebuilt JS is added.");
        // Fallback agar Alfred load na ho
        alert(randomWin); 
    }
    const btn = document.querySelector('.cookie-btn-pro');
    btn.style.transform = "scale(0.95)";
    setTimeout(() => btn.style.transform = "translateY(-3px) scale(1.02)", 100);

    // Alfred trigger
    Alfred.show(randomWin, 'jar', cost);
}
// --- Initialization ---
document.addEventListener('DOMContentLoaded', () => {
    PulseEngine.updateUI();
    // Wave 2 mein hum yahan Daily Check logic daalenge
});

const rankData = [
    { name: "Initiate", points: 0, icon: "🛡️", desc: "The journey begins. Discipline is your weapon.", color: "#888" },
    { name: "Operator", points: 1000, icon: "⚡", desc: "Breaking the cycle of stagnation.", color: "#00ccff" },
    { name: "War Machine", points: 5000, icon: "⚙️", desc: "An unstoppable force against procrastination.", color: "#00ff9d" },
    { name: "Commander", points: 15000, icon: "🦅", desc: "Tactical genius. Leading with precision.", color: "#ffd700" },
    { name: "Architect", points: 30000, icon: "👁️", desc: "Rules no longer apply to you. You create them.", color: "#cc00ff" }
];

function openRankModal() {
    const container = document.getElementById('rank-list-container');
    const currentPP = PulseEngine.data.totalPP;
    const currentRank = PulseEngine.data.level;
    
    container.innerHTML = ''; 

    rankData.forEach(rank => {
        const isCurrent = (rank.name === currentRank);
        const isUnlocked = (currentPP >= rank.points);
        
        container.innerHTML += `
            <div class="rank-node ${isUnlocked ? 'unlocked' : ''} ${isCurrent ? 'current' : ''}" 
                 onclick="showRankDetail('${rank.name}')">
                <div class="node-circle">${rank.icon}</div>
                <div class="node-name">${rank.name.toUpperCase()}</div>
            </div>
        `;
    });

    document.getElementById('rank-modal').style.display = 'flex';
}

function showRankDetail(rankName) {
    const detailPanel = document.getElementById('rank-detail-panel');
    const rank = rankData.find(r => r.name === rankName);
    const currentPP = PulseEngine.data.totalPP;
    
    // Status Logic
    const statusText = currentPP >= rank.points ? 
        `<span style="color:${rank.color}">[ COMPLETED ]</span>` : 
        `<span style="color:#ff4d4d">[ LOCKED ]</span>`;

    detailPanel.innerHTML = `
        <div class="rank-detail-wrapper" style="display:flex; justify-content: space-between; align-items: flex-start; text-align: left;">
            <div class="detail-main">
                <h4 style="color:${rank.color}; margin:0; font-size: 16px; letter-spacing: 2px;">
                    ${rank.name.toUpperCase()} STATUS: ${statusText}
                </h4>
                <p style="color:#eee; margin:10px 0; font-size: 13px; font-style: italic; max-width: 400px;">
                    "${rank.desc}"
                </p>
            </div>
            <div class="detail-stats" style="border-left: 1px solid rgba(255,255,255,0.1); padding-left: 20px;">
                <p style="margin:0; font-size: 11px; color: #888;">REQUIREMENT: <span style="color:#fff">${rank.points} PP</span></p>
                <p style="margin:5px 0 0; font-size: 11px; color: #888;">UNLOCKED PERKS: <span style="color:${rank.color}">Standard Protocol</span></p>
            </div>
        </div>
    `;
}

function closeRankModal() {
    document.getElementById('rank-modal').style.display = 'none';
}
function updateTimelinePath() {
    const trackFill = document.querySelector('.timeline-track-fill');
    if (!trackFill) return;

    const currentPP = PulseEngine.data.totalPP;
    // Ranks: Initiate (0), Operator (1k), War Machine (5k), Commander (15k), Architect (30k)
    let fillPercent = 0;

    if (currentPP >= 30000) fillPercent = 100;
    else if (currentPP >= 15000) fillPercent = 75;
    else if (currentPP >= 5000) fillPercent = 50;
    else if (currentPP >= 1000) fillPercent = 25;
    else fillPercent = 0;

    // Trigger animation after a small delay for smooth effect
    setTimeout(() => {
        trackFill.style.width = fillPercent + "%";
    }, 300);
}
// Is helper function ko PulseEngine ke bahar ya andar kahi bhi rakho
function syncHeaderTheme() {
    const header = document.querySelector('.master-header');
    if (!header) return;

    // Rank se spaces hatao (e.g. "War Machine" -> "WarMachine")
    const cleanRank = PulseEngine.data.level.replace(/\s+/g, '');
    
    // Sab purani theme classes remove karo
    const allThemes = ['theme-Initiate', 'theme-Operator', 'theme-WarMachine', 'theme-Commander', 'theme-Architect'];
    header.classList.remove(...allThemes);
    
    // Nayi dedicated class add karo
    header.classList.add(`theme-${cleanRank}`);
}

// ISE APNE PulseEngine.updateUI() KE END MEIN CALL KARO
// PulseEngine.updateUI() {
//    ... existing code ...
//    syncHeaderTheme();
// }
// Call this inside your PulseEngine.updateUI() or DOMContentLoaded
function triggerDevPoints() {

    PulseEngine.addPoints(1000);
    if(typeof updateRank === 'function') updateRank(); // Agar aapka rank update function hai
    PulseEngine.updateUI();
    updateMasterTheme(); // Theme ko force update karega

}

// triggerArchitectAscension();
window.addEventListener('DOMContentLoaded', syncHeaderTheme);
