// =====================================================
// SMART PADHAI — USER SESSION MANAGER
// Load order: Supabase CDN → userSession.js → everything else
// =====================================================

(function () {
    const SUPABASE_URL = "https://jgkohrwpyjlfywvqsozj.supabase.co";
    const SUPABASE_ANON_KEY = "sb_publishable_OkDNIEJg0BDU9dx3aqcm8A_uFqb5jd6";

    let _supabaseClient = null;

    if (typeof supabase !== "undefined" && supabase.createClient) {
        _supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        window.supabaseClient = _supabaseClient;
        window._supabase = _supabaseClient;
    } else {
        console.error("[UserSession] Supabase CDN not loaded before userSession.js");
    }

    const PROTECTED_KEYS = [
        "_current_user_id",
        "_current_user_email"
    ];

    function isProtected(key) {
        if (PROTECTED_KEYS.includes(key)) return true;
        if (typeof key === "string" && (key.startsWith("sb-") || key.startsWith("supabase"))) return true;
        return false;
    }

    function getCurrentUserIdSync() {
        return localStorage.getItem("_current_user_id");
    }

    window.userKey = function (baseKey) {
        const uid = getCurrentUserIdSync();

        if (!uid) {
            console.warn(`[SafeStorage] No active user for key: ${baseKey}`);
            return `guest_${baseKey}`;
        }

        return `${baseKey}_${uid}`;
    };

    window.SafeStorage = {
        getItem: function (key, fallback = null) {
            try {
                if (isProtected(key)) {
                    const protectedValue = localStorage.getItem(key);
                    return protectedValue ?? fallback;
                }

                const raw = localStorage.getItem(window.userKey(key));

                if (raw === null || raw === undefined) return fallback;

                try {
                    return JSON.parse(raw);
                } catch {
                    return raw;
                }
            } catch (err) {
                console.error(`[SafeStorage] getItem failed for ${key}:`, err);
                return fallback;
            }
        },

        setItem: function (key, value) {
            try {
                if (isProtected(key)) {
                    localStorage.setItem(key, String(value));
                    return;
                }

                const safeKey = window.userKey(key);
                const finalValue =
                    typeof value === "string" ? value : JSON.stringify(value);

                localStorage.setItem(safeKey, finalValue);
            } catch (err) {
                console.error(`[SafeStorage] setItem failed for ${key}:`, err);
            }
        },

        removeItem: function (key) {
            try {
                if (isProtected(key)) {
                    localStorage.removeItem(key);
                    return;
                }

                localStorage.removeItem(window.userKey(key));
            } catch (err) {
                console.error(`[SafeStorage] removeItem failed for ${key}:`, err);
            }
        },

        clearCurrentUser: function () {
            const uid = getCurrentUserIdSync();
            if (!uid) return;

            const keysToRemove = [];

            for (let i = 0; i < localStorage.length; i++) {
                const k = localStorage.key(i);
                if (k && k.endsWith("_" + uid)) {
                    keysToRemove.push(k);
                }
            }

            keysToRemove.forEach(k => localStorage.removeItem(k));
        }
    };

    function applySession(session) {
        if (session && session.user) {
            localStorage.setItem("_current_user_id", session.user.id);
            localStorage.setItem("_current_user_email", session.user.email || "");
            console.log("[UserSession] User active:", session.user.email, session.user.id);
        } else {
            localStorage.removeItem("_current_user_id");
            localStorage.removeItem("_current_user_email");
            console.log("[UserSession] No active session.");
        }
    }

    window.getCurrentUserOrRedirect = async function () {
        if (!_supabaseClient) {
            window.location.href = "login.html";
            return null;
        }

        // P2 Fix 3: Auth timeout — if Supabase getUser hangs, redirect safely
        const AUTH_TIMEOUT_MS = 10000; // 10 seconds
        let timedOut = false;

        const timeoutPromise = new Promise((resolve) => {
            setTimeout(() => {
                timedOut = true;
                resolve({ data: { user: null }, error: { message: "Auth check timed out" } });
            }, AUTH_TIMEOUT_MS);
        });

        const { data, error } = await Promise.race([
            _supabaseClient.auth.getUser(),
            timeoutPromise
        ]);

        if (timedOut) {
            console.warn("[UserSession] Auth check timed out after", AUTH_TIMEOUT_MS, "ms. Redirecting to login.");
            window.location.href = "login.html";
            return null;
        }

        if (error || !data.user) {
            window.location.href = "login.html";
            return null;
        }

        // P2 Fix 4: Detect account switch — if user ID changed, reset PulseEngine load flag
        const prevUserId = localStorage.getItem("_current_user_id");
        if (prevUserId && prevUserId !== data.user.id) {
            console.log("[UserSession] Account switch detected:", prevUserId, "→", data.user.id);
            if (typeof PulseEngine !== 'undefined') {
                PulseEngine.hasLoadedFromSupabase = false;
            }
            // P9B-fix: Clear stale profile on account switch
            window.SMART_PADHAI_PROFILE = null;
            if (typeof renderSidebarStudentProfile === 'function') {
                renderSidebarStudentProfile(null);
            }
        }

        localStorage.setItem("_current_user_id", data.user.id);
        localStorage.setItem("_current_user_email", data.user.email || "");

        return data.user;
    };

    window.getCurrentSession = async function () {
        if (!_supabaseClient) return null;

        const { data, error } = await _supabaseClient.auth.getSession();
        if (error) return null;

        return data.session;
    };

    window.fetchUserRows = async function (tableName, columns = "*") {
        const user = await window.getCurrentUserOrRedirect();
        if (!user) return [];

        const { data, error } = await _supabaseClient
            .from(tableName)
            .select(columns)
            .eq("user_id", user.id);

        if (error) {
            console.error(`[${tableName}] fetch failed:`, error);
            return [];
        }

        return data || [];
    };

    window.upsertUserRow = async function (tableName, row, conflictKey) {
        const user = await window.getCurrentUserOrRedirect();
        if (!user) return null;

        const finalRow = {
            ...row,
            user_id: user.id
        };

        const query = _supabaseClient
            .from(tableName)
            .upsert(finalRow, conflictKey ? { onConflict: conflictKey } : undefined)
            .select();

        const { data, error } = await query;

        if (error) {
            console.error(`[${tableName}] upsert failed:`, error);
            return null;
        }

        return data;
    };

    window.insertUserRow = async function (tableName, row) {
        const user = await window.getCurrentUserOrRedirect();
        if (!user) return null;

        const finalRow = {
            ...row,
            user_id: user.id
        };

        const { data, error } = await _supabaseClient
            .from(tableName)
            .insert(finalRow)
            .select();

        if (error) {
            console.error(`[${tableName}] insert failed:`, error);
            return null;
        }

        return data;
    };

    async function initUserSession() {
        if (!_supabaseClient) return;

        try {
            const { data, error } = await _supabaseClient.auth.getSession();

            if (error) {
                console.warn("[UserSession] getSession error:", error.message);
                return;
            }

            applySession(data?.session);
        } catch (err) {
            console.warn("[UserSession] init failed:", err);
        }

        _supabaseClient.auth.onAuthStateChange((event, session) => {
            console.log("[UserSession] Auth event:", event);
            applySession(session);

            if (event === "SIGNED_OUT") {
                window.location.href = "login.html";
            }
        });
    }

    window.smartPadhaiLogout = async function () {
        // P2 Fix 5: Optional — sync pulse before logout, but ONLY if already loaded
        // This ensures the latest PP/rank is saved to Supabase before switching accounts
        if (typeof PulseEngine !== 'undefined' && PulseEngine.hasLoadedFromSupabase && typeof syncPulseEngineToSupabase === 'function') {
            try {
                await syncPulseEngineToSupabase();
                console.log("[Logout] Pulse synced before logout.");
            } catch (err) {
                console.warn("[Logout] Pulse sync before logout failed:", err);
            }
        }

        // Reset PulseEngine load flag so next login must reload from Supabase
        if (typeof PulseEngine !== 'undefined') {
            PulseEngine.hasLoadedFromSupabase = false;
        }

        // P9B-fix: Clear profile state before redirect to prevent stale data flash
        window.SMART_PADHAI_PROFILE = null;
        window.CURRENT_USER_ID = null;
        if (typeof renderSidebarStudentProfile === 'function') {
            renderSidebarStudentProfile(null);
        }

        if (_supabaseClient) {
            await _supabaseClient.auth.signOut();
        }

        // Only remove session identity keys — do NOT remove user-prefixed SafeStorage data
        // (other accounts' data must be preserved for account switching)
        localStorage.removeItem("_current_user_id");
        localStorage.removeItem("_current_user_email");

        window.location.href = "login.html";
    };

    initUserSession();
})();
// =====================================================
// USER SESSION MANAGER
// Ye file har page pe load hoti hai
// userId ko localStorage mein store karti hai
// Taaki migration.js use kar sake
// =====================================================

const SUPABASE_URL = "https://jgkohrwpyjlfywvqsozj.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_OkDNIEJg0BDU9dx3aqcm8A_uFqb5jd6";

// Global userId — poori site use karegi
window.CURRENT_USER_ID = null;
window.SMART_PADHAI_PROFILE = null;
window.smartPadhaiSupabaseClient = null;

function getStoredStudentProfile() {
    // P9B-fix: Use SafeStorage (user-scoped key) instead of raw localStorage
    // This prevents account-switch profile leakage
    try {
        const profile = SafeStorage.getItem("smart_padhai_user_profile", null);
        if (profile && typeof profile === "object") {
            return profile;
        }
        // Fallback: if SafeStorage returned a string (shouldn't happen but defensive)
        if (typeof profile === "string") {
            try { return JSON.parse(profile); } catch { return null; }
        }
        return null;
    } catch (err) {
        console.warn("[Profile] SafeStorage profile read failed:", err);
        return null;
    }
}

function normalizeStudentProfile(source = {}, user = null) {
    const email = source.email || user?.email || localStorage.getItem("_current_user_email") || "";
    const name = source.name || user?.user_metadata?.full_name || user?.user_metadata?.name || email?.split("@")[0] || "Student";
    const operativeName = source.operativeName || source.operative_name || source.nickname || source.name || name;
    const classLevel = source.classLevel || source.class_level || "";
    const board = source.board || "";
    const operativeLevel = source.operativeLevel || source.operative_level || source.student_tier || "";

    return {
        userId: source.userId || source.user_id || user?.id || localStorage.getItem("_current_user_id") || "",
        name,
        email,
        operativeName,
        nickname: source.nickname || operativeName,
        age: source.age || "",
        bio: source.bio || source.about || "",
        operativeLevel,
        classLevel,
        board,
        academicYear: source.academicYear || source.academic_year || "",
        strengths: Array.isArray(source.strengths) ? source.strengths : [],
        weaknesses: Array.isArray(source.weaknesses) ? source.weaknesses : [],
        struggleNote: source.struggleNote || source.struggle_note || "",
        onboardingCompleted: source.onboardingCompleted ?? source.onboarding_completed ?? false,
        updatedAt: source.updatedAt || source.updated_at || new Date().toISOString()
    };
}

function saveStudentProfileBackup(profile) {
    // P9B-fix: Use SafeStorage (user-scoped key) instead of raw localStorage
    // This ensures profile backups are isolated per user
    try {
        SafeStorage.setItem("smart_padhai_user_profile", profile);
    } catch (err) {
        console.warn("[Profile] SafeStorage profile backup skipped:", err);
    }
}

function titleCaseOperativeLevel(level) {
    if (!level) return "Profile";
    const label = String(level).replace(/_/g, " ").replace(/\b\w/g, char => char.toUpperCase());
    return `${label} Operative`;
}

function profileBelongsToCurrentUser(profile) {
    // P9B-fix: Validate that a profile belongs to the currently logged-in user
    if (!profile) return false;
    const currentUid = localStorage.getItem("_current_user_id");
    if (!currentUid) return false; // no active user
    const profileUid = profile.userId || profile.user_id;
    if (!profileUid) return false; // no owner info — treat as unsafe
    return profileUid === currentUid;
}

function renderSidebarStudentProfile(profile) {
    const card = document.getElementById("sidebarStudentProfile");
    if (!card) return;

    // P9B-fix: Strict data source priority with ownership validation
    // 1. Explicit argument (if provided and belongs to current user)
    // 2. window.SMART_PADHAI_PROFILE (if belongs to current user)
    // 3. SafeStorage backup (if belongs to current user)
    // 4. Fallback to loading/empty state
    let source = null;

    if (profile && profileBelongsToCurrentUser(profile)) {
        source = profile;
    } else if (window.SMART_PADHAI_PROFILE && profileBelongsToCurrentUser(window.SMART_PADHAI_PROFILE)) {
        source = window.SMART_PADHAI_PROFILE;
    } else {
        const stored = getStoredStudentProfile();
        if (stored && profileBelongsToCurrentUser(stored)) {
            source = stored;
        }
    }

    if (!source) {
        // No valid profile for current user — show loading/fallback state
        const avatarEl = document.getElementById("sidebarProfileAvatar");
        const nameEl = document.getElementById("sidebarProfileName");
        const metaEl = document.getElementById("sidebarProfileMeta");
        const levelEl = document.getElementById("sidebarProfileLevel");

        const emailFallback = localStorage.getItem("_current_user_email") || "";
        if (avatarEl) avatarEl.textContent = emailFallback ? emailFallback.charAt(0).toUpperCase() : "?";
        if (nameEl) nameEl.textContent = "Student";
        if (metaEl) metaEl.textContent = "Loading profile...";
        if (levelEl) levelEl.textContent = "";
        return;
    }

    const normalized = normalizeStudentProfile(source);

    const displayName = normalized.operativeName || normalized.nickname || normalized.name || "Student";
    const meta = normalized.classLevel && normalized.board
        ? `${normalized.classLevel} · ${normalized.board}`
        : "Set up profile";

    const avatarEl = document.getElementById("sidebarProfileAvatar");
    const nameEl = document.getElementById("sidebarProfileName");
    const metaEl = document.getElementById("sidebarProfileMeta");
    const levelEl = document.getElementById("sidebarProfileLevel");

    if (avatarEl) avatarEl.textContent = displayName.trim().charAt(0) || "S";
    if (nameEl) nameEl.textContent = displayName;
    if (metaEl) metaEl.textContent = meta;
    if (levelEl) levelEl.textContent = titleCaseOperativeLevel(normalized.operativeLevel);
}

function renderSidebarProfileWhenReady(profile) {
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", () => renderSidebarStudentProfile(profile), { once: true });
        return;
    }
    renderSidebarStudentProfile(profile);
}

async function loadStudentProfile(client, user) {
    // P9B-fix: Account-switch safe profile loading
    // Step 1: Immediately clear sidebar to loading state for the new user
    // This prevents showing the previous user's profile even briefly
    window.SMART_PADHAI_PROFILE = null;
    renderSidebarProfileWhenReady(null); // shows loading state

    // Step 2: Check SafeStorage for current user's profile (user-scoped key)
    let localProfile = getStoredStudentProfile();
    if (localProfile && !profileBelongsToCurrentUser(localProfile)) {
        // Belongs to a different user — do NOT use it
        console.warn("[Profile] Local profile belongs to different user — discarding");
        localProfile = null;
    }

    // Step 2b: Optional migration — if no user-scoped profile exists,
    // check the old global key and migrate if it belongs to current user
    if (!localProfile) {
        try {
            const rawGlobal = localStorage.getItem("smart_padhai_user_profile");
            if (rawGlobal) {
                const globalProfile = JSON.parse(rawGlobal);
                if (globalProfile) {
                    const gUid = globalProfile.userId || globalProfile.user_id;
                    if (gUid === user.id) {
                        console.log("[Profile] Migrating global profile to user-scoped SafeStorage");
                        localProfile = globalProfile;
                        saveStudentProfileBackup(normalizeStudentProfile(localProfile, user));
                    } else if (gUid) {
                        console.log("[Profile] Global profile belongs to different user — skipping migration");
                    }
                }
            }
        } catch (err) {
            console.warn("[Profile] Global profile migration check failed:", err);
        }
    }

    // Step 3: If we have a valid local profile for this user, render it as interim
    let fallbackProfile = normalizeStudentProfile(localProfile || {}, user);
    if (localProfile) {
        renderSidebarProfileWhenReady(fallbackProfile);
    }

    let resolvedProfile = fallbackProfile;

    // Step 4: Always fetch fresh from Supabase
    try {
        const { data, error } = await client
            .from("student_profile")
            .select("*")
            .eq("user_id", user.id)
            .maybeSingle();

        if (error) {
            console.warn("[Profile] Supabase profile load failed; using local/auth fallback:", error);
        } else if (data) {
            resolvedProfile = normalizeStudentProfile(data, user);
            saveStudentProfileBackup(resolvedProfile);
            renderSidebarProfileWhenReady(resolvedProfile);
        } else {
            // No Supabase row — but we still have a valid fallback from auth/local
            // Save it so SafeStorage has something for next time
            if (resolvedProfile.userId) {
                saveStudentProfileBackup(resolvedProfile);
            }
        }
    } catch (err) {
        console.warn("[Profile] Profile load skipped; using local/auth fallback:", err);
    }

    window.SMART_PADHAI_PROFILE = resolvedProfile;
    window.dispatchEvent(new CustomEvent("smartPadhai:profileUpdated", { detail: resolvedProfile }));
    return resolvedProfile;
}

async function logoutSmartPadhai() {
    // P9B-fix: Clear profile state before redirect to prevent stale data flash
    window.SMART_PADHAI_PROFILE = null;
    window.CURRENT_USER_ID = null;

    // Clear sidebar to loading state immediately
    renderSidebarStudentProfile(null);

    try {
        const client = window.smartPadhaiSupabaseClient || supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        await client.auth.signOut();
    } catch (err) {
        console.warn("[Session] Logout warning:", err);
    } finally {
        localStorage.removeItem("_current_user_id");
        localStorage.removeItem("_current_user_token");
        localStorage.removeItem("_current_user_email");
        window.location.href = "./login.html";
    }
}

async function initUserSession() {
    try {
        const client = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        window.smartPadhaiSupabaseClient = client;
        const { data } = await client.auth.getSession();

        if (!data?.session?.user) {
            console.warn("[Session] No user logged in");
            // Login page pe redirect karo agar protected page hai
            const publicPages = ['login.html', 'authcallback.html', 'reset-password.html'];
            const currentPage = window.location.pathname.split('/').pop();
            if (!publicPages.includes(currentPage)) {
                window.location.href = './login.html';
            }
            return;
        }

        const user = data.session.user;
        const userId = user.id;

        // Global variable set karo
        window.CURRENT_USER_ID = userId;
        window.CURRENT_USER_TOKEN = data.session.access_token;

        // localStorage mein bhi save karo — migration.js ke liye
        localStorage.setItem('_current_user_id', userId);
        localStorage.setItem('_current_user_token', data.session.access_token);
        localStorage.setItem('_current_user_email', user.email);

        await loadStudentProfile(client, user);
        console.log("[Session] ✅ User ready:", userId);

    } catch (err) {
        console.error("[Session] Failed:", err);
    }
}

// Helper — user-specific localStorage key banao
function userKey(baseKey) {
    const uid = window.CURRENT_USER_ID || localStorage.getItem('_current_user_id');
    if (!uid) return baseKey; // fallback
    return `${baseKey}_${uid}`;
}

// Page load pe chalao
initUserSession();

// ── P9B: Re-render sidebar profile card on profileUpdated event ──
// This ensures the card updates whenever the profile changes
// (e.g., after onboarding, profile edit, or Supabase sync)
window.addEventListener("smartPadhai:profileUpdated", function (e) {
    const profile = e?.detail || null;
    renderSidebarStudentProfile(profile);
});

// ── P9B: DOMContentLoaded fallback ──
// If initUserSession() ran before the sidebar HTML was parsed,
// re-render the card once the DOM is ready.
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
        renderSidebarStudentProfile();
    }, { once: true });
}

// ═══════════════════════════════════════════════════════
// P9B-fix: PROFILE CARD CLICK → PROFILE MODAL
// ═══════════════════════════════════════════════════════

function openStudentProfileModal() {
    // Remove existing modal if any
    closeStudentProfileModal();

    const profile = window.SMART_PADHAI_PROFILE;
    if (!profile) return; // No profile to show

    const email = localStorage.getItem("_current_user_email") || profile.email || "";
    const displayName = profile.operativeName || profile.nickname || profile.name || "Student";
    const avatarLetter = displayName.trim().charAt(0) || "S";
    const classBoard = profile.classLevel && profile.board
        ? `${profile.classLevel} · ${profile.board}`
        : "Not set";
    const level = titleCaseOperativeLevel(profile.operativeLevel);
    const strengths = Array.isArray(profile.strengths) && profile.strengths.length > 0
        ? profile.strengths.join(", ")
        : "Not set";
    const weaknesses = Array.isArray(profile.weaknesses) && profile.weaknesses.length > 0
        ? profile.weaknesses.join(", ")
        : "Not set";
    const bio = profile.bio || profile.about || "";

    const overlay = document.createElement("div");
    overlay.id = "studentProfileModalOverlay";
    overlay.className = "sp-modal-overlay";
    overlay.setAttribute("data-action", "close-student-profile");

    overlay.innerHTML = `
        <div class="sp-modal-card student-profile-modal" onclick="event.stopPropagation()">
            <div class="profile-modal-header">
                <div class="profile-modal-avatar">${avatarLetter}</div>
                <div class="profile-modal-header-info">
                    <div class="profile-modal-name">${displayName}</div>
                    <div class="profile-modal-email">${email}</div>
                </div>
                <button class="profile-modal-close" data-action="close-student-profile" aria-label="Close profile">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="18" y1="6" x2="6" y2="18"/>
                        <line x1="6" y1="6" x2="18" y2="18"/>
                    </svg>
                </button>
            </div>
            <div class="profile-modal-body">
                <div class="profile-modal-field">
                    <span class="profile-modal-label">Class & Board</span>
                    <span class="profile-modal-value">${classBoard}</span>
                </div>
                <div class="profile-modal-field">
                    <span class="profile-modal-label">Operative Level</span>
                    <span class="profile-modal-value profile-modal-level">${level}</span>
                </div>
                ${bio ? `
                <div class="profile-modal-field">
                    <span class="profile-modal-label">Bio</span>
                    <span class="profile-modal-value">${bio}</span>
                </div>` : ""}
                <div class="profile-modal-field">
                    <span class="profile-modal-label">Strengths</span>
                    <span class="profile-modal-value">${strengths}</span>
                </div>
                <div class="profile-modal-field">
                    <span class="profile-modal-label">Weaknesses</span>
                    <span class="profile-modal-value">${weaknesses}</span>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(overlay);

    // Close on overlay click
    overlay.addEventListener("click", function (e) {
        if (e.target === overlay || e.target.hasAttribute("data-action")) {
            closeStudentProfileModal();
        }
    });

    // Close on Escape
    const escHandler = function (e) {
        if (e.key === "Escape") {
            closeStudentProfileModal();
            document.removeEventListener("keydown", escHandler);
        }
    };
    document.addEventListener("keydown", escHandler);
    overlay._escHandler = escHandler;

    // Animate in
    requestAnimationFrame(() => {
        overlay.style.opacity = "1";
        const card = overlay.querySelector(".sp-modal-card");
        if (card) card.style.transform = "scale(1)";
    });
}

function closeStudentProfileModal() {
    const overlay = document.getElementById("studentProfileModalOverlay");
    if (!overlay) return;
    if (overlay._escHandler) {
        document.removeEventListener("keydown", overlay._escHandler);
    }
    overlay.remove();
}

// Attach click listener to sidebar profile card
function initProfileCardClick() {
    const card = document.getElementById("sidebarStudentProfile");
    if (!card) return;
    card.style.cursor = "pointer";
    card.setAttribute("data-action", "open-student-profile");
    card.addEventListener("click", function (e) {
        e.preventDefault();
        e.stopPropagation();
        openStudentProfileModal();
    });
}

// Init click handler when DOM is ready
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initProfileCardClick, { once: true });
} else {
    initProfileCardClick();
}
