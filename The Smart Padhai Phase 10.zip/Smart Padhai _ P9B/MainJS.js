/**
 * PULSE ENGINE v2.0 — SMART PADHAI (ARCHITECT EDITION)
 * Refactored by Claude (Senior Engineer, Super-Squad)
 *
 * CHANGES FROM v1:
 *  1. addPoints() — Natural Tasks now sync to localStorage reliably.
 *     "Silent rejections" are gone; every rejection logs a reason.
 *  2. Smart Validation — missing/null rewardId is auto-generated.
 *     All guard exits now print a console reason via _reject().
 *  3. Daily Cap raised from 50 PP → 200 PP for Natural Tasks.
 *  4. Legacy Protection — triggerArchitectAscension() and Alfred are
 *     untouched. UI / Progress Bar logic is pixel-perfect as before.
 */

/* ─────────────────────────────────────────────
   RANK LOGOS  (unchanged from original)
───────────────────────────────────────────── */
const rankLogos = {
    "Initiate":    `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 5px #888);"><path d="M12 2L4 5V11C4 16.07 7.41 20.84 12 22C16.59 20.84 20 16.07 20 11V5L12 2Z" stroke="#888" stroke-width="2" fill="rgba(136,136,136,0.2)"/></svg>`,
    "Operator":    `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 8px #00ccff);"><path d="M13 2L3 14H12L11 22L21 10H12L13 2Z" fill="#00ccff"/></svg>`,
    "War Machine": `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 8px #00ff9d);"><path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" fill="#00ff9d"/><path d="M19.4 15V9L17.6 7.2L14.8 7.7L12 5L9.2 7.7L6.4 7.2L4.6 9V15L6.4 16.8L9.2 16.3L12 19L14.8 16.3L17.6 16.8L19.4 15Z" stroke="#00ff9d" stroke-width="2"/></svg>`,
    "Commander":   `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 10px #ffd700);"><path d="M12 2L2 7L12 12L22 7L12 2Z" fill="#ffd700"/><path d="M2 17L12 22L22 17M2 12L12 17L22 12" stroke="#ffd700" stroke-width="2"/></svg>`,
    "Architect":   `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 12px #cc00ff);"><path d="M12 5C7 5 2.73 8.11 1 12.5C2.73 16.89 7 20 12 20C17 20 21.27 16.89 23 12.5C21.27 8.11 17 5 12 5ZM12 17.5C9.24 17.5 7 15.26 7 12.5C7 9.74 9.24 7.5 12 7.5C14.76 7.5 17 9.74 17 12.5C17 15.26 14.76 17.5 12 17.5ZM12 9.5C10.34 9.5 9 10.84 9 12.5C9 14.16 10.34 15.5 12 15.5C13.66 15.5 15 14.16 15 12.5C15 10.84 13.66 9.5 12 9.5Z" fill="#cc00ff"/></svg>`
};

/* ─────────────────────────────────────────────
   PP LOG HELPER — writes to smart_padhai_pp_logs localStorage
   PP Deduction Logging Patch: ensures every PP change
   (positive and negative) is recorded as a daily log entry
   so Dashboard PP circle can calculate today's net PP correctly.
───────────────────────────────────────────── */
function _getLocalDateKey(d) {
    d = d || new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
}

function _writePPLog({ points, type, source, reason, date, createdAt }) {
    try {
        const logs = SafeStorage.getItem('smart_padhai_pp_logs', []) || [];
        if (!Array.isArray(logs)) return;

        const entry = {
            id: `${type === 'negative' ? 'pp_loss' : 'pp_gain'}_${date || _getLocalDateKey()}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
            points: Number(points),
            type: type || (Number(points) >= 0 ? 'positive' : 'negative'),
            source: source || 'System',
            reason: reason || (Number(points) >= 0 ? 'PP reward' : 'PP deduction'),
            date: date || _getLocalDateKey(),
            createdAt: createdAt || new Date().toISOString()
        };

        logs.push(entry);

        // Cap log size: keep last 500 entries to prevent localStorage bloat
        if (logs.length > 500) logs.splice(0, logs.length - 500);

        SafeStorage.setItem('smart_padhai_pp_logs', logs);

        console.info(`[PPLog] ${entry.points >= 0 ? '+' : ''}${entry.points} PP logged | ${entry.source} | ${entry.reason}`);
    } catch (e) {
        console.error('[PPLog] Failed to write PP log:', e);
    }
}

/* ─────────────────────────────────────────────
   PULSE ENGINE v2.0
───────────────────────────────────────────── */
const PulseEngine = {

    DAILY_CAP: 10000000,
    STORAGE_KEY: 'pulse_engine_data',

    // P2 Fix 4: Account-switch protection flag
    // Must be true before syncPulseEngineToSupabase() can write.
    // Prevents default PulseEngine data from overwriting existing Supabase data.
    hasLoadedFromSupabase: false,

    data: (() => {
        let legacy = SafeStorage.getItem(this?.STORAGE_KEY || 'pulse_engine_data') || {};
        return {
            totalPP:       Number(legacy.totalPP    ?? 500),
            level:         legacy.level             || "Initiate",
            hasAscended:   !!legacy.hasAscended,
            shields:       Number(legacy.shields    ?? 1),
            streak:        Number(legacy.streak     ?? 0),
            lastActivity:  legacy.lastActivity      || new Date().toDateString(),
            multiplier:    Number(legacy.multiplier ?? 1.0),
            inventory:     legacy.inventory         || [],
            dailyDate:     legacy.dailyDate         || new Date().toDateString(),
            dailyEarned:   Number(legacy.dailyEarned ?? legacy.dailyEarnedPP ?? 0),
            dailyEarnedPP: Number(legacy.dailyEarnedPP ?? legacy.dailyEarned ?? 0),
            rewardLedger:  legacy.rewardLedger      || {},
            priorityTasks: legacy.priorityTasks     || {}
        };
    })(),

save() {
    SafeStorage.setItem("pulse_engine_data", this.data);

    // P2 Fix 4: Only sync to Supabase if pulse state has been loaded first.
    // This prevents default data (500 PP, Initiate) from overwriting
    // real user data during the race between init and Supabase load.
    if (this.hasLoadedFromSupabase && typeof syncPulseEngineToSupabase === "function") {
        syncPulseEngineToSupabase().catch(err => {
            console.error("[Pulse] Background sync failed:", err);
        });
    } else if (!this.hasLoadedFromSupabase) {
        console.warn("[Pulse] save() called before Supabase load — skipping Supabase sync to prevent data overwrite.");
    }
},

    _reject(reason, context = {}) {
        console.warn(`[PulseEngine] Points rejected — ${reason}`, context);
        if (typeof Alfred !== 'undefined') Alfred.show(`BLOCKED: ${reason}`, 'penalty', 0);
    },

    _resolveRewardId(meta, type) {
        if (meta?.rewardId) return meta.rewardId.trim();
        return `auto_${type}_${new Date().toDateString().replace(/\s+/g, '_')}`;
    },

    dailyCheck() {
        const today = new Date().toDateString();
        if (this.data.dailyDate === today) return;

        const hadIncomplete = Object.values(this.data.priorityTasks || {}).some(v => v === false);
        if (hadIncomplete) {
            // Use deductPoints so negative log is written for Dashboard net PP
            this.data.totalPP = Math.max(0, this.data.totalPP - 10);
            Alfred?.show("PRIORITY MISS: -10 PP", 'penalty', 10);
            _writePPLog({
                points: -10,
                type: 'negative',
                source: 'Penalty',
                reason: 'Priority Miss',
                date: _getLocalDateKey(),
                createdAt: new Date().toISOString()
            });
        }

        this.data.dailyDate = today;
        this.data.dailyEarned = 0;
        this.data.dailyEarnedPP = 0;
        this.data.rewardLedger = {};
        this.data.priorityTasks = {};
        this.calculateLevel();
        this.save();
    },
    /* ── Priority task tracker ── */
    setPriorityTask(taskId, isCompleted) {
        if (!taskId) {
            this._reject('setPriorityTask called without a taskId');
            return;
        }
        this.data.priorityTasks[taskId] = !!isCompleted;
        this.save();
    },

    /* ── CORE: addPoints  [FIX #1, #2, #3] ─────────────────────────────
     *
     *  Parameters
     *    amount   {number|null}  PP to award; null = use baseRates default
     *    type     {string}       'task' | 'mission' | 'timer' | 'checkin'
     *    meta     {object}
     *      .rewardId  {string}   Idempotency key (auto-generated if missing)
     *      .isDev     {boolean}  Bypass daily cap for dev boosts
     *
     *  Returns   {number}  actual PP granted (0 if rejected)
     *
     * ─────────────────────────────────────────────────────────────────── */
    addPoints(amount, type = "task", meta = {}) {
        this.dailyCheck();

        const isDev = meta?.isDev === true;
        const baseRates = { timer: 10, task: 5, mission: 15, checkin: 2 };

        if (amount === null || amount === undefined || isNaN(Number(amount))) {
            amount = baseRates[type] ?? 5;
        }
        amount = Number(amount);
        
        if (amount <= 0) {
            this._reject('amount must be > 0', { amount, type });
            return 0;
        }

        if (!baseRates.hasOwnProperty(type)) {
            this._reject(`unknown type "${type}" — use task/mission/timer/checkin`, { type });
            return 0;
        }

        let rewardId = null;
        if (!isDev && (type === 'task' || type === 'mission')) {
            rewardId = this._resolveRewardId(meta, type);
            if (this.data.rewardLedger[rewardId]) {
                this._reject(`duplicate rewardId "${rewardId}" already claimed today`, { rewardId, type });
                return 0;
            }
        }

        // Timer/checkin: also dedup if caller explicitly provides a rewardId
        // (prevents double-award on page refresh or rapid clicks)
        if (!isDev && (type === 'timer' || type === 'checkin') && meta?.rewardId) {
            const explicitId = String(meta.rewardId);
            if (this.data.rewardLedger[explicitId]) {
                this._reject(`duplicate rewardId "${explicitId}" already claimed`, { rewardId: explicitId, type });
                return 0;
            }
            rewardId = explicitId;
        }

        if (!isDev && this.data.dailyEarned >= this.DAILY_CAP) {
            this._reject(`daily cap reached (${this.DAILY_CAP} PP)`, { dailyEarned: this.data.dailyEarned });
            return 0;
        }

        let m = 1.0;
        if      (this.data.streak >= 30) m = 2.0;
        else if (this.data.streak >= 15) m = 1.5;
        else if (this.data.streak >= 7)  m = 1.2;
        this.data.multiplier = m;

        const finalPoints = Math.floor(amount * m);
        const remaining = isDev ? Infinity : Math.max(0, this.DAILY_CAP - this.data.dailyEarned);
        const granted   = isDev ? finalPoints : Math.min(finalPoints, remaining);

        if (granted <= 0) {
            this._reject('no headroom left under daily cap', { remaining, finalPoints });
            return 0;
        }

        // COMMIT POINTS
        this.data.totalPP += granted;
        if (!isDev) {
            this.data.dailyEarned += granted;
            this.data.dailyEarnedPP += granted;
            if (rewardId) this.data.rewardLedger[rewardId] = true;
        }

        this.calculateLevel();
        this.save(); 

        // UI Feedback
        if (typeof showPPToast === 'function') {
            showPPToast(granted, type, m);
        }

        const multDisplay = document.getElementById('multiplier-tag');
        if (multDisplay) multDisplay.innerText = m + "x";

logPulseTransaction({
    transactionType: "reward",
    reason: type || "PP reward",
    source: type || "unknown",
    rewardId,
    ppChange: granted,
    multiplier: this.data.multiplier,
    finalPP: this.data.totalPP,
    metadata: meta || {}
});

// Write positive PP log to localStorage for Dashboard net PP calculation
_writePPLog({
    points: granted,
    type: 'positive',
    source: type || 'unknown',
    reason: type || 'PP reward',
    date: _getLocalDateKey(),
    createdAt: new Date().toISOString()
});

// Dispatch PP update event so Dashboard circle re-renders
try {
    window.dispatchEvent(new CustomEvent('smartPadhai:ppUpdated'));
} catch (e) { /* non-critical */ }

console.info(`[PulseEngine] +${granted} PP | Total: ${this.data.totalPP}`);
return granted;
    },
    /* ── Deduct points ──
     * PP Deduction Logging Patch:
     *   - Now accepts optional `reason` string
     *   - Writes a negative PP log entry to smart_padhai_pp_logs
     *   - Dispatches smartPadhai:ppUpdated event
     *   - totalPP still clamped to 0 (no negative totalPP)
     *   - dailyEarnedPP is NOT reduced (stays positive-only)
     */
    deductPoints(amount, reason) {
        this.dailyCheck();
        const n = Math.abs(Number(amount || 0));
        if (n <= 0) return;
        this.data.totalPP = Math.max(0, this.data.totalPP - n);
        this.calculateLevel();
        this.save();

        // Write negative PP log for Dashboard net PP calculation
        _writePPLog({
            points: -n,
            type: 'negative',
            source: 'Penalty',
            reason: reason || 'PP deduction',
            date: _getLocalDateKey(),
            createdAt: new Date().toISOString()
        });

        // Dispatch PP update event so Dashboard circle re-renders
        try {
            window.dispatchEvent(new CustomEvent('smartPadhai:ppUpdated'));
        } catch (e) { /* non-critical */ }

        console.info(`[PulseEngine] -${n} PP | Total: ${this.data.totalPP} | Reason: ${reason || 'PP deduction'}`);
    },


    /* ── Rank calculation ── */
    calculateLevel() {
        const pp       = this.data.totalPP;
        const oldLevel = this.data.level;
        let   newLevel = "Initiate";

        if      (pp >= 30000) newLevel = "Architect";
        else if (pp >= 15000) newLevel = "Commander";
        else if (pp >= 5000)  newLevel = "War Machine";
        else if (pp >= 1000)  newLevel = "Operator";

        if (pp < 30000) this.data.hasAscended = false;

        if (newLevel !== oldLevel) {
            if (newLevel === "Architect" && !this.data.hasAscended) {
                this.data.hasAscended = true;
                setTimeout(() => {
                    if (typeof triggerArchitectAscension === 'function') triggerArchitectAscension();
                }, 800);
            }
            this.data.level = newLevel;
            if (typeof Alfred !== 'undefined') Alfred.show(`RANK UPGRADED: ${newLevel}`, 'reward', 0);
        }
        this.syncThemeClasses();
    },

    /* ── Theme sync ── */
    syncThemeClasses() {
        const header = document.querySelector('.master-header');
        if (!header) return;
        const rankClass = `theme-${this.data.level.replace(/\s+/g, '')}`;
        header.classList.remove(
            'theme-Initiate', 'theme-Operator', 'theme-WarMachine', 'theme-Commander', 'theme-Architect'
        );
        header.classList.add(rankClass);
    },

    /* ── UI render (unchanged logic, unchanged element IDs) ── */
    updateUI() {
        const ppValue     = this.data.totalPP;
        const currentRank = this.data.level;

        const elements = {
            level:      document.getElementById('global-level-display'),
            ppDisplay:  document.getElementById('global-pp-display'),
            xpNeeded:   document.getElementById('xp-needed'),
            pulseFill:  document.getElementById('global-pulse-fill'),
            trophy:     document.getElementById('trophy-pp-display'),
            mainBadge:  document.getElementById('main-shard-badge'),
            rankName:   document.getElementById('rank-name')
        };

        // Rank display with logo
        if (elements.level) {
            elements.level.innerHTML = `<div style="display:flex; align-items:center; gap:8px;">${rankLogos[currentRank]} <span>${currentRank}</span></div>`;
            const colors = {
                "Initiate": "#888", "Operator": "#00ccff",
                "War Machine": "#00ff9d", "Commander": "#ffd700", "Architect": "#cc00ff"
            };
            elements.level.style.color = colors[currentRank];
        }

        if (elements.ppDisplay) elements.ppDisplay.innerText = ppValue.toLocaleString();
        if (elements.trophy)    elements.trophy.innerText    = ppValue.toLocaleString();

        // PROGRESS BAR — relative logic (untouched)
        if (elements.pulseFill) {
            const brackets = {
                "Initiate":    { min: 0,     max: 1000,  img: "assets/Iniate rank.png",         color: "#808080" },
                "Operator":    { min: 1000,  max: 5000,  img: "assets/Operator.png",             color: "#00eeff" },
                "War Machine": { min: 5000,  max: 15000, img: "assets/war machine.png",          color: "#39ff14" },
                "Commander":   { min: 15000, max: 30000, img: "assets/commander rank.png",       color: "#ffcc00" },
                "Architect":   { min: 30000, max: 50000, img: "assets/The all seeing Eye.png",   color: "#bc13fe" }
            };

            const config = brackets[currentRank];
            if (elements.xpNeeded) elements.xpNeeded.innerText = `${config.max.toLocaleString()} PP`;

            const relativePP = ppValue - config.min;
            const range      = config.max - config.min;
            const progress   = Math.min(Math.max((relativePP / range) * 100, 0), 100);
            elements.pulseFill.style.width = progress + "%";

            if (elements.mainBadge && elements.mainBadge.getAttribute('src') !== config.img) {
                elements.mainBadge.style.opacity = '0';
                setTimeout(() => {
                    elements.mainBadge.src          = config.img;
                    elements.mainBadge.style.opacity = '0.7';
                }, 300);
            }
            if (elements.rankName) elements.rankName.innerText = currentRank;

            document.documentElement.style.setProperty('--accent-color', config.color);
            document.documentElement.style.setProperty('--accent-glow',  config.color + "66");
        }

        this.syncThemeClasses();
        if (typeof updateTimelinePath === 'function') updateTimelinePath();
    }
};
window.PulseEngine = PulseEngine;
/* ─────────────────────────────────────────────
   LEGACY PRESERVED — DO NOT MODIFY
   triggerArchitectAscension + Alfred
───────────────────────────────────────────── */
function triggerArchitectAscension() {
    const overlay = document.getElementById('ascension-overlay');
    if (!overlay) return;
    overlay.style.display  = 'flex';
    overlay.style.opacity  = '1';
    overlay.classList.add('flash-active');
    setTimeout(() => overlay.classList.add('show-content'), 500);
    setTimeout(() => {
        overlay.style.transition = "opacity 3s cubic-bezier(0.4, 0, 0.2, 1)";
        overlay.style.opacity    = '0';
        setTimeout(() => {
            overlay.style.display = 'none';
            overlay.classList.remove('flash-active', 'show-content');
            overlay.style.opacity = '1';
        }, 3000);
    }, 9000);
}

const Alfred = {
    show(message, type = 'reward', cost = 0) {
        const card  = document.getElementById('alfred-card');
        const text  = document.getElementById('alfred-text');
        const badge = document.getElementById('alfred-badge');
        if (!card) return;
        card.className = type + '-mode active';
        const headers = {
            'reward':  'SYST_AUTH // SUCCESS',
            'penalty': 'SYST_WARN // PENALTY',
            'jar':     'NEURAL_SYNC // COOKIE_JAR'
        };
        badge.innerHTML = `<span>${headers[type]}</span>`;
        text.style.opacity = '0';
        text.innerText     = message;
        setTimeout(() => { text.style.transition = "opacity 0.5s ease"; text.style.opacity = '1'; }, 300);
        setTimeout(() => card.classList.remove('active'), 7000);
    }
};
function showPPToast(granted, type, multiplier) {
  const typeColors = {
    task: '#7F77DD', mission: '#cc00ff',
    timer: '#00ff9d', checkin: '#00ccff'
  };
  const color = typeColors[type] || '#cc00ff';
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'pp-toast';
  toast.innerHTML =
    `<span style="color:${color};font-size:18px">+${granted} PP</span>` +
    `<span style="font-size:12px;opacity:0.6">${type}</span>` +
    (multiplier > 1 ? `<span class="pp-mult">${multiplier}x</span>` : '');

  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}
/* ─────────────────────────────────────────────
   UTILITY FUNCTIONS (unchanged)
───────────────────────────────────────────── */
function openCookieJar() {
    const victories = [
        "Remember when you crushed that Physics backlog?",
        "You stop when you're DONE.",
        "Stay Hard!"
    ];
    PulseEngine.deductPoints(10, 'Cookie Jar');
    Alfred.show(victories[Math.floor(Math.random() * victories.length)], 'jar', 10);
}
function showRankDetail(rankName) {
    const detailPanel = document.getElementById('rank-detail-panel');
    if (!detailPanel) {
        console.error("Panel element 'rank-detail-panel' missing!");
        return;
    }

    const rank = rankData.find(r => r.name === rankName);
    if (!rank) return;

    const currentPP = PulseEngine.data.totalPP;
    
    // Status logic
    const statusText = currentPP >= rank.points ? 
        `<span style="color:${rank.color}">[ COMPLETED ]</span>` : 
        `<span style="color:#ff4d4d">[ LOCKED ]</span>`;

    // HTML Update
    detailPanel.innerHTML = `
        <div class="rank-detail-wrapper" style="display:flex; justify-content: space-between; align-items: flex-start; text-align: left;">
            <div class="detail-main">
                <h4 style="color:${rank.color}; margin:0; font-size: 16px; letter-spacing: 2px;">
                    ${rank.name.toUpperCase()} STATUS: ${statusText}
                </h4>
                <p style="color:#eee; margin:10px 0; font-size: 13px; font-style: italic; max-width: 400px;">
                    "${rank.desc}"
                </p>
            </div>
            <div class="detail-stats" style="border-left: 1px solid rgba(255,255,255,0.1); padding-left: 20px;">
                <p style="margin:0; font-size: 11px; color: #888;">REQUIREMENT: <span style="color:#fff">${rank.points} PP</span></p>
                <p style="margin:5px 0 0; font-size: 11px; color: #888;">UNLOCKED PERKS: <span style="color:${rank.color}">Standard Protocol</span></p>
            </div>
        </div>
    `;
    
    console.log("Panel updated for:", rankName); // Debugging ke liye
}
const rankData = [
    { name: "Initiate",    points: 0,     icon: "🛡️", desc: "The journey begins.",    color: "#888"     },
    { name: "Operator",    points: 1000,  icon: "⚡", desc: "Breaking the cycle.",    color: "#00ccff"  },
    { name: "War Machine", points: 5000,  icon: "⚙️", desc: "Unstoppable force.",      color: "#00ff9d"  },
    { name: "Commander",   points: 15000, icon: "🦅", desc: "Tactical genius.",        color: "#ffd700"  },
    { name: "Architect",   points: 30000, icon: "👁️", desc: "You create the rules.",   color: "#cc00ff"  }
];

function openRankModal() {
    const container = document.getElementById('rank-list-container');
    const pp = PulseEngine.data.totalPP;
    const currentRank = PulseEngine.data.level;
    
    // 1. Rank Nodes generate karo
    container.innerHTML = rankData.map(rank => `
        <div class="rank-node ${pp >= rank.points ? 'unlocked' : ''} ${currentRank === rank.name ? 'current' : ''}" 
             onclick="showRankDetail('${rank.name}')">
            <div class="node-circle">${rank.icon}</div>
            <div class="node-name">${rank.name.toUpperCase()}</div>
        </div>`).join('');

    // 2. Default detail load karo (Architect level details)
    showRankDetail(currentRank);

    // 3. Modal show karo
    const modal = document.getElementById('rank-modal');
    modal.style.display = 'flex';

    // 4. FIX: Agar "x" button kaam nahi kar raha, toh modal ke bahar click karne par close ho jaye
    modal.onclick = function(event) {
        if (event.target === modal) {
            closeRankModal();
        }
    }
}
// Modal band karne ka function jo missing tha
function closeRankModal() {
    const modal = document.getElementById('rank-modal');
    if (modal) {
        modal.style.display = 'none';
        console.log("Ranking Protocol v2.0: Modal Closed Safely.");
    }
}
function updateTimelinePath() {
    const trackFill = document.querySelector('.timeline-track-fill');
    if (!trackFill) return;
    const pp = PulseEngine.data.totalPP;
    const fill = pp >= 30000 ? 100 : pp >= 15000 ? 75 : pp >= 5000 ? 50 : pp >= 1000 ? 25 : 0;
    setTimeout(() => { trackFill.style.width = fill + "%"; }, 300);
}
function triggerDevPoints() {
    console.log("🛠️ DEV_PROTOCOL: Initiating 1000 PP Boost...");
    
    // Claude ke engine ke hisaab se sahi injection:
    const granted = PulseEngine.addPoints(1000, 'mission', { 
        rewardId: 'dev_boost_' + Date.now(), 
        isDev: true 
    });

}
async function loadPulseEngineFromSupabase() {
    const user = await getCurrentUserOrRedirect();
    if (!user) return null;

    try {
        const { data, error } = await supabaseClient
            .from("pulse_engine_state")
            .select("*")
            .eq("user_id", user.id)
            .maybeSingle();

        if (error) {
            console.error("[Pulse] Load failed:", error);
            // Even on error, mark as loaded so we don't block forever.
            // Default data will be used as fallback.
            PulseEngine.hasLoadedFromSupabase = true;
            return null;
        }

        if (!data) {
            // NEW USER: No pulse row exists yet. Create default state in Supabase.
            console.warn("[Pulse] No pulse state found for user. Creating default state.");
            PulseEngine.hasLoadedFromSupabase = true; // Allow sync for new user
            const syncResult = await syncPulseEngineToSupabase();
            return syncResult;
        }

        // EXISTING USER: Restore pulse state from Supabase (source of truth)
        // P6G Patch: daily earned PP is highly UI-sensitive and can lag in Supabase.
        // If the current user's local SafeStorage has a higher daily value for today,
        // preserve it instead of allowing a stale cloud 0 to wipe the dashboard circle.
        const localPulse = SafeStorage.getItem("pulse_engine_data", {}) || {};
        const todayStr = new Date().toDateString();
        const cloudDailyEarned = Number(
            data.daily_earned_pp ??
            data.dailyEarnedPP ??
            data.dailyEarned ??
            0
        );
        const localDailyEarned = Number(
            localPulse.dailyEarnedPP ??
            localPulse.dailyEarned ??
            0
        );
        const localDailyDate = localPulse.dailyDate || localPulse.lastActivity || null;
        const mergedDailyEarned =
            localDailyDate === todayStr
                ? Math.max(cloudDailyEarned, localDailyEarned)
                : cloudDailyEarned;

        const pulseData = {
            totalPP: data.total_pp || 0,

            dailyEarnedPP: mergedDailyEarned,
            dailyEarned: mergedDailyEarned,

            level: data.level || data.rank || "Initiate",
            rank: data.rank || data.level || "Initiate",
            hasAscended: !!data.has_ascended,
            streak: data.streak_days || 0,
            bestStreak: data.best_streak || 0,
            multiplier: Number(data.multiplier || 1),

            lastActiveDate: data.last_active_date || null,
            lastResetDate: data.last_reset_date || null,

            rewardLedger: data.reward_ledger || {},
            penaltyLedger: data.penalty_ledger || {},

            // Preserve fields not in Supabase but in local state
            shields: PulseEngine.data.shields || 1,
            inventory: PulseEngine.data.inventory || [],
            lastActivity: data.last_active_date || PulseEngine.data.lastActivity || todayStr,
            dailyDate: localDailyDate === todayStr ? localDailyDate : todayStr,
            priorityTasks: PulseEngine.data.priorityTasks || {}
        };

        SafeStorage.setItem("pulse_engine_data", pulseData);

        // OVERWRITE default data with real Supabase data
        PulseEngine.data = {
            ...PulseEngine.data,
            ...pulseData
        };

        // P2 Fix 4: Mark as loaded — now sync is allowed
        PulseEngine.hasLoadedFromSupabase = true;

        console.log("[Pulse] Loaded from Supabase (source of truth):", {
            totalPP: pulseData.totalPP,
            level: pulseData.level,
            streak: pulseData.streak
        });
        return pulseData;
    } catch (err) {
        console.error("[Pulse] Load exception:", err);
        PulseEngine.hasLoadedFromSupabase = true; // Unblock on exception
        return null;
    }
}
async function syncPulseEngineToSupabase() {
    // P2 Fix 4: Block sync until pulse state has loaded from Supabase.
    // This prevents default PulseEngine data from overwriting real user data.
    if (!PulseEngine.hasLoadedFromSupabase) {
        console.warn("[Pulse] syncPulseEngineToSupabase BLOCKED — pulse not loaded from Supabase yet.");
        return null;
    }

    const user = await getCurrentUserOrRedirect();
    if (!user) return null;

    const pulse = SafeStorage.getItem("pulse_engine_data", PulseEngine?.data || {});

    const row = {
        user_id: user.id,

        total_pp: Number(pulse.totalPP || pulse.pp || 0),
        daily_earned_pp: Number(
            pulse.dailyEarnedPP ??
            pulse.dailyEarned ??
            pulse.daily_earned_pp ??
            0
        ),

        rank: pulse.rank || pulse.level || "Initiate",
        level: pulse.level || pulse.rank || "Initiate",

        streak_days: Number(pulse.streak || pulse.streakDays || 0),
        best_streak: Number(pulse.bestStreak || 0),
        multiplier: Number(pulse.multiplier || 1),

        last_active_date: pulse.lastActiveDate || null,
        last_reset_date: pulse.lastResetDate || null,

        reward_ledger: pulse.rewardLedger || {},
        penalty_ledger: pulse.penaltyLedger || {},
        raw_data: pulse,

        updated_at: new Date().toISOString()
    };

    const { data, error } = await supabaseClient
        .from("pulse_engine_state")
        .upsert(row, {
            onConflict: "user_id"
        })
        .select()
        .single();

    if (error) {
        console.error("[Pulse] Sync failed:", error);
        return null;
    }

    await syncPulseSummaryToProfile(row);

    console.log("[Pulse] Synced:", data);
    return data;


}
async function syncPulseSummaryToProfile(pulseRow) {
    const user = await getCurrentUserOrRedirect();
    if (!user) return null;

    const { data, error } = await supabaseClient
        .from("student_profile")
        .upsert({
            user_id: user.id,
            user_key: user.id,
            email: user.email,

            total_pp: pulseRow.total_pp,
            daily_earned_pp: pulseRow.daily_earned_pp,
            rank: pulseRow.rank,
            level: pulseRow.level,
            streak_days: pulseRow.streak_days,
            best_streak: pulseRow.best_streak,
            multiplier: pulseRow.multiplier,

            updated_at: new Date().toISOString()
        }, {
            onConflict: "user_id"
        })
        .select()
        .single();

    if (error) {
        console.error("[Pulse/Profile] Sync failed:", error);
        return null;
    }

    return data;
}
async function logPulseTransaction({
    transactionType = "reward",
    reason = "",
    source = "",
    rewardId = null,
    ppChange = 0,
    multiplier = 1,
    finalPP = 0,
    metadata = {}
}) {
    const user = await getCurrentUserOrRedirect();
    if (!user) return null;

    const { data, error } = await supabaseClient
        .from("pulse_transactions")
        .insert({
            user_id: user.id,
            transaction_type: transactionType,
            reason,
            source,
            reward_id: rewardId,
            pp_change: ppChange,
            multiplier,
            final_pp: finalPP,
            metadata
        })
        .select()
        .single();

    if (error) {
        if (String(error.message).includes("duplicate")) {
            console.warn("[Pulse] Duplicate reward blocked:", rewardId);
            return null;
        }

        console.error("[Pulse] Transaction log failed:", error);
        return null;
    }

    return data;
}
/* ─────────────────────────────────────────────
   STREAK SYSTEM V2 — QUALIFIED STUDY DAY
   Streak is no longer just "todayPP > 0".
   A day counts for streak only if the student performs
   meaningful study work (net PP + real activity signals).
───────────────────────────────────────────── */
const StreakSystem = {

    QUALIFIED_KEY: 'smart_padhai_streak_qualified_days',
    PP_LOGS_KEY: 'smart_padhai_pp_logs',
    SNAPSHOTS_KEY: 'productivity_snapshots_log',
    SESSION_REVIEWS_KEY: 'smart_padhai_session_reviews',
    MASTER_KEY: 'smartPadhaiData',

    // Minimum thresholds
    NET_PP_THRESHOLD: 20,
    FOCUS_MIN_THRESHOLD: 25,
    FOCUS_RECOVERY_THRESHOLD: 45,
    TASK_THRESHOLD: 1,

    // Last dispatched quality — prevents duplicate streakUpdated events
    _lastQuality: null,

    /**
     * Get today's date key in YYYY-MM-DD format (local time).
     */
    _dateKey(d) {
        d = d || new Date();
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
    },

    /**
     * Read PP logs from localStorage safely.
     */
    _getPPLogs() {
        try {
            const raw = SafeStorage.getItem(this.PP_LOGS_KEY, []);
            if (!raw || !Array.isArray(raw)) return [];
            return raw;
        } catch (e) { return []; }
    },

    /**
     * Calculate net PP for a specific date from PP logs.
     */
    _getNetPPForDate(dateKey) {
        const logs = this._getPPLogs();
        return logs
            .filter(log => {
                if (!log) return false;
                const rawDate = log.date || log.createdAt;
                if (!rawDate) return false;
                const logDateKey = String(rawDate).includes('T')
                    ? this._dateKey(new Date(rawDate))
                    : String(rawDate).slice(0, 10);
                return logDateKey === dateKey;
            })
            .reduce((sum, log) => {
                const points = Number(log.points || 0);
                return Number.isFinite(points) ? sum + points : sum;
            }, 0);
    },

    /**
     * Get today's focus minutes from productivity_snapshots_log.
     * Falls back to 0 if no data available. Never fakes focus minutes.
     */
    _getTodayFocusMinutes() {
        const today = this._dateKey();
        try {
            const snapshots = SafeStorage.getItem(this.SNAPSHOTS_KEY, []);
            if (!Array.isArray(snapshots)) return 0;
            const todaySnap = snapshots.find(s => s && s.snapshot_date === today);
            if (todaySnap && Number(todaySnap.focus_minutes || 0) > 0) {
                return Number(todaySnap.focus_minutes);
            }
        } catch (e) { /* no data */ }
        return 0;
    },

    /**
     * Count tasks/chapters completed today from smartPadhaiData.
     * A completed task means read && notes && pyq all true,
     * with lastUpdated timestamp matching today.
     * Never fakes completed tasks.
     */
    _getTodayCompletedTasks() {
        const today = this._dateKey();
        let count = 0;
        try {
            const masterData = SafeStorage.getItem(this.MASTER_KEY, {});
            if (!masterData || typeof masterData !== 'object' || Array.isArray(masterData)) return 0;

            function toBool(v) { return v === true || v === 'true'; }

            for (const chap in masterData) {
                const entry = masterData[chap];
                if (!entry || typeof entry !== 'object') continue;
                const read = toBool(entry.read);
                const notes = toBool(entry.notes);
                const pyq = toBool(entry.pyq);
                const completed = read && notes && pyq;

                if (completed && entry.lastUpdated) {
                    const lastDate = String(entry.lastUpdated).includes('T')
                        ? this._dateKey(new Date(entry.lastUpdated))
                        : String(entry.lastUpdated).slice(0, 10);
                    if (lastDate === today) count++;
                }
            }
        } catch (e) { /* no data */ }
        return count;
    },

    /**
     * Count session reviews saved today.
     * Never fakes reviews.
     */
    _getTodaySessionReviews() {
        const today = this._dateKey();
        try {
            const reviews = SafeStorage.getItem(this.SESSION_REVIEWS_KEY, []);
            if (!Array.isArray(reviews)) return 0;
            return reviews.filter(r => {
                if (!r || !r.date) return false;
                const reviewDate = String(r.date).includes('T')
                    ? this._dateKey(new Date(r.date))
                    : String(r.date).slice(0, 10);
                return reviewDate === today;
            }).length;
        } catch (e) { return 0; }
    },

    /**
     * Count backlog items cleared today from productivity_snapshots_log.
     * Falls back to 0. Never fakes backlog clearings.
     */
    _getTodayBacklogCleared() {
        const today = this._dateKey();
        try {
            const snapshots = SafeStorage.getItem(this.SNAPSHOTS_KEY, []);
            if (!Array.isArray(snapshots)) return 0;
            const todaySnap = snapshots.find(s => s && s.snapshot_date === today);
            if (todaySnap && Number(todaySnap.backlogs_cleared || 0) > 0) {
                return Number(todaySnap.backlogs_cleared);
            }
        } catch (e) { /* no data */ }
        return 0;
    },

    /**
     * CORE: Get today's qualification summary.
     * Returns a structured object with qualification status,
     * quality level, all signals, and human-readable reasons/missing.
     */
    getTodayQualificationSummary() {
        const todayNetPP = this._getNetPPForDate(this._dateKey());
        const focusMinutes = this._getTodayFocusMinutes();
        const completedTasks = this._getTodayCompletedTasks();
        const sessionReviews = this._getTodaySessionReviews();
        const backlogCleared = this._getTodayBacklogCleared();

        const meaningfulSignal =
            focusMinutes >= this.FOCUS_MIN_THRESHOLD ||
            completedTasks >= this.TASK_THRESHOLD ||
            sessionReviews >= this.TASK_THRESHOLD ||
            backlogCleared >= this.TASK_THRESHOLD;

        const hasPartialSignal =
            focusMinutes > 0 ||
            completedTasks > 0 ||
            sessionReviews > 0 ||
            backlogCleared > 0;

        let qualifies = false;
        let quality = 'none';
        const reasons = [];
        const missing = [];

        // ── Rule A: Normal qualification ──
        if (todayNetPP >= this.NET_PP_THRESHOLD && meaningfulSignal) {
            qualifies = true;
            quality = 'secured';
            reasons.push(`Net PP ${todayNetPP} >= ${this.NET_PP_THRESHOLD}`);
            if (focusMinutes >= this.FOCUS_MIN_THRESHOLD) reasons.push(`${focusMinutes} min focus`);
            if (completedTasks >= 1) reasons.push(`${completedTasks} task(s) completed`);
            if (sessionReviews >= 1) reasons.push(`${sessionReviews} review(s)`);
            if (backlogCleared >= 1) reasons.push(`${backlogCleared} backlog cleared`);
        }

        // ── Special Recovery Rule ──
        if (todayNetPP < 0 && focusMinutes >= this.FOCUS_RECOVERY_THRESHOLD && completedTasks >= 1) {
            qualifies = true;
            quality = 'recovery';
            reasons.push(`Recovery: ${focusMinutes} min focus + ${completedTasks} task(s) despite net ${todayNetPP} PP`);
        }

        // ── Quality upgrades ──
        if (qualifies && quality !== 'recovery') {
            if (todayNetPP >= 100 && completedTasks >= 2) {
                quality = 'elite';
            } else if (todayNetPP >= 50 || focusMinutes >= 45) {
                quality = 'strong';
            }
        }

        // ── "Almost" detection ──
        if (!qualifies) {
            if (todayNetPP >= this.NET_PP_THRESHOLD && !meaningfulSignal) {
                quality = 'almost';
                reasons.push(`Net PP ${todayNetPP} met but no meaningful signal`);
                missing.push('Need 25+ min focus OR 1+ task/review/backlog');
            } else if (meaningfulSignal && todayNetPP < this.NET_PP_THRESHOLD) {
                quality = 'almost';
                reasons.push(`Has activity signal but Net PP ${todayNetPP} < ${this.NET_PP_THRESHOLD}`);
                missing.push(`Need ${this.NET_PP_THRESHOLD - todayNetPP} more net PP`);
            } else if (hasPartialSignal && todayNetPP < this.NET_PP_THRESHOLD) {
                quality = 'almost';
                reasons.push(`Partial activity (${focusMinutes} min, ${completedTasks} tasks)`);
                missing.push(`Need ${this.NET_PP_THRESHOLD - todayNetPP} more net PP + stronger signal`);
            } else if (todayNetPP < 0) {
                quality = 'none';
                reasons.push(`Net PP is negative (${todayNetPP})`);
                if (focusMinutes >= this.FOCUS_RECOVERY_THRESHOLD) {
                    missing.push('Need 1+ completed task for recovery');
                } else {
                    missing.push(`Need ${this.FOCUS_RECOVERY_THRESHOLD}+ min focus + 1 task for recovery`);
                }
            } else {
                reasons.push(`Net PP ${todayNetPP} < ${this.NET_PP_THRESHOLD}`);
                missing.push(`Need ${this.NET_PP_THRESHOLD - todayNetPP} more net PP + study signal`);
            }
        }

        return {
            qualifies,
            quality,
            todayNetPP,
            focusMinutes,
            completedTasks,
            sessionReviews,
            backlogCleared,
            reasons,
            missing
        };
    },

    /**
     * Get the qualified days log from storage.
     * Returns an object keyed by date string.
     */
    _getQualifiedDaysLog() {
        try {
            return SafeStorage.getItem(this.QUALIFIED_KEY, {}) || {};
        } catch (e) { return {}; }
    },

    /**
     * Save today's qualification result to the forward-compatible log.
     * Does not delete old data. Only writes today's entry.
     */
    _saveTodayQualification(summary) {
        try {
            const log = this._getQualifiedDaysLog();
            const today = this._dateKey();

            log[today] = {
                qualifies: summary.qualifies,
                quality: summary.quality,
                todayNetPP: summary.todayNetPP,
                focusMinutes: summary.focusMinutes,
                completedTasks: summary.completedTasks,
                sessionReviews: summary.sessionReviews,
                backlogCleared: summary.backlogCleared,
                updatedAt: new Date().toISOString()
            };

            // Keep only last 90 days of qualification data
            const cutoff = new Date();
            cutoff.setDate(cutoff.getDate() - 90);
            const cutoffKey = this._dateKey(cutoff);
            for (const key in log) {
                if (key < cutoffKey) delete log[key];
            }

            SafeStorage.setItem(this.QUALIFIED_KEY, log);
        } catch (e) {
            console.warn('[StreakSystem] Failed to save qualification log:', e);
        }
    },

    /**
     * Refresh streak calculation.
     * - Evaluates today's qualification
     * - Saves to qualified days log
     * - Calculates current and best streak
     * - Dispatches streakUpdated event only on actual state change
     */
    refreshStreak() {
        try {
            const summary = this.getTodayQualificationSummary();
            this._saveTodayQualification(summary);

            const streakData = this._calculateStreaks(summary);
            this._currentStreakData = streakData;

            // Dispatch event only if quality actually changed
            if (this._lastQuality !== summary.quality) {
                this._lastQuality = summary.quality;
                try {
                    window.dispatchEvent(new CustomEvent('smartPadhai:streakUpdated'));
                } catch (e) { /* non-critical */ }
            }
        } catch (err) {
            console.warn('[StreakSystem] refreshStreak failed:', err);
        }
    },

    /**
     * Calculate current and best streak.
     * For TODAY: uses the qualification summary.
     * For historical days: checks qualified days log first,
     * then falls back to legacy activeDates (pp > 0) if no qualification data.
     */
    _calculateStreaks(todaySummary) {
        const qualifiedLog = this._getQualifiedDaysLog();
        const ppLogs = this._getPPLogs();

        // Build a set of dates that had PP > 0 (legacy fallback)
        const legacyActiveDates = new Set();
        for (const log of ppLogs) {
            if (!log) continue;
            const rawDate = log.date || log.createdAt;
            if (!rawDate) continue;
            const dateKey = String(rawDate).includes('T')
                ? this._dateKey(new Date(rawDate))
                : String(rawDate).slice(0, 10);
            if (Number(log.points || 0) > 0) {
                legacyActiveDates.add(dateKey);
            }
        }

        // Build set of qualified dates
        const qualifiedDates = new Set();
        for (const [dateKey, entry] of Object.entries(qualifiedLog)) {
            if (entry && entry.qualifies) {
                qualifiedDates.add(dateKey);
            }
        }

        // Today qualifies?
        const today = this._dateKey();
        const todayQualified = todaySummary.qualifies;

        // Count current streak backwards from today
        let currentStreak = 0;
        if (todayQualified) {
            currentStreak = 1;
            let d = new Date();
            d.setDate(d.getDate() - 1);
            while (true) {
                const key = this._dateKey(d);
                // Check qualified log first, then legacy fallback
                if (qualifiedLog[key]) {
                    if (qualifiedLog[key].qualifies) {
                        currentStreak++;
                        d.setDate(d.getDate() - 1);
                    } else {
                        break; // Qualified log says NOT qualified — trust it
                    }
                } else if (legacyActiveDates.has(key)) {
                    // Legacy: no qualification data, but had PP > 0 — count as active
                    currentStreak++;
                    d.setDate(d.getDate() - 1);
                } else {
                    break;
                }
            }
        } else {
            // Today not qualified — streak is 0 even if yesterday was active
            // But we still report the "pending" streak (streak that would continue if today qualified)
            let d = new Date();
            d.setDate(d.getDate() - 1);
            while (true) {
                const key = this._dateKey(d);
                if (qualifiedLog[key]) {
                    if (qualifiedLog[key].qualifies) {
                        currentStreak++;
                        d.setDate(d.getDate() - 1);
                    } else {
                        break;
                    }
                } else if (legacyActiveDates.has(key)) {
                    currentStreak++;
                    d.setDate(d.getDate() - 1);
                } else {
                    break;
                }
            }
        }

        // Calculate best streak from last 90 days
        let bestStreak = 0;
        let run = 0;
        const start = new Date();
        start.setDate(start.getDate() - 90);
        for (let i = 0; i < 90; i++) {
            const d = new Date(start);
            d.setDate(d.getDate() + i);
            const key = this._dateKey(d);
            const isQualified = key === today
                ? todayQualified
                : (qualifiedLog[key] ? qualifiedLog[key].qualifies : legacyActiveDates.has(key));
            if (isQualified) {
                run++;
                if (run > bestStreak) bestStreak = run;
            } else {
                run = 0;
            }
        }
        bestStreak = Math.max(bestStreak, currentStreak);

        // Active days this month
        const now = new Date();
        const monthStart = this._dateKey(new Date(now.getFullYear(), now.getMonth(), 1));
        let activeDaysThisMonth = 0;
        for (const [dateKey, entry] of Object.entries(qualifiedLog)) {
            if (dateKey >= monthStart && entry.qualifies) activeDaysThisMonth++;
        }
        // Also count legacy active days this month that don't have qualification data
        for (const dateKey of legacyActiveDates) {
            if (dateKey >= monthStart && !qualifiedLog[dateKey]) activeDaysThisMonth++;
        }

        // Build activeDates array (for heatmap tooltip enhancement)
        const activeDates = [...qualifiedDates];
        for (const dateKey of legacyActiveDates) {
            if (!qualifiedLog[dateKey]) activeDates.push(dateKey);
        }

        return {
            currentStreak,
            bestStreak,
            activeDaysThisMonth,
            activeDates,
            todayQualified,
            todayQuality: todaySummary.quality
        };
    },

    /**
     * Get streak summary for external consumers.
     * Returns cached data if available, otherwise recalculates.
     */
    getStreakSummary() {
        if (!this._currentStreakData) {
            this.refreshStreak();
        }
        return this._currentStreakData || {
            currentStreak: 0,
            bestStreak: 0,
            activeDaysThisMonth: 0,
            activeDates: [],
            todayQualified: false,
            todayQuality: 'none'
        };
    },

    /**
     * Get qualification data for a specific date.
     * Returns null if no data exists for that date.
     */
    getQualificationForDate(dateKey) {
        const log = this._getQualifiedDaysLog();
        return log[dateKey] || null;
    },

    // Cached streak data
    _currentStreakData: null
};
window.StreakSystem = StreakSystem;

/* ─────────────────────────────────────────────
   AUTH-SAFE INIT — called from protected pages after userSession is ready
───────────────────────────────────────────── */
PulseEngine.loadFromSupabase = loadPulseEngineFromSupabase;
PulseEngine.syncToSupabase = syncPulseEngineToSupabase;
window.PulseEngine = PulseEngine;
window.loadPulseEngineFromSupabase = loadPulseEngineFromSupabase;
window.syncPulseEngineToSupabase = syncPulseEngineToSupabase;

window.initPulseEngineAfterAuth = async function initPulseEngineAfterAuth() {
    try {
        const user = await getCurrentUserOrRedirect();
        if (!user) return null;

        await loadPulseEngineFromSupabase();
        PulseEngine.dailyCheck();
        PulseEngine.updateUI();

        console.info("[PulseEngine] Initialized after auth:", {
            user_id: user.id,
            totalPP: PulseEngine.data.totalPP,
            level: PulseEngine.data.level,
            dailyEarned: PulseEngine.data.dailyEarned
        });
        return PulseEngine.data;
    } catch (err) {
        console.error("[PulseEngine] Auth-safe init failed:", err);
        return null;
    }
};
