/**
 * Smart Padhai — Panic Protocol V2A
 * Plan Type Detector + Chapter Urgency Ranking + Dashboard preview data.
 *
 * Safety: reads existing SafeStorage/localStorage data only, does not mutate app data,
 * does not touch the DOM, does not dispatch events, and does not make API calls.
 */
(function () {
    'use strict';

    const MASTER_KEY = 'smartPadhaiData';
    const MEMORY_KEY = 'smart_padhai_memory_decay';
    const CALENDAR_KEY = 'calendarStrategy';
    const AUTOPSY_KEY = 'smart_padhai_exam_autopsies';
    const PP_KEY = 'pulse_engine_data';
    const EXAM_SCOPE_KEY = 'smart_padhai_exam_scope';
    const EXAM_SYLLABUS_KEYS = [
        EXAM_SCOPE_KEY,
        'smart_padhai_exam_syllabus',
        'smart_padhai_exam_syllabus_selection',
        'smart_padhai_selected_exam_syllabus',
        'examSyllabusSelection',
        'selectedExamSyllabus',
        'selected_exam_syllabus'
    ];

    const PLAN_LABELS = {
        '3_DAY_RESCUE': '3-Day Rescue',
        '7_DAY_BLITZ': '7-Day Blitz',
        '14_DAY_SIEGE': '14-Day Siege',
        FRESH_START: 'Fresh Start',
        NORMAL: 'Normal Mode'
    };

    function safeGet(key, fallback) {
        try {
            if (window.SafeStorage && typeof window.SafeStorage.getItem === 'function') {
                const value = window.SafeStorage.getItem(key, fallback);
                return value === undefined || value === null ? fallback : value;
            }
        } catch (error) {
            // Fall through to localStorage.
        }

        try {
            const raw = window.localStorage ? window.localStorage.getItem(key) : null;
            if (raw === undefined || raw === null || raw === '') return fallback;
            try {
                return JSON.parse(raw);
            } catch (error) {
                return raw;
            }
        } catch (error) {
            return fallback;
        }
    }

    function toBool(value) {
        return value === true || value === 'true' || value === 1 || value === '1' || value === 'yes';
    }

    function toNumber(value, fallback) {
        const num = Number(value);
        return Number.isFinite(num) ? num : fallback;
    }

    function normalizeKey(value) {
        return String(value || '').trim().toLowerCase();
    }

    function normalizeSubjectLabel(subject) {
        const value = String(subject || '').trim();
        return (!value || normalizeKey(value) === 'unknown') ? 'General' : value;
    }

    function inferSubject(raw, chapterName, fallbackSubject) {
        const direct = raw?.subject || raw?.examSubject || raw?.course || raw?.stream || fallbackSubject;
        if (direct && normalizeKey(direct) !== 'unknown') return String(direct).trim();

        const sourceText = [chapterName, raw?.title, raw?.source, raw?.category, raw?.backlogSource]
            .filter(Boolean)
            .join(' ')
            .toLowerCase();
        const knownSubjects = ['physics', 'chemistry', 'biology', 'science', 'maths', 'math', 'english', 'hindi', 'history', 'geography', 'civics', 'economics'];
        const matched = knownSubjects.find(subject => sourceText.includes(subject));
        if (!matched) return 'General';
        if (matched === 'math') return 'Maths';
        return matched.charAt(0).toUpperCase() + matched.slice(1);
    }

    function asNameSet(values) {
        const set = new Set();
        const add = (value) => {
            if (!value) return;
            if (typeof value === 'string') {
                set.add(normalizeKey(value));
                return;
            }
            if (typeof value === 'object') {
                const name = value.chapterName || value.chapter || value.name || value.title || value.label;
                if (name) set.add(normalizeKey(name));
            }
        };

        if (Array.isArray(values)) values.forEach(add);
        else if (values && typeof values === 'object') {
            Object.entries(values).forEach(([key, value]) => {
                if (value === true || value?.selected === true || value?.included === true || value?.comingInExam === true || value?.inExam === true) add(value?.chapterName || value?.chapter || value?.name || key);
            });
        }
        return set;
    }

    function normalizeScopeToken(value) {
        return normalizeKey(value)
            .replace(/[^a-z0-9]+/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function safeChapterId(subject, chapterName) {
        const normalizePart = (value) => normalizeScopeToken(value).replace(/\s+/g, '_');
        return `${normalizePart(subject || 'general')}__${normalizePart(chapterName || 'chapter')}`;
    }

    function getExamScopeSafe() {
        const scope = safeGet(EXAM_SCOPE_KEY, null);
        if (!scope || typeof scope !== 'object') return null;
        const selectedChapterNames = Array.isArray(scope.selectedChapterNames) ? scope.selectedChapterNames.filter(Boolean) : [];
        const selectedChapterIds = Array.isArray(scope.selectedChapterIds) ? scope.selectedChapterIds.filter(Boolean) : [];
        if (!scope.subject || (!selectedChapterNames.length && !selectedChapterIds.length)) return null;
        return {
            subject: String(scope.subject).trim(),
            examDate: scope.examDate || null,
            selectedChapterIds,
            selectedChapterNames,
            updatedAt: scope.updatedAt || null
        };
    }

    function saveExamScope(scope) {
        if (!scope || typeof scope !== 'object') return false;
        const subject = String(scope.subject || '').trim();
        const selectedChapterNames = Array.isArray(scope.selectedChapterNames) ? scope.selectedChapterNames.filter(Boolean) : [];
        const selectedChapterIds = Array.isArray(scope.selectedChapterIds) ? scope.selectedChapterIds.filter(Boolean) : [];
        if (!subject || (!selectedChapterNames.length && !selectedChapterIds.length)) return false;
        const normalized = {
            subject,
            examDate: scope.examDate || null,
            selectedChapterIds,
            selectedChapterNames,
            updatedAt: new Date().toISOString()
        };
        try {
            if (window.SafeStorage && typeof window.SafeStorage.setItem === 'function') {
                window.SafeStorage.setItem(EXAM_SCOPE_KEY, normalized);
            } else if (window.localStorage) {
                window.localStorage.setItem(EXAM_SCOPE_KEY, JSON.stringify(normalized));
            }
            return true;
        } catch (error) {
            return false;
        }
    }

    function clearExamScope() {
        try {
            if (window.SafeStorage && typeof window.SafeStorage.removeItem === 'function') {
                window.SafeStorage.removeItem(EXAM_SCOPE_KEY);
            } else if (window.localStorage) {
                window.localStorage.removeItem(EXAM_SCOPE_KEY);
            }
            return true;
        } catch (error) {
            return false;
        }
    }

    function chapterMatchesExamScope(chapter, scope) {
        if (!chapter || !scope) return false;
        const subjectMatches = !scope.subject || normalizeScopeToken(chapter.subject) === normalizeScopeToken(scope.subject) || normalizeScopeToken(chapter.subject) === 'general';
        const chapterId = chapter.id || safeChapterId(chapter.subject, chapter.chapterName);
        const idMatches = (scope.selectedChapterIds || []).map(normalizeScopeToken).includes(normalizeScopeToken(chapterId));
        const nameMatches = (scope.selectedChapterNames || []).map(normalizeScopeToken).includes(normalizeScopeToken(chapter.chapterName));
        return idMatches || (nameMatches && subjectMatches);
    }

    function normalizeDate(dateLike) {
        if (!dateLike) return null;
        const date = dateLike instanceof Date ? new Date(dateLike.getTime()) : new Date(dateLike);
        if (Number.isNaN(date.getTime())) return null;
        date.setHours(0, 0, 0, 0);
        return date;
    }

    function calculateDaysLeft(examDate) {
        const exam = normalizeDate(examDate);
        const today = normalizeDate(new Date());
        if (!exam || !today) return null;
        return Math.max(0, Math.ceil((exam.getTime() - today.getTime()) / 86400000));
    }

    function asArray(data) {
        if (!data) return [];
        if (Array.isArray(data)) return data;
        if (typeof data === 'object') return Object.values(data);
        return [];
    }

    function findValueByChapter(data, chapterName, subject) {
        if (!data || typeof data !== 'object') return null;
        const chapterKey = normalizeKey(chapterName);
        const subjectKey = normalizeKey(subject);

        if (!Array.isArray(data)) {
            const direct = data[chapterName] || data[chapterKey];
            if (direct && typeof direct === 'object') return direct;

            for (const key of Object.keys(data)) {
                const value = data[key];
                if (!value || typeof value !== 'object') continue;
                const keyMatches = normalizeKey(key) === chapterKey;
                const nameMatches = [value.chapterName, value.chapter, value.name, value.title]
                    .some(candidate => normalizeKey(candidate) === chapterKey);
                const subjectMatches = !subjectKey || normalizeKey(value.subject) === subjectKey;
                if ((keyMatches || nameMatches) && subjectMatches) return value;
            }
        }

        for (const value of asArray(data)) {
            if (!value || typeof value !== 'object') continue;
            const nameMatches = [value.chapterName, value.chapter, value.name, value.title]
                .some(candidate => normalizeKey(candidate) === chapterKey);
            const subjectMatches = !subjectKey || !value.subject || normalizeKey(value.subject) === subjectKey;
            if (nameMatches && subjectMatches) return value;
        }

        return null;
    }

    function getRetention(chapter, context) {
        const decayEntry = findValueByChapter(context.memoryDecay, chapter.chapterName, chapter.subject);
        const candidates = [
            decayEntry?.retention,
            decayEntry?.retentionPercent,
            decayEntry?.score,
            chapter.memoryMeta?.retention,
            chapter.memoryMeta?.retentionPercent,
            chapter.memoryMeta?.score
        ];
        for (const candidate of candidates) {
            const retention = toNumber(candidate, null);
            if (retention !== null) return Math.max(0, Math.min(100, retention));
        }

        if (chapter.tasksDone === 3) return 70;
        if (chapter.tasksDone === 2) return 55;
        if (chapter.tasksDone === 1) return 35;
        return 20;
    }

    function getReviewDates(chapter, context) {
        const decayEntry = findValueByChapter(context.memoryDecay, chapter.chapterName, chapter.subject) || {};
        return {
            lastReviewDate: decayEntry.lastReviewDate || decayEntry.lastReviewed || decayEntry.reviewedAt || chapter.memoryMeta?.lastReviewDate || chapter.lastUpdated || null,
            nextReviewDate: decayEntry.nextReviewDate || decayEntry.nextReview || chapter.memoryMeta?.nextReviewDate || null,
            memoryStatus: decayEntry.memoryStatus || decayEntry.status || chapter.memoryMeta?.memoryStatus || null
        };
    }

    function getChapterCandidates(masterData) {
        if (!masterData || typeof masterData !== 'object') return [];

        const candidates = [];
        const pushCandidate = (chapterName, raw, fallbackSubject) => {
            if (!chapterName || !raw || typeof raw !== 'object') return;
            if (raw._scheduledFor) return;

            const read = toBool(raw.read);
            const notes = toBool(raw.notes);
            const pyq = toBool(raw.pyq);
            const tasksDone = [read, notes, pyq].filter(Boolean).length;

            candidates.push({
                chapterName: String(chapterName),
                subject: normalizeSubjectLabel(inferSubject(raw, chapterName, fallbackSubject)),
                id: raw.id || raw.chapterId || safeChapterId(inferSubject(raw, chapterName, fallbackSubject), chapterName),
                read,
                notes,
                pyq,
                tasksDone,
                taskGap: (3 - tasksDone) / 3,
                isSyllabus: raw.isSyllabus !== false,
                memoryMeta: raw.memoryMeta || null,
                marksWeight: raw.marksWeight ?? raw.weight ?? raw.marks ?? null,
                notebookDone: toBool(raw.notebookDone ?? raw.copyDone ?? raw.copy ?? raw.notebookComplete ?? raw.notebookCompleted),
                notebookPending: toBool(raw.notebookPending ?? raw.copyPending ?? raw.notebookBacklog) || (raw.notebookStatus && normalizeKey(raw.notebookStatus) !== 'complete'),
                backlogCategory: raw.backlogCategory || raw.category || raw.backlogType || raw.source || null,
                comingInExam: toBool(raw.comingInExam ?? raw.inExam ?? raw.exam ?? raw.examSelected ?? raw.isExamSyllabus ?? raw.examSyllabus),
                lastUpdated: raw.lastUpdated || raw.updatedAt || null,
                _raw: raw
            });
        };

        if (Array.isArray(masterData)) {
            masterData.forEach((item, index) => {
                const name = item?.chapterName || item?.chapter || item?.name || item?.title || `Chapter ${index + 1}`;
                pushCandidate(name, item, item?.subject);
            });
            return candidates;
        }

        Object.entries(masterData).forEach(([key, value]) => {
            if (!value || typeof value !== 'object') return;

            const nestedChapters = value.chapters || value.items || value.tasks;
            if (nestedChapters && typeof nestedChapters === 'object' && !('read' in value || 'notes' in value || 'pyq' in value)) {
                Object.entries(nestedChapters).forEach(([chapterKey, chapterValue]) => {
                    if (chapterValue && typeof chapterValue === 'object') {
                        const name = chapterValue.chapterName || chapterValue.chapter || chapterValue.name || chapterKey;
                        pushCandidate(name, chapterValue, value.subject || key);
                    }
                });
                return;
            }

            const name = value.chapterName || value.chapter || value.name || key;
            pushCandidate(name, value, value.subject);
        });

        return candidates;
    }

    function getNearestExam(calendarData) {
        const today = normalizeDate(new Date());
        if (!today) return null;

        const exams = [];
        const addExam = (entry, fallbackDate, fallbackSubject) => {
            if (!entry && !fallbackDate) return;
            const item = entry && typeof entry === 'object' ? entry : {};
            const mode = normalizeKey(item.mode || item.type || item.category || item.kind);
            const looksLikeExam = mode === 'exam' || mode.includes('exam') || normalizeKey(item.title || item.text || item.label).includes('exam') || normalizeKey(fallbackSubject).includes('exam');
            const date = normalizeDate(item.examDate || item.date || item.startDate || item.dueDate || fallbackDate);
            if (!looksLikeExam || !date || date < today) return;
            exams.push({
                subject: item.subject || item.course || item.title || item.text || fallbackSubject || 'Exam',
                date
            });
        };

        if (Array.isArray(calendarData)) {
            calendarData.forEach(item => addExam(item, null, null));
        } else if (calendarData && typeof calendarData === 'object') {
            Object.entries(calendarData).forEach(([key, value]) => {
                if (Array.isArray(value)) {
                    value.forEach(item => addExam(item, key, null));
                } else if (value && typeof value === 'object') {
                    addExam(value, key, value.subject || key);
                    if (Array.isArray(value.events)) value.events.forEach(item => addExam(item, key, value.subject || key));
                    if (Array.isArray(value.exams)) value.exams.forEach(item => addExam(Object.assign({ type: 'exam' }, item), key, value.subject || key));
                }
            });
        }

        exams.sort((a, b) => a.date.getTime() - b.date.getTime());
        return exams[0] || null;
    }

    function extractWeakChapters(autopsies) {
        const weak = new Set();
        const addWeak = (entry, fallbackSubject) => {
            if (!entry || typeof entry !== 'object') return;
            const subject = entry.subject || fallbackSubject || null;
            const weakLists = [entry.weakChapters, entry.weak_chapters, entry.chaptersWeak, entry.problemChapters];
            weakLists.forEach(list => {
                if (!Array.isArray(list)) return;
                list.forEach(item => {
                    const name = typeof item === 'string' ? item : (item?.chapterName || item?.chapter || item?.name || item?.title);
                    if (!name) return;
                    weak.add(normalizeKey(name));
                    if (subject) weak.add(`${normalizeKey(subject)}::${normalizeKey(name)}`);
                });
            });
        };

        if (Array.isArray(autopsies)) {
            autopsies.forEach(entry => addWeak(entry, null));
        } else if (autopsies && typeof autopsies === 'object') {
            Object.entries(autopsies).forEach(([subject, entry]) => {
                if (Array.isArray(entry)) entry.forEach(item => addWeak(item, subject));
                else addWeak(entry, subject);
            });
        }
        return weak;
    }

    function readExamSyllabusSelection(nearestExam, chapters, examScope) {
        if (examScope) {
            return {
                isSelected: true,
                hasScope: true,
                subject: examScope.subject,
                chapterNames: asNameSet(examScope.selectedChapterNames),
                chapterIds: asNameSet(examScope.selectedChapterIds),
                scope: examScope
            };
        }
        const candidates = [];
        EXAM_SYLLABUS_KEYS.forEach(key => {
            const value = safeGet(key, null);
            if (value) candidates.push(value);
        });
        if (nearestExam?.syllabus || nearestExam?.chapters || nearestExam?.selectedChapters || nearestExam?.includedChapters) candidates.push(nearestExam);

        const examSubjectKey = normalizeKey(nearestExam?.subject);
        let selectedSubject = null;
        const chapterNames = new Set();
        let hasSelection = false;

        const consume = (entry) => {
            if (!entry || typeof entry !== 'object') return;
            const entrySubject = entry.subject || entry.examSubject || entry.course || entry.title;
            if (entrySubject && (!examSubjectKey || normalizeKey(entrySubject) === examSubjectKey || normalizeKey(entrySubject).includes(examSubjectKey) || examSubjectKey.includes(normalizeKey(entrySubject)))) {
                selectedSubject = selectedSubject || String(entrySubject).trim();
                hasSelection = true;
            }
            const sources = [entry.chapters, entry.selectedChapters, entry.includedChapters, entry.chapterNames, entry.syllabus, entry.examChapters, entry.items];
            sources.forEach(source => {
                const names = asNameSet(source);
                names.forEach(name => chapterNames.add(name));
                if (names.size) hasSelection = true;
            });
        };

        candidates.forEach(candidate => {
            if (Array.isArray(candidate)) candidate.forEach(consume);
            else if (candidate && typeof candidate === 'object') {
                consume(candidate);
                Object.values(candidate).forEach(value => {
                    if (value && typeof value === 'object') consume(value);
                });
            }
        });

        const flaggedChapters = chapters.filter(chapter => chapter.comingInExam).map(chapter => normalizeKey(chapter.chapterName));
        flaggedChapters.forEach(name => chapterNames.add(name));
        if (flaggedChapters.length) hasSelection = true;

        return {
            isSelected: hasSelection,
            subject: selectedSubject || nearestExam?.subject || null,
            chapterNames
        };
    }

    function applyExamSyllabusFilter(chapters, selection, nearestExam) {
        if (!selection?.isSelected) return chapters;
        const subjectKey = normalizeKey(selection.subject || nearestExam?.subject);
        return chapters.filter(chapter => {
            if (selection.scope) return chapterMatchesExamScope(chapter, selection.scope);
            const chapterKey = normalizeKey(chapter.chapterName);
            const subjectMatches = subjectKey && normalizeKey(chapter.subject) === subjectKey;
            const selectedByName = selection.chapterNames?.has(chapterKey);
            if (selection.chapterNames && selection.chapterNames.size > 0) return selectedByName || chapter.comingInExam;
            return chapter.comingInExam || subjectMatches;
        });
    }

    function buildSyllabusTruth(selection, nearestExam) {
        if (selection?.isSelected) {
            const subject = selection.subject || nearestExam?.subject || 'selected exam';
            return {
                isSelected: true,
                hasScope: Boolean(selection.hasScope),
                subject,
                selectedCount: selection.scope?.selectedChapterNames?.length || selection.chapterNames?.size || 0,
                message: `Using selected ${subject} syllabus.`
            };
        }
        return {
            isSelected: false,
            hasScope: false,
            subject: nearestExam?.subject || null,
            selectedCount: 0,
            message: 'Exam syllabus not selected. Plan may include general tracked tasks.',
            warning: 'Using all tracked chapters because exam syllabus is not selected.'
        };
    }

    function detectTaskType(chapter, context) {
        const retention = getRetention(chapter, context || {});
        const explicitDecay = findValueByChapter(context?.memoryDecay, chapter?.chapterName, chapter?.subject);
        const hasExplicitRetention = explicitDecay?.retention != null || explicitDecay?.retentionPercent != null || chapter?.memoryMeta?.retention != null || chapter?.memoryMeta?.retentionPercent != null;
        const category = normalizeKey(chapter.backlogCategory);
        const notebookIncomplete = chapter.notebookPending || (!chapter.notes && (chapter.read || chapter.pyq || category.includes('notebook') || category.includes('copy')));
        if (notebookIncomplete) return 'NOTEBOOK_BACKLOG';
        if (hasExplicitRetention && retention < 40) return 'MEMORY_CRITICAL';
        if (!chapter.read) return 'CHAPTER_STUDY';
        if (!chapter.pyq) return 'PYQ_PENDING';
        if (retention < 40) return 'MEMORY_CRITICAL';
        const reviewDates = getReviewDates(chapter, context || {});
        if (normalizeKey(reviewDates.memoryStatus).includes('due')) return 'REVISION_DUE';
        if (category.includes('custom')) return 'CUSTOM_BACKLOG';
        if (category.includes('backlog')) return 'CUSTOM_BACKLOG';
        return 'CHAPTER_STUDY';
    }

    function collectContext() {
        const masterData = safeGet(MASTER_KEY, {});
        const memoryDecay = safeGet(MEMORY_KEY, {});
        const calendarData = safeGet(CALENDAR_KEY, {});
        const autopsies = safeGet(AUTOPSY_KEY, []);
        const ppSignals = safeGet(PP_KEY, {});

        const allChapters = getChapterCandidates(masterData).filter(chapter => chapter.isSyllabus !== false);
        const examScope = getExamScopeSafe();
        let nearestExam = getNearestExam(calendarData);
        if (examScope?.examDate) {
            const scopedDate = normalizeDate(examScope.examDate);
            if (scopedDate) nearestExam = { subject: examScope.subject, date: scopedDate, type: 'exam', source: 'manual-scope' };
        }
        const examSyllabusSelection = readExamSyllabusSelection(nearestExam, allChapters, examScope);
        const chapters = applyExamSyllabusFilter(allChapters, examSyllabusSelection, nearestExam);
        const syllabusTruth = buildSyllabusTruth(examSyllabusSelection, nearestExam);
        const total = chapters.length;
        const completed = chapters.filter(chapter => chapter.tasksDone === 3).length;
        const completionRate = total > 0 ? completed / total : 0;
        const backlogCount = chapters.filter(chapter => chapter.tasksDone > 0 && chapter.tasksDone < 3).length;
        const daysLeft = nearestExam ? calculateDaysLeft(nearestExam.date) : null;
        const weakChapters = extractWeakChapters(autopsies);
        const memoryCriticalCount = chapters.filter(chapter => getRetention(chapter, { memoryDecay }) < 40).length;

        return {
            masterData,
            memoryDecay,
            calendarData,
            autopsies,
            ppSignals,
            examScope,
            hasExamScope: Boolean(examScope),
            examScopeSubject: examScope?.subject || null,
            examScopeChapterCount: examScope?.selectedChapterNames?.length || 0,
            examSyllabusSelection,
            syllabusTruth,
            allChapters,
            chapters,
            total,
            completed,
            completionRate,
            backlogCount,
            nearestExam,
            daysLeft,
            weakChapters,
            memoryCriticalCount
        };
    }

    function determinePlanType(context) {
        const completionRate = toNumber(context?.completionRate, 0);
        const backlogCount = toNumber(context?.backlogCount, 0);
        const daysLeft = typeof context?.daysLeft === 'number' ? context.daysLeft : null;
        const examSubject = context?.nearestExam?.subject || null;

        let planType = 'NORMAL';
        let reason = 'No urgent exam. Keep clearing tasks and reinforcing studied chapters.';
        let severity = 'low';

        if (context?.nearestExam && daysLeft !== null) {
            if (daysLeft <= 3) {
                planType = '3_DAY_RESCUE';
                reason = `Exam is within ${daysLeft} day${daysLeft === 1 ? '' : 's'}. Practice-first rescue mode is active.`;
                severity = 'critical';
            } else if (daysLeft <= 7) {
                planType = '7_DAY_BLITZ';
                reason = `Exam is within ${daysLeft} days and syllabus pressure is high. Stabilize weak chapters with retrieval + PYQs.`;
                severity = 'urgent';
            } else if (daysLeft <= 14) {
                planType = '14_DAY_SIEGE';
                reason = `Exam is within ${daysLeft} days. Use spaced retrieval while closing high-urgency gaps.`;
                severity = 'moderate';
            } else if (completionRate < 0.50) {
                planType = 'FRESH_START';
                reason = `Exam is ${daysLeft} days away, but completion is below 50%. Build foundation without staring at the full backlog.`;
                severity = 'moderate';
            } else if (backlogCount > 8 || completionRate < 0.70 || toNumber(context.memoryCriticalCount, 0) > 2) {
                planType = '14_DAY_SIEGE';
                reason = `Exam is ${daysLeft} days away. Current risk signals need a steady siege plan.`;
                severity = 'moderate';
            }
        } else if (completionRate < 0.40 || backlogCount > 10) {
            planType = 'FRESH_START';
            reason = `No exam date found. Completion/backlog pressure indicates Fresh Start mode.`;
            severity = 'moderate';
        }

        return {
            planType,
            modeLabel: PLAN_LABELS[planType],
            reason,
            daysLeft,
            examSubject,
            severity
        };
    }

    function isWeakChapter(chapter, weakChapters) {
        return weakChapters?.has(normalizeKey(chapter.chapterName)) || weakChapters?.has(`${normalizeKey(chapter.subject)}::${normalizeKey(chapter.chapterName)}`);
    }

    function calcUrgencyScore(chapter, context) {
        const tasksDone = toNumber(chapter?.tasksDone, 0);
        const taskGap = (3 - tasksDone) / 3;
        const retention = getRetention(chapter, context || {});
        const marksWeight = toNumber(chapter?.marksWeight, 5);
        const decayPenalty = Math.max(0, (100 - retention) / 100);
        let urgency = marksWeight * (decayPenalty * 0.5 + taskGap * 0.3);
        const reasonTags = [];

        if (isWeakChapter(chapter, context?.weakChapters)) {
            urgency += 15;
            reasonTags.push('Autopsy Flag');
        }
        if (tasksDone === 2) {
            urgency += 10;
            reasonTags.push('Quick Win');
        }
        if (retention < 40) {
            urgency += 8;
            reasonTags.push('Memory Critical');
        }
        if (tasksDone > 0 && tasksDone < 3) {
            urgency += 5;
            reasonTags.push('Backlog');
        }
        if (tasksDone === 0) reasonTags.push('Not Started');

        if (typeof context?.daysLeft === 'number') {
            if (context.daysLeft <= 3) urgency *= 1.5;
            else if (context.daysLeft <= 7) urgency *= 1.2;
        }

        return {
            score: Math.round(urgency * 10) / 10,
            urgencyScore: Math.round(urgency * 10) / 10,
            retention,
            tasksDone,
            taskGap,
            reasonTags: Array.from(new Set(reasonTags))
        };
    }

    function session(type, label, instruction, estimatedMinutes) {
        return { type, label, instruction, estimatedMinutes };
    }

    function recommendSessionType(chapter, planType, context) {
        const retention = typeof chapter?.retention === 'number' ? chapter.retention : getRetention(chapter, context || {});
        const tasksDone = toNumber(chapter?.tasksDone, 0);
        const taskType = chapter?.taskType || detectTaskType(chapter, context || {});
        const daysLeft = typeof context?.daysLeft === 'number' ? context.daysLeft : null;

        if (daysLeft !== null && daysLeft <= 1) {
            return session('ERROR_REVIEW', 'Error Review', 'Review mistakes and recall formulas/definitions. No new chapters.', 30);
        }

        if (taskType === 'NOTEBOOK_BACKLOG') {
            return session('NOTEBOOK_SPRINT', 'Notebook Sprint', 'Complete pending notebook work. Then write 5 key points from memory.', 30);
        }

        if (taskType === 'PYQ_PENDING') {
            return session('PYQ_PRACTICE', 'PYQ Practice', 'Attempt 10 questions without notes. Review wrong answers.', 35);
        }

        if (taskType === 'MEMORY_CRITICAL' || retention < 40 || taskType === 'REVISION_DUE') {
            return session('SPACED_RETRIEVAL', 'Spaced Retrieval', 'Recall formulas/concepts on blank sheet before opening notes.', 25);
        }

        if (taskType === 'CHAPTER_STUDY' || tasksDone === 0 || !chapter?.read) {
            return session('CONCEPT_RETRIEVAL', 'Concept Retrieval', 'Read summary once, close material, recall main ideas.', 45);
        }

        return session('MIXED_PRACTICE', 'Mixed Practice', 'Alternate self-testing and problem solving. Avoid passive rereading.', 40);
    }

    function getProtocolRules(planType) {
        const rules = {
            '3_DAY_RESCUE': {
                methodRatio: '80% PYQ / 20% targeted recall',
                doRule: 'Practice test first, study second.',
                dontRule: 'Do not start low-value new chapters.',
                maxChaptersToday: 4
            },
            '7_DAY_BLITZ': {
                methodRatio: '60% retrieval + PYQ / 40% concept stabilization',
                doRule: 'Review weak chapters with 24–72 hour spacing.',
                dontRule: 'Do not save PYQs for the final day.',
                maxChaptersToday: 5
            },
            '14_DAY_SIEGE': {
                methodRatio: '50% retrieval / 30% PYQ / 20% concept repair',
                doRule: 'Use spaced reviews every 3–5 days.',
                dontRule: 'Do not let critical chapters go stale.',
                maxChaptersToday: 6
            },
            FRESH_START: {
                methodRatio: '40% recall / 40% completion / 20% review',
                doRule: 'Show only the next few targets. Build momentum.',
                dontRule: 'Do not stare at the full backlog.',
                maxChaptersToday: 4
            },
            NORMAL: {
                methodRatio: 'Balanced study mode',
                doRule: 'Clear one high-value task today.',
                dontRule: 'Do not let backlog grow silently.',
                maxChaptersToday: 3
            }
        };
        return rules[planType] || rules.NORMAL;
    }

    function getBattlePlanRules(planType) {
        const rules = {
            '3_DAY_RESCUE': {
                maxBlocks: 3,
                checkpoint: 'Score each PYQ set. Review only wrong answers.',
                recoveryRule: 'No new low-value chapters today.'
            },
            '7_DAY_BLITZ': {
                maxBlocks: 3,
                checkpoint: 'Mark weak answers and revisit them after 24–72 hours.',
                recoveryRule: 'Do not save PYQs for the final day.'
            },
            '14_DAY_SIEGE': {
                maxBlocks: 4,
                checkpoint: 'Schedule a spaced review for critical chapters after 3–5 days.',
                recoveryRule: 'Do not let high-risk chapters go stale.'
            },
            FRESH_START: {
                maxBlocks: 3,
                checkpoint: 'Complete the blocks, then stop. Recovery needs consistency, not overload.',
                recoveryRule: 'Show only today’s targets. Do not stare at the full backlog.'
            },
            NORMAL: {
                maxBlocks: 2,
                checkpoint: 'Finish one meaningful study block and protect consistency.',
                recoveryRule: 'Do not let backlog grow silently.'
            }
        };
        return rules[planType] || rules.NORMAL;
    }

    function getFallbackMinutes(sessionType) {
        const fallbackMinutes = {
            PYQ_PRACTICE: 35,
            SPACED_RETRIEVAL: 25,
            CONCEPT_RETRIEVAL: 45,
            TARGETED_RECALL_PATCH: 30,
            MIXED_PRACTICE: 40
        };
        return fallbackMinutes[sessionType] || 40;
    }

    function getMethodTag(sessionType) {
        const tags = {
            PYQ_PRACTICE: 'PYQ',
            SPACED_RETRIEVAL: 'Retrieval',
            CONCEPT_RETRIEVAL: 'Concept Recall',
            TARGETED_RECALL_PATCH: 'Recall Patch',
            MIXED_PRACTICE: 'Mixed'
        };
        return tags[sessionType] || 'Practice';
    }

    function interleaveBlocksBySubject(blocks) {
        if (!Array.isArray(blocks) || blocks.length <= 2) return blocks || [];

        const subjects = new Set(blocks.map(block => normalizeKey(block.subject || 'General')));
        if (subjects.size <= 1) return blocks;

        const remaining = blocks.slice();
        const ordered = [];

        while (remaining.length) {
            const previousSubject = normalizeKey(ordered[ordered.length - 1]?.subject || '');
            let nextIndex = remaining.findIndex(block => normalizeKey(block.subject || 'General') !== previousSubject);
            if (nextIndex === -1) nextIndex = 0;
            ordered.push(remaining.splice(nextIndex, 1)[0]);
        }

        return ordered.map((block, index) => Object.assign({}, block, { blockNumber: index + 1 }));
    }

    function buildDailyBattlePlan(plan) {
        const planType = plan?.planType || 'NORMAL';
        const battleRules = getBattlePlanRules(planType);
        const topChapters = Array.isArray(plan?.topChapters) ? plan.topChapters : [];

        const blocks = topChapters.slice(0, battleRules.maxBlocks).map((chapter, index) => {
            const sessionType = chapter.sessionType || {};
            const type = sessionType.type || 'MIXED_PRACTICE';
            const estimatedMinutes = Math.max(1, Math.round(toNumber(sessionType.estimatedMinutes, getFallbackMinutes(type))));

            return {
                blockNumber: index + 1,
                chapterName: chapter.chapterName || 'Untitled Chapter',
                subject: chapter.subject || 'General',
                sessionType: type,
                sessionLabel: sessionType.label || 'Mixed Practice',
                instruction: sessionType.instruction || 'Alternate self-testing and problem solving. Avoid passive rereading.',
                estimatedMinutes,
                checkpoint: battleRules.checkpoint,
                methodTag: getMethodTag(type)
            };
        });

        const interleavedBlocks = interleaveBlocksBySubject(blocks);
        const totalMinutes = interleavedBlocks.reduce((sum, block) => sum + block.estimatedMinutes, 0);

        return {
            totalMinutes,
            blocks: interleavedBlocks,
            checkpoint: battleRules.checkpoint,
            recoveryRule: battleRules.recoveryRule
        };
    }

    function getChapterHints(plan, startIndex, count) {
        const chapters = Array.isArray(plan?.topChapters) ? plan.topChapters : [];
        if (!chapters.length) return [];
        return chapters
            .slice(startIndex, startIndex + count)
            .map(chapter => chapter?.chapterName)
            .filter(Boolean);
    }

    function distributeChapterHints(plan, stepIndex) {
        const chapters = Array.isArray(plan?.topChapters) ? plan.topChapters : [];
        if (!chapters.length) return [];
        if (plan?.planType === '3_DAY_RESCUE') return getChapterHints(plan, 0, 3);
        if (stepIndex === 0) return getChapterHints(plan, 0, 3);
        if (stepIndex === 1) return getChapterHints(plan, 1, 2);
        if (stepIndex === 2) return getChapterHints(plan, 0, 2);
        return getChapterHints(plan, 0, 3);
    }

    function buildProtocolTimeline(plan) {
        const planType = plan?.planType || 'NORMAL';
        const timelineByType = {
            '3_DAY_RESCUE': {
                title: 'Protocol Timeline',
                subtitle: '3-day rescue roadmap.',
                finalWarning: 'No new low-value chapters. Damage control only.',
                days: [
                    { dayLabel: 'Day 1', phase: 'Rescue', focus: 'Highest urgency chapters', method: 'Retrieval + PYQ', rule: 'Attempt questions before reading notes.' },
                    { dayLabel: 'Day 2', phase: 'Re-test', focus: 'Same weak chapters after 12–24h', method: 'Spaced Retrieval', rule: 'Re-attempt yesterday’s mistakes without looking.' },
                    { dayLabel: 'Day 3', phase: 'Exam Eve', focus: 'Error review + strong chapters', method: 'Light Recall', rule: 'No new material.' }
                ]
            },
            '7_DAY_BLITZ': {
                title: 'Protocol Timeline',
                subtitle: 'Compact roadmap for this blitz mode.',
                finalWarning: 'Do not save PYQs for the final day.',
                days: [
                    { dayLabel: 'Days 1–2', phase: 'Stabilize', focus: 'Critical weak chapters', method: 'Retrieval + PYQ' },
                    { dayLabel: 'Days 3–4', phase: 'Review Loop', focus: 'Revisit weak chapters after 24–72h', method: 'Spaced Retrieval + PYQ' },
                    { dayLabel: 'Days 5–6', phase: 'Simulation', focus: 'Interleaved practice / mock blocks', method: 'Mixed PYQ Practice' },
                    { dayLabel: 'Day 7', phase: 'Exam Eve', focus: 'Error log + formula recall', method: 'Light Recall', rule: 'Do not start new topics.' }
                ]
            },
            '14_DAY_SIEGE': {
                title: 'Protocol Timeline',
                subtitle: 'Compact roadmap for this siege mode.',
                finalWarning: 'Do not let critical chapters go stale.',
                days: [
                    { dayLabel: 'Days 1–4', phase: 'Foundation', focus: 'Critical + high-risk chapters', method: 'Retrieval + PYQ' },
                    { dayLabel: 'Days 5–8', phase: 'Spacing Cycle', focus: 'Review critical chapters after 3–5 days', method: 'Spaced Retrieval' },
                    { dayLabel: 'Days 9–12', phase: 'Interleaving', focus: 'Mixed PYQ sets across subjects', method: 'Interleaved Practice' },
                    { dayLabel: 'Days 13–14', phase: 'Sharpen', focus: 'Mock + error review', method: 'Exam Simulation + Light Recall' }
                ]
            },
            FRESH_START: {
                title: 'Protocol Timeline',
                subtitle: 'Recovery roadmap for rebuilding momentum.',
                finalWarning: 'Recovery first. No guilt metrics.',
                days: [
                    { dayLabel: 'Next 48h', phase: 'Stabilize', focus: '2–4 high-ROI tasks', method: 'Completion + Recall' },
                    { dayLabel: 'Days 3–5', phase: 'Momentum', focus: 'Quick wins and started chapters', method: 'Task Completion' },
                    { dayLabel: 'Days 6–7', phase: 'Review', focus: 'Revisit recovered chapters', method: 'Spaced Retrieval' },
                    { dayLabel: 'Week 2', phase: 'Build', focus: 'Move into Siege/Blitz depending exam pressure', method: 'Retrieval + PYQ' }
                ]
            },
            NORMAL: {
                title: 'Protocol Timeline',
                subtitle: 'Simple roadmap for consistency.',
                finalWarning: 'Do not let backlog grow silently.',
                days: [
                    { dayLabel: 'Today', phase: 'Execute', focus: 'One high-value task', method: 'Focus Block' },
                    { dayLabel: 'Tomorrow', phase: 'Review', focus: 'Revisit today’s weak point', method: 'Short Recall' },
                    { dayLabel: 'This Week', phase: 'Build', focus: 'Prevent backlog growth', method: 'Consistent Study' }
                ]
            }
        };

        const template = timelineByType[planType] || timelineByType.NORMAL;
        return {
            title: template.title,
            subtitle: template.subtitle,
            days: template.days.map((day, index) => Object.assign({}, day, {
                chapterHints: distributeChapterHints(plan, index)
            })),
            finalWarning: template.finalWarning
        };
    }

    function getPlanChapters(plan, startIndex, count) {
        const chapters = Array.isArray(plan?.topChapters) ? plan.topChapters : [];
        if (!chapters.length) return [];
        return chapters.slice(startIndex, startIndex + count).filter(Boolean);
    }

    function getChapterNamesFromList(chapters) {
        return (Array.isArray(chapters) ? chapters : [])
            .map(chapter => chapter?.chapterName)
            .filter(Boolean);
    }

    function fallbackInstructionForMethod(method) {
        const instructions = {
            'PYQ Practice': 'Attempt questions without notes. Score yourself and review wrong answers.',
            'Spaced Retrieval': 'Recall key points from memory before opening notes.',
            'Spaced Retrieval + PYQ': 'Re-attempt weak answers first, then solve a short PYQ set.',
            'Retrieval + PYQ': 'Recall the chapter first, then attempt PYQs without notes.',
            'Interleaved Practice': 'Mix questions across chapters and track mistakes immediately.',
            'Mixed Practice': 'Alternate self-testing and problem solving. Avoid passive rereading.',
            'Light Recall': 'Review formulas, definitions, and marked errors only.',
            'Error Review': 'Rework mistakes without looking at the solution first.',
            'Focus Block': 'Complete one meaningful task with full attention.',
            'Task Completion': 'Finish the smallest useful pending task and mark the gap clearly.',
            'Short Recall': 'Write the weak point from memory, then check notes briefly.'
        };
        return instructions[method] || 'Use active recall first. Avoid passive rereading.';
    }

    function minutesForMethod(method) {
        const minutes = {
            'PYQ Practice': 35,
            'Spaced Retrieval': 25,
            'Spaced Retrieval + PYQ': 35,
            'Retrieval + PYQ': 35,
            'Interleaved Practice': 40,
            'Mixed Practice': 40,
            'Light Recall': 25,
            'Error Review': 30,
            'Focus Block': 30,
            'Task Completion': 30,
            'Short Recall': 20
        };
        return minutes[method] || 35;
    }

    function buildDayBlocks(chapters, method, maxBlocks) {
        const selected = (Array.isArray(chapters) ? chapters : []).slice(0, maxBlocks);
        return selected.map(chapter => {
            const session = chapter?.sessionType || {};
            const label = method || session.label || 'Mixed Practice';
            return {
                chapterName: chapter.chapterName,
                method: label,
                minutes: Math.max(1, Math.round(toNumber(session.estimatedMinutes, minutesForMethod(label)))),
                instruction: session.instruction || fallbackInstructionForMethod(label)
            };
        });
    }

    function makeAdaptiveDay(dayNumber, label, phase, focus, method, chapters, checkpoint, avoid, maxBlocks) {
        return {
            dayNumber,
            label,
            phase,
            focus,
            method,
            chapters: getChapterNamesFromList(chapters),
            blocks: buildDayBlocks(chapters, method, maxBlocks),
            checkpoint,
            avoid
        };
    }

    function getAdaptivePlanTitle(plan, visibleCount, hasExam) {
        const subject = plan?.examSubject || 'Exam';
        const displayDays = Math.max(1, Math.ceil(toNumber(plan?.daysLeft, 1)));
        if (hasExam) return `${displayDays}-Day ${subject} Exam Plan`;
        if (plan?.planType === 'FRESH_START') return '3-Day Fresh Start Recovery Plan';
        return 'Weekly Study Rhythm';
    }

    function getAdaptiveSubtitle(plan, hasExam) {
        const subject = plan?.examSubject || 'Exam';
        const displayDays = Math.max(1, Math.ceil(toNumber(plan?.daysLeft, 1)));
        if (hasExam) return `${subject} exam in ${displayDays} day${displayDays === 1 ? '' : 's'}. Follow this day-wise plan.`;
        if (plan?.planType === 'FRESH_START') return 'No exam date found. Use this recovery plan without overload.';
        return 'No urgent exam found. Use this rhythm to protect consistency.';
    }

    function buildGroupedLabels(totalDays, visibleCount) {
        const labels = [];
        for (let i = 0; i < visibleCount; i++) {
            const start = Math.floor((i * totalDays) / visibleCount) + 1;
            const end = Math.floor(((i + 1) * totalDays) / visibleCount);
            labels.push(start === end ? `Day ${start}` : `Days ${start}–${end}`);
        }
        return labels;
    }

    function generateAdaptiveDayPlan(plan) {
        const hasRawDaysLeft = plan?.daysLeft !== null && plan?.daysLeft !== undefined;
        const rawDaysLeft = Number(plan?.daysLeft);
        const hasExam = hasRawDaysLeft && Number.isFinite(rawDaysLeft) && rawDaysLeft >= 0;
        const daysLeft = hasExam ? Math.max(1, Math.ceil(rawDaysLeft)) : null;
        const topChapters = Array.isArray(plan?.topChapters) ? plan.topChapters : [];
        const top3 = getPlanChapters(plan, 0, 3);
        const top2 = getPlanChapters(plan, 0, 2);
        const next2 = getPlanChapters(plan, 1, 2);
        const maxShortBlocks = daysLeft && daysLeft <= 4 ? 3 : 4;
        let days = [];
        let finalWarning = 'Keep the plan focused. Do not add unnecessary tasks.';

        if (!hasExam) {
            if (plan?.planType === 'FRESH_START') {
                days = [
                    makeAdaptiveDay(1, 'Day 1', 'Stabilize', 'Quick wins and high-ROI tasks', 'Task Completion', top3, 'Complete the blocks, then stop before overload.', 'Do not stare at the full backlog.', 3),
                    makeAdaptiveDay(2, 'Day 2', 'Momentum', 'Started chapters and small pending gaps', 'Task Completion', top2.length ? top2 : top3, 'Finish one started chapter or clearly mark the remaining gap.', 'Do not measure recovery with guilt metrics.', 3),
                    makeAdaptiveDay(3, 'Day 3', 'Review', 'Revisit recovered chapters', 'Spaced Retrieval', top3, 'Recall recovered chapters from memory before notes.', 'Do not restart the entire backlog.', 3)
                ];
                finalWarning = 'Recovery first. No guilt metrics.';
            } else {
                days = [
                    makeAdaptiveDay(1, 'Today', 'Execute', 'One high-value task', 'Focus Block', top2.length ? top2 : top3, 'Finish one meaningful study block.', 'Do not let backlog grow silently.', 2),
                    makeAdaptiveDay(2, 'Tomorrow', 'Review', 'Revisit today’s weak point', 'Short Recall', top2.length ? top2 : top3, 'Write the weak point from memory before notes.', 'Do not skip the review loop.', 2),
                    makeAdaptiveDay(3, 'This Week', 'Build', 'Prevent backlog growth', 'Consistent Study', top3, 'Clear one high-value task before adding more.', 'Do not let small gaps become silent backlog.', 2)
                ];
                finalWarning = 'Do not let backlog grow silently.';
            }
        } else if (daysLeft <= 1) {
            days = [
                makeAdaptiveDay(1, 'Day 1', 'Emergency Recall', 'Error log + formula/definition recall', 'Light Recall', top3, 'Review marked mistakes and recall formulas/definitions from memory.', 'No new material.', 3)
            ];
            finalWarning = 'No new material. Error review and light recall only.';
        } else if (daysLeft === 2) {
            days = [
                makeAdaptiveDay(1, 'Day 1', 'Rescue', 'Highest urgency PYQ + recall', 'Retrieval + PYQ', top3, 'Score each PYQ set and mark weak answers.', 'Do not reread passively.', 3),
                makeAdaptiveDay(2, 'Day 2', 'Exam Eve', 'Error review + light recall', 'Light Recall', top2.length ? top2 : top3, 'Rework mistakes without looking first.', 'No new chapters.', 3)
            ];
            finalWarning = 'No new topics on exam eve. Review mistakes and sleep properly.';
        } else if (daysLeft === 3) {
            days = [
                makeAdaptiveDay(1, 'Day 1', 'Rescue', 'Highest urgency chapters', 'Retrieval + PYQ', top3, 'Score each PYQ set and mark weak answers.', 'Do not reread passively.', 3),
                makeAdaptiveDay(2, 'Day 2', 'Re-test', 'Re-test weak chapters + remaining urgent gaps', 'Spaced Retrieval + PYQ', top2.length ? top2 : top3, 'Re-attempt Day 1 mistakes without looking.', 'Do not add low-value chapters.', 3),
                makeAdaptiveDay(3, 'Day 3', 'Exam Eve', 'Error review + formula/definition recall', 'Light Recall', top3.slice(0, 1), 'Build a final error list and recall key points.', 'No new chapters.', 3)
            ];
            finalWarning = 'No new topics on exam eve. Review mistakes and sleep properly.';
        } else if (daysLeft === 4) {
            days = [
                makeAdaptiveDay(1, 'Day 1', 'Stabilize', 'Highest urgency memory-critical chapters', 'Retrieval + PYQ', top3, 'Score each PYQ set and mark weak answers.', 'Do not reread passively.', 3),
                makeAdaptiveDay(2, 'Day 2', 'Re-test', 'Same Day 1 weak chapters after 24h', 'Spaced Retrieval + PYQ', top2.length ? top2 : top3, 'Re-attempt Day 1 mistakes without looking.', 'Do not add low-value chapters.', 3),
                makeAdaptiveDay(3, 'Day 3', 'Simulation', 'Mixed PYQ / mini mock', 'Interleaved Practice', top3, 'Build an error log from mixed practice.', 'Do not ignore repeated mistakes.', 3),
                makeAdaptiveDay(4, 'Day 4', 'Exam Eve', 'Error log + formula/definition recall', 'Light Recall', top3.slice(0, 1), 'Review errors and recall formulas/definitions from memory.', 'No new chapters.', 3)
            ];
            finalWarning = 'No new topics on exam eve. Review mistakes and sleep properly.';
        } else if (daysLeft <= 7) {
            for (let day = 1; day <= daysLeft; day++) {
                const isLast = day === daysLeft;
                const isSimulation = day >= Math.max(5, daysLeft - 1) && !isLast;
                const phase = isLast ? 'Exam Eve' : day <= 2 ? 'Stabilize' : day <= 4 ? 'Review Loop' : 'Simulation';
                const focus = isLast ? 'Error log + formula/definition recall' : day <= 2 ? 'Critical chapters' : day <= 4 ? 'Spaced review + high-risk chapters' : 'Mixed practice / mock blocks';
                const method = isLast ? 'Light Recall' : day <= 2 ? 'Retrieval + PYQ' : day <= 4 ? 'Spaced Retrieval + PYQ' : isSimulation ? 'Interleaved Practice' : 'Mixed Practice';
                const chapters = isLast ? top3.slice(0, 1) : day <= 2 ? top3 : day <= 4 ? (next2.length ? next2 : top3) : top3;
                const checkpoint = isLast ? 'Review errors and recall key points only.' : day <= 2 ? 'Score PYQ sets and mark weak answers.' : day <= 4 ? 'Re-attempt weak answers after spacing.' : 'Build an error log from mixed practice.';
                const avoid = isLast ? 'No new chapters.' : 'Do not reread passively.';
                days.push(makeAdaptiveDay(day, `Day ${day}`, phase, focus, method, chapters, checkpoint, avoid, maxShortBlocks));
            }
            finalWarning = 'Do not save PYQs for the final day.';
        } else {
            const labels = buildGroupedLabels(Math.min(daysLeft, 14), 7);
            const grouped = [
                ['Foundation', 'Critical + high-risk chapters', 'Retrieval + PYQ', top3, 'Score initial PYQ sets and mark weak chapters.', 'Do not drift into low-value tasks.'],
                ['Critical Review', 'Revisit critical chapters', 'Spaced Retrieval', top2.length ? top2 : top3, 'Recall before opening notes.', 'Do not let critical chapters go stale.'],
                ['High-Risk Chapters', 'Close high-risk task gaps', 'PYQ Practice', next2.length ? next2 : top3, 'Attempt questions without notes.', 'Do not skip wrong-answer review.'],
                ['Spacing Cycle', 'Review critical chapters after spacing', 'Spaced Retrieval', top3, 'Re-test weak answers after 3–5 days.', 'Do not restart from scratch.'],
                ['Interleaved PYQ', 'Mixed PYQ sets across subjects', 'Interleaved Practice', top3, 'Mix chapters and track repeated mistakes.', 'Do not practice only comfortable topics.'],
                ['Mock', 'Mini mock / timed mixed practice', 'Mixed Practice', top3, 'Build an error log from timed practice.', 'Do not ignore timing mistakes.'],
                ['Error Review', 'Error log + light recall', 'Light Recall', top3.slice(0, 1), 'Review errors and recall formulas/definitions.', 'No new chapters in final review.']
            ];
            days = grouped.map((item, index) => makeAdaptiveDay(index + 1, labels[index], item[0], item[1], item[2], item[3], item[4], item[5], 4));
            finalWarning = 'Do not let critical chapters go stale.';
        }

        return {
            title: getAdaptivePlanTitle(plan, days.length, hasExam),
            subtitle: getAdaptiveSubtitle(plan, hasExam),
            daysLeft,
            days,
            finalWarning,
            hasChapterData: topChapters.length > 0
        };
    }

    function generatePlan() {
        const context = collectContext();
        const planMeta = determinePlanType(context);
        const rules = getProtocolRules(planMeta.planType);

        if (!context.chapters.length) {
            return {
                planType: planMeta.planType,
                modeLabel: planMeta.modeLabel,
                daysLeft: planMeta.daysLeft,
                examSubject: planMeta.examSubject,
                severity: planMeta.severity,
                reason: context.hasExamScope && context.allChapters?.length ? 'Selected exam chapters were not found in tracked syllabus data.' : 'Not enough study data yet. Complete syllabus/backlog tracking to unlock precise panic planning.',
                completionRate: 0,
                backlogCount: 0,
                memoryCriticalCount: 0,
                topChapters: [],
                syllabusTruth: context.syllabusTruth,
                dailyBattlePlan: buildDailyBattlePlan({ planType: planMeta.planType, topChapters: [] }),
                protocolTimeline: buildProtocolTimeline({ planType: planMeta.planType, topChapters: [] }),
                adaptiveDayPlan: generateAdaptiveDayPlan({ planType: planMeta.planType, daysLeft: planMeta.daysLeft, examSubject: planMeta.examSubject, topChapters: [], dailyBattlePlan: { blocks: [] } }),
                rules,
                alerts: ['No chapter data found. Add syllabus progress to activate V2 planning.'],
                _lowConfidence: true
            };
        }

        const topChapters = context.chapters
            .filter(chapter => chapter.tasksDone < 3 || getRetention(chapter, context) < 60 || isWeakChapter(chapter, context.weakChapters))
            .map(chapter => {
                const scored = calcUrgencyScore(chapter, context);
                const taskType = detectTaskType(Object.assign({}, chapter, { retention: scored.retention }), context);
                const sessionType = recommendSessionType(Object.assign({}, chapter, { retention: scored.retention, taskType }), planMeta.planType, context);
                return {
                    chapterName: chapter.chapterName,
                    subject: chapter.subject,
                    urgencyScore: scored.urgencyScore,
                    retention: scored.retention,
                    tasksDone: scored.tasksDone,
                    taskGap: scored.taskGap,
                    reasonTags: scored.reasonTags,
                    taskType,
                    sessionType
                };
            })
            .sort((a, b) => b.urgencyScore - a.urgencyScore)
            .slice(0, 3);

        const alerts = [];
        if (context.syllabusTruth && !context.syllabusTruth.isSelected) alerts.push(context.syllabusTruth.warning);
        if (context.memoryCriticalCount > 0) alerts.push(`${context.memoryCriticalCount} memory-critical chapter${context.memoryCriticalCount === 1 ? '' : 's'} detected.`);
        if (context.backlogCount > 8) alerts.push(`${context.backlogCount} started chapters are still incomplete.`);

        const plan = {
            planType: planMeta.planType,
            modeLabel: planMeta.modeLabel,
            daysLeft: planMeta.daysLeft,
            examSubject: planMeta.examSubject,
            severity: planMeta.severity,
            reason: planMeta.reason,
            completionRate: context.completionRate,
            backlogCount: context.backlogCount,
            memoryCriticalCount: context.memoryCriticalCount,
            topChapters,
            syllabusTruth: context.syllabusTruth,
            rules,
            alerts
        };

        plan.dailyBattlePlan = buildDailyBattlePlan(plan);
        plan.protocolTimeline = buildProtocolTimeline(plan);
        plan.adaptiveDayPlan = generateAdaptiveDayPlan(plan);
        return plan;
    }

    window.PanicProtocolV2 = {
        generatePlan,
        determinePlanType,
        collectContext,
        getChapterCandidates,
        calcUrgencyScore,
        recommendSessionType,
        getProtocolRules,
        buildDailyBattlePlan,
        generateDailyBattlePlan: buildDailyBattlePlan,
        interleaveBlocksBySubject,
        buildProtocolTimeline,
        generateProtocolTimeline: buildProtocolTimeline,
        generateAdaptiveDayPlan,
        detectTaskType,
        getExamScopeSafe,
        saveExamScope,
        clearExamScope,
        chapterMatchesExamScope
    };
}());
