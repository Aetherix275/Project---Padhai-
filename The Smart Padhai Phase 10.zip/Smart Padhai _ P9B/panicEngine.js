/**
 * PANIC PROTOCOL ENGINE - Improved Version
 * Fixed Calendar Strategy Parsing + SafeStorage
 */

(function () {
    const MANUAL_OVERRIDE_KEY = 'panicProtocolExamDate';
    const CALENDAR_KEY = 'calendarStrategy';
    const ONE_HOUR_MS = 60 * 60 * 1000;

    const MODE_DEFINITIONS = {
        BLITZ: { label: 'Blitz Mode', className: 'mode-blitz', difficulty: 'HIGH INTENSITY', alert: '⚠️ BLITZ MODE ACTIVATED' },
        SIEGE: { label: 'Siege Mode', className: 'mode-siege', difficulty: 'MEDIUM-HIGH', alert: '🛡️ SIEGE MODE ACTIVE' },
        FRESH: { label: 'Fresh Start Mode', className: 'mode-fresh', difficulty: 'FOUNDATION', alert: '✅ FRESH START MODE' }
    };

    const MODE_TASKS = {
        BLITZ: ['2 high-yield chapters revision', '1 full-length mock test + error log', 'Rapid recall drill', 'Past-year questions sprint'],
        SIEGE: ['1 core chapter deep study + notes', '1 mini test + analysis', 'Backlog rescue block', 'Spaced revision'],
        FRESH: ['Syllabus mapping: pick 2 topics', 'Focused learning block (90 min)', 'Light backlog cleanup', 'Revision + planning']
    };

    function normalizeDate(dateLike) {
        if (!dateLike) return null;
        const date = new Date(dateLike);
        if (Number.isNaN(date.getTime())) return null;
        date.setHours(0, 0, 0, 0);
        return date;
    }

    function toISODate(date) {
        return date ? date.toISOString().split('T')[0] : null;
    }

    // Improved Calendar Parser
    function parseCalendarStrategy() {
        const data = SafeStorage.getItem(CALENDAR_KEY);
        if (!data) return [];

        const exams = [];

        // Case 1: Array format
        if (Array.isArray(data)) {
            data.forEach(event => {
                if (event?.type === 'exam' || event?.mode === 'exam') {
                    exams.push({
                        subject: event.subject || event.title || 'Exam',
                        date: normalizeDate(event.date || event.examDate)
                    });
                }
            });
        } 
        // Case 2: Object format (most common in your project)
        else if (typeof data === 'object') {
            Object.keys(data).forEach(key => {
                const event = data[key];
                if (event && (event.type === 'exam' || event.mode === 'exam' || key.includes('exam'))) {
                    exams.push({
                        subject: event.subject || event.text || event.title || 'Upcoming Exam',
                        date: normalizeDate(key || event.date || event.examDate)
                    });
                }
            });
        }

        return exams.filter(e => e.date);
    }

    function getManualOverrideExam() {
        const override = SafeStorage.getItem(MANUAL_OVERRIDE_KEY);
        const date = normalizeDate(override);
        if (!date) return null;
        return { subject: 'Manual Override', date, source: 'manual' };
    }

    function getNearestExam() {
        const today = normalizeDate(new Date());
        const manual = getManualOverrideExam();
        if (manual && manual.date >= today) return manual;

        const exams = parseCalendarStrategy();
        const futureExams = exams.filter(exam => exam.date >= today);
        
        if (!futureExams.length) return null;

        futureExams.sort((a, b) => a.date - b.date);
        return futureExams[0];
    }

    function calculateDaysLeft(examDate) {
        if (!examDate) return null;
        const today = normalizeDate(new Date());
        const diffMs = examDate.getTime() - today.getTime();
        return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    }

    function getMode(daysLeft) {
        if (typeof daysLeft !== 'number') return 'FRESH';
        if (daysLeft <= 7) return 'BLITZ';
        if (daysLeft <= 14) return 'SIEGE';
        return 'FRESH';
    }

    function updateTaskList(modeKey) {
        const taskList = document.getElementById('panicTaskList');
        if (!taskList) return;
        const tasks = MODE_TASKS[modeKey] || MODE_TASKS.FRESH;
        taskList.innerHTML = tasks.map((task, i) => `<li>${i+1}. ${task}</li>`).join('');
    }

    function renderUI(state) {
        const indicator = document.getElementById('panicModeIndicator');
        const toast = document.getElementById('panicActivationToast');

        if (indicator) {
            indicator.textContent = MODE_DEFINITIONS[state.mode].label;
            indicator.className = MODE_DEFINITIONS[state.mode].className;
        }

        if (toast) {
            const text = state.daysLeft 
                ? `${state.subject} | Exam in ${state.daysLeft} day(s)` 
                : 'No upcoming exam detected in calendarStrategy.';
            toast.textContent = `${MODE_DEFINITIONS[state.mode].alert} | ${text}`;
        }

        updateTaskList(state.mode);
    }

    function execute() {
        const state = {
            subject: 'No Upcoming Exam',
            daysLeft: null,
            mode: 'FRESH'
        };

        const nearest = getNearestExam();
        if (nearest) {
            state.subject = nearest.subject;
            state.daysLeft = calculateDaysLeft(nearest.date);
            state.mode = getMode(state.daysLeft);
        }

        window.PanicProtocolEngineState = state;
        renderUI(state);
    }

    window.PanicProtocolEngine = {
        run: execute,
        refresh: execute,
        getState: () => window.PanicProtocolEngineState
    };

    // __SPA_MODE GUARD: In SPA mode, the dashboardRoute handles
    // initialization and interval management. The DOMContentLoaded
    // auto-init is disabled to prevent duplicate intervals.
    if (!window.__SPA_MODE) {
    document.addEventListener('DOMContentLoaded', () => {
        execute();
        setInterval(execute, ONE_HOUR_MS);
    });
    }
})();