// =====================================================
// SMART PADHAI → SUPABASE CORE MIGRATION SCRIPT v2
// Multi-user safe: every row gets user_id, no global clears.
//
// Migrates:
//   syllabus_master_tracker  → syllabus_progress
//   notebook_matrix_data     → notebooks
//   calendarStrategy         → calendar_events
//   commanderMissions        → missions
//   tacticalSchedule         → tactical_schedule
//
// Conflict keys (unique per user):
//   syllabus_progress  → user_id, subject, chapter
//   notebooks          → user_id, source_key
//   calendar_events    → user_id, source_key
//   missions           → user_id, source_key
//   tactical_schedule  → user_id, source_key
//
// REQUIRES (loaded before this script):
//   1. Supabase CDN
//   2. userSession.js  (provides supabaseClient, getCurrentUserOrRedirect,
//                        SafeStorage)
// =====================================================

// ── Helper: read from SafeStorage safely ──────────────
function safeParseLS(key, fallback = null) {
    try {
        const raw = SafeStorage.getItem(key);
        if (!raw) return fallback;
        return raw;
    } catch (err) {
        console.warn(`[Migration] Failed to parse ${key}`, err);
        return fallback;
    }
}

// ── Helper: generate a stable source_key from parts ───
// We use a simple deterministic string so the same logical
// record always produces the same source_key for upserts.
function makeSourceKey(...parts) {
    return parts
        .filter(p => p !== null && p !== undefined && p !== "")
        .map(p => String(p).replace(/[^a-zA-Z0-9_-]/g, "_"))
        .join("__");
}

// ── Helper: clear ONLY the current user's rows from a table ──
// NEVER deletes globally. Uses supabaseClient (auth-aware).
async function clearUserRows(tableName, userId) {
    if (!window.supabaseClient) {
        console.error(`[Migration] supabaseClient not available — cannot clear ${tableName}`);
        return false;
    }

    try {
        const { error } = await window.supabaseClient
            .from(tableName)
            .delete()
            .eq("user_id", userId);

        if (error) {
            console.error(`[Migration] Failed to clear ${tableName} for user ${userId}:`, error.message);
            return false;
        }

        console.log(`[Migration] Cleared ${tableName} for user ${userId}`);
        return true;
    } catch (err) {
        console.error(`[Migration] Clear error for ${tableName}:`, err);
        return false;
    }
}

// ── Helper: upsert rows for the current user via supabaseClient ──
// Adds user_id to every row and uses the given conflict key.
async function upsertUserRows(tableName, rows, conflictKey, userId) {
    if (!Array.isArray(rows) || rows.length === 0) {
        console.log(`[Migration] No rows to upsert for ${tableName}`);
        return { upserted: 0, errors: [] };
    }

    if (!window.supabaseClient) {
        console.error(`[Migration] supabaseClient not available — cannot upsert ${tableName}`);
        return { upserted: 0, errors: ["supabaseClient not available"] };
    }

    // Ensure every row has user_id
    const rowsWithUser = rows.map(row => ({
        ...row,
        user_id: userId
    }));

    try {
        const { data, error } = await window.supabaseClient
            .from(tableName)
            .upsert(rowsWithUser, { onConflict: conflictKey })
            .select();

        if (error) {
            console.error(`[Migration] ${tableName} upsert failed:`, error.message);
            return { upserted: 0, errors: [error.message] };
        }

        const count = Array.isArray(data) ? data.length : 0;
        console.log(`[Migration] ${tableName} upserted ${count} rows`);
        return { upserted: count, errors: [] };
    } catch (err) {
        console.error(`[Migration] ${tableName} upsert exception:`, err);
        return { upserted: 0, errors: [String(err)] };
    }
}


// =====================================================
// ROW BUILDERS  (pure functions — no Supabase calls)
// Each returns an array of row objects. The caller is
// responsible for adding user_id and upserting.
// =====================================================

// ── 1. Syllabus Progress ──────────────────────────────
function buildSyllabusRows() {
    const tracker = safeParseLS("syllabus_master_tracker", {});
    const progressData = safeParseLS("smartPadhaiData", {});
    const rows = [];

    if (!tracker || typeof tracker !== "object") return rows;

    Object.keys(tracker).forEach((chapter) => {
        const progress = progressData[chapter] || {};

        const read  = progress.read  === true;
        const notes = progress.notes === true;
        const pyq   = progress.pyq   === true;

        const completedCount  = [read, notes, pyq].filter(Boolean).length;
        const progressPercent = Math.round((completedCount / 3) * 100);

        rows.push({
            subject: progress.subject || "Unknown",
            chapter: chapter,
            completed: completedCount === 3,
            progress: progressPercent,
            raw_data: {
                registry: tracker[chapter],
                progress: progress
            },
            last_updated: progress.lastUpdated || null
        });
    });

    return rows;
}

// ── 2. Notebooks ──────────────────────────────────────
function buildNotebookRows() {
    const data = safeParseLS("notebook_matrix_data", {});
    const rows = [];

    if (!data || typeof data !== "object") return rows;

    Object.entries(data).forEach(([key, value]) => {
        // Generate a stable source_key from the localStorage key
        const source_key = makeSourceKey("nb", key);

        if (value && typeof value === "object" && !Array.isArray(value)) {
            rows.push({
                source_key: source_key,
                subject: value.subject || key,
                notebook_type: value.type || value.notebook_type || "general",
                title: value.title || key,
                completed:
                    value.completed === true ||
                    value.done === true ||
                    value.status === "completed",
                delta_pages:
                    Number(value.delta_pages || value.deltaPages || value.pages || 0),
                raw_data: value,
                last_updated:
                    value.lastUpdated ||
                    value.last_updated ||
                    null
            });
        } else {
            rows.push({
                source_key: source_key,
                subject: "Unknown",
                notebook_type: "general",
                title: key,
                completed: value === true,
                delta_pages: 0,
                raw_data: value,
                last_updated: null
            });
        }
    });

    return rows;
}

// ── 3. Calendar Events ────────────────────────────────
function buildCalendarRows() {
    const data = safeParseLS("calendarStrategy", {});
    const rows = [];

    if (!data || typeof data !== "object") return rows;

    Object.entries(data).forEach(([date, eventData]) => {
        // Generate a stable source_key from the date
        const source_key = makeSourceKey("cal", date);

        rows.push({
            source_key: source_key,
            event_date: date,
            mode: eventData?.mode || "general",
            title:
                eventData?.text ||
                eventData?.title ||
                eventData?.name ||
                "Untitled Event",
            description:
                eventData?.description ||
                eventData?.note ||
                null,
            event_type:
                eventData?.type ||
                eventData?.mode ||
                "general",
            raw_data: eventData
        });
    });

    return rows;
}

// ── 4. Commander Missions ─────────────────────────────
function buildMissionRows() {
    const data = safeParseLS("commanderMissions", {});
    const rows = [];

    if (!data || typeof data !== "object") return rows;

    Object.entries(data).forEach(([slot, missions]) => {
        if (Array.isArray(missions)) {
            missions.forEach((mission, index) => {
                // Stable source_key from slot + index
                const source_key = makeSourceKey("mis", slot, index);

                rows.push({
                    source_key: source_key,
                    slot: slot,
                    title:
                        mission?.title ||
                        mission?.name ||
                        "Untitled Mission",
                    status:
                        mission?.status ||
                        (mission?.completed ? "completed" : "pending"),
                    priority:
                        mission?.priority ||
                        mission?.level ||
                        null,
                    reward_pp:
                        Number(mission?.reward_pp || mission?.pp || mission?.reward || 0),
                    mission_date:
                        mission?.date ||
                        mission?.mission_date ||
                        null,
                    raw_data: mission
                });
            });
        }
    });

    return rows;
}

// ── 5. Tactical Schedule ──────────────────────────────
function buildTacticalScheduleRows() {
    const data = safeParseLS("tacticalSchedule", {});
    const rows = [];

    if (!data) return rows;

    if (Array.isArray(data)) {
        data.forEach((block, index) => {
            const source_key = makeSourceKey("tac", index, block?.block_name || block?.name || block?.title || "");
            rows.push({
                source_key: source_key,
                block_name:
                    block?.block_name ||
                    block?.name ||
                    block?.title ||
                    "Unnamed Block",
                start_time:
                    block?.start_time ||
                    block?.start ||
                    block?.time ||
                    null,
                end_time:
                    block?.end_time ||
                    block?.end ||
                    null,
                subject:
                    block?.subject ||
                    null,
                task:
                    block?.task ||
                    block?.title ||
                    block?.description ||
                    null,
                status:
                    block?.status ||
                    (block?.completed ? "completed" : "pending"),
                raw_data: block
            });
        });
    } else if (typeof data === "object") {
        Object.entries(data).forEach(([blockName, block]) => {
            const source_key = makeSourceKey("tac", blockName);
            rows.push({
                source_key: source_key,
                block_name: blockName,
                start_time:
                    block?.start_time ||
                    block?.start ||
                    block?.time ||
                    null,
                end_time:
                    block?.end_time ||
                    block?.end ||
                    null,
                subject:
                    block?.subject ||
                    null,
                task:
                    block?.task ||
                    block?.title ||
                    block?.description ||
                    null,
                status:
                    block?.status ||
                    (block?.completed ? "completed" : "pending"),
                raw_data: block
            });
        });
    }

    return rows;
}


// =====================================================
// MAIN MIGRATION FUNCTION
// =====================================================
async function migrateCoreLocalStorageToSupabase() {
    console.log("%c========== SMART PADHAI CORE MIGRATION v2 STARTED ==========", "color: #00ccff; font-weight: bold");

    // ── Step 1: Get current user ──────────────────────
    const user = await getCurrentUserOrRedirect();
    if (!user) {
        console.error("[Migration] No authenticated user — aborting migration.");
        return;
    }

    const userId = user.id;
    console.log(`[Migration] Current user: ${user.email} (${userId})`);

    // ── Step 2: Build all rows (SafeStorage is now user-scoped) ──
    const syllabusRows  = buildSyllabusRows();
    const notebookRows  = buildNotebookRows();
    const calendarRows  = buildCalendarRows();
    const missionRows   = buildMissionRows();
    const scheduleRows  = buildTacticalScheduleRows();

    console.log(`[Migration] Rows prepared:`);
    console.log(`  syllabus_progress : ${syllabusRows.length}`);
    console.log(`  notebooks         : ${notebookRows.length}`);
    console.log(`  calendar_events   : ${calendarRows.length}`);
    console.log(`  missions          : ${missionRows.length}`);
    console.log(`  tactical_schedule : ${scheduleRows.length}`);

    // ── Step 3: Clear ONLY current user's existing rows ──
    // This ensures a clean mirror without touching other users' data.
    await clearUserRows("syllabus_progress", userId);
    await clearUserRows("notebooks",         userId);
    await clearUserRows("calendar_events",   userId);
    await clearUserRows("missions",          userId);
    await clearUserRows("tactical_schedule", userId);

    // ── Step 4: Upsert rows with user_id + conflict keys ──
    const results = {};

    results.syllabus_progress = await upsertUserRows(
        "syllabus_progress",
        syllabusRows,
        "user_id,subject,chapter",
        userId
    );

    results.notebooks = await upsertUserRows(
        "notebooks",
        notebookRows,
        "user_id,source_key",
        userId
    );

    results.calendar_events = await upsertUserRows(
        "calendar_events",
        calendarRows,
        "user_id,source_key",
        userId
    );

    results.missions = await upsertUserRows(
        "missions",
        missionRows,
        "user_id,source_key",
        userId
    );

    results.tactical_schedule = await upsertUserRows(
        "tactical_schedule",
        scheduleRows,
        "user_id,source_key",
        userId
    );

    // ── Step 5: Summary ───────────────────────────────
    const totalUpserted = Object.values(results).reduce((sum, r) => sum + r.upserted, 0);
    const allErrors     = Object.values(results).flatMap(r => r.errors);

    console.log("%c========== MIGRATION SUMMARY ==========", "color: #00ff9d; font-weight: bold");
    console.log(`  User       : ${user.email} (${userId})`);
    console.log(`  Syllabus   : ${results.syllabus_progress.upserted} rows upserted`);
    console.log(`  Notebooks  : ${results.notebooks.upserted} rows upserted`);
    console.log(`  Calendar   : ${results.calendar_events.upserted} rows upserted`);
    console.log(`  Missions   : ${results.missions.upserted} rows upserted`);
    console.log(`  Schedule   : ${results.tactical_schedule.upserted} rows upserted`);
    console.log(`  Total      : ${totalUpserted} rows`);

    if (allErrors.length > 0) {
        console.error(`[Migration] Errors encountered:`);
        allErrors.forEach(e => console.error(`  - ${e}`));
    } else {
        console.log(`[Migration] No errors.`);
    }

    console.log("%c========== SMART PADHAI CORE MIGRATION v2 FINISHED ==========", "color: #00ccff; font-weight: bold");
}
