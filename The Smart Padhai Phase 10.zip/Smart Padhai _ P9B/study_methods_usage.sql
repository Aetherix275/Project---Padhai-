-- ═══════════════════════════════════════════════════════════════
-- Smart Padhai — study_methods_usage Table + RLS
-- Phase 5C: Study Vault Detailed Methods
-- ═══════════════════════════════════════════════════════════════
--
-- Run this in the Supabase SQL Editor (one-time setup)
--

-- 1. Create the table
CREATE TABLE IF NOT EXISTS study_methods_usage (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id             uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    method_name         varchar(50) NOT NULL,
    times_activated     integer DEFAULT 0,
    total_minutes       integer DEFAULT 0,
    effectiveness_rating integer DEFAULT 0,
    last_used           timestamptz,
    created_at          timestamptz DEFAULT now(),
    updated_at          timestamptz DEFAULT now(),

    CONSTRAINT unique_user_method UNIQUE (user_id, method_name)
);

-- 2. Enable Row Level Security
ALTER TABLE study_methods_usage ENABLE ROW LEVEL SECURITY;

-- 3. RLS Policy: Users can only read/write their own method usage
CREATE POLICY "Users can read own study methods"
    ON study_methods_usage
    FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own study methods"
    ON study_methods_usage
    FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own study methods"
    ON study_methods_usage
    FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own study methods"
    ON study_methods_usage
    FOR DELETE
    USING (auth.uid() = user_id);

-- 4. Index for fast queries by user
CREATE INDEX IF NOT EXISTS idx_study_methods_user
    ON study_methods_usage (user_id, method_name);

-- 5. Grant anon key access (required for REST API calls with anon key)
GRANT ALL ON study_methods_usage TO anon;
GRANT ALL ON study_methods_usage TO authenticated;

-- ═══════════════════════════════════════════════════════════════
-- Verification (run after creation):
--
-- SELECT * FROM study_methods_usage LIMIT 5;
-- Should return empty or your own rows only
-- ═══════════════════════════════════════════════════════════════
