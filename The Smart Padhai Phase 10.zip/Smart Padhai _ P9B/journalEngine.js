// =====================================================
// SMART PADHAI — JOURNAL ENGINE MODULE
// Phase 5D: Operator Journal / Diary
// =====================================================
//
// SafeStorage-first, Supabase mirror second.
// Uses window.supabaseClient (no raw fetch).
// Every Supabase row includes user_id.
// Upsert with onConflict: "user_id,entry_date".
//
// Load order: userSession.js → journalEngine.js → vault inline
// =====================================================

const JournalEngine = {
    STORAGE_KEY: 'operator_journal_entries',

    // ── Get all entries from SafeStorage ──
    getAllEntries() {
        return SafeStorage.getItem(this.STORAGE_KEY, []);
    },

    // ── Get entry for a specific date ──
    getEntryByDate(dateStr) {
        const all = this.getAllEntries();
        return all.find(e => e.entry_date === dateStr) || null;
    },

    // ── Get today's date string (YYYY-MM-DD) ──
    getTodayStr() {
        const d = new Date();
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    },

    // ── Save or update an entry ──
    // entryData = { mood, focus_rating, what_i_studied, biggest_distraction, today_win, tomorrow_target, notes }
    async saveEntry(entryData) {
        const all = this.getAllEntries();
        const todayStr = this.getTodayStr();

        // Find existing entry for today
        const existingIdx = all.findIndex(e => e.entry_date === todayStr);

        const entry = {
            entry_date: todayStr,
            mood: entryData.mood || 'Normal',
            focus_rating: entryData.focus_rating || 5,
            what_i_studied: entryData.what_i_studied || '',
            biggest_distraction: entryData.biggest_distraction || '',
            today_win: entryData.today_win || '',
            tomorrow_target: entryData.tomorrow_target || '',
            notes: entryData.notes || '',
            updated_at: new Date().toISOString()
        };

        if (existingIdx >= 0) {
            // Update existing entry
            entry.created_at = all[existingIdx].created_at;
            all[existingIdx] = entry;
        } else {
            // Create new entry
            entry.created_at = new Date().toISOString();
            all.push(entry);
        }

        // Sort by date descending (newest first)
        all.sort((a, b) => b.entry_date.localeCompare(a.entry_date));

        // Save to SafeStorage first
        SafeStorage.setItem(this.STORAGE_KEY, all);

        // Mirror to Supabase (non-blocking)
        this._mirrorToSupabase(entry);

        return entry;
    },

    // ── Delete an entry by date ──
    async deleteEntry(dateStr) {
        let all = this.getAllEntries();
        const entry = all.find(e => e.entry_date === dateStr);

        all = all.filter(e => e.entry_date !== dateStr);
        SafeStorage.setItem(this.STORAGE_KEY, all);

        // Delete from Supabase (non-blocking)
        this._deleteFromSupabase(dateStr);

        return true;
    },

    // ── Get entries for the last N days ──
    getRecentEntries(days = 7) {
        const all = this.getAllEntries();
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - days);
        const cutoffStr = `${cutoff.getFullYear()}-${String(cutoff.getMonth() + 1).padStart(2, '0')}-${String(cutoff.getDate()).padStart(2, '0')}`;

        return all.filter(e => e.entry_date >= cutoffStr);
    },

    // ── Mirror entry to Supabase journal_entries table ──
    async _mirrorToSupabase(entry) {
        if (!window.supabaseClient) {
            console.warn('[JournalEngine] No Supabase client — skipping mirror');
            return;
        }

        try {
            const user = await getCurrentUserOrRedirect();
            if (!user) return;

            const row = {
                user_id: user.id,
                entry_date: entry.entry_date,
                mood: entry.mood,
                focus_rating: entry.focus_rating,
                what_i_studied: entry.what_i_studied,
                biggest_distraction: entry.biggest_distraction,
                today_win: entry.today_win,
                tomorrow_target: entry.tomorrow_target,
                notes: entry.notes,
                updated_at: entry.updated_at || new Date().toISOString()
            };

            const { error } = await window.supabaseClient
                .from('journal_entries')
                .upsert(row, { onConflict: 'user_id,entry_date' });

            if (error) {
                console.warn('[JournalEngine] Supabase mirror error:', error.message);
            } else {
                console.log(`[JournalEngine] Synced entry for ${entry.entry_date} to Supabase`);
            }
        } catch (err) {
            console.warn('[JournalEngine] Mirror failed:', err);
        }
    },

    // ── Delete entry from Supabase ──
    async _deleteFromSupabase(dateStr) {
        if (!window.supabaseClient) return;

        try {
            const user = await getCurrentUserOrRedirect();
            if (!user) return;

            const { error } = await window.supabaseClient
                .from('journal_entries')
                .delete()
                .eq('user_id', user.id)
                .eq('entry_date', dateStr);

            if (error) {
                console.warn('[JournalEngine] Supabase delete error:', error.message);
            } else {
                console.log(`[JournalEngine] Deleted entry for ${dateStr} from Supabase`);
            }
        } catch (err) {
            console.warn('[JournalEngine] Delete failed:', err);
        }
    },

    // ── Load entries from Supabase (on vault page load, merge with SafeStorage) ──
    async loadFromSupabase() {
        if (!window.supabaseClient) return;

        try {
            const rows = await fetchUserRows('journal_entries');
            if (!rows || rows.length === 0) return;

            const local = this.getAllEntries();

            rows.forEach(row => {
                const existing = local.find(e => e.entry_date === row.entry_date);
                if (!existing) {
                    // Add new entry from Supabase
                    local.push({
                        entry_date: row.entry_date,
                        mood: row.mood || 'Normal',
                        focus_rating: row.focus_rating || 5,
                        what_i_studied: row.what_i_studied || '',
                        biggest_distraction: row.biggest_distraction || '',
                        today_win: row.today_win || '',
                        tomorrow_target: row.tomorrow_target || '',
                        notes: row.notes || '',
                        created_at: row.created_at,
                        updated_at: row.updated_at
                    });
                } else if (row.updated_at && (!existing.updated_at || row.updated_at > existing.updated_at)) {
                    // Supabase version is newer — overwrite local
                    existing.mood = row.mood || existing.mood;
                    existing.focus_rating = row.focus_rating || existing.focus_rating;
                    existing.what_i_studied = row.what_i_studied ?? existing.what_i_studied;
                    existing.biggest_distraction = row.biggest_distraction ?? existing.biggest_distraction;
                    existing.today_win = row.today_win ?? existing.today_win;
                    existing.tomorrow_target = row.tomorrow_target ?? existing.tomorrow_target;
                    existing.notes = row.notes ?? existing.notes;
                    existing.updated_at = row.updated_at;
                }
            });

            // Sort by date descending
            local.sort((a, b) => b.entry_date.localeCompare(a.entry_date));

            SafeStorage.setItem(this.STORAGE_KEY, local);
            console.log('[JournalEngine] Loaded from Supabase:', rows.length, 'rows');
        } catch (err) {
            console.warn('[JournalEngine] Supabase load failed:', err);
        }
    },

    // ════════════════════════════════════════════════════
    // AESTRA-READY SUMMARY (Phase 5D)
    // Does NOT send raw journal text to AESTRA.
    // Returns compressed stats only.
    // This function exists for future AESTRA integration.
    // Do NOT call it automatically.
    // ════════════════════════════════════════════════════
    getJournalSummaryForAestra() {
        const recent = this.getRecentEntries(7);

        if (recent.length === 0) {
            return {
                entries_count: 0,
                message: 'No journal entries in the last 7 days.'
            };
        }

        // Last 7 moods
        const lastMoods = recent.map(e => e.mood);

        // Average focus rating
        const avgFocus = recent.reduce((sum, e) => sum + (e.focus_rating || 5), 0) / recent.length;

        // Common distractions count
        const distractionCounts = {};
        recent.forEach(e => {
            if (e.biggest_distraction && e.biggest_distraction.trim()) {
                const d = e.biggest_distraction.trim().toLowerCase();
                distractionCounts[d] = (distractionCounts[d] || 0) + 1;
            }
        });
        const commonDistractions = Object.entries(distractionCounts)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 3)
            .map(([name, count]) => ({ name, count }));

        // Tomorrow targets list
        const tomorrowTargets = recent
            .filter(e => e.tomorrow_target && e.tomorrow_target.trim())
            .map(e => e.tomorrow_target.trim())
            .slice(0, 5);

        return {
            entries_count: recent.length,
            last_7_moods: lastMoods,
            average_focus_rating: Math.round(avgFocus * 10) / 10,
            common_distractions: commonDistractions,
            tomorrow_targets: tomorrowTargets
        };
    }
};
