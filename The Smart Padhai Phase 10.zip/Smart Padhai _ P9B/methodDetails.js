// =====================================================
// SMART PADHAI — METHOD DETAILS MODULE
// Phase 5C: Study Vault Detailed Methods
// =====================================================
//
// Contains all 9 study method content as JS objects.
// No Supabase dependency for content — only usage tracking
// hits Supabase via study_methods_usage table.
//
// Load order: userSession.js → methodDetails.js → vault inline
// =====================================================

const METHOD_DETAILS = [
    // ── 1. POMODORO ─────────────────────────────────────
    {
        id: "pomodoro",
        name: "Pomodoro Technique",
        emoji: "⏱️",
        badge: "Focus Crusader",
        shortDesc: "50 min Deep Work + 10 min Break. Mobile ko black hole mein daal do. Focus is your currency!",
        whatItIs: "Pomodoro Technique ek time-management method hai jismein tum focused study intervals mein kaam karte ho — typically 50 minutes ka deep work block followed by 10 minutes ka short break. 4 blocks ke baad ek longer break (25-30 min) lete ho. Ye technique tumhara brain fatigue se bachata hai aur concentration peak par rakhta hai. Naam Italy ke tomato timer se aaya hai — simple but deadly effective.",
        whenToUse: [
            "Jab tumhe long study sessions karni ho (3+ ghante)",
            "Jab distract hone ka fear ho (phone, social media)",
            "Jab revision marathon chal raha ho exam se pehle",
            "Jab tumhara attention span short lag raha ho",
            "Jab numericals practice karni ho continuously"
        ],
        bestSubjects: ["Physics", "Mathematics", "Chemistry Numericals", "Accounts", "Computer Science"],
        steps: [
            "Apna target decide karo — exactly kya karna hai ye 50 min mein",
            "Phone ko dusre kamre mein rakh do ya airplane mode ON karo",
            "Timer set karo 50 minute ka — NO PAUSE allowed",
            "Sirf ek task par focus karo — multi-tasking is the enemy",
            "Jab timer ring kare — utho, pani piyo, stretch karo (10 min break)",
            "4 Pomodoros ke baad 25-30 min ka long break lo",
            "Har Pomodoro ke end mein check karo — kya target complete hua?"
        ],
        commonMistakes: [
            "Break mein phone check karna — ye break nahi hai, distraction hai",
            "Timer pause karna — agar urgent hai toh session restart karo",
            "Ek hi Pomodoro mein 3-4 topics jump karna — stick to ONE task",
            "Break skip karna directly — brain ko recovery chahiye for next sprint",
            "50 min mein 25 min productive + 25 min daydreaming — focus meter track karo"
        ]
    },

    // ── 2. FEYNMAN TECHNIQUE ────────────────────────────
    {
        id: "feynman",
        name: "Feynman Technique",
        emoji: "🗣️",
        badge: "Feynman Adept",
        shortDesc: "Agar tum kisi topic ko 5 saal ke bacche ko nahi samjha sakte, toh tum usey khud nahi samjhe ho. Teach it to learn it.",
        whatItIs: "Nobel Prize winner Richard Feynman ki technique hai ye. Core idea simple hai — kisi bhi concept ko itna deeply samjho ki tum use kisi 5 saal ke bacche ko explain kar sako. Jargon, complicated terms, aur surface-level reading band karo. Agar tum simple language mein explain nahi kar sakte, matlab tumhe gap hai understanding mein. Ye technique tumhe EXACTLY dikhata hai tumhe kahan aur kya padhna baaki hai.",
        whenToUse: [
            "Jab concept samajh aa raha hai par yaad nahi ho raha",
            "Jab tumhe lagta hai tumne samjha lekin exam mein blank ho jate ho",
            "Jab theoretical subjects padh rahe ho (Biology, Civics, History)",
            "Jab answer writing practice karni ho — explanation clarity ke liye",
            "Jab kisi difficult chapter ko pehli baar padh rahe ho"
        ],
        bestSubjects: ["Biology", "Physics Theory", "History", "Civics", "Economics", "Chemistry Organic"],
        steps: [
            "Topic ka naam ek blank sheet par likho — sirf naam",
            "Apne words mein explain karo jaise tum kisi bachche ko samjha rahe ho — NO JARGON",
            "Jahan bhi tum stuck ho ya vague ho jaate ho — wo tumhara GAP hai, circle karo",
            "Wapas textbook ya notes mein jao aur SIRF wahi gap wala part padho",
            "Dubara explain karo — ab simple aur clear hona chahiye",
            "Optional: Kisi ko actually samjhao (friend, sibling, even wall) — speaking aloud se 2x retention hota hai"
        ],
        commonMistakes: [
            "Jargon use karna — 'mitochondria is powerhouse' is NOT Feynman level explanation",
            "Sirf read karke 'samjh gaya' sochna — explain KARO, likho ya bolo",
            "Gap identify karke wahi chhod dena — gap = study target, fill karo",
            "Over-simplification — simple ≠ wrong, facts accurate rakhne padenge",
            "Sirf ek baar karna — multiple rounds chahiye for deep mastery"
        ]
    },

    // ── 3. ACTIVE RECALL ────────────────────────────────
    {
        id: "active-recall",
        name: "Active Recall",
        emoji: "🧠",
        badge: "Recall Hunter",
        shortDesc: "Reading is passive. Testing is active. Book band karo aur khud se dushman ki tarah sawal pucho!",
        whatItIs: "Active Recall ek evidence-based study method hai jismein tum information ko actively yaad karne ki koshish karte ho — instead of passively re-reading notes. Book band karo, apne aap se sawal pucho, aur jo yaad aaya wo likho. Jo nahi yaad aaya — wahi tumhara weak spot hai. Research kehta hai active recall re-reading se 150% zyada effective hai. Ye method brain ko force karta hai neural pathways banane jo long-term memory banate hain.",
        whenToUse: [
            "Revision ke time — re-reading is WASTE, recall karo",
            "Exam se pehle mock test attempt karte waqt",
            "Jab tumhe lagta hai 'ye toh aata hai' par check nahi kiya",
            "Daily review ke liye — subah uthte hi kal ka padha hua recall karo",
            "Jab answer writing speed improve karni ho"
        ],
        bestSubjects: ["All Subjects", "Especially Biology", "History", "Chemistry Reactions", "Formulas", "Definitions"],
        steps: [
            "Topic padho — ek baar carefully (one proper read-through)",
            "Book/notes BAND karo — ab sirf dimaag se yaad karo",
            "Blank paper par likho jo yaad aaya — points, diagrams, formulas kuch bhi",
            "Apne likhe hue ko original notes se compare karo",
            "Jo miss hua ya galat tha — wo HIGHLIGHT karo, ye tumhara weak zone hai",
            "Weak zone ko phir se padho aur DUBARA recall karo after 1 hour",
            "Next day subah — bina dekhe same topic ka recall test lo"
        ],
        commonMistakes: [
            "Re-reading ko study samajhna — ye comfort zone hai, not learning",
            "Recall karke check nahi karna — bina verification recall useless hai",
            "Sirf headings yaad karna — details bhi yaad hone chahiye",
            "Ek baar recall karke 'done' sochna — spaced repetition chahiye",
            "Recall mein stuck hone par turant notes khoolna — 30 sec try karo pehle"
        ]
    },

    // ── 4. SPACED REPETITION ────────────────────────────
    {
        id: "spaced-repetition",
        name: "Spaced Repetition",
        emoji: "🔄",
        badge: "Repetition Master",
        shortDesc: "Ek hi cheez ko barte-barte increasing intervals mein revise karo. Brain wiring strong hogi permanently.",
        whatItIs: "Spaced Repetition ek scientifically proven technique hai jismein tum information ko increasing time gaps mein revise karte ho. Pehle 1 din baad, phir 3 din baad, phir 7 din, phir 15 din, phir 30 din. Har baar jab tum successfully recall karte ho, next interval badh jaata hai. Agar fail ho jaate ho, toh interval reset ho jaata hai. Ebbinghaus forgetting curve ke against ye sabse powerful weapon hai — ye technique memory decay ko reverse karta hai.",
        whenToUse: [
            "Jab long-term memory chahiye — exam ke liye last minute cramming nahi",
            "Vocabulary, formulas, dates, reactions yaad karne ke liye",
            "Jab same mistakes repeatedly ho rahe ho",
            "Daily revision schedule banana ho",
            "Jab syllabus bahut bada hai aur sab yaad rakhna hai"
        ],
        bestSubjects: ["Biology Terms", "Chemistry Reactions", "Math Formulas", "History Dates", "Vocabulary", "Definitions"],
        steps: [
            "Naya topic padhne ke baad USI DIN 5-10 min ka quick recall karo",
            "Day 1: Next day subah — bina dekhe recall karo",
            "Day 3: 3 din baad — flashcards ya self-test use karo",
            "Day 7: Weekly review — poora topic ka mental map banao",
            "Day 15: Biweekly check — sirf weak points recall karo",
            "Day 30: Monthly — agar ab bhi yaad hai, toh PERMANENT memory ban gaya",
            "Kahi bhi fail ho — reset to Day 1, dubara start karo (no shame)"
        ],
        commonMistakes: [
            "Har din sab kuch revise karna — ye overload hai, spaced intervals follow karo",
            "Intervals skip kar dena — consistency is the key",
            "Sirf re-reading karna — recall karo, matra padhna nahi",
            "Easy items ko over-revising — time waste, focus on weak items",
            "Koi tracking system nahi rakhna — calendar ya app use karo intervals ke liye"
        ]
    },

    // ── 5. 80/20 RULE (PARETO) ─────────────────────────
    {
        id: "pareto",
        name: "80/20 Rule (Pareto)",
        emoji: "📊",
        badge: "Pareto Warrior",
        shortDesc: "20% topics se 80% questions aate hain. Smart Padhai ka matlab hai un High-Yield topics ko pehle neutralize karna.",
        whatItIs: "Pareto Principle kehta hai ki 80% results 20% efforts se aate hain. Exam context mein — 20% syllabus ke topics se 80% exam questions aate hain. Smart student wo hai jo pehle ye 20% high-yield topics identify kare aur unhe MASTER kar le. Baaki 80% syllabus ke liye kam time do. Ye technique tumhe selective focus deti hai — har topic par equal time dena is POOR strategy. PYQs (Previous Year Questions) analysis karke ye 20% dhundho — exam pattern me hidden hai.",
        whenToUse: [
            "Jab syllabus bahut bada hai aur time kam hai",
            "Exam se 1-2 hafta pehle — last minute priority sorting",
            "Jab tumhara score stuck hai 60-70% par — high-yield focus se boost hoga",
            "Jab naya subject start karna ho — pehle core 20% cover karo",
            "Revision planning ke time — priority order mein rakhne ke liye"
        ],
        bestSubjects: ["All Subjects", "Especially Board Exams", "Entrance Exams", "Competitive Exams"],
        steps: [
            "Last 5-10 years ke PYQs (Previous Year Questions) collect karo",
            "Har question ko uske topic/chapter se map karo",
            "Count karo — kaunse topics se sabse zyada questions aate hain",
            "Top 20% topics ki list banao — ye tumhare HIGH-YIELD targets hain",
            "Pehle YE 20% topics MASTER karo — 100% clarity aur practice",
            "Baaki 80% topics ko basic level par cover karo — surface level enough",
            "Har mock test ke baad analysis karo — kya 20% prediction sahi thi?"
        ],
        commonMistakes: [
            "Sirf easy topics ko 20% mein daalna — high-yield ≠ easy, PYQs se prove karo",
            "Baaki 80% completely ignore karna — basic coverage zaroori hai",
            "PYQ analysis ke bina assumptions lena — DATA se decide karo",
            "Ek baar identify karke re-evaluate nahi karna — pattern change ho sakta hai",
            "Overconfidence in 20% — exam mein surprises aate hain, minimum coverage rakhho"
        ]
    },

    // ── 6. PAST PAPER METHOD ────────────────────────────
    {
        id: "past-paper",
        name: "Past Paper Method",
        emoji: "📝",
        badge: "Paper Strategist",
        shortDesc: "Previous year papers hi actual exam ka blueprint hain. Solve karo, analyze karo, predict karo.",
        whatItIs: "Past Paper Method mein tum previous years ke exam papers ko actual exam conditions mein solve karte ho — timer lagake, syllabus dekh ke, full answer writing karke. Ye method tumhe 3 cheezein deta hai: (1) Exam pattern samajhna, (2) Time management practice, (3) Exactly kahan weak hain ye pata lagana. Past papers exam ka sabse accurate simulation hain — koi bhi mock test isse better nahi hai. 5 saal ke papers solve karke tum 70-80% questions predict kar sakte ho.",
        whenToUse: [
            "Exam se 2-3 hafte pehle — full mock practice ke liye",
            "Jab pattern samajhna ho — kaunse chapters important hain",
            "Time management test karna ho — 3 hour paper 3 hour mein complete ho raha hai?",
            "Answer writing format practice ke liye",
            "Jab confidence build karna ho — 'main kar sakta hu' feeling ke liye"
        ],
        bestSubjects: ["Board Exams (All)", "NEET", "JEE", "CUET", "UPSC Prelims", "Any competitive exam"],
        steps: [
            "Last 5 years ke papers collect karo — official ya trusted source se",
            "Ek paper lo — timer set karo exactly exam duration ke barabar",
            "Phone band, books band — EXAM CONDITIONS maintain karo",
            "Full paper solve karo — har question attempt karo, na chodo",
            "Timer ring hone ke baad — check karo marking scheme se",
            "Analysis: Kaunse questions miss huye? Kaunse galat huye? Time kahan laga?",
            "Weak areas identify karke unhe next study session mein target karo",
            "Minimum 5 papers solve karo exam se pehle — each one better than last"
        ],
        commonMistakes: [
            "Papers solve karke check nahi karna — analysis bina checking ke useless hai",
            "Casually solve karna bina timer ke — exam pressure simulate nahi hoga",
            "Sirf ek paper solve karke 'done' sochna — minimum 5 chahiye for pattern",
            "Answer writing skip karke sirf mental solve karna — writing speed bhi test honi chahiye",
            "Negative marking ignore karna — real exam mein ye game changer hai"
        ]
    },

    // ── 7. ERROR NOTEBOOK ───────────────────────────────
    {
        id: "error-notebook",
        name: "Error Notebook",
        emoji: "📕",
        badge: "Error Eliminator",
        shortDesc: "Apni galtiyon ko track karo — har galat answer ek goldmine hai agar usse seekho. Mistakes = free points.",
        whatItIs: "Error Notebook ek dedicated notebook ya document hai jismein tum APNI har galti record karte ho — galat answers, silly mistakes, conceptual errors, calculation mistakes, jo bhi galat hua. Har error ke saath 3 cheezein likhti hain: (1) Kya galat kiya, (2) Kyun galat hua, (3) Next time kaise sahi karunga. Ye method tumhe repeatedly wahi galti repeat karne se roakta hai. Studies kehti hain error tracking se 40% improvement aata hai same type ke questions mein.",
        whenToUse: [
            "Har mock test ke baad — galat answers analyze karo",
            "Jab same type ki galtiyan repeat ho rahi ho",
            "Jab calculation mistakes se marks ja rahe ho",
            "Revision ke time — error notebook = your personal weak spots map",
            "Jab 'ye toh aata tha' feeling aati hai par marks nahi aate"
        ],
        bestSubjects: ["Mathematics", "Physics Numericals", "Chemistry Reactions", "Accounting", "Any subject with calculations"],
        steps: [
            "Ek dedicated notebook ya digital doc banao — ONLY for errors",
            "Har galat answer ke liye entry banao: Question + Tumhara wrong answer + Correct answer",
            "Reason likho — 'silly mistake' nahi, SPECIFIC reason: 'sign miss kiya', 'formula galat yaad kiya'",
            "Correction strategy likho — 'Next time sign check karunga pehle step mein'",
            "Weekly review — sab entries ek baar phir se padho",
            "Before exam — sirf Error Notebook padho, ye tumhara cheat sheet hai",
            "Pattern identify karo — agar 5 baar calculation error hai, toh calculation practice karo specifically"
        ],
        commonMistakes: [
            "'Silly mistake' likh kar chhod dena — SPECIFIC reason nahi likhne se improvement nahi hoga",
            "Entry banakar kabhi review nahi karna — notebook padhna bhi zaroori hai",
            "Sirf wrong answers note karna — conceptual misunderstandings bhi record karo",
            "Overconfidence — 'ab ye galti nahi karunga' bina strategy ke — likho KISE avoid karoge",
            "Digital aur physical dono mein karna — ek hi system use karo consistency ke liye"
        ]
    },

    // ── 8. MIND MAPPING ─────────────────────────────────
    {
        id: "mind-mapping",
        name: "Mind Mapping",
        emoji: "🗺️",
        badge: "Mind Mapper",
        shortDesc: "Visual diagrams se concepts ko connect karo. Brain ko structure dikhao — scattered notes se structured map tak.",
        whatItIs: "Mind Mapping ek visual thinking technique hai jismein tum ek central topic se related subtopics ko branches ki tarah draw karte ho. Ek page par poora chapter ka blueprint ban jaata hai. Brain visual information ko 60,000x faster process karta hai than text. Mind maps tumhe 'big picture' aur 'details' dono ek saath dikhate hain. Revision time mein 1 mind map dekhna = 10 pages notes padhne se better. Ye technique especially powerful hai jab concepts interconnected hain.",
        whenToUse: [
            "Jab chapter ka overview banana ho pehli baad padhte waqt",
            "Revision ke time — poora chapter ek nazar mein",
            "Jab concepts connected hain aur relationships samajhne ho",
            "Essay ya long answer writing ke liye structure banana ho",
            "Jab tumhe topic ki depth + breadth dono chahiye ek view mein"
        ],
        bestSubjects: ["Biology", "History", "Geography", "Chemistry Organic", "Economics", "Political Science"],
        steps: [
            "Page ke center mein MAIN TOPIC likho — bada aur bold",
            "Main branches banao — chapter ke major sections ya themes",
            "Har branch se sub-branches nikalo — details, examples, formulas",
            "Colors use karo — har branch ka alag color (visual memory boost)",
            "Key words likho — full sentences nahi, SIRF key terms",
            "Connections draw karo — agar do branches related hain toh arrow lagao",
            "Images/symbols add karo — brain images ko faster yaad rakhta hai",
            "Revision mein — mind map dekho, bina notes ke recall karo"
        ],
        commonMistakes: [
            "Bahut zyada text likhna — mind map keywords ka tool hai, paragraphs ka nahi",
            "Messy drawing — neatness matters for brain processing, clean rakho",
            "Sirf ek baar bana kar revision nahi karna — repeatedly dekhna zaroori hai",
            "Har detail include karna — sirf IMPORTANT points, not everything",
            "Digital tools pe depend karna — pen-paper se zyada retention hota hai (research proven)"
        ]
    },

    // ── 9. DEEP WORK ────────────────────────────────────
    {
        id: "deep-work",
        name: "Deep Work",
        emoji: "🎯",
        badge: "Deep Worker",
        shortDesc: "Distraction-free, maximum concentration ka state. 1 hour Deep Work = 4 hours shallow study. Quality over quantity.",
        whatItIs: "Deep Work ek professional-level focus technique hai (Cal Newport ki book se) jismein tum zero-distraction environment mein cognitively demanding tasks karte ho. Shallow study = notes padhte waqt phone check karna, songs sunna, TV chalna. Deep Work = door closed, phone off, single task, timer running, full brainpower ek cheez par. Research kehta hai 1 hour of true Deep Work = 4 hours of distracted study. Tumhara brain 'flow state' mein jaata hai jahan learning speed 5x hoti hai.",
        whenToUse: [
            "Jab bahut difficult topic padhna ho — jo full concentration maangta hai",
            "Jab deadline close hai aur maximum output chahiye minimum time mein",
            "Jab complex problem solve karni ho — math, physics derivations",
            "Jab creative work karna ho — essay writing, project work",
            "Jab tumhe 'quality study hours' count karni ho, not just time spent"
        ],
        bestSubjects: ["Mathematics", "Physics Derivations", "Programming", "Research Projects", "Essay Writing"],
        steps: [
            "DEEP WORK BLOCK schedule karo — calendar mein fix time slot",
            "Environment prepare karo — silent room, clean desk, water bottle ready",
            "Phone OFF karo — not silent, not vibrate, COMPLETELY OFF ya dusre kamre mein",
            "Internet block karo — agar nahi chahiye toh WiFi off, agar chahiye toh site blocker lagao",
            "Ek CLEAR task decide karo — 'Physics Chapter 5 ke derivations complete karna'",
            "Deep Work timer start karo — minimum 90 minutes, no interruptions",
            "Session ke baad — 20-30 min complete break (walk, food, NOT phone)",
            "Daily log: Kitne Deep Work hours kiye? Track karo weekly"
        ],
        commonMistakes: [
            "'Almost Deep Work' karna — music with lyrics, phone nearby, tab open — ye shallow hai",
            "2-3 ghante continuously karna bina break — brain fatigue, quality drop",
            "Easy tasks ko Deep Work mein daalna — only cognitively demanding tasks qualify",
            "Routine nahi banana — Deep Work needs SCHEDULED blocks, not 'jab mood ho'",
            "Environment ignore karna — noisy room = 0 Deep Work, place matters"
        ]
    }
];

// =====================================================
// METHOD USAGE TRACKER
// SafeStorage-first, Supabase mirror second
// =====================================================

const MethodUsageTracker = {
    STORAGE_KEY: 'study_methods_usage',

    // ── Get all usage data from SafeStorage ──
    getAllUsage() {
        return SafeStorage.getItem(this.STORAGE_KEY, {});
    },

    // ── Get usage for a single method ──
    getUsage(methodId) {
        const all = this.getAllUsage();
        return all[methodId] || {
            timesActivated: 0,
            totalMinutes: 0,
            effectivenessRating: 0,
            lastUsed: null
        };
    },

    // ── Record method activation (badge activation) ──
    async recordActivation(methodId) {
        const all = this.getAllUsage();
        const current = all[methodId] || {
            timesActivated: 0,
            totalMinutes: 0,
            effectivenessRating: 0,
            lastUsed: null
        };

        current.timesActivated = (current.timesActivated || 0) + 1;
        current.lastUsed = new Date().toISOString();

        all[methodId] = current;

        // Save to SafeStorage first
        SafeStorage.setItem(this.STORAGE_KEY, all);

        // Mirror to Supabase (non-blocking, fire-and-forget)
        this._mirrorToSupabase(methodId, current);

        return current;
    },

    // ── Add minutes to a method ──
    async addMinutes(methodId, minutes) {
        if (!minutes || minutes <= 0) return;

        const all = this.getAllUsage();
        const current = all[methodId] || {
            timesActivated: 0,
            totalMinutes: 0,
            effectivenessRating: 0,
            lastUsed: null
        };

        current.totalMinutes = (current.totalMinutes || 0) + minutes;
        current.lastUsed = new Date().toISOString();

        all[methodId] = current;

        // Save to SafeStorage first
        SafeStorage.setItem(this.STORAGE_KEY, all);

        // Mirror to Supabase (non-blocking)
        this._mirrorToSupabase(methodId, current);

        return current;
    },

    // ── Set effectiveness rating (0-10) ──
    async setRating(methodId, rating) {
        if (rating < 0 || rating > 10) return;

        const all = this.getAllUsage();
        const current = all[methodId] || {
            timesActivated: 0,
            totalMinutes: 0,
            effectivenessRating: 0,
            lastUsed: null
        };

        current.effectivenessRating = rating;
        current.lastUsed = new Date().toISOString();

        all[methodId] = current;

        // Save to SafeStorage first
        SafeStorage.setItem(this.STORAGE_KEY, all);

        // Mirror to Supabase (non-blocking)
        this._mirrorToSupabase(methodId, current);

        return current;
    },

    // ── Mirror to Supabase study_methods_usage table ──
    async _mirrorToSupabase(methodId, usageData) {
        if (!window.supabaseClient) {
            console.warn('[MethodUsageTracker] No Supabase client — skipping mirror');
            return;
        }

        try {
            const user = await getCurrentUserOrRedirect();
            if (!user) return;

            // Map methodId to the display name for Supabase
            const methodDetail = METHOD_DETAILS.find(m => m.id === methodId);
            const methodName = methodDetail ? methodDetail.name : methodId;

            const row = {
                user_id: user.id,
                method_name: methodName,
                times_activated: usageData.timesActivated || 0,
                total_minutes: usageData.totalMinutes || 0,
                effectiveness_rating: usageData.effectivenessRating || 0,
                last_used: usageData.lastUsed,
                updated_at: new Date().toISOString()
            };

            const { error } = await window.supabaseClient
                .from('study_methods_usage')
                .upsert(row, { onConflict: 'user_id,method_name' });

            if (error) {
                console.warn('[MethodUsageTracker] Supabase mirror error:', error.message);
            } else {
                console.log(`[MethodUsageTracker] Synced ${methodName} to Supabase`);
            }
        } catch (err) {
            console.warn('[MethodUsageTracker] Mirror failed:', err);
        }
    },

    // ── Load usage from Supabase (on vault page load, to merge with SafeStorage) ──
    async loadFromSupabase() {
        if (!window.supabaseClient) return;

        try {
            const rows = await fetchUserRows('study_methods_usage');
            if (!rows || rows.length === 0) return;

            const local = this.getAllUsage();

            rows.forEach(row => {
                // Find methodId from method_name
                const detail = METHOD_DETAILS.find(m => m.name === row.method_name);
                const methodId = detail ? detail.id : row.method_name;

                const existing = local[methodId];
                // Keep whichever data is more recent / higher
                if (!existing || (row.updated_at && (!existing.lastUsed || row.updated_at > existing.lastUsed))) {
                    local[methodId] = {
                        timesActivated: row.times_activated || 0,
                        totalMinutes: row.total_minutes || 0,
                        effectivenessRating: row.effectiveness_rating || 0,
                        lastUsed: row.last_used || row.updated_at
                    };
                }
            });

            SafeStorage.setItem(this.STORAGE_KEY, local);
            console.log('[MethodUsageTracker] Loaded from Supabase:', rows.length, 'rows');
        } catch (err) {
            console.warn('[MethodUsageTracker] Supabase load failed:', err);
        }
    }
};

// =====================================================
// ADD TO MISSION — Creates a mission in commanderMissions
// via SafeStorage (same system as Time.html)
// =====================================================

const MethodMission = {
    // ── Add a study method as a mission to the nearest time slot ──
    addMethodToMission(methodId) {
        const methodDetail = METHOD_DETAILS.find(m => m.id === methodId);
        if (!methodDetail) {
            console.warn('[MethodMission] Unknown method:', methodId);
            return false;
        }

        // Determine which slot to add to based on current time
        const hour = new Date().getHours();
        let slot;
        if (hour >= 5 && hour < 12) slot = 'morning';
        else if (hour >= 12 && hour < 17) slot = 'afternoon';
        else slot = 'night';

        // Get existing missions
        const missions = SafeStorage.getItem('commanderMissions', {
            morning: [],
            afternoon: [],
            night: []
        });

        // Ensure the slot array exists
        if (!missions[slot]) missions[slot] = [];

        // Create mission entry matching Time.html's format
        const colors = ['#00ff9d', '#00d1ff', '#ff4757', '#ffd700', '#ff8c00', '#5c67ff'];
        const missionColor = colors[Math.floor(Math.random() * colors.length)];

        missions[slot].push({
            time: this._getDefaultTime(slot),
            title: `${methodDetail.emoji} ${methodDetail.name} Session`,
            status: 'pending',
            color: missionColor,
            ppRewarded: false
        });

        SafeStorage.setItem('commanderMissions', missions);

        console.log(`[MethodMission] Added ${methodDetail.name} to ${slot} slot`);
        return slot;
    },

    // ── Get default time string for slot ──
    _getDefaultTime(slot) {
        switch (slot) {
            case 'morning': return '07:00 - 08:00';
            case 'afternoon': return '14:00 - 15:00';
            case 'night': return '20:00 - 21:00';
            default: return '09:00 - 10:00';
        }
    }
};
