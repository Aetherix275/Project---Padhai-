/**
 * AESTRA AI - State Engine (Phase 2)
 * Converts telemetry snapshots into behavior-aware state transitions.
 */
(function attachStateEngine(global) {
  const FIVE_MINUTES = 5 * 60 * 1000;
  const DEBUG_PREFIX = '[AESTRA StateEngine]';

  const stateMemory = {
    currentState: null,
    lastSnapshotTs: null
  };

  function getEventBus() {
    if (global.AESTRA_EVENT_BUS && typeof global.AESTRA_EVENT_BUS.emit === 'function') {
      return global.AESTRA_EVENT_BUS;
    }

    // Safe fallback bus to preserve modular integration if core bus is not yet bootstrapped.
    const listeners = {};
    global.AESTRA_EVENT_BUS = {
      on(eventName, handler) {
        if (!listeners[eventName]) listeners[eventName] = [];
        listeners[eventName].push(handler);
      },
      emit(eventName, payload) {
        (listeners[eventName] || []).forEach((handler) => {
          try { handler(payload); } catch (error) { console.error(`${DEBUG_PREFIX} listener error`, error); }
        });
      }
    };
    return global.AESTRA_EVENT_BUS;
  }

  function getLatestSnapshot() {
    if (!global.TelemetryStore || typeof global.TelemetryStore.latestSnapshot !== 'function') return null;
    return global.TelemetryStore.latestSnapshot();
  }

  function classifyState(snapshot) {
    if (!snapshot || !global.AESTRA_STATE_RULES) return null;
    const { normalizeTelemetry, STATE_PROFILES, scoreState } = global.AESTRA_STATE_RULES;
    const signals = normalizeTelemetry(snapshot);

    const scored = Object.entries(STATE_PROFILES).map(([name, profile]) => ({
      state: name,
      score: scoreState(profile, signals, stateMemory.currentState),
      description: profile.description
    })).sort((a, b) => b.score - a.score);

    const top = scored[0];
    const second = scored[1];
    const confidence = Math.max(0, top.score - (second ? second.score : 0));

    return {
      state: top.state,
      confidence,
      score: top.score,
      rankedStates: scored,
      signals,
      sourceTimestamp: snapshot.timestamp,
      evaluatedAt: new Date().toISOString()
    };
  }

  function evaluateAndEmit() {
    const snapshot = getLatestSnapshot();
    if (!snapshot) {
      console.debug(`${DEBUG_PREFIX} No telemetry snapshot available yet.`);
      return;
    }
    if (snapshot.timestamp === stateMemory.lastSnapshotTs) return;

    const stateData = classifyState(snapshot);
    if (!stateData) return;

    stateMemory.lastSnapshotTs = snapshot.timestamp;

    if (stateMemory.currentState !== stateData.state) {
      const previous = stateMemory.currentState;
      stateMemory.currentState = stateData.state;
      const eventPayload = { ...stateData, previousState: previous };
      getEventBus().emit('STATE_CHANGED', eventPayload);
      console.info(`${DEBUG_PREFIX} STATE_CHANGED`, eventPayload);
    } else {
      console.debug(`${DEBUG_PREFIX} State steady`, {
        state: stateData.state,
        score: stateData.score,
        confidence: stateData.confidence
      });
    }
  }

  const StateEngine = {
    init() {
      evaluateAndEmit();
      setInterval(evaluateAndEmit, FIVE_MINUTES);
      console.info(`${DEBUG_PREFIX} Initialized.`);
    },
    evaluateNow() {
      evaluateAndEmit();
    },
    getCurrentState() {
      return stateMemory.currentState;
    }
  };

  global.StateEngine = StateEngine;
  // __SPA_MODE GUARD: In SPA mode, aestraRoute.js handles initialization.
  if (!window.__SPA_MODE) {
    document.addEventListener('DOMContentLoaded', () => {
      try {
        StateEngine.init();
      } catch (error) {
        console.error(`${DEBUG_PREFIX} Init failed`, error);
      }
    });
  }
})(window);
