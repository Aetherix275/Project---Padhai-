/**
 * AESTRA AI - Observer Engine (Phase 1)
 * Tracks behavior signals and generates telemetry snapshots.
 */
(function attachObserverEngine(global) {
  const FIVE_MINUTES = 5 * 60 * 1000;
  const INACTIVITY_TIMEOUT = 60 * 1000;

  const state = {
    sessionStartMs: Date.now(),
    lastActivityMs: Date.now(),
    inactivityMs: 0,
    inactivityStartMs: null,
    tabSwitches: 0,
    focusModeStartMs: null,
    focusModeMs: 0,
    studyActiveStartMs: Date.now(),
    studyDurationMs: 0,
    tasksCompleted: 0,
    tasksObserved: 0
  };

  function now() {
    return Date.now();
  }

  function isFocusModeActive() {
    return document.body.classList.contains('ghost-active');
  }

  function registerActivity() {
    const t = now();
    if (state.inactivityStartMs) {
      state.inactivityMs += Math.max(0, t - state.inactivityStartMs);
      state.inactivityStartMs = null;
    }
    state.lastActivityMs = t;
  }

  function updateInactivity() {
    const t = now();
    const idleFor = t - state.lastActivityMs;
    if (idleFor >= INACTIVITY_TIMEOUT && !state.inactivityStartMs) {
      state.inactivityStartMs = t;
    }
  }

  function updateFocusModeDuration() {
    const t = now();
    if (isFocusModeActive()) {
      if (!state.focusModeStartMs) state.focusModeStartMs = t;
    } else if (state.focusModeStartMs) {
      state.focusModeMs += Math.max(0, t - state.focusModeStartMs);
      state.focusModeStartMs = null;
    }
  }

  function updateStudyDuration() {
    const t = now();
    if (document.visibilityState === 'visible' && !state.studyActiveStartMs) {
      state.studyActiveStartMs = t;
    }
    if (document.visibilityState !== 'visible' && state.studyActiveStartMs) {
      state.studyDurationMs += Math.max(0, t - state.studyActiveStartMs);
      state.studyActiveStartMs = null;
    }
  }

  function getLiveStudyDurationMs() {
    const t = now();
    return state.studyDurationMs + (state.studyActiveStartMs ? (t - state.studyActiveStartMs) : 0);
  }

  function getLiveFocusDurationMs() {
    const t = now();
    return state.focusModeMs + (state.focusModeStartMs ? (t - state.focusModeStartMs) : 0);
  }

  function deriveTelemetry() {
    updateInactivity();
    updateFocusModeDuration();
    updateStudyDuration();

    const totalSessionMs = Math.max(1, now() - state.sessionStartMs);
    const effectiveInactivity = state.inactivityMs + (state.inactivityStartMs ? (now() - state.inactivityStartMs) : 0);
    const activeRatio = Math.max(0, 1 - (effectiveInactivity / totalSessionMs));
    const focusRatio = Math.min(1, getLiveFocusDurationMs() / totalSessionMs);
    const completionRate = state.tasksObserved > 0 ? (state.tasksCompleted / state.tasksObserved) : 0;

    const focusLevel = Math.round(((activeRatio * 0.6) + (focusRatio * 0.4)) * 100);

    let disciplineState = 'stable';
    if (completionRate >= 0.7 && focusLevel >= 65) disciplineState = 'disciplined';
    else if (completionRate < 0.35 || focusLevel < 40) disciplineState = 'drifting';

    let riskLevel = 'low';
    if (state.tabSwitches >= 8 || focusLevel < 40) riskLevel = 'high';
    else if (state.tabSwitches >= 3 || focusLevel < 60) riskLevel = 'medium';

    const energyPattern = focusLevel >= 70 ? 'high-output' : focusLevel >= 45 ? 'steady' : 'fatigued';

    return {
      timestamp: new Date().toISOString(),
      focusLevel,
      disciplineState,
      riskLevel,
      energyPattern,
      metrics: {
        mouseInactivityMs: Math.round(effectiveInactivity),
        tabSwitches: state.tabSwitches,
        focusModeDurationMs: Math.round(getLiveFocusDurationMs()),
        studySessionDurationMs: Math.round(getLiveStudyDurationMs()),
        taskCompletionRate: Number(completionRate.toFixed(2))
      }
    };
  }

  function observeTaskCompletion() {
    // Safe delegated listener avoids touching existing task logic.
    document.addEventListener('click', (event) => {
      const checkbox = event.target.closest('.custom-check');
      if (!checkbox) return;

      // Delay lets existing click handlers update classList first.
      setTimeout(() => {
        state.tasksObserved += 1;
        if (checkbox.classList.contains('checked')) state.tasksCompleted += 1;
      }, 0);
    });
  }

  function startSnapshotTimer() {
    setInterval(() => {
      if (!global.TelemetryStore) return;
      const snapshot = deriveTelemetry();
      global.TelemetryStore.saveSnapshot(snapshot);
    }, FIVE_MINUTES);
  }

  const ObserverEngine = {
    init() {
      // Input activity signals for inactivity tracking.
      ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll'].forEach((evt) => {
        window.addEventListener(evt, registerActivity, { passive: true });
      });

      // Tab visibility switches are tracked as discipline risk signals.
      document.addEventListener('visibilitychange', () => {
        state.tabSwitches += 1;
        updateStudyDuration();
      });

      // Observe focus-mode class toggles without changing existing functions.
      const observer = new MutationObserver(updateFocusModeDuration);
      observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });

      observeTaskCompletion();
      startSnapshotTimer();

      // Prime first snapshot so dashboard can consume data immediately.
      if (global.TelemetryStore) {
        global.TelemetryStore.saveSnapshot(deriveTelemetry());
      }
    },

    getTelemetry() {
      return deriveTelemetry();
    }
  };

  global.ObserverEngine = ObserverEngine;

  // __SPA_MODE GUARD: In SPA mode, aestraRoute.js handles initialization.
  if (!window.__SPA_MODE) {
    document.addEventListener('DOMContentLoaded', () => {
      try {
        ObserverEngine.init();
        console.info('[ObserverEngine] Initialized.');
      } catch (error) {
        console.error('[ObserverEngine] Initialization failed:', error);
      }
    });
  }
})(window);
