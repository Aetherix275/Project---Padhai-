/**
 * AESTRA Core Coordination Layer
 * Updated with SafeStorage
 */

(function attachAestraCore(global) {
  const DEBUG_PREFIX = '[AESTRA Core]';
  const TICK_MS = 2500;

  function getBus() {
    return global.AESTRA_EVENT_BUS || null;
  }

  function ensureDeps() {
    return !!(global.AESTRA_EVENT_ROUTER_FACTORY && global.AESTRA_SYNC_MANAGER_FACTORY && global.AESTRA_SYSTEM_PRIORITY);
  }

  function channelFromEvent(eventName) {
    if (eventName === 'PRESSURE_STATE_UPDATED') return 'pressure';
    if (eventName === 'TACTICAL_PLAN_UPDATED') return 'tactical';
    if (eventName === 'NARRATIVE_UPDATED') return 'personality';
    if (eventName === 'MEMORY_UPDATED') return 'memory';
    if (eventName === 'STATE_CHANGED') return 'state';
    return 'observer';
  }

  function createCore() {
    const router = global.AESTRA_EVENT_ROUTER_FACTORY.createRouter();
    const sync = global.AESTRA_SYNC_MANAGER_FACTORY.createSyncManager();

    function applyEvent(eventName, payload) {
      const channel = channelFromEvent(eventName);
      if (channel === 'pressure') sync.unified.pressure = payload;
      if (channel === 'tactical') sync.unified.tactical = payload;
      if (channel === 'personality') sync.unified.narrative = payload;
      if (channel === 'memory') sync.unified.memory = payload;
      if (channel === 'state') sync.unified.state = payload;
      sync.markFresh(channel);
    }

    function preventContradictions() {
      const pressureLevel = sync.unified.pressure?.urgencyLevel;
      const narrative = sync.unified.narrative;
      if (!narrative) return;
      if (pressureLevel === 'CRITICAL' || pressureLevel === 'HIGH') {
        sync.unified.diagnostics.droppedNarratives += 1;
        sync.unified.health.contradictorySignalsBlocked += 1;
        sync.unified.narrative = {
          ...narrative,
          message: 'System priority override: pressure protocol active. Tactical compliance required.'
        };
      }
    }

    function synchronize() {
      const batch = router.drain();
      if (!batch.length) return;
      sync.onBatch(batch);
      batch.forEach(({ eventName, payload }) => applyEvent(eventName, payload));

      const candidates = [
        { channel: 'pressure', confidence: sync.unified.pressure?.intensity || 0, urgencyLevel: sync.unified.pressure?.urgencyLevel },
        { channel: 'tactical', confidence: sync.unified.tactical?.confidence || 0 },
        { channel: 'personality', confidence: sync.unified.narrative?.confidence || 0 }
      ].sort(global.AESTRA_SYSTEM_PRIORITY.comparePriority);

      sync.unified.diagnostics.arbitrationDecisions = candidates.map((c) => ({
        channel: c.channel,
        score: global.AESTRA_SYSTEM_PRIORITY.computePriority(c)
      }));

      preventContradictions();
      sync.unified.updatedAt = new Date().toISOString();

      if (sync.shouldEmit()) {
        getBus()?.emit?.('AESTRA_CORE_UPDATED', sync.unified);
        console.info(`${DEBUG_PREFIX} AESTRA_CORE_UPDATED`, sync.unified);
      }
    }

    return {
      route: router.route,
      synchronize,
      getUnifiedAestraState() {
        return sync.unified;
      }
    };
  }

  const AestraCore = {
    _core: null,
    init() {
      if (!ensureDeps()) {
        console.warn(`${DEBUG_PREFIX} Missing dependencies.`);
        return;
      }

      this._core = createCore();
      const bus = getBus();
      ['STATE_CHANGED', 'MEMORY_UPDATED', 'TACTICAL_PLAN_UPDATED', 'NARRATIVE_UPDATED', 'PRESSURE_STATE_UPDATED'].forEach((evt) => {
        bus?.on?.(evt, (payload) => this._core.route(evt, payload));
      });

      setInterval(() => this._core.synchronize(), TICK_MS);
      console.info(`${DEBUG_PREFIX} Initialized.`);
    },
    getUnifiedAestraState() {
      return this._core?.getUnifiedAestraState?.() || null;
    }
  };

  global.AestraCore = AestraCore;

  // __SPA_MODE GUARD: In SPA mode, aestraRoute.js handles initialization.
  // The DOMContentLoaded auto-init is disabled to prevent duplicate interval/listener setup.
  if (!window.__SPA_MODE) {
    document.addEventListener('DOMContentLoaded', () => {
      try {
        AestraCore.init();
      } catch (error) {
        console.error(`${DEBUG_PREFIX} Init failed`, error);
      }
    });
  }
})(window);