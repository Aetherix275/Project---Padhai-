/**
 * AESTRA AI - Telemetry Store
 * Updated with SafeStorage for multi-user support
 */

(function attachTelemetryStore(global) {
  const STORAGE_KEY = 'aestra_observer_snapshots_v1';
  const MAX_SNAPSHOTS = 288; // Keep last 24h if sampled every 5 min.

  function safeParse(raw) {
    if (!raw) return [];
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      console.warn('[TelemetryStore] Corrupt snapshot data, resetting.', error);
      return [];
    }
  }

  const TelemetryStore = {
    loadSnapshots() {
      return safeParse(SafeStorage.getItem(STORAGE_KEY));
    },

    saveSnapshot(snapshot) {
      const current = this.loadSnapshots();
      current.push(snapshot);

      // Bounded list prevents unbounded growth
      const trimmed = current.slice(-MAX_SNAPSHOTS);
      SafeStorage.setItem(STORAGE_KEY, trimmed);
      return trimmed;
    },

    latestSnapshot() {
      const current = this.loadSnapshots();
      return current.length ? current[current.length - 1] : null;
    },

    // Optional: Clear only current user's telemetry
    clearUserTelemetry() {
      SafeStorage.removeItem(STORAGE_KEY);
    }
  };

  global.TelemetryStore = TelemetryStore;
})(window);