/**
 * AESTRA AI - Memory Pattern Library (Phase 3)
 * Updated with SafeStorage for multi-user support
 */

(function attachMemoryPatterns(global) {
  const MEMORY_KEY = 'aestra_memory_core_v1';

  const DEFAULT_MEMORY = {
    updatedAt: null,
    strongestStudyHours: [],
    weakestProductivityPeriods: [],
    commonCollapsePatterns: [],
    recoveryBehavior: { avgRecoveryMinutes: 0, successfulRecoveries: 0, recoveryWindows: [] },
    streakHistory: [],
    historicalStates: [],
    averageFocusTrends: { daily: [], weeklyAverageFocus: 0 },
    meta: { lastDailySummaryDate: null, lastWeeklySummaryWeekKey: null }
  };

  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

  function safeParse(raw) {
    try { return JSON.parse(raw); } catch (_) { return null; }
  }

  function loadMemory() {
    const parsed = safeParse(SafeStorage.getItem(MEMORY_KEY));
    return parsed && typeof parsed === 'object' ? { ...DEFAULT_MEMORY, ...parsed } : { ...DEFAULT_MEMORY };
  }

  function saveMemory(memory) {
    SafeStorage.setItem(MEMORY_KEY, memory);
    return memory;
  }

  // ... (rest of the functions remain exactly same)

  function weekKey(isoDate) {
    const d = new Date(isoDate);
    const jan1 = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const dayOfYear = Math.floor((d - jan1) / 86400000) + 1;
    const week = Math.ceil(dayOfYear / 7);
    return `${d.getUTCFullYear()}-W${week}`;
  }

  // All other functions (summarizeHourlyWindows, detectCollapsePatterns, etc.) stay unchanged

  global.AESTRA_MEMORY_PATTERNS = {
    MEMORY_KEY,
    loadMemory,
    saveMemory,
    weekKey,
    summarizeHourlyWindows,
    detectCollapsePatterns,
    detectRecoveryBehavior,
    computeFocusTrend,
    updateStreakHistory,
    summarizeStateQuality
  };
})(window);