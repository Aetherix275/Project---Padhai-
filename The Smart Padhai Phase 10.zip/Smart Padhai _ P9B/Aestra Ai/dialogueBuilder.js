/**
 * AESTRA AI - Dialogue Builder
 * Updated with SafeStorage for multi-user support
 */

(function attachDialogueBuilder(global) {
  const HISTORY_KEY = 'aestra_narrative_history_v1';
  const MAX_HISTORY = 25;

  function loadHistory() {
    return SafeStorage.getItem(HISTORY_KEY, []);
  }

  function saveHistory(lines) {
    SafeStorage.setItem(HISTORY_KEY, lines.slice(-MAX_HISTORY));
  }

  function fill(template, vars) {
    return template.replace(/\{(\w+)\}/g, (_, key) => (vars[key] ?? 'unknown'));
  }

  function pickLine(candidates, history) {
    const fresh = candidates.filter((line) => !history.includes(line));
    const pool = fresh.length ? fresh : candidates;
    return pool[Math.floor(Math.random() * pool.length)];
  }

  function buildNarrativeLines(context, tone) {
    const templates = global.AESTRA_NARRATIVE_TEMPLATES;
    if (!templates) return [];

    const history = loadHistory();
    const vars = {
      focusLevel: context.telemetry?.focusLevel ?? 0,
      riskLevel: context.telemetry?.riskLevel ?? 'low',
      energyPattern: context.telemetry?.energyPattern ?? 'steady',
      completionRate: Math.round((context.telemetry?.metrics?.taskCompletionRate || 0) * 100),
      state: context.state || 'UNKNOWN',
      stateConfidence: context.stateConfidence ?? 0,
      tacticalConfidence: context.tactical?.confidence ?? 0,
      primaryAction: context.tactical?.recommendations?.[0] || 'stabilize execution',
      stackedActions: (context.tactical?.recommendations || []).slice(0, 3).join(', ') || 'stabilize, prioritize, execute',
      backlogSize: context.tactical?.meta?.backlogSize ?? 0,
      upcomingDeadlines: context.tactical?.meta?.upcomingDeadlines ?? 0
    };

    const blocks = ['observation', 'tactical', 'briefing'];
    if (tone === 'Brutal' || tone === 'Cold' || tone === 'Elite') blocks.push('pressure');
    if (tone === 'Recovery' || context.state === 'REBORN') blocks.push('recovery');

    const lines = blocks.map((block) => {
      const lineTemplate = pickLine(templates[block], history);
      return fill(lineTemplate, vars);
    });

    saveHistory(history.concat(lines));
    return lines;
  }

  global.AESTRA_DIALOGUE_BUILDER = { buildNarrativeLines };
})(window);