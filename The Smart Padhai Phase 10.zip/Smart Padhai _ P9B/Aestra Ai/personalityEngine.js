/**
 * AESTRA AI - Personality Engine (Phase 5)
 *
 * Adaptive tactical OS narration layer.
 * Not a chatbot: produces contextual system narration from behavior intelligence.
 */
(function attachPersonalityEngine(global) {
  const DEBUG_PREFIX = '[AESTRA PersonalityEngine]';

  function getBus() {
    return global.AESTRA_EVENT_BUS || null;
  }

  function selectTone(context) {
    // Tone switching logic:
    // weighted by risk + state + tactical confidence to avoid random narration mood.
    const risk = context.telemetry?.riskLevel;
    const state = context.state;
    const confidence = context.tactical?.confidence || 0;

    if (state === 'COLLAPSING' || context.detections?.collapseDetected) return 'Recovery';
    if (state === 'OVERDRIVE' && confidence >= 70) return 'Elite';
    if (risk === 'high' && confidence >= 65) return 'Brutal';
    if (risk === 'high') return 'Cold';
    if (state === 'LOCKED_IN') return 'Tactical';
    if (state === 'REBORN') return 'Mentor';
    return 'Tactical';
  }

  function computeNarrativeConfidence(context) {
    const s = context.stateConfidence || 0;
    const t = context.tactical?.confidence || 0;
    const telemetryStrength = Math.min(100, Math.max(0, Number(context.telemetry?.focusLevel || 0)));
    return Math.round((s * 0.35) + (t * 0.45) + (telemetryStrength * 0.20));
  }

  function gatherContext() {
    const telemetry = global.TelemetryStore?.latestSnapshot?.() || null;
    const tactical = global.TacticalEngine?.generateTacticalPlan?.() || null;
    const state = global.StateEngine?.getCurrentState?.() || null;
    const recoveryProfile = global.MemoryCore?.getRecoveryProfile?.() || {};
    const weaknessProfile = global.MemoryCore?.getWeaknessProfile?.() || {};

    const recentState = (recoveryProfile.historicalStates || []).slice(-1)[0] || {};
    return {
      telemetry,
      tactical,
      state,
      stateConfidence: recentState.confidence || 0,
      detections: {
        collapseDetected: (weaknessProfile.commonCollapsePatterns || []).length >= 5
      }
    };
  }

  function generateNarrative() {
    if (!global.AESTRA_DIALOGUE_BUILDER || !global.AESTRA_TONE_PROFILES) return null;

    const context = gatherContext();
    if (!context.telemetry || !context.tactical) {
      console.debug(`${DEBUG_PREFIX} Missing telemetry/tactical context; narrative skipped.`);
      return null;
    }

    const tone = selectTone(context);
    const toneProfile = global.AESTRA_TONE_PROFILES[tone];
    const lines = global.AESTRA_DIALOGUE_BUILDER.buildNarrativeLines(context, tone);
    const confidence = computeNarrativeConfidence(context);

    const narrativeData = {
      generatedAt: new Date().toISOString(),
      tone,
      toneProfile,
      confidence,
      context: {
        state: context.state,
        riskLevel: context.telemetry.riskLevel,
        tacticalConfidence: context.tactical.confidence
      },
      lines,
      message: lines.join(' ')
    };

    getBus()?.emit?.('NARRATIVE_UPDATED', narrativeData);
    console.info(`${DEBUG_PREFIX} NARRATIVE_UPDATED`, narrativeData);
    return narrativeData;
  }

  const PersonalityEngine = {
    init() {
      getBus()?.on?.('TACTICAL_PLAN_UPDATED', () => generateNarrative());
      getBus()?.on?.('MEMORY_UPDATED', () => generateNarrative());
      getBus()?.on?.('STATE_CHANGED', () => generateNarrative());
      generateNarrative();
      console.info(`${DEBUG_PREFIX} Initialized.`);
    },
    generateNarrative
  };

  global.PersonalityEngine = PersonalityEngine;
  // __SPA_MODE GUARD: In SPA mode, aestraRoute.js handles initialization.
  if (!window.__SPA_MODE) {
    document.addEventListener('DOMContentLoaded', () => {
      try {
        PersonalityEngine.init();
      } catch (error) {
        console.error(`${DEBUG_PREFIX} Init failed`, error);
      }
    });
  }
})(window);
