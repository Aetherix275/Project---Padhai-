-- ═══════════════════════════════════════════════════════════════
-- Smart Padhai — productivity_snapshots Table + RLS
-- Phase 5B: Productivity Graph Upgrade
-- ═══════════════════════════════════════════════════════════════
--
-- Run this in the Supabase SQL Editor (one-time setup)
--

-- 1. Create the table
CREATE TABLE IF NOT EXISTS productivity_snapshots (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id             uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    snapshot_date       date NOT NULL,
    pp_earned           integer DEFAULT 0,
    backlogs_cleared    integer DEFAULT 0,
    sessions_completed  integer DEFAULT 0,
    focus_minutes       integer DEFAULT 0,
    consistency_score   integer DEFAULT 0,
    created_at          timestamptz DEFAULT now(),
    updated_at          timestamptz DEFAULT now(),

    -- Unique constraint: one snapshot per user per day
    CONSTRAINT uq_user_snapshot_date UNIQUE (user_id, snapshot_date)
);

-- 2. Enable Row Level Security
ALTER TABLE productivity_snapshots ENABLE ROW LEVEL SECURITY;

-- 3. RLS Policies: Users can only access their own snapshots
CREATE POLICY "Users can read own productivity snapshots"
    ON productivity_snapshots
    FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own productivity snapshots"
    ON productivity_snapshots
    FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own productivity snapshots"
    ON productivity_snapshots
    FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own productivity snapshots"
    ON productivity_snapshots
    FOR DELETE
    USING (auth.uid() = user_id);

-- 4. Index for fast queries by user and date (descending for recent-first)
CREATE INDEX IF NOT EXISTS idx_productivity_snapshots_user_date
    ON productivity_snapshots (user_id, snapshot_date DESC);

-- 5. Grant anon key access (required for REST API calls with anon key)
-- The RLS policies above ensure data isolation even with anon access
GRANT ALL ON productivity_snapshots TO anon;
GRANT ALL ON productivity_snapshots TO authenticated;

-- ═══════════════════════════════════════════════════════════════
-- Verification (run after creation):
--
-- SELECT * FROM productivity_snapshots LIMIT 5;
-- Should return empty or your own rows only
-- ═══════════════════════════════════════════════════════════════
