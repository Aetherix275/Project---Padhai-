-- ═══════════════════════════════════════════════════════════════
-- Smart Padhai — focus_sessions Table + RLS
-- Phase 5A: Custom Dashboard Timer
-- ═══════════════════════════════════════════════════════════════
--
-- Run this in the Supabase SQL Editor (one-time setup)
--

-- 1. Create the table
CREATE TABLE IF NOT EXISTS focus_sessions (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    session_date    date NOT NULL,
    duration_minutes integer NOT NULL,
    label           varchar(30) DEFAULT 'Other',
    completed       boolean DEFAULT false,
    pp_earned       integer DEFAULT 0,
    started_at      timestamptz DEFAULT now(),
    completed_at    timestamptz
);

-- 2. Enable Row Level Security
ALTER TABLE focus_sessions ENABLE ROW LEVEL SECURITY;

-- 3. RLS Policy: Users can only read/write their own sessions
CREATE POLICY "Users can read own focus sessions"
    ON focus_sessions
    FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own focus sessions"
    ON focus_sessions
    FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own focus sessions"
    ON focus_sessions
    FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own focus sessions"
    ON focus_sessions
    FOR DELETE
    USING (auth.uid() = user_id);

-- 4. Index for fast queries by user and date (descending for recent-first)
CREATE INDEX IF NOT EXISTS idx_focus_sessions_user_date
    ON focus_sessions (user_id, session_date DESC);

-- 5. Grant anon key access (required for REST API calls with anon key)
-- The RLS policies above ensure data isolation even with anon access
GRANT ALL ON focus_sessions TO anon;
GRANT ALL ON focus_sessions TO authenticated;

-- ═══════════════════════════════════════════════════════════════
-- Verification (run after creation):
--
-- SELECT * FROM focus_sessions LIMIT 5;
-- Should return empty or your own rows only
-- ═══════════════════════════════════════════════════════════════
