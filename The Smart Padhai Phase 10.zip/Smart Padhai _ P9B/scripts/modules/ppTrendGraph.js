/**
 * ═══════════════════════════════════════════════════════
 * SMART PADHAI — PP TREND GRAPH MODULE
 * Inline SVG only. No external libraries. No Canvas.
 * ═══════════════════════════════════════════════════════
 */

const PPTrendGraph = (() => {
  let _container = null;
  let _abortController = null;
  let _tooltipEl = null;

  // ── Helpers ──
  function _getLocalDateKey(date) {
    const d = date || new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  function _getPPLogsSafe() {
    try {
      const raw = typeof SafeStorage !== 'undefined' 
        ? SafeStorage.getItem('smart_padhai_pp_logs', []) 
        : JSON.parse(localStorage.getItem('smart_padhai_pp_logs') || '[]');
      return Array.isArray(raw) ? raw : [];
    } catch (e) {
      return [];
    }
  }

  function _buildDailyTrend(rangeDays) {
    const logs = _getPPLogsSafe();
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const trendData = [];
    for (let i = rangeDays - 1; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      trendData.push({
        dateKey: _getLocalDateKey(d),
        displayDate: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        netPP: 0,
        positivePP: 0,
        negativePP: 0,
        actions: 0
      });
    }

    const dateMap = new Map(trendData.map(d => [d.dateKey, d]));

    for (const log of logs) {
      if (!log) continue;
      const logDateStr = log.date || (log.createdAt ? new Date(log.createdAt).toISOString().split('T')[0] : null);
      if (!logDateStr) continue;

      const entry = dateMap.get(logDateStr);
      if (entry) {
        const pts = Number(log.points) || 0;
        entry.netPP += pts;
        if (pts > 0) entry.positivePP += pts;
        if (pts < 0) entry.negativePP += Math.abs(pts);
        entry.actions += 1;
      }
    }

    return trendData;
  }

  function _getTrendStats(trendData) {
    let totalNet = 0;
    let best = -Infinity;
    let worst = Infinity;
    let activeDays = 0;

    for (const d of trendData) {
      totalNet += d.netPP;
      if (d.netPP > best) best = d.netPP;
      if (d.netPP < worst) worst = d.netPP;
      if (d.actions > 0) activeDays++;
    }

    const avg = activeDays > 0 ? Math.round((totalNet / activeDays) * 10) / 10 : 0;

    return {
      total: totalNet,
      avg: avg,
      best: best === -Infinity ? 0 : best,
      worst: worst === Infinity ? 0 : worst,
      activeDays
    };
  }

  function _generateInsight(stats, trendData) {
    if (stats.activeDays < 2) return "First data points tracked. Keep building.";
    
    const allPositive = trendData.filter(d => d.actions > 0).every(d => d.netPP >= 0);
    if (allPositive && stats.activeDays > 0) return "Perfect run. Every tracked day stayed positive.";

    const len = trendData.length;
    if (len >= 6) {
      const last3 = trendData.slice(-3).reduce((sum, d) => sum + d.netPP, 0);
      const prev3 = trendData.slice(-6, -3).reduce((sum, d) => sum + d.netPP, 0);
      if (last3 > prev3) return "Trending up. Momentum is improving.";
      if (last3 < prev3) return "Trending down. Repair the rhythm today.";
    }

    if (stats.total < 0) return "Tough stretch. Start with one recovery task.";
    
    return "Holding steady. Keep the chain alive.";
  }

  function _renderSVG(trendData, width = 640, height = 260) {
    const margin = { top: 24, right: 20, bottom: 36, left: 40 };
    const graphW = width - margin.left - margin.right;
    const graphH = height - margin.top - margin.bottom;

    const netValues = trendData.map(d => d.netPP);
    // FIX 2: Correct spread syntax
    const minVal = Math.min(0, Math.min(...netValues));
    const maxVal = Math.max(10, Math.max(...netValues));
    const range = maxVal - minVal || 1;

    const getX = (i) => margin.left + (i / (trendData.length - 1 || 1)) * graphW;
    const getY = (val) => margin.top + graphH - ((val - minVal) / range) * graphH;

    let gridLines = '';
    const steps = 4;
    for (let i = 0; i <= steps; i++) {
      const val = minVal + (range * (i / steps));
      const y = getY(val);
      gridLines += `<line x1="${margin.left}" y1="${y}" x2="${width - margin.right}" y2="${y}" class="pp-trend-grid-line" />`;
      gridLines += `<text x="${margin.left - 8}" y="${y + 4}" class="pp-trend-y-label" text-anchor="end">${Math.round(val)}</text>`;
    }

    const zeroY = getY(0);
    const zeroLine = `<line x1="${margin.left}" y1="${zeroY}" x2="${width - margin.right}" y2="${zeroY}" class="pp-trend-zero-line" stroke-dasharray="4 4" />`;

    let pathD = "";
    let pointsHTML = "";
    let hitboxesHTML = "";

    trendData.forEach((d, i) => {
      const x = getX(i);
      const y = getY(d.netPP);
      if (i === 0) pathD += `M ${x} ${y}`;
      else pathD += ` L ${x} ${y}`;

      const pointClass = d.netPP > 0 ? 'positive' : (d.netPP < 0 ? 'negative' : 'zero');
      
      pointsHTML += `<circle cx="${x}" cy="${y}" r="3" class="pp-trend-point ${pointClass}" />`;
      hitboxesHTML += `<circle cx="${x}" cy="${y}" r="12" class="pp-trend-hitbox" data-index="${i}" />`;
    });

    let xLabels = "";
    const step = Math.ceil(trendData.length / 7);
    trendData.forEach((d, i) => {
      if (i % step === 0 || i === trendData.length - 1) {
        xLabels += `<text x="${getX(i)}" y="${height - 8}" class="pp-trend-x-label" text-anchor="middle">${d.displayDate}</text>`;
      }
    });

    return {
      svgContent: `
        <svg viewBox="0 0 ${width} ${height}" class="pp-trend-svg" preserveAspectRatio="xMidYMid meet">
          <defs>
            <filter id="glow-green" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
            <filter id="glow-red" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>
          ${gridLines}
          ${zeroLine}
          <path d="${pathD}" class="pp-trend-path" fill="none" stroke-linejoin="round" stroke-linecap="round" />
          ${pointsHTML}
          ${hitboxesHTML}
          ${xLabels}
        </svg>
      `,
      zeroY,
      margin
    };
  }

  function _showTooltip(e, trendData, margin) {
    if (!_tooltipEl) return;
    const idx = parseInt(e.target.dataset.index, 10);
    const d = trendData[idx];
    if (!d) return;

    const netSign = d.netPP >= 0 ? '+' : '';
    const posSign = d.positivePP > 0 ? '+' : '';
    const negSign = d.negativePP > 0 ? '-' : '';

    _tooltipEl.innerHTML = `
      <div class="pp-tooltip-date">${d.displayDate}</div>
      <div class="pp-tooltip-row">
        <span class="pp-tooltip-label">Net:</span>
        <span class="pp-tooltip-value ${d.netPP >= 0 ? 'pos' : 'neg'}">${netSign}${d.netPP} PP</span>
      </div>
      <div class="pp-tooltip-row">
        <span class="pp-tooltip-label">Earned:</span>
        <span class="pp-tooltip-value pos">${posSign}${d.positivePP}</span>
      </div>
      <div class="pp-tooltip-row">
        <span class="pp-tooltip-label">Lost:</span>
        <span class="pp-tooltip-value neg">${negSign}${d.negativePP}</span>
      </div>
      <div class="pp-tooltip-row">
        <span class="pp-tooltip-label">Actions:</span>
        <span class="pp-tooltip-value">${d.actions}</span>
      </div>
    `;

    const rect = e.target.getBoundingClientRect();
    const containerRect = _container.getBoundingClientRect();
    
    let left = rect.left - containerRect.left + (rect.width / 2);
    let top = rect.top - containerRect.top - 10;

    const tooltipWidth = 140;
    if (left + tooltipWidth > containerRect.width) left = containerRect.width - tooltipWidth - 8;
    if (left < 8) left = 8;
    if (top < 8) top = rect.bottom - containerRect.top + 8;

    _tooltipEl.style.left = `${left}px`;
    _tooltipEl.style.top = `${top}px`;
    _tooltipEl.style.display = 'block';
  }

  function _hideTooltip() {
    if (_tooltipEl) _tooltipEl.style.display = 'none';
  }

  function render(container, options = {}) {
    if (!container) return;
    _container = container;
    
    if (_abortController) _abortController.abort();
    _abortController = new AbortController();
    const signal = _abortController.signal;

    const storedRange = typeof SafeStorage !== 'undefined' 
      ? SafeStorage.getItem('smart_padhai_pp_trend_range', 7) 
      : 7;
    const rangeDays = [7, 14, 30].includes(Number(storedRange)) ? Number(storedRange) : 7;

    const trendData = _buildDailyTrend(rangeDays);
    const stats = _getTrendStats(trendData);
    const activeDaysWithLogs = trendData.filter(d => d.actions > 0).length;

    if (activeDaysWithLogs < 2) {
      container.innerHTML = `
        <div class="pp-trend-empty">
          <div class="pp-trend-empty-icon">📊</div>
          <div class="pp-trend-empty-title">No PP data yet</div>
          <div class="pp-trend-empty-sub">Complete tasks and earn PP to see your trend.</div>
        </div>
      `;
      return;
    }

    const insight = _generateInsight(stats, trendData);
    const { svgContent } = _renderSVG(trendData);

    const formatStat = (val) => {
      if (val > 0) return `<span class="pos">+${val}</span>`;
      if (val < 0) return `<span class="neg">${val}</span>`;
      return `<span class="zero">0</span>`;
    };

    container.innerHTML = `
      <div class="pp-trend-header">
        <div class="pp-trend-title">PP Earned Trend</div>
        <div class="pp-trend-controls">
          <button type="button" class="pp-trend-btn ${rangeDays === 7 ? 'active' : ''}" data-range="7">7D</button>
          <button type="button" class="pp-trend-btn ${rangeDays === 14 ? 'active' : ''}" data-range="14">14D</button>
          <button type="button" class="pp-trend-btn ${rangeDays === 30 ? 'active' : ''}" data-range="30">30D</button>
        </div>
      </div>
      
      <div class="pp-trend-svg-wrap">
        ${svgContent}
        <div class="pp-trend-tooltip" id="ppTrendTooltip"></div>
      </div>

      <div class="pp-trend-stats">
        <div class="pp-trend-stat">
          <div class="pp-trend-stat-value">${formatStat(stats.avg)}</div>
          <div class="pp-trend-stat-label">Average</div>
        </div>
        <div class="pp-trend-stat">
          <div class="pp-trend-stat-value">${formatStat(stats.best)}</div>
          <div class="pp-trend-stat-label">Best Day</div>
        </div>
        <div class="pp-trend-stat">
          <div class="pp-trend-stat-value">${formatStat(stats.total)}</div>
          <div class="pp-trend-stat-label">Total Net</div>
        </div>
        <div class="pp-trend-stat">
          <div class="pp-trend-stat-value">${stats.activeDays}</div>
          <div class="pp-trend-stat-label">Active Days</div>
        </div>
      </div>

      <div class="pp-trend-footer">
        <span class="pp-trend-insight">💡 ${insight}</span>
      </div>
    `;

    _tooltipEl = container.querySelector('#ppTrendTooltip');

    container.querySelectorAll('.pp-trend-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const newRange = parseInt(e.target.dataset.range, 10);
        if (typeof SafeStorage !== 'undefined') {
          SafeStorage.setItem('smart_padhai_pp_trend_range', newRange);
        }
        render(container, options);
      }, { signal });
    });

    container.querySelectorAll('.pp-trend-hitbox').forEach(hitbox => {
      hitbox.addEventListener('mouseenter', (e) => _showTooltip(e, trendData), { signal });
      hitbox.addEventListener('mouseleave', _hideTooltip, { signal });
      hitbox.addEventListener('touchstart', (e) => {
        e.preventDefault();
        _showTooltip(e, trendData);
      }, { signal });
    });

    container.addEventListener('mouseleave', _hideTooltip, { signal });
  }

  function destroy() {
    if (_abortController) {
      _abortController.abort();
      _abortController = null;
    }
    _container = null;
    _tooltipEl = null;
  }

  window.PPTrendGraph = {
    render,
    destroy,
    getPPLogsSafe: _getPPLogsSafe,
    buildDailyTrend: _buildDailyTrend,
    getTrendStats: _getTrendStats
  };

  return window.PPTrendGraph;
})();