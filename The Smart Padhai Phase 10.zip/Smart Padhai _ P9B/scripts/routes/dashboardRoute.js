/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — DASHBOARD ROUTE MODULE (Phase 9 Syllabus Progress Circle Real Sync)
 *  The heart of the app: PulseEngine card, stat circles, badges,
 *  quote, action hint, panic protocol, GraphEngine, TimerEngine,
 *  ghost mode, cookie jar, rank modal, Weekly Reality Mirror.
 * ═══════════════════════════════════════════════════════════════════
 *
 *  CRITICAL CONSTRAINTS:
 *    1. Do NOT call loadPulseEngineFromSupabase() here
 *    2. Do NOT call initPulseEngineAfterAuth() here
 *    3. Only call PulseEngine.updateUI() — app-init.js inits once
 *    4. If PulseEngine.hasLoadedFromSupabase is false → loading state
 *    5. PP must NEVER reset to 500/490/default
 *    6. Use SafeStorage for all data reads (auto user_{id}_ prefix)
 *    7. Backlog: started = read||notes||pyq, completed = read&&notes&&pyq
 *       realBacklog = started && !completed. Only count read/notes/pyq.
 *    8. All events use data-action + delegation + AbortController
 *    9. No inline onclick handlers
 *   10. CSS loaded dynamically on init, unloaded on cleanup
 *
 *  Phase 9A Sprint 3B: Weekly Reality Mirror Upgrade
 *    - Upgraded from basic Weekly Report Card to Weekly Reality Mirror
 *    - Multi-source data: time_blocks_v1, productivity_snapshots_log,
 *      pulse_engine_data, smartPadhaiData, notebook_matrix_data,
 *      syllabus_master_tracker, badge_progress_v2
 *    - Weekly Reality Score out of 10 (weighted formula)
 *    - Compact top summary: "Weekly Reality: 6.8/10 — Stable but inconsistent"
 *    - Expanded mirror panel: score, blocks, minutes, missed, backlog,
 *      notebook, syllabus, best day, weakest day, insight, next week target
 *    - 7-day mini graph with color-coded dots (Mon-Sun)
 *    - Reality Verdict: one honest sentence about the week
 *    - Next Week Target: practical, actionable goal
 *    - Data honesty: no lifetime PP as weekly PP, honest fallbacks
 *    - Derived-only from SafeStorage. No Supabase writes.
 *    - No external chart libraries.
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear timers
 * ═══════════════════════════════════════════════════════════════════
 */

const DashboardRoute = (() => {

    // ── Private state ──
    let _container = null;
    let _abortController = null;
    let _cssLinkEl = null;
    let _panicInterval = null;
    let _neuralLinesTimeout = null;  // Kept for cleanup safety; no longer used
    let _graphInitialized = false;
    let _reviewFormState = { focusQuality: null, difficulty: null, mood: null };
    let _activeSessionReviewContext = null;
    let _selectedHeatmapRange = 30;
    let _streakEventHandler = null;
    let _isRenderingHeatmap = false;
    let _comebackEventHandler = null;
    let _directiveEventHandlers = [];
    let _examScopeModalState = { subject: null, examDate: '', selectedIds: new Set(), warning: '' };

    // ── Dashboard Clarity & Compact Mode state ──
    let _dashboardViewMode = 'full';       // 'full' or 'compact'
    let _collapsedSections = {};            // { sectionId: true/false }
    let _compactInitialized = false;        // Whether compact mode has auto-collapsed once

    // ── Dashboard Clarity Constants (defined early for init access) ──
    const VIEW_MODE_KEY = 'smart_padhai_dashboard_view_mode';
    const COLLAPSED_KEY = 'smart_padhai_dashboard_collapsed_sections';
    const COMPACT_INIT_KEY = 'smart_padhai_dashboard_compact_initialized';

    const COLLAPSIBLE_SECTIONS = [
        'weeklyPPGoal',
        'weeklyRealityMirror',
        'sessionInsights',
        'weeklyInsights',
        'optimalStudyWindow',
        'streakHeatmap',
        'comebackCard',
        'studyAutopsy',
        'graphSection'
    ];

    const CSS_PATH = './styles/modules/dashboard.css';
    const PANIC_V2_SCRIPT_PATH = './scripts/modules/panicProtocolV2.js';
    const PANIC_BATTLE_OPEN_KEY = 'smart_padhai_panic_battle_plan_open';
    const PANIC_TIMELINE_OPEN_KEY = 'smart_padhai_panic_timeline_open';
    const PANIC_ADAPTIVE_OPEN_KEY = 'smart_padhai_panic_adaptive_plan_open';
    let _panicV2LoadPromise = null;
    let _currentPanicV2Plan = null;

    // ── Constants ──
    const MASTER_KEY = 'smartPadhaiData';
    const NOTEBOOK_KEY = 'notebook_matrix_data';
    const PULSE_KEY = 'pulse_engine_data';
    const TIME_BLOCKS_KEY = 'time_blocks_v1';

    const TECHNIQUE_ICON_MAP = {
        'Pareto Warrior': '🎯',
        'Mind Mapper': '🧠',
        'Repetition Master': '🔁',
        'Recall Hunter': '🧩',
        'Focus Crusader': '⚡',
        'Feynman Adept': '🎓',
        'Deep Worker': '🌊',
        'Paper Strategist': '📝'
    };

    const TECHNIQUE_ICON_MAP_NORMALIZED = Object.keys(TECHNIQUE_ICON_MAP).reduce((map, name) => {
        map[name.trim().toLowerCase()] = TECHNIQUE_ICON_MAP[name];
        return map;
    }, {});

    /**
     * LEGACY: Get today's daily earned PP from PulseEngine.
     * Used only as a last-resort fallback by _getDirectiveTodayPP().
     * DO NOT use this for the Pulse Score Circle — use _getTodayNetPP() instead.
     */
    function _getTodayDailyEarnedPP() {
        const pulse = window.PulseEngine?.data || {};
        const local = SafeStorage.getItem(PULSE_KEY, {}) || {};

        const candidates = [
            pulse.dailyEarnedPP,
            pulse.dailyEarned,
            pulse.daily_earned_pp,
            local.dailyEarnedPP,
            local.dailyEarned,
            local.daily_earned_pp
        ]
            .map(v => Number(v))
            .filter(v => Number.isFinite(v) && v >= 0);

        return candidates.length ? Math.max(...candidates) : 0;
    }

    /**
     * FIX 1: Date-safe today key using LOCAL time (not UTC).
     * Ensures day reset matches the student's local day boundary.
     */
    function _getLocalDateKey(date) {
        const d = date || new Date();
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
    }

    /**
     * FIX 1: Get PP logs safely from SafeStorage.
     * Returns an array of log entries with { date, points, source, type, ... }.
     */
    function _getPPLogsForDateSafe() {
        try {
            // Prefer PPLogSystem if available (it has proper date filtering)
            if (typeof PPLogSystem !== 'undefined' && PPLogSystem.getLogs) {
                const logs = PPLogSystem.getLogs();
                if (Array.isArray(logs) && logs.length > 0) return logs;
            }
            if (typeof PPLogSystem !== 'undefined' && PPLogSystem.getAllLogs) {
                const logs = PPLogSystem.getAllLogs();
                if (Array.isArray(logs) && logs.length > 0) return logs;
            }
        } catch (e) { /* fallback */ }

        try {
            const raw = SafeStorage.getItem('smart_padhai_pp_logs', []);
            if (Array.isArray(raw)) return raw;
        } catch (e) { /* fallback */ }

        return [];
    }

    function _getPPLogDateKeySafe(log) {
        if (!log) return '';
        const rawDate = log.date || log.createdAt || log.created_at || log.timestamp || log.completed_at;
        if (!rawDate) return '';
        const rawString = String(rawDate);
        if (rawString.includes('T')) {
            const parsed = new Date(rawString);
            if (isNaN(parsed.getTime())) return rawString.slice(0, 10);
            return _getLocalDateKey(parsed);
        }
        return rawString.slice(0, 10);
    }

    function _getPPLogPointsSafe(log) {
        if (!log) return 0;
        const candidates = [log.points, log.ppChange, log.pp_change, log.amount, log.value];
        for (const candidate of candidates) {
            const points = Number(candidate);
            if (Number.isFinite(points)) return points;
        }
        return 0;
    }

    function _getCurrentWeekBounds() {
        const now = new Date();
        const dayOfWeek = now.getDay(); // 0=Sun, 1=Mon, ...
        const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
        const start = new Date(now);
        start.setDate(now.getDate() + mondayOffset);
        start.setHours(0, 0, 0, 0);

        const end = new Date(start);
        end.setDate(start.getDate() + 6);
        end.setHours(23, 59, 59, 999);

        return { start, end };
    }

    function _getWeeklyNetPPSafe() {
        const { start, end } = _getCurrentWeekBounds();
        return _getNetPPBetweenDatesSafe(start, end);
    }

    /**
     * FIX 1: Calculate today's NET PP from PP logs.
     * Positive + negative logs summed = true net PP for today.
     * Automatically resets each day because it filters by today's date.
     */
    function _getTodayNetPP() {
        const today = _getLocalDateKey();
        const logs = _getPPLogsForDateSafe();

        return logs
            .filter(log => _getPPLogDateKeySafe(log) === today)
            .reduce((sum, log) => sum + _getPPLogPointsSafe(log), 0);
    }

    /**
     * FIX 5: Calculate yesterday's NET PP from PP logs.
     * Used for today vs yesterday comparison.
     */
    function _getYesterdayNetPP() {
        const d = new Date();
        d.setDate(d.getDate() - 1);
        const yesterday = _getLocalDateKey(d);
        const logs = _getPPLogsForDateSafe();

        return logs
            .filter(log => _getPPLogDateKeySafe(log) === yesterday)
            .reduce((sum, log) => sum + _getPPLogPointsSafe(log), 0);
    }

    /**
     * PP Circle Net Reality Patch: Get today's PP breakdown.
     * Returns { earned, lost, net, actionCount } for hover/tooltip display.
     */
    function _getTodayPPBreakdownSafe() {
        try {
            const today = _getLocalDateKey();
            const logs = _getPPLogsForDateSafe();
            let earned = 0, lost = 0, actionCount = 0;

            logs.forEach(log => {
                if (!log || _getPPLogDateKeySafe(log) !== today) return;

                const points = _getPPLogPointsSafe(log);
                if (!Number.isFinite(points)) return;
                actionCount++;
                if (points >= 0) {
                    earned += points;
                } else {
                    lost += Math.abs(points);
                }
            });

            return { earned, lost, net: earned - lost, actionCount };
        } catch (err) {
            return { earned: 0, lost: 0, net: 0, actionCount: 0 };
        }
    }

    /**
     * Productivity Analytics Net PP Patch: Get net PP between two dates (inclusive).
     * Reads smart_padhai_pp_logs and sums all points (positive + negative)
     * for each log entry whose date falls within [startDate, endDate].
     * @param {Date} startDate - Start of range (local date)
     * @param {Date} endDate   - End of range (local date, inclusive)
     * @returns {number} Net PP for the date range
     */
    function _getNetPPBetweenDatesSafe(startDate, endDate) {
        try {
            const logs = _getPPLogsForDateSafe();
            const startKey = _getLocalDateKey(startDate);
            const endKey = _getLocalDateKey(endDate);

            return logs.reduce((sum, log) => {
                if (!log) return sum;
                const logDateKey = _getPPLogDateKeySafe(log);
                if (!logDateKey || logDateKey < startKey || logDateKey > endKey) return sum;

                return sum + _getPPLogPointsSafe(log);
            }, 0);
        } catch (err) {
            console.warn('[Dashboard] Net PP date range calculation failed:', err);
            return 0;
        }
    }

    /**
     * Productivity Analytics Net PP Patch: Override GraphEngine PP values
     * in the Productivity Analytics cards with true net PP from logs.
     *
     * GraphEngine.getPPEarnedForDate() uses dailyEarnedPP (positive-only)
     * or snapshot data. This function replaces those values with net PP
     * (positive + negative) from smart_padhai_pp_logs.
     */
    function _renderProductivityNetPP() {
        try {
            // ── Today vs Yesterday ──
            const todayNetPP = _getTodayNetPP();
            const yesterdayNetPP = _getYesterdayNetPP();
            const todayDelta = todayNetPP - yesterdayNetPP;

            // Update Today PP value
            const todayPPEl = document.getElementById('ge-today-pp');
            if (todayPPEl) {
                todayPPEl.textContent = todayNetPP;
            }

            // Update Today delta
            _setNetPPDelta('ge-delta-pp', todayDelta);

            // ── This Week vs Last Week ──
            // Calculate week boundaries (Monday-based, matching GraphEngine)
            const now = new Date();
            const dayOfWeek = now.getDay(); // 0=Sun, 1=Mon, ...
            const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
            const thisWeekStart = new Date(now);
            thisWeekStart.setDate(now.getDate() + mondayOffset);
            thisWeekStart.setHours(0, 0, 0, 0);

            const thisWeekEnd = new Date(thisWeekStart);
            thisWeekEnd.setDate(thisWeekStart.getDate() + 6); // Sunday

            const lastWeekStart = new Date(thisWeekStart);
            lastWeekStart.setDate(thisWeekStart.getDate() - 7);
            const lastWeekEnd = new Date(thisWeekStart);
            lastWeekEnd.setDate(thisWeekStart.getDate() - 1);

            const thisWeekNetPP = _getNetPPBetweenDatesSafe(thisWeekStart, thisWeekEnd);
            const lastWeekNetPP = _getNetPPBetweenDatesSafe(lastWeekStart, lastWeekEnd);
            const weekDelta = thisWeekNetPP - lastWeekNetPP;

            // Update Week PP value
            const weekPPEl = document.getElementById('ge-week-pp');
            if (weekPPEl) {
                weekPPEl.textContent = thisWeekNetPP;
            }

            // Update Week delta
            _setNetPPDelta('ge-week-delta-pp', weekDelta);

            // ── Update labels from "PP Earned" to "NET PP" ──
            _updatePPLabelsToNetPP();

        } catch (err) {
            console.warn('[Dashboard] Net PP override failed:', err);
        }
    }

    /**
     * Set delta element with proper sign and color class for net PP.
     * Handles positive, negative, and zero delta states.
     */
    function _setNetPPDelta(elementId, deltaValue) {
        const el = document.getElementById(elementId);
        if (!el) return;

        if (deltaValue > 0) {
            el.textContent = '+' + deltaValue;
            el.className = 'ge-delta ge-delta-up';
        } else if (deltaValue < 0) {
            el.textContent = String(deltaValue);
            el.className = 'ge-delta ge-delta-down';
        } else {
            el.textContent = '0';
            el.className = 'ge-delta ge-delta-neutral';
        }
    }

    /**
     * Update "PP Earned" labels to "NET PP" in Productivity Analytics cards.
     * Only changes the label text; does not affect any other element.
     */
    function _updatePPLabelsToNetPP() {
        // Find all ge-compare-label elements inside the Productivity Analytics section
        // that currently say "PP Earned" and update them to "NET PP"
        const section = document.querySelector('.dash-graph-section');
        if (!section) return;

        const labels = section.querySelectorAll('.ge-compare-label');
        labels.forEach(label => {
            if (label.textContent.trim() === 'PP Earned') {
                label.textContent = 'NET PP';
            }
        });
    }

    /**
     * Consistency Score Truth Patch (V2).
     * Belt-and-suspenders override: after GraphEngine renders the Consistency Score,
     * this function recalculates using today's REAL data directly from PP logs,
     * focus sessions, session reviews, and timestamped backlog clearance.
     *
     * Scoring formula:
     *   PP (30):   ppScore = Math.max(0, Math.min(30, todayNetPP))
     *   Focus (25): if focusMinutes >= 25 → 25, else proportional
     *   Sessions (25): if sessionsToday >= 1 → 25, else 0
     *   Backlog Cleared (20): if backlogClearedToday >= 1 → 20, else 0
     *
     * This ensures consistency score reflects today's actual discipline actions,
     * not weekly/lifetime/gross values.
     */
    function _renderConsistencyScoreTruthPatch() {
        try {
            // ── PP: today's net PP from PP logs ──
            const todayNetPP = _getTodayNetPP();
            const ppScore = Math.max(0, Math.min(30, todayNetPP));

            // ── Focus: today's real focus minutes ──
            let focusMinutesToday = 0;
            try {
                const sessions = _getFocusSessionsSafe();
                const today = _getLocalDateKey();
                focusMinutesToday = sessions
                    .filter(s => s && s.session_date === today && s.completed)
                    .reduce((sum, s) => sum + (s.duration_minutes || 0), 0);
            } catch (e) { /* fallback to 0 */ }
            const focusScore = Math.min(25, Math.floor((focusMinutesToday / 25) * 25));

            // ── Sessions: today's real completed session/review count only ──
            const sessionsToday = _getTodayRealSessionCountSafe();
            const sessionsScore = sessionsToday >= 1 ? 25 : 0;

            // ── Backlog Cleared: only backlogs cleared TODAY with timestamp ──
            let backlogClearedToday = 0;
            try {
                const masterData = SafeStorage.getItem(MASTER_KEY, {});
                const today = _getLocalDateKey();
                for (const chap in masterData) {
                    const entry = masterData[chap];
                    if (!entry || typeof entry !== 'object') continue;
                    if (entry._scheduledFor) continue;
                    const read  = entry.read === true || entry.read === 'true';
                    const notes = entry.notes === true || entry.notes === 'true';
                    const pyq   = entry.pyq === true || entry.pyq === 'true';
                    if (!(read && notes && pyq)) continue; // not completed
                    // Must have lastUpdated timestamp matching today
                    if (entry.lastUpdated) {
                        const tsDate = new Date(entry.lastUpdated);
                        if (!isNaN(tsDate.getTime())) {
                            const tsKey = String(entry.lastUpdated).includes('T')
                                ? _getLocalDateKey(tsDate)
                                : String(entry.lastUpdated).slice(0, 10);
                            if (tsKey === today) {
                                backlogClearedToday++;
                            }
                        }
                    }
                }
            } catch (e) { /* fallback to 0 */ }
            const backlogScore = backlogClearedToday >= 1 ? 20 : 0;

            // ── Total consistency score ──
            const consistencyScore = Math.min(100, Math.max(0, ppScore + focusScore + sessionsScore + backlogScore));

            // ── Update DOM ──
            // Update score ring value
            const scoreEl = document.getElementById('ge-consistency-value');
            if (scoreEl) scoreEl.textContent = consistencyScore;

            // Update SVG ring
            const circle = document.getElementById('ge-consistency-ring');
            if (circle) {
                const circumference = 2 * Math.PI * 42;
                circle.style.strokeDasharray = circumference;
                const offset = circumference - (consistencyScore / 100) * circumference;
                circle.style.strokeDashoffset = offset;
            }

            // Update breakdown rows
            const ppEl = document.getElementById('ge-score-pp');
            if (ppEl) ppEl.textContent = ppScore + '/30';

            const focusEl = document.getElementById('ge-score-focus');
            if (focusEl) focusEl.textContent = focusScore + '/25';

            const sessionsEl = document.getElementById('ge-score-sessions');
            if (sessionsEl) sessionsEl.textContent = sessionsScore + '/25';

            const backlogsEl = document.getElementById('ge-score-backlogs');
            if (backlogsEl) {
                backlogsEl.textContent = backlogScore + '/20';
                if (backlogScore === 0) {
                    backlogsEl.title = 'No dated backlog clearance recorded today.';
                } else {
                    backlogsEl.title = backlogClearedToday + ' backlog(s) cleared today.';
                }
            }

            console.log('[Dashboard] Consistency Score Truth Patch applied:', consistencyScore + '/100', {
                pp: ppScore + '/30', focus: focusScore + '/25',
                sessions: sessionsScore + '/25', backlog: backlogScore + '/20'
            });

        } catch (err) {
            console.warn('[Dashboard] Consistency Score Truth Patch failed:', err);
        }
    }

    /**
     * Productivity Reality Line — Dynamic quote/insight strip.
     * Returns { icon, text, meta } based on today's real data.
     * Never makes fake claims. Data-driven honesty only.
     */
    function _getProductivityRealityLine() {
        try {
            const todayNetPP = _getTodayNetPP();
            const yesterdayNetPP = _getYesterdayNetPP();
            let focusMinutesToday = 0;
            try {
                const sessions = _getFocusSessionsSafe();
                const today = _getLocalDateKey();
                focusMinutesToday = sessions
                    .filter(s => s && s.session_date === today && s.completed)
                    .reduce((sum, s) => sum + (s.duration_minutes || 0), 0);
            } catch (e) { /* 0 */ }

            // Rule 1: Net PP negative → recovery signal
            if (todayNetPP < 0) {
                return {
                    icon: '\u26A1',
                    text: 'Recovery starts when the scoreboard is honest.',
                    meta: 'Net PP is negative today'
                };
            }

            // Rule 2: No PP and no focus → day not started
            if (todayNetPP === 0 && focusMinutesToday === 0) {
                return {
                    icon: '\u26A1',
                    text: 'No focus block logged yet. The day is still recoverable.',
                    meta: 'Start with one 25-minute block'
                };
            }

            // Rule 3: Today ahead of yesterday → momentum
            if (todayNetPP > yesterdayNetPP) {
                return {
                    icon: '\u26A1',
                    text: 'Momentum is returning. Protect it with one more clean block.',
                    meta: 'Today is ahead of yesterday'
                };
            }

            // Rule 4: Focus block logged today
            if (focusMinutesToday >= 25) {
                return {
                    icon: '\u26A1',
                    text: 'One real focus block beats ten fake intentions.',
                    meta: 'Focus logged today'
                };
            }

            // Rule 5: Weekly net PP is positive
            try {
                const now = new Date();
                const dayOfWeek = now.getDay();
                const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
                const thisWeekStart = new Date(now);
                thisWeekStart.setDate(now.getDate() + mondayOffset);
                thisWeekStart.setHours(0, 0, 0, 0);
                const thisWeekEnd = new Date(thisWeekStart);
                thisWeekEnd.setDate(thisWeekStart.getDate() + 6);
                const weeklyNetPP = _getNetPPBetweenDatesSafe(thisWeekStart, thisWeekEnd);
                if (weeklyNetPP > 0) {
                    return {
                        icon: '\u26A1',
                        text: 'Consistency is invisible before it becomes obvious.',
                        meta: 'Weekly trend is active'
                    };
                }
            } catch (e) { /* fallback to default */ }

            // Rule 6: Default
            return {
                icon: '\u26A1',
                text: 'Small honest actions become visible progress.',
                meta: 'Productivity signal'
            };
        } catch (err) {
            return {
                icon: '\u26A1',
                text: 'Small honest actions become visible progress.',
                meta: 'Productivity signal'
            };
        }
    }

    /**
     * Render the Productivity Reality Line into the DOM.
     * Updates icon, text, and meta from _getProductivityRealityLine().
     */
    function _renderProductivityRealityLine() {
        try {
            const line = _getProductivityRealityLine();
            const container = document.getElementById('productivityRealityLine');
            if (!container) return;

            const iconEl = container.querySelector('.productivity-reality-icon');
            const textEl = container.querySelector('.productivity-reality-text');
            const metaEl = container.querySelector('.productivity-reality-meta');

            if (iconEl) iconEl.textContent = line.icon;
            if (textEl) textEl.textContent = line.text;
            if (metaEl) metaEl.textContent = line.meta;
        } catch (err) {
            // Silent — reality line is non-critical UI
        }
    }


    // ════════════════════════════════════════════════════════
    //  ACADEMIC PROFILE HELPERS (Phase 9 — Syllabus Progress Sync)
    // ════════════════════════════════════════════════════════

    /**
     * Get current user's academic profile for syllabus filtering.
     *
     * Priority:
     *   1. window.SMART_PADHAI_PROFILE (set by sidebar/profile card)
     *   2. SafeStorage.getItem("smart_padhai_user_profile") (user-scoped)
     *   3. Fallback — returns classLevel: null (NOT a hardcoded class)
     *
     * CRITICAL: Never returns a fake classLevel.
     * If no profile exists, classLevel is null so the UI shows
     * "Profile not set" instead of lying with another class.
     * Never falls back from unsupported class to a different class.
     */
    function _getDashboardAcademicProfileSafe() {
        try {
            // 1. Global profile object (set by profile card / sidebar)
            const globalProfile = window.SMART_PADHAI_PROFILE;
            if (globalProfile && typeof globalProfile === 'object' && Object.keys(globalProfile).length > 0) {
                return globalProfile;
            }

            // 2. SafeStorage profile (auto user-scoped by SafeStorage)
            const storedProfile = SafeStorage?.getItem
                ? SafeStorage.getItem('smart_padhai_user_profile', null)
                : null;
            if (storedProfile && typeof storedProfile === 'object' && Object.keys(storedProfile).length > 0) {
                return storedProfile;
            }
        } catch (err) {
            console.warn('[Dashboard] Academic profile read failed:', err);
        }

        // 3. No profile found — return null classLevel so UI shows "Profile not set"
        // Do NOT hardcode a class like 10 or 9 — that causes profile mismatch bugs
        return {
            classLevel: null,
            board: 'CBSE',
            academicYear: '2026-27'
        };
    }

    // ── Shared string normaliser (used by name + emoji helpers) ──
    const _cleanStr = (v) => {
        if (!v || typeof v !== 'string') return null;
        const t = v.trim();
        if (!t || t.toLowerCase() === 'undefined' || t.toLowerCase() === 'null') return null;
        return t;
    };

    /**
     * Resolve current auth user from Supabase cached session.
     * Returns the user object or null — never throws.
     */
    function _getDashboardAuthUser() {
        try {
            const session = window.supabase?.auth?.session?.() || window._supabaseSession || null;
            return session?.user || null;
        } catch (_) { return null; }
    }

    /**
     * Resolve the current user's profile object from all known sources.
     *
     * Source priority:
     *   1. window.SMART_PADHAI_PROFILE
     *   2. SafeStorage 'smart_padhai_user_profile'
     *   3. localStorage 'smart_padhai_user_profile' (raw JSON)
     *   4. AppState.currentUserProfile / userProfile / currentUser
     *   5. window.currentUser
     *
     * Account-switch safety: if storedProfile.userId doesn't match the
     * current auth user id the profile is discarded.
     *
     * Returns the profile object or null.
     */
    function _getDashboardProfileSafe() {
        try {
            const authUser = _getDashboardAuthUser();
            let profile = null;

            // Source 1: global profile set by sidebar / profile card
            if (window.SMART_PADHAI_PROFILE && typeof window.SMART_PADHAI_PROFILE === 'object'
                    && Object.keys(window.SMART_PADHAI_PROFILE).length > 0) {
                profile = window.SMART_PADHAI_PROFILE;
            }

            // Source 2: SafeStorage (auto user-scoped)
            if (!profile && typeof SafeStorage !== 'undefined' && SafeStorage?.getItem) {
                const stored = SafeStorage.getItem('smart_padhai_user_profile', null);
                if (stored && typeof stored === 'object') profile = stored;
            }

            // Source 3: localStorage raw JSON fallback
            if (!profile) {
                try {
                    const raw = localStorage.getItem('smart_padhai_user_profile');
                    if (raw) {
                        const parsed = JSON.parse(raw);
                        if (parsed && typeof parsed === 'object') profile = parsed;
                    }
                } catch (_) { /* malformed JSON — ignore */ }
            }

            // Source 4 & 5: AppState / global currentUser
            if (!profile) {
                profile = window.AppState?.currentUserProfile
                    || window.AppState?.userProfile
                    || window.AppState?.currentUser
                    || window.currentUser
                    || null;
            }

            // Account-switch safety: discard profile if userId doesn't match auth
            if (profile && authUser?.id) {
                const storedUid = profile.userId || profile.user_id || profile.id || null;
                if (storedUid && storedUid !== authUser.id) {
                    console.warn('[Dashboard] Profile userId mismatch — ignoring stale profile.');
                    profile = null;
                }
            }

            return profile;
        } catch (err) {
            console.warn('[Dashboard] _getDashboardProfileSafe error:', err);
            return null;
        }
    }

    /**
     * Return the operative-level emoji for a given profile object.
     *
     * Reads (in order): operativeLevel, operative_level, student_tier, levelType
     * Normalises to lowercase + underscores before matching.
     *
     * Mapping:
     *   topper                       → 😎
     *   average                      → 😃
     *   comeback / comeback_fighter  → 🔥
     *   anything else                → '' (empty — no emoji shown)
     */
    function _getOperativeLevelEmojiSafe(profile) {
        try {
            if (!profile || typeof profile !== 'object') return '';

            const raw = profile.operativeLevel
                || profile.operative_level
                || profile.student_tier
                || profile.levelType
                || '';

            if (!raw || typeof raw !== 'string') return '';

            // Normalise: lowercase, trim, spaces → underscores
            const key = raw.trim().toLowerCase().replace(/\s+/g, '_');

            if (key === 'topper')                            return '😎';
            if (key === 'average')                           return '😃';
            if (key === 'comeback' || key === 'comeback_fighter') return '🔥';

            return '';
        } catch (err) {
            console.warn('[Dashboard] _getOperativeLevelEmojiSafe error:', err);
            return '';
        }
    }

    /**
     * Return the correct emoji for a Smart Padhai rank string.
     *
     * Rank ladder:  Initiate → Operator → War Machine → Commander → Architect
     * Normalises:   trim, lowercase, spaces → underscores before matching.
     *
     * Mapping:
     *   initiate                   → 🛡️
     *   operator                   → ⚔️
     *   war_machine / war machine  → 🔥
     *   commander                  → 🦅
     *   architect                  → 👁️
     *   unknown / missing          → 🛡️  (safe fallback)
     */
    function _getRankEmojiSafe(rank) {
        try {
            const key = String(rank || '').trim().toLowerCase().replace(/\s+/g, '_');
            if (key === 'operator')                           return '⚔️';
            if (key === 'war_machine')                        return '🔥';
            if (key === 'commander')                          return '🦅';
            if (key === 'architect')                          return '👁️';
            // initiate or any unknown/empty → shield (safe default)
            return '🛡️';
        } catch (err) {
            console.warn('[Dashboard] _getRankEmojiSafe error:', err);
            return '🛡️';
        }
    }

    /**
     * Update the hero-rank-icon span with the emoji matching the current rank.
     * Reads PulseEngine.data.level — same source PulseEngine.updateUI() uses.
     * Safe to call multiple times (idempotent, no re-render).
     */
    function _updateHeroRankIcon() {
        try {
            const el = document.getElementById('hero-rank-icon-el');
            if (!el) return;
            const rank = window.PulseEngine?.data?.level || 'Initiate';
            el.textContent = _getRankEmojiSafe(rank);
        } catch (err) {
            console.warn('[Dashboard] _updateHeroRankIcon error:', err);
        }
    }

    /**
     * Get the display name for the current logged-in user.
     *
     * Priority:
     *   1. profile.operativeName
     *   2. profile.nickname
     *   3. profile.operative_name
     *   4. profile.name
     *   5. Supabase auth user metadata full_name / name
     *   6. Email prefix
     *   7. "Student" (safe fallback — never hardcoded to any specific user)
     */
    function _getDashboardDisplayNameSafe() {
        try {
            const profile  = _getDashboardProfileSafe();
            const authUser = _getDashboardAuthUser();

            // Extract name from profile
            if (profile) {
                const n = _cleanStr(profile.operativeName)
                    || _cleanStr(profile.nickname)
                    || _cleanStr(profile.operative_name)
                    || _cleanStr(profile.name);
                if (n) return n;
            }

            // Fallback to Supabase auth metadata
            if (authUser) {
                const meta = authUser.user_metadata || authUser.raw_user_meta_data || {};
                const n = _cleanStr(meta.full_name)
                    || _cleanStr(meta.name)
                    || _cleanStr(authUser.email?.split('@')[0]);
                if (n) return n;
            }

        } catch (err) {
            console.warn('[Dashboard] _getDashboardDisplayNameSafe error:', err);
        }

        return 'Student';
    }

    /**
     * Update the hero title element with emoji + display name for the current user.
     * Safe to call multiple times (idempotent DOM update, no re-render).
     *
     * Renders:  [emoji] [displayName]   e.g.  😎 Sarth Joshi
     * If no operative level is set, renders displayName only.
     */
    function _updateHeroDisplayName() {
        try {
            const el = document.getElementById('hero-user-name');
            if (!el) return;

            const profile     = _getDashboardProfileSafe();
            const displayName = _getDashboardDisplayNameSafe();
            const emoji       = _getOperativeLevelEmojiSafe(profile);

            el.textContent = emoji ? `${emoji} ${displayName}` : displayName;
        } catch (err) {
            console.warn('[Dashboard] _updateHeroDisplayName error:', err);
        }
    }

    /**
     * Calculate syllabus progress summary for the current user's active preset.
     * Returns { total, completed, percent, classLevel, board, academicYear, source }.
     *
     * Completion = read && notes && revised && pyq (4-field standard).
     * Filters by classLevel/board/academicYear metadata when available,
     * falls back to isSyllabus === true for legacy data.
     *
     * CRITICAL PROFILE MISMATCH FIX:
     *   - Does NOT use userClass (stale global key that leaks across accounts)
     *   - If profile has no classLevel, returns source "no_profile"
     *   - If no matching syllabus entries, returns source "no_matching_syllabus"
     *   - Never falls back from unsupported class to another class
     */
    function _getSyllabusProgressSummarySafe() {
        try {
            // Use global _getAcademicProfileSafe if available (from other modules),
            // otherwise fall back to dashboard's own profile helper
            const profile = typeof _getAcademicProfileSafe === 'function'
                ? _getAcademicProfileSafe()
                : _getDashboardAcademicProfileSafe();

            // Resolve classLevel — but do NOT fall back to a hardcoded class
            const rawClassLevel = Number(
                profile?.classLevel ||
                profile?.class_level ||
                profile?.grade ||
                0
            );
            const classLevel = Number.isFinite(rawClassLevel) && rawClassLevel > 0
                ? rawClassLevel
                : null;

            const board = String(profile?.board || 'CBSE').toUpperCase();
            const academicYear = profile?.academicYear || profile?.academic_year || '2026-27';

            // If no classLevel, cannot filter syllabus — return empty with no_profile source
            if (classLevel === null) {
                return {
                    total: 0,
                    completed: 0,
                    percent: 0,
                    classLevel: null,
                    board,
                    academicYear,
                    source: 'no_profile'
                };
            }

            const masterData = SafeStorage.getItem(MASTER_KEY, {});
            if (!masterData || typeof masterData !== 'object' || Array.isArray(masterData)) {
                return { total: 0, completed: 0, percent: 0, classLevel, board, academicYear, source: 'empty' };
            }

            function toBool(v) { return v === true || v === 'true'; }

            // Filter chapters matching current profile only — no userClass fallback
            const chapters = Object.entries(masterData).filter(([chapterName, entry]) => {
                if (!entry || typeof entry !== 'object') return false;
                if (entry.isSyllabus !== true) return false;

                // If metadata exists on the entry, match against current profile
                const hasMeta = entry.classLevel || entry.board || entry.academicYear || entry.presetKey;

                if (hasMeta) {
                    const entryClass = Number(entry.classLevel || classLevel);
                    const entryBoard = String(entry.board || board).toUpperCase();
                    const entryYear = entry.academicYear || academicYear;

                    return entryClass === classLevel &&
                           entryBoard === board &&
                           entryYear === academicYear;
                }

                // Legacy fallback: no metadata — count all isSyllabus chapters
                // Only if we have a valid classLevel from the user's profile
                return true;
            });

            const total = chapters.length;

            // 4-field completion: read + notes + revised + pyq all true
            const completed = chapters.filter(([chapterName, entry]) => {
                return !!(toBool(entry.read) && toBool(entry.notes) && toBool(entry.revised) && toBool(entry.pyq));
            }).length;

            const percent = total > 0
                ? Math.round((completed / total) * 100)
                : 0;

            return {
                total,
                completed,
                percent,
                classLevel,
                board,
                academicYear,
                source: total === 0 ? 'no_matching_syllabus' : 'smartPadhaiData'
            };
        } catch (err) {
            console.warn('[Dashboard] Syllabus progress summary failed:', err);
            return { total: 0, completed: 0, percent: 0, classLevel: null, board: 'CBSE', academicYear: '2026-27', source: 'error' };
        }
    }


    // ════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════

    async function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;

        // 0b. Load Dashboard Clarity state from storage
        _dashboardViewMode = _getDashboardViewMode();
        _collapsedSections = _getCollapsedSections();
        try {
            _compactInitialized = SafeStorage.getItem(COMPACT_INIT_KEY, false) === true;
        } catch (e) { _compactInitialized = false; }

        // If compact mode and first time, auto-collapse secondary sections
        if (_dashboardViewMode === 'compact' && !_compactInitialized) {
            COLLAPSIBLE_SECTIONS.forEach(id => {
                if (_collapsedSections[id] === undefined) {
                    _collapsedSections[id] = true;
                }
            });
            _saveCollapsedSections();
            try { SafeStorage.setItem(COMPACT_INIT_KEY, true); } catch (e) { /* silent */ }
            _compactInitialized = true;
        }

        // 1. Load CSS
        _loadCSS();

        // 2. Render HTML
        container.innerHTML = _renderHTML();

        // 2a. Update hero display name dynamically (never hardcoded)
        _updateHeroDisplayName();

        // 2b. Update hero rank icon emoji (uses PulseEngine data if already loaded)
        _updateHeroRankIcon();

        // 2b. Apply Dashboard Clarity: view mode + collapsible states
        _applyDashboardViewMode();
        _applyCollapsibleStates();

        // 3. Wait for PulseEngine then update UI
        await _waitForPulseEngine();

        // 4. Update dashboard circles
        _updateDashboardCircles();

        // 5. Display badges
        _displayBadges();

        // 6. Display quote
        _displayRandomQuote();

        // 7. Update Smart Next Step by Ashukari
        _renderAshukariNextStep();

        // 7b. Render Weekly Report Card (Phase 9A Sprint 3)
        _renderWeeklyReportCard();

        // 7c. Render Weekly PP Goal Bar (Sprint 9 — Discipline Economy)
        _renderWeeklyPPGoal();

        // 7d. Initialize rank change detection for celebrations
        if (window.PulseEngine && PulseEngine.data) {
            _lastKnownRank = PulseEngine.data.level;
        }

        // 7e. Render Session Insights card (Phase 2 — Session Review)
        _renderSessionInsights();

        // 7f. One-time StreakSystem refresh before first heatmap render
        if (window.StreakSystem && typeof window.StreakSystem.refreshStreak === 'function') {
            try {
                window.StreakSystem.refreshStreak();
            } catch (err) {
                console.warn('[DashboardRoute] Initial streak refresh failed:', err);
            }
        }

        // 7f2. RPM Wave 1: Update hero streak display with real count
        _updateHeroStreakDisplay();

        // 7g. Initialize ComebackSystem before rendering
        if (window.ComebackSystem && typeof window.ComebackSystem.init === 'function') {
            try {
                window.ComebackSystem.init();
            } catch (err) {
                console.warn('[DashboardRoute] ComebackSystem init failed:', err);
            }
        }

        // 7h. Render Streak Heatmap (Phase 2 — Heatmap, synced with StreakSystem)
        _renderStreakHeatmap(30);

        // 7i. Comeback Card — REMOVED from dashboard (RPM Wave 1)
        // _renderComebackCard();

        // 7i-optimal. Render Optimal Study Window
        _renderOptimalStudyWindow();

        // 7j. Listen for StreakSystem updates (ComebackSystem listener disabled — RPM Wave 1)
        _startStreakEventListener();
        // _startComebackEventListener();

        // 7k. Render Tactical Daily Directive (after Hero section)
        _renderDailyDirective();
        _startDirectiveEventListeners();

        // 7k2. Start Ashukari Smart Next Step event listeners (RPM Wave 2B)
        _startAshukariEventListeners();

        // 7l. Render Study Autopsy card
        _renderStudyAutopsyCard();

        // 7m. Start Smart Cookie Jar event listeners (RPM Wave 2C)
        _startCookieJarEventListeners();



        // [Phase 7D] Step 8 (neural lines) REMOVED — no longer called

        // 8. Init GraphEngine (after DOM exists, await for first-visit Supabase load)
        await _initGraphEngine();
            // 8b. Init PP Trend Graph
  const ppTrendContainer = container.querySelector('#ppTrendGraph');
    if (ppTrendContainer) {
      if (window.PPTrendGraph) {
        window.PPTrendGraph.render(ppTrendContainer);
      } else {
        console.warn("[DashboardRoute] PPTrendGraph module not loaded.");
        ppTrendContainer.innerHTML = `
          <div class="pp-trend-empty">
            <div class="pp-trend-empty-title">PP Trend module not loaded.</div>
          </div>`;
      }
    }
        // 9. Init TimerEngine UI (refresh only)
        _initTimerEngine();

        // 10. Start PanicProtocol
        await _ensurePanicProtocolV2Loaded();
        _startPanicProtocol();

          [
            'smartPadhai:syllabusUpdated',
            'smartPadhai:memoryUpdated',
            'smartPadhai:backlogUpdated',
            'smartPadhai:autopsyUpdated',
            'smartPadhai:examScopeUpdated',
            'smartPadhai:ppUpdated'
        ].forEach(eventName => {
            _abortController.signal.addEventListener('abort', () => {
                // listeners below are removed when abortController aborts
            });
            window.addEventListener(eventName, () => {
                if (!_abortController.signal.aborted && window.PanicProtocolV2) {
                    try {
                        const plan = PanicProtocolV2.generatePlan();
                        _renderPanicV2Card(plan);
                    } catch (e) { /* silent */ }
                }
            }, { signal: _abortController.signal });
        });

        // 11. Bind events
        _bindEvents(container, _abortController.signal);

        console.log('[DashboardRoute] Initialized (Phase 9 Syllabus Progress Circle Real Sync)');
    }

    function cleanup() {
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }
        if (_panicInterval) {
            clearInterval(_panicInterval);
            _panicInterval = null;
        }
        if (_neuralLinesTimeout) {
            clearTimeout(_neuralLinesTimeout);
            _neuralLinesTimeout = null;
        }
        // Close any open modals
        const modal = document.getElementById('rank-modal');
        if (modal) modal.style.display = 'none';
        // Remove StreakSystem and ComebackSystem event listeners
        _stopStreakEventListener();
        _stopComebackEventListener();
        // Remove Directive event listeners
        _stopDirectiveEventListeners();
        // Remove Ashukari event listeners (RPM Wave 2B)
        _stopAshukariEventListeners();
        // Remove Smart Cookie Jar event listeners (RPM Wave 2C)
        _stopCookieJarEventListeners();
        _closeSmartCookieJar();
        // Remove ghost-active from body + exit focus mode
        document.body.classList.remove('ghost-active');
        _focusModeActive = false;
        // Reset page title
        document.title = 'Smart Padhai | Action OS';
        // Unload CSS
        _unloadCSS();
        _container = null;
        console.log('[DashboardRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.dashboardCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;

        // Hero user-name overflow safety (long nicknames, mobile)
        if (!document.getElementById('_dashboard-hero-name-css')) {
            const style = document.createElement('style');
            style.id = '_dashboard-hero-name-css';
            style.textContent = `
                .hero-user-name {
                    display: block;
                    overflow-wrap: anywhere;
                    word-break: break-word;
                    max-width: 100%;
                }
            `;
            document.head.appendChild(style);
        }
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-dashboard-css]');
        if (el) { el.remove(); _cssLinkEl = null; }
    }

    // ════════════════════════════════════════════════════════
    //  PULSE ENGINE WAIT + UI UPDATE
    // ════════════════════════════════════════════════════════

    /**
     * Wait for PulseEngine.hasLoadedFromSupabase to be true.
     * Show loading overlay if not ready. Retry every 500ms up to 10s.
     * CRITICAL: Do NOT call loadPulseEngineFromSupabase() or
     * initPulseEngineAfterAuth() here — app-init.js handles that.
     */
    async function _waitForPulseEngine() {
        // Check immediately
        if (window.PulseEngine && PulseEngine.hasLoadedFromSupabase) {
            _updatePulseEngineUI();
            return;
        }

        // Show loading overlay
        _showPulseLoadingOverlay();

        const maxRetries = 20; // 20 * 500ms = 10 seconds
        let attempt = 0;

        return new Promise((resolve) => {
            const interval = setInterval(() => {
                attempt++;

                if (window.PulseEngine && PulseEngine.hasLoadedFromSupabase) {
                    clearInterval(interval);
                    _hidePulseLoadingOverlay();
                    _updatePulseEngineUI();
                    resolve();
                    return;
                }

                if (attempt >= maxRetries) {
                    clearInterval(interval);
                    _hidePulseLoadingOverlay();
                    console.warn('[DashboardRoute] PulseEngine still not loaded after 10s. Rendering with fallback data.');
                    // Attempt UI update anyway — PulseEngine.updateUI() handles missing elements gracefully
                    if (window.PulseEngine) {
                        _updatePulseEngineUI();
                    }
                    resolve();
                }
            }, 500);
        });
    }

    function _showPulseLoadingOverlay() {
        if (!_container) return;
        // Remove existing overlay if any
        const existing = _container.querySelector('.pulse-loading-overlay');
        if (existing) return;

        const overlay = document.createElement('div');
        overlay.className = 'pulse-loading-overlay';
        overlay.style.cssText = `
            position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.7); z-index: 9999;
            display: flex; align-items: center; justify-content: center;
            flex-direction: column; gap: 16px;
        `;
        overlay.innerHTML = `
            <div style="color: #00ccff; font-size: 1.2rem; font-weight: 700; letter-spacing: 2px;">
                Loading PulseEngine...
            </div>
            <div style="width: 40px; height: 40px; border: 3px solid #222; border-top-color: #00ccff;
                        border-radius: 50%; animation: pulse-spin 0.8s linear infinite;"></div>
        `;
        _container.appendChild(overlay);
    }

    function _hidePulseLoadingOverlay() {
        const overlay = _container?.querySelector('.pulse-loading-overlay');
        if (overlay) overlay.remove();
    }

    /**
     * Update PulseEngine-driven UI elements.
     * Called from _waitForPulseEngine and on returning to dashboard.
     * CRITICAL: Only calls PulseEngine.updateUI(). Never resets PP.
     */
    function _updatePulseEngineUI() {
        if (!window.PulseEngine) return;

        // PulseEngine.updateUI() handles:
        //   global-level-display, global-pp-display, xp-needed,
        //   global-pulse-fill, trophy-pp-display, main-shard-badge,
        //   rank-name, syncThemeClasses, updateTimelinePath
        PulseEngine.updateUI();

        // Sync hero-rank-icon emoji to current rank
        _updateHeroRankIcon();

        // RPM Wave 1: Update hero streak display via dedicated function
        // (uses StreakSystem.getStreakSummary() for real count)
        _updateHeroStreakDisplay();
    }

    // ════════════════════════════════════════════════════════
    //  SVG RING PROGRESS HELPER
    // ════════════════════════════════════════════════════════

    function _setRingProgress(elementId, percent) {
        const circle = document.getElementById(elementId);
        if (!circle) return;
        const radius = circle.r?.baseVal?.value;
        if (!radius || radius <= 0) return;
        const circumference = 2 * Math.PI * radius;
        const clampedPercent = Math.max(0, Math.min(100, percent));
        circle.style.strokeDasharray = circumference;
        circle.style.strokeDashoffset = circumference - (clampedPercent / 100 * circumference);
    }

    // ════════════════════════════════════════════════════════
    //  DASHBOARD CIRCLES UPDATE (CRITICAL BACKLOG RULE)
    // ════════════════════════════════════════════════════════

    function _updateDashboardCircles() {
        // ── Helper: Backlog calculation ──
        // Only count read/notes/pyq fields.
        // Do NOT count isSyllabus, _scheduledFor, lastUpdated.
        function toBool(v) { return v === true || v === 'true'; }

        function isRealBacklog(status) {
            if (!status || typeof status !== 'object') return false;
            if (status._scheduledFor) return false;
            const read = toBool(status.read);
            const notes = toBool(status.notes);
            const pyq = toBool(status.pyq);
            const started = read || notes || pyq;
            const completed = read && notes && pyq;
            return started && !completed;
        }

        function isFullyCompleted(status) {
            if (!status || typeof status !== 'object') return false;
            return toBool(status.read) && toBool(status.notes) && toBool(status.pyq);
        }

        // ── 1. BACKLOG CIRCLE ──
        const masterData = SafeStorage.getItem(MASTER_KEY, {});
        let backlogCount = 0;

        if (masterData && typeof masterData === 'object' && !Array.isArray(masterData)) {
            for (const chap in masterData) {
                const entry = masterData[chap];
                if (isRealBacklog(entry)) backlogCount++;
            }
        }

        const backlogText = document.getElementById('backlog-text');
        if (backlogText) backlogText.textContent = backlogCount;
        _setRingProgress('backlogCircle', Math.min(100, (backlogCount / 10) * 100));

        const backlogHover = document.getElementById('backlog-hover');
        if (backlogHover) {
            backlogHover.textContent = backlogCount === 0
                ? 'All caught up!'
                : `${backlogCount} chapter${backlogCount !== 1 ? 's' : ''} in progress`;
        }

        // ── 2. PROGRESS CIRCLE (Phase 9 — Real Syllabus Sync) ──
        // Uses _getSyllabusProgressSummarySafe() to calculate:
        //   completedChapters / totalSyllabusChapters for current user's active preset.
        // Filters by classLevel/board/academicYear metadata when available,
        // falls back to isSyllabus === true for legacy data.
        // Completion = read + notes + revised + pyq all true (4-field).
        //
        // PROFILE MISMATCH FIX:
        //   - If classLevel is null → "Profile not set"
        //   - If no matching syllabus → "No active syllabus preset"
        //   - Never shows another class's data for the current user
        const syllabusProgress = _getSyllabusProgressSummarySafe();

        console.log('[DashboardRoute] Syllabus progress (Phase 9 sync):', syllabusProgress);

        const progressPct = syllabusProgress.percent;
        const progressText = document.getElementById('progress-text');
        if (progressText) {
            progressText.textContent = progressPct + '%';
        }
        _setRingProgress('progressCircle', progressPct);

        const progressHover = document.getElementById('progress-hover');
        if (progressHover) {
            if (syllabusProgress.source === 'no_profile') {
                progressHover.textContent = 'Profile not set';
            } else if (syllabusProgress.total === 0) {
                progressHover.textContent = 'No active syllabus preset';
            } else {
                progressHover.textContent = `${syllabusProgress.completed}/${syllabusProgress.total} chapters completed`;
            }
        }

        // Class/board label — only show if classLevel exists
        const progressSubtext = document.getElementById('progress-subtext');
        if (progressSubtext) {
            if (syllabusProgress.classLevel !== null) {
                progressSubtext.textContent = `Class ${syllabusProgress.classLevel} \u00B7 ${syllabusProgress.board}`;
            } else {
                progressSubtext.textContent = 'Profile not set';
            }
        }

        // ── 3. NOTEBOOKS CIRCLE ──
        const notebookData = SafeStorage.getItem(NOTEBOOK_KEY, []);
        let notebookDone = 0;
        let notebookTotal = 0;

        if (Array.isArray(notebookData)) {
            notebookTotal = notebookData.length;
            notebookDone = notebookData.filter(row => row && row.done === true).length;
        }

        const notebookPct = notebookTotal > 0 ? Math.round((notebookDone / notebookTotal) * 100) : 0;
        const notebookText = document.getElementById('notebook-text');
        if (notebookText) notebookText.textContent = `${notebookDone}/${notebookTotal}`;
        _setRingProgress('notebookCircle', notebookPct);

        const notebookHover = document.getElementById('notebook-hover');
        if (notebookHover) {
            notebookHover.textContent = notebookTotal === 0
                ? 'No notebooks tracked'
                : `${notebookDone} of ${notebookTotal} complete`;
        }

        // ── 4. PULSE SCORE CIRCLE ──
        // FIX 2: Use date-safe _getTodayNetPP() instead of stale PulseEngine.dailyEarnedPP.
        // This ensures the circle shows ONLY today's net PP (positive + negative).
        const todayNetPP = _getTodayNetPP();

        const pulseText = document.getElementById('pulse-text');
        const scoreCircle = document.getElementById('scoreCircle');
        const pulseSquare = document.getElementById('pulse-square');

        // FIX 3: Display correct text format based on sign
        if (pulseText) {
            if (todayNetPP > 0) {
                pulseText.textContent = '+' + todayNetPP;
            } else if (todayNetPP < 0) {
                pulseText.textContent = String(todayNetPP);  // already has minus sign
            } else {
                pulseText.textContent = '0';
            }
        }

        // FIX 3: Apply visual state classes + ring color based on net PP
        // Uses both pulse-score-* (existing) and pulse-net-* (spec) for compatibility
        if (pulseSquare) {
            pulseSquare.classList.remove(
                'pulse-score-positive', 'pulse-score-negative', 'pulse-score-neutral',
                'pulse-net-positive', 'pulse-net-negative', 'pulse-net-zero'
            );
            if (todayNetPP > 0) {
                pulseSquare.classList.add('pulse-score-positive', 'pulse-net-positive');
            } else if (todayNetPP < 0) {
                pulseSquare.classList.add('pulse-score-negative', 'pulse-net-negative');
            } else {
                pulseSquare.classList.add('pulse-score-neutral', 'pulse-net-zero');
            }
        }

        // FIX 4: Ring progress logic — positive, zero, or negative
        if (scoreCircle) {
            if (todayNetPP > 0) {
                // Green ring fill based on todayNetPP / 200
                scoreCircle.setAttribute('stroke', '#00ff9d');
                _setRingProgress('scoreCircle', Math.min(100, (todayNetPP / 200) * 100));
            } else if (todayNetPP < 0) {
                // Red ring fill based on absolute value / 100
                scoreCircle.setAttribute('stroke', '#ff4c4c');
                _setRingProgress('scoreCircle', Math.min(100, (Math.abs(todayNetPP) / 100) * 100));
            } else {
                // Neutral — no fill, neutral color
                scoreCircle.setAttribute('stroke', '#00d1ff');
                _setRingProgress('scoreCircle', 0);
            }
        }

        // FIX 5: Hover text with Earned/Lost/Net breakdown + today vs yesterday
        const breakdown = _getTodayPPBreakdownSafe();
        const yesterdayNetPP = _getYesterdayNetPP();
        const pulseHover = document.getElementById('pulse-hover');
        if (pulseHover) {
            let hoverMsg = '';
            if (breakdown.actionCount > 0) {
                // Show full breakdown: Earned / Lost / Net
                const netSign = breakdown.net >= 0 ? '+' : '';
                hoverMsg = `Earned: +${breakdown.earned} PP | Lost: -${breakdown.lost} PP | Net: ${netSign}${breakdown.net} PP`;
            } else {
                hoverMsg = 'No PP activity today';
            }
            // Add today vs yesterday comparison
            const diff = todayNetPP - yesterdayNetPP;
            if (diff > 0) {
                hoverMsg += ` | +${diff} vs yesterday`;
            } else if (diff < 0) {
                hoverMsg += ` | ${diff} vs yesterday`;
            } else if (yesterdayNetPP !== 0 || todayNetPP !== 0) {
                hoverMsg += ' | Same as yesterday';
            }
            pulseHover.textContent = hoverMsg;
        }
    }

    // ════════════════════════════════════════════════════════
    //  PULSE SCORE CIRCLE — Lightweight refresh on PP changes
    // ════════════════════════════════════════════════════════

    /**
     * FIX 7: Lightweight refresh of only the Pulse Score Circle.
     * Called when PP events fire (smartPadhai:ppUpdated, etc.)
     * Does NOT re-render all 4 circles — only the pulse score.
     * Does NOT dispatch events (prevents infinite loops).
     */
    function _updatePulseScoreCircle() {
        const todayNetPP = _getTodayNetPP();

        const pulseText = document.getElementById('pulse-text');
        const scoreCircle = document.getElementById('scoreCircle');
        const pulseSquare = document.getElementById('pulse-square');

        // Display text
        if (pulseText) {
            if (todayNetPP > 0) {
                pulseText.textContent = '+' + todayNetPP;
            } else if (todayNetPP < 0) {
                pulseText.textContent = String(todayNetPP);
            } else {
                pulseText.textContent = '0';
            }
        }

        // Visual state classes (both pulse-score-* and pulse-net-* for compatibility)
        if (pulseSquare) {
            pulseSquare.classList.remove(
                'pulse-score-positive', 'pulse-score-negative', 'pulse-score-neutral',
                'pulse-net-positive', 'pulse-net-negative', 'pulse-net-zero'
            );
            if (todayNetPP > 0) {
                pulseSquare.classList.add('pulse-score-positive', 'pulse-net-positive');
            } else if (todayNetPP < 0) {
                pulseSquare.classList.add('pulse-score-negative', 'pulse-net-negative');
            } else {
                pulseSquare.classList.add('pulse-score-neutral', 'pulse-net-zero');
            }
        }

        // Ring color + progress
        if (scoreCircle) {
            if (todayNetPP > 0) {
                scoreCircle.setAttribute('stroke', '#00ff9d');
                _setRingProgress('scoreCircle', Math.min(100, (todayNetPP / 200) * 100));
            } else if (todayNetPP < 0) {
                scoreCircle.setAttribute('stroke', '#ff4c4c');
                _setRingProgress('scoreCircle', Math.min(100, (Math.abs(todayNetPP) / 100) * 100));
            } else {
                scoreCircle.setAttribute('stroke', '#00d1ff');
                _setRingProgress('scoreCircle', 0);
            }
        }

        // Hover text with Earned/Lost/Net breakdown + today vs yesterday
        const breakdown = _getTodayPPBreakdownSafe();
        const yesterdayNetPP = _getYesterdayNetPP();
        const pulseHover = document.getElementById('pulse-hover');
        if (pulseHover) {
            let hoverMsg = '';
            if (breakdown.actionCount > 0) {
                const netSign = breakdown.net >= 0 ? '+' : '';
                hoverMsg = `Earned: +${breakdown.earned} PP | Lost: -${breakdown.lost} PP | Net: ${netSign}${breakdown.net} PP`;
            } else {
                hoverMsg = 'No PP activity today';
            }
            const diff = todayNetPP - yesterdayNetPP;
            if (diff > 0) {
                hoverMsg += ` | +${diff} vs yesterday`;
            } else if (diff < 0) {
                hoverMsg += ` | ${diff} vs yesterday`;
            } else if (yesterdayNetPP !== 0 || todayNetPP !== 0) {
                hoverMsg += ' | Same as yesterday';
            }
            pulseHover.textContent = hoverMsg;
        }

        // Also refresh PP Breakdown tooltip if open
        try { _renderPPBreakdown(); } catch (e) { /* silent */ }
    }

    // ════════════════════════════════════════════════════════
    //  BADGES
    // ════════════════════════════════════════════════════════

    function _displayBadges() {
        const container = document.getElementById('badgeContainer');
        if (!container) return;

        const activeBadges = SafeStorage.getItem('activeBadges', []);

        if (!activeBadges || !Array.isArray(activeBadges) || activeBadges.length === 0) {
            container.innerHTML = '<p style="color:#666; font-size:0.7rem;">No Active Techniques</p>';
            return;
        }

        // Badge class mapping based on name
        function getBadgeClass(name) {
            const lower = (name || '').toLowerCase();
            if (lower.includes('legendary') || lower.includes('architect')) return 'legendary';
            if (lower.includes('focus') || lower.includes('deep work')) return 'focus';
            if (lower.includes('recall') || lower.includes('memory')) return 'recall';
            if (lower.includes('strategy') || lower.includes('tactical')) return 'strategy';
            return 'focus';
        }

        // Technique icon mapping: prefer the stored technique icon, then exact normalized name fallback.
        function getBadgeEmoji(badge, name) {
            if (badge && typeof badge === 'object' && typeof badge.icon === 'string' && badge.icon.trim()) {
                return badge.icon.trim();
            }

            const normalized = String(name || '').trim().toLowerCase();
            if (TECHNIQUE_ICON_MAP_NORMALIZED[normalized]) {
                return TECHNIQUE_ICON_MAP_NORMALIZED[normalized];
            }

            const lower = normalized;
            if (lower.includes('legendary') || lower.includes('architect')) return '\uD83D\uDC51';
            if (lower.includes('focus') || lower.includes('deep work')) return '\uD83C\uDFAF';
            if (lower.includes('recall') || lower.includes('memory')) return '\uD83E\uDDE0';
            if (lower.includes('strategy') || lower.includes('tactical')) return '\u2694\uFE0F';
            if (lower.includes('speed')) return '\u26A1';
            if (lower.includes('streak')) return '\uD83D\uDD25';
            return '\uD83C\uDFAF';
        }

        container.innerHTML = activeBadges.map(badge => {
            const name = typeof badge === 'string' ? badge : (badge.name || badge.title || 'Unknown');
            const cssClass = getBadgeClass(name);
            const emoji = getBadgeEmoji(badge, name);
            return `<div class="badge-item ${cssClass}">
                <span class="badge-emoji">${_escHtml(emoji)}</span>
                <span class="badge-name">${_escHtml(name)}</span>
            </div>`;
        }).join('');
    }

    // ════════════════════════════════════════════════════════
    //  QUOTE
    // ════════════════════════════════════════════════════════

    function _displayRandomQuote() {
        const famousQuotes = [
            { q: '"I never lose. I either win or learn."', a: 'Nelson Mandela' },
            { q: '"It always seems impossible until it\'s done."', a: 'Nelson Mandela' },
            { q: '"The way to get started is to quit talking and begin doing."', a: 'Walt Disney' },
            { q: '"Success is not final, failure is not fatal: it is the courage to continue that counts."', a: 'Winston Churchill' },
            { q: '"Your time is limited, so don\'t waste it living someone else\'s life."', a: 'Steve Jobs' },
            { q: '"Work hard in silence, let your success be your noise."', a: 'Frank Ocean' },
            { q: '"Don\'t decrease the goal. Increase the effort."', a: 'Grant Cardone' },
            { q: '"Arise, awake, and stop not till the goal is reached."', a: 'Swami Vivekananda' },
            { q: '"Discipline is the way, I make Mistakes but I always Comeback"', a: 'Hayato' }
        ];

        const randomIndex = Math.floor(Math.random() * famousQuotes.length);
        const quote = famousQuotes[randomIndex];

        const quoteText = document.getElementById('quoteText');
        const quoteAuthor = document.getElementById('quoteAuthor');

        if (quoteText) quoteText.textContent = quote.q;
        if (quoteAuthor) quoteAuthor.textContent = '\u2014 ' + quote.a;
    }

    // ════════════════════════════════════════════════════════
    // ════════════════════════════════════════════════════════
    //  ASHUKARI'S SMART NEXT STEP (RPM Wave 2B)
    //  Rule-based deterministic next-step engine.
    //  Replaces the old 9-Level Action Hint with a richer card.
    // ════════════════════════════════════════════════════════

    /** Safely get today's net PP (reuses _getTodayNetPP). */
    function _getTodayNetPPSafe() {
        try { return _getTodayNetPP(); } catch (e) { return 0; }
    }

    /** Find chapters with retention < 40 from memory decay data. */
    function _getCriticalMemoryChapter() {
        try {
            const masterData = SafeStorage.getItem(MASTER_KEY, {});
            const decayData = SafeStorage.getItem('smart_padhai_memory_decay', {});
            let lowestRetention = 100;
            let criticalChapter = null;

            // Check memory decay storage
            if (decayData && typeof decayData === 'object' && !Array.isArray(decayData)) {
                for (const chapKey in decayData) {
                    const meta = decayData[chapKey];
                    if (!meta || typeof meta !== 'object') continue;
                    const ret = Number(meta.retention ?? 100);
                    if (Number.isFinite(ret) && ret < 40 && ret < lowestRetention) {
                        lowestRetention = ret;
                        // Try to find a friendly chapter name
                        const entry = masterData && masterData[chapKey];
                        criticalChapter = {
                            name: (entry && !entry._scheduledFor) ? chapKey : chapKey,
                            retention: ret,
                            subject: meta.subject || chapKey.split('—')[0] || chapKey.split('-')[0] || ''
                        };
                    }
                }
            }

            // Also check memoryMeta inside smartPadhaiData entries
            if (masterData && typeof masterData === 'object' && !Array.isArray(masterData)) {
                for (const chap in masterData) {
                    const entry = masterData[chap];
                    if (!entry || typeof entry !== 'object') continue;
                    if (entry.memoryMeta) {
                        const ret = Number(entry.memoryMeta.retention ?? 100);
                        if (Number.isFinite(ret) && ret < 40 && ret < lowestRetention) {
                            lowestRetention = ret;
                            criticalChapter = {
                                name: chap,
                                retention: ret,
                                subject: chap.split('—')[0] || chap.split('-')[0] || ''
                            };
                        }
                    }
                }
            }

            return criticalChapter; // null if no critical memory
        } catch (e) { return null; }
    }

    /** Find the top critical/high backlog task. */
    function _getTopBacklogTaskSafe() {
        try {
            const backlog = _analyzeBacklogForDirective();
            if (backlog.topCriticalTask) {
                return {
                    title: backlog.topCriticalTask,
                    subject: backlog.topCriticalTask.split('—')[0] || backlog.topCriticalTask.split('-')[0] || '',
                    isCritical: backlog.criticalCount > 0,
                    isOverdue: backlog.overdueCount > 0
                };
            }
            return null;
        } catch (e) { return null; }
    }

    /** Find critical syllabus gaps. */
    function _getCriticalSyllabusGapSafe() {
        try {
            const syllabus = _analyzeSyllabusForDirective();
            if (syllabus.topRiskChapter || syllabus.criticalGaps > 0 || syllabus.highRiskGaps > 0) {
                return {
                    chapter: syllabus.topRiskChapter || 'Weakest chapter',
                    subject: (syllabus.topRiskChapter || '').split('—')[0] || (syllabus.topRiskChapter || '').split('-')[0] || '',
                    criticalGaps: syllabus.criticalGaps,
                    highRiskGaps: syllabus.highRiskGaps
                };
            }
            return null;
        } catch (e) { return null; }
    }

    /** Check for exam urgency (tomorrow or within 7 days). */
    function _getExamUrgencySafe() {
        try {
            const calendarData = SafeStorage.getItem('calendarStrategy', {});
            if (!calendarData || typeof calendarData !== 'object') return null;

            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const tomorrow = new Date(today);
            tomorrow.setDate(tomorrow.getDate() + 1);
            const tomorrowStr = tomorrow.toISOString().split('T')[0];
            const nextWeek = new Date(today);
            nextWeek.setDate(nextWeek.getDate() + 7);
            const nextWeekStr = nextWeek.toISOString().split('T')[0];

            let examTomorrow = null;
            let examThisWeek = null;

            for (const key in calendarData) {
                const event = calendarData[key];
                if (!event || (event.mode !== 'exam' && event.type !== 'exam')) continue;
                const eventDateStr = key.includes('-') ? key : (event.date || event.examDate || '');
                const subject = event.subject || event.text || event.title || 'Exam';

                if (eventDateStr === tomorrowStr || eventDateStr === tomorrow.toDateString()) {
                    examTomorrow = { subject, date: eventDateStr };
                } else if (eventDateStr >= tomorrowStr && eventDateStr <= nextWeekStr) {
                    if (!examThisWeek) examThisWeek = { subject, date: eventDateStr };
                }
            }

            return examTomorrow ? { type: 'tomorrow', ...examTomorrow } : examThisWeek ? { type: 'thisWeek', ...examThisWeek } : null;
        } catch (e) { return null; }
    }

    /** Get Weekly Reality Mirror signal (score, confidence). */
    function _getWeeklyRealitySignalSafe() {
        try {
            const report = _calculateWeeklyReality();
            return {
                weeklyScore: report.weeklyScore || 0,
                dataConfidence: report.dataConfidence || 'Low',
                hasData: report.hasData
            };
        } catch (e) {
            return { weeklyScore: 0, dataConfidence: 'Low', hasData: false };
        }
    }

    /** Get Optimal Study Window signal. */
    function _getOptimalWindowSignalSafe() {
        try {
            const analysis = _analyzeOptimalStudyWindows();
            if (!analysis || !analysis.bestBucket) return { active: false };

            // Determine if current time falls inside the best window
            const now = new Date();
            const currentHour = now.getHours() + now.getMinutes() / 60;
            const bucketDef = TIME_BUCKETS[analysis.bestBucket];
            if (!bucketDef) return { active: false, confidence: analysis.confidence };

            const inWindow = currentHour >= bucketDef.start && currentHour < bucketDef.end;
            return {
                active: inWindow,
                bestBucket: analysis.bestBucket,
                label: bucketDef.label,
                confidence: analysis.confidence
            };
        } catch (e) {
            return { active: false };
        }
    }

    /** Get streak safety signal. Streak System V2: uses Qualified Study Day. */
    function _getStreakSignalSafe() {
        try {
            const summary = _getStreakSystemSummarySafe();
            const currentStreak = Number(summary?.currentStreak || summary?.streak || 0);
            const todayQualified = summary?.todayQualified || false;
            const todayQuality = summary?.todayQuality || 'none';

            // If StreakSystem V2 is available, use qualification data
            if (summary && summary.todayQualified !== undefined) {
                return {
                    currentStreak,
                    todayHasActivity: todayQualified,
                    atRisk: currentStreak > 0 && !todayQualified,
                    quality: todayQuality
                };
            }

            // Legacy fallback
            const todayPP = _getTodayNetPPSafe();
            return {
                currentStreak,
                todayHasActivity: todayPP > 0,
                atRisk: currentStreak > 0 && todayPP <= 0,
                quality: todayPP > 0 ? 'secured' : 'none'
            };
        } catch (e) {
            return { currentStreak: 0, todayHasActivity: false, atRisk: false, quality: 'none' };
        }
    }

    /**
     * Generate the Smart Next Step using Ashukari's priority logic.
     * Returns a structured step object.
     */
    function _generateAshukariNextStep() {
        // ── Gather all signals ──
        const exam = _getExamUrgencySafe();
        const memory = _getCriticalMemoryChapter();
        const backlog = _getTopBacklogTaskSafe();
        const syllabus = _getCriticalSyllabusGapSafe();
        const todayPP = _getTodayNetPPSafe();
        const streak = _getStreakSignalSafe();
        const optimalWindow = _getOptimalWindowSignalSafe();
        const weekly = _getWeeklyRealitySignalSafe();

        // ── Priority 1: Exam tomorrow ──
        if (exam && exam.type === 'tomorrow') {
            return {
                type: 'exam',
                title: 'Activate Panic Protocol for ' + exam.subject,
                reason: 'Exam is tomorrow. Emergency revision has priority.',
                timeEstimate: '45\u201390 min',
                primaryAction: { label: 'Open Syllabus', target: 'syllabus' },
                secondaryAction: { label: 'Start Timer', target: 'timer' },
                toneLine: 'No experiments today. Only survival priorities.',
                confidence: 'High'
            };
        }

        // ── Priority 2: Memory Critical ──
        if (memory) {
            return {
                type: 'memoryCritical',
                title: 'Revise ' + memory.subject + ' \u2014 ' + memory.name,
                reason: 'Estimated retention is below safe level (' + memory.retention + '%).',
                timeEstimate: '25\u201345 min',
                primaryAction: { label: 'Open Syllabus', target: 'syllabus' },
                secondaryAction: { label: 'Start Timer', target: 'timer' },
                toneLine: 'Forgotten chapters do not forgive delay.',
                confidence: 'Medium'
            };
        }

        // ── Priority 3: Critical backlog ──
        if (backlog && (backlog.isCritical || backlog.isOverdue)) {
            return {
                type: 'backlog',
                title: 'Clear ' + backlog.title,
                reason: 'This task is ranked highest in backlog pressure.',
                timeEstimate: '30\u201360 min',
                primaryAction: { label: 'Open Backlog', target: 'backlog' },
                secondaryAction: { label: 'Start Timer', target: 'timer' },
                toneLine: 'Backlog grows in silence. Cut it now.',
                confidence: 'Medium'
            };
        }

        // ── Priority 4: Syllabus critical gap ──
        if (syllabus && syllabus.criticalGaps > 0) {
            return {
                type: 'syllabusGap',
                title: 'Fix ' + syllabus.subject + ' \u2014 ' + syllabus.chapter,
                reason: 'Syllabus Gap Analyzer marked this as high risk.',
                timeEstimate: '35\u201360 min',
                primaryAction: { label: 'Open Syllabus', target: 'syllabus' },
                secondaryAction: { label: 'Start Timer', target: 'timer' },
                toneLine: 'Weak links become exam traps.',
                confidence: 'Medium'
            };
        }

        // ── Priority 5: Today PP is 0 ──
        if (todayPP <= 0) {
            return {
                type: 'lowActivity',
                title: 'Complete one small mission',
                reason: 'No activity recorded today.',
                timeEstimate: '15\u201325 min',
                primaryAction: { label: 'Start Timer', target: 'timer' },
                secondaryAction: { label: 'Open Backlog', target: 'backlog' },
                toneLine: 'Momentum starts ugly. Start anyway.',
                confidence: 'High'
            };
        }

        // ── Priority 6: Streak at risk ──
        if (streak.atRisk) {
            return {
                type: 'streak',
                title: 'Protect your streak with one focused task',
                reason: 'Your ' + streak.currentStreak + '-day streak is active, but today has no PP yet.',
                timeEstimate: '20\u201330 min',
                primaryAction: { label: 'Start Timer', target: 'timer' },
                secondaryAction: { label: 'Open Backlog', target: 'backlog' },
                toneLine: 'Do not let a clean chain break quietly.',
                confidence: 'High'
            };
        }

        // ── Priority 7: Optimal study window active ──
        if (optimalWindow.active && optimalWindow.confidence !== 'Low') {
            return {
                type: 'optimalWindow',
                title: 'Start Deep Work now',
                reason: 'This is your strongest study window (' + (optimalWindow.label || 'now') + ').',
                timeEstimate: '45 min',
                primaryAction: { label: 'Start Timer', target: 'timer' },
                secondaryAction: { label: 'Open Syllabus', target: 'syllabus' },
                toneLine: 'Your brain is online. Use it.',
                confidence: optimalWindow.confidence
            };
        }

        // ── Priority 8: Weekly score low ──
        if (weekly.hasData && weekly.weeklyScore > 0 && weekly.weeklyScore < 4) {
            return {
                type: 'weeklyLow',
                title: 'Clear one high-value task today',
                reason: 'Weekly Reality Mirror shows weak momentum (' + weekly.weeklyScore + '/10).',
                timeEstimate: '30\u201345 min',
                primaryAction: { label: 'Open Backlog', target: 'backlog' },
                secondaryAction: { label: 'Start Timer', target: 'timer' },
                toneLine: 'Repair the week before it becomes a pattern.',
                confidence: weekly.dataConfidence
            };
        }

        // ── Priority 9: Default ──
        return {
            type: 'default',
            title: 'Complete the highest-value pending task',
            reason: 'No emergency detected. Build momentum.',
            timeEstimate: '25\u201335 min',
            primaryAction: { label: 'Open Backlog', target: 'backlog' },
            secondaryAction: { label: 'Start Timer', target: 'timer' },
            toneLine: 'Ordinary days build dangerous discipline.',
            confidence: 'Low'
        };
    }

    /**
     * Handle Ashukari action button clicks.
     * Uses existing SpaRouter for navigation, scrolls to timer for timer target.
     */
    function _handleAshukariAction(target) {
        try {
            if (target === 'syllabus' || target === 'backlog' || target === 'timetable') {
                if (window.SpaRouter && typeof window.SpaRouter.navigate === 'function') {
                    window.SpaRouter.navigate('/' + target);
                }
            } else if (target === 'timer') {
                // Scroll to focus timer section rather than auto-starting
                const timerCard = _container?.querySelector('.focus-timer-card');
                if (timerCard) {
                    timerCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    // Brief highlight
                    timerCard.style.boxShadow = '0 0 30px rgba(0, 212, 255, 0.5)';
                    setTimeout(() => { timerCard.style.boxShadow = ''; }, 1500);
                }
            } else if (target === 'panic') {
                // Navigate to syllabus as panic landing
                if (window.SpaRouter && typeof window.SpaRouter.navigate === 'function') {
                    window.SpaRouter.navigate('/syllabus');
                }
            }
        } catch (e) { /* safe: do not break app */ }
    }

    /**
     * Render the Smart Next Step card into the quickwin-strip area.
     * Replaces the old simple hintContent span.
     */
    function _renderAshukariNextStep() {
        const strip = _container?.querySelector('.quickwin-strip');
        if (!strip) return;

        const step = _generateAshukariNextStep();
        if (!step) return;

        // Confidence color class
        const confClass = step.confidence === 'High' ? 'ashukari-conf-high'
            : step.confidence === 'Medium' ? 'ashukari-conf-medium'
            : 'ashukari-conf-low';

        strip.innerHTML = `
            <div class="ashukari-next-step">
                <div class="ashukari-step-header">
                    <span class="ashukari-step-label">ASHUKARI\u2019S NEXT STEP</span>
                    <span class="ashukari-confidence ${confClass}">${step.confidence}</span>
                </div>
                <div class="ashukari-step-subtitle">One move. Right now. No overthinking.</div>
                <div class="ashukari-step-grid">
                    <div class="ashukari-step-main">
                        <div class="ashukari-step-field">
                            <span class="ashukari-step-key">Do Now:</span>
                            <span class="ashukari-step-value">${step.title}</span>
                        </div>
                        <div class="ashukari-step-field">
                            <span class="ashukari-step-key">Why:</span>
                            <span class="ashukari-step-reason">${step.reason}</span>
                        </div>
                        <div class="ashukari-step-field">
                            <span class="ashukari-step-key">Time:</span>
                            <span class="ashukari-step-time">${step.timeEstimate}</span>
                        </div>
                    </div>
                    <div class="ashukari-step-actions">
                        <button class="ashukari-step-btn ashukari-btn-primary" data-action="ashukari-action" data-target="${step.primaryAction.target}">${step.primaryAction.label}</button>
                        <button class="ashukari-step-btn ashukari-btn-secondary" data-action="ashukari-action" data-target="${step.secondaryAction.target}">${step.secondaryAction.label}</button>
                    </div>
                </div>
                <div class="ashukari-tone-line">\u201C${step.toneLine}\u201D</div>
            </div>
        `;
    }

    // ════════════════════════════════════════════════════════
    //  ASHUKARI EVENT LISTENERS (RPM Wave 2B)
    // ════════════════════════════════════════════════════════

    let _ashukariEventHandler = null;
    let _ashukariRenderPending = false;

    function _startAshukariEventListeners() {
        _stopAshukariEventListeners();
        _ashukariEventHandler = () => {
            // Debounce: avoid render loops from rapid events
            if (_ashukariRenderPending) return;
            _ashukariRenderPending = true;
            requestAnimationFrame(() => {
                try { _renderAshukariNextStep(); } catch (e) { /* silent */ }
                _ashukariRenderPending = false;
            });
        };
        window.addEventListener('smartPadhai:ppUpdated', _ashukariEventHandler);
        window.addEventListener('smartPadhai:streakUpdated', _ashukariEventHandler);
        window.addEventListener('smartPadhai:syllabusUpdated', _ashukariEventHandler);
        window.addEventListener('smartPadhai:memoryUpdated', _ashukariEventHandler);
        window.addEventListener('smartPadhai:backlogUpdated', _ashukariEventHandler);
        window.addEventListener('smartPadhai:sessionReviewSaved', _ashukariEventHandler);
    }

    function _stopAshukariEventListeners() {
        if (_ashukariEventHandler) {
            window.removeEventListener('smartPadhai:ppUpdated', _ashukariEventHandler);
            window.removeEventListener('smartPadhai:streakUpdated', _ashukariEventHandler);
            window.removeEventListener('smartPadhai:syllabusUpdated', _ashukariEventHandler);
            window.removeEventListener('smartPadhai:memoryUpdated', _ashukariEventHandler);
            window.removeEventListener('smartPadhai:backlogUpdated', _ashukariEventHandler);
            window.removeEventListener('smartPadhai:sessionReviewSaved', _ashukariEventHandler);
            _ashukariEventHandler = null;
        }
        _ashukariRenderPending = false;
    }

    // ════════════════════════════════════════════════════════
    //  FOCUS ACTIVATED MODE (RPM Wave 1: Upgraded from Ghost Mode)
    // ════════════════════════════════════════════════════════

    let _focusModeActive = false;

    function _toggleFocusMode() {
        const wrapper = _container?.querySelector('.dashboard-wrapper');
        if (!wrapper) return;

        _focusModeActive = !_focusModeActive;

        if (_focusModeActive) {
            // Enter Focus Activated Mode
            wrapper.classList.add('focus-activated-mode');
            document.body.classList.add('ghost-active');
            // Add blur-target to header children that should dim (not ghost button area)
            _applyHeaderFocusBlur(true);
        } else {
            // Exit Focus Activated Mode
            wrapper.classList.remove('focus-activated-mode');
            document.body.classList.remove('ghost-active');
            _applyHeaderFocusBlur(false);
        }

        // Update button text/style
        const ghostBtn = _container?.querySelector('#ghostBtn');
        if (ghostBtn) {
            if (_focusModeActive) {
                ghostBtn.textContent = 'Exit Focus';
                ghostBtn.style.opacity = '1';
                ghostBtn.style.boxShadow = '0 0 20px rgba(0,204,255,0.5)';
            } else {
                ghostBtn.textContent = 'Ghost Mode';
                ghostBtn.style.opacity = '';
                ghostBtn.style.boxShadow = '';
            }
        }
    }

    /**
     * Add/remove focus-blur-target on header inner elements
     * that should dim during focus mode. Ghost button stays clear.
     */
    function _applyHeaderFocusBlur(add) {
        const header = _container?.querySelector('#header');
        if (!header) return;

        // Elements to blur: hero-right, rank pill, pp section inner, badge container
        const targets = header.querySelectorAll('.hero-right, .hero-rank-pill, .pulse-bar-container, #badgeContainer, .pp-counter, .hero-quote-strip');
        targets.forEach(el => {
            if (add) {
                el.classList.add('focus-blur-target');
            } else {
                el.classList.remove('focus-blur-target');
            }
        });
    }

    function _exitFocusMode() {
        if (!_focusModeActive) return;
        _focusModeActive = false;
        const wrapper = _container?.querySelector('.dashboard-wrapper');
        if (wrapper) wrapper.classList.remove('focus-activated-mode');
        document.body.classList.remove('ghost-active');
        _applyHeaderFocusBlur(false);

        const ghostBtn = _container?.querySelector('#ghostBtn');
        if (ghostBtn) {
            ghostBtn.textContent = 'Ghost Mode';
            ghostBtn.style.opacity = '';
            ghostBtn.style.boxShadow = '';
        }
    }

    // ════════════════════════════════════════════════════════
    //  NEURAL SVG LINES (DEPRECATED — Phase 7D)
    //  Function definition kept for reference; no longer called.
    // ════════════════════════════════════════════════════════

    function _drawNeuralLines() {
        const svg = _container?.querySelector('#neural-svg');
        if (!svg) return;

        const squares = _container?.querySelectorAll('.stat-square');
        if (!squares || squares.length < 2) return;

        // Clear existing lines
        svg.innerHTML = '';

        // Get positions of stat squares
        const positions = [];
        squares.forEach(sq => {
            const rect = sq.getBoundingClientRect();
            const containerRect = svg.parentElement.getBoundingClientRect();
            positions.push({
                x: rect.left - containerRect.left + rect.width / 2,
                y: rect.top - containerRect.top + rect.height / 2
            });
        });

        // Draw bezier curves between adjacent squares
        for (let i = 0; i < positions.length - 1; i++) {
            const from = positions[i];
            const to = positions[i + 1];
            const midX = (from.x + to.x) / 2;
            const midY = (from.y + to.y) / 2;

            const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            const d = `M ${from.x} ${from.y} Q ${midX} ${from.y} ${midX} ${midY} T ${to.x} ${to.y}`;
            path.setAttribute('d', d);
            path.setAttribute('stroke', 'rgba(0, 204, 255, 0.15)');
            path.setAttribute('stroke-width', '1.5');
            path.setAttribute('fill', 'none');
            path.setAttribute('class', 'neural-path');
            svg.appendChild(path);
        }

        // Also draw a line from first to last for the loop effect
        if (positions.length >= 3) {
            const first = positions[0];
            const last = positions[positions.length - 1];
            const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            const cpx = first.x;
            const cpy = last.y;
            const d = `M ${first.x} ${first.y} Q ${cpx} ${cpy} ${last.x} ${last.y}`;
            path.setAttribute('d', d);
            path.setAttribute('stroke', 'rgba(0, 204, 255, 0.08)');
            path.setAttribute('stroke-width', '1');
            path.setAttribute('fill', 'none');
            path.setAttribute('class', 'neural-path-dim');
            svg.appendChild(path);
        }
    }

    // ════════════════════════════════════════════════════════
    //  RANK MODAL
    // ════════════════════════════════════════════════════════

    function _openRankModal() {
        if (typeof openRankModal === 'function') {
            openRankModal();
        } else {
            // Fallback: manually show modal
            const modal = document.getElementById('rank-modal');
            if (modal) modal.style.display = 'flex';
        }
    }

    function _closeRankModal() {
        if (typeof closeRankModal === 'function') {
            closeRankModal();
        } else {
            const modal = document.getElementById('rank-modal');
            if (modal) modal.style.display = 'none';
        }
    }

    function _showRankDetail(rankName) {
        if (typeof showRankDetail === 'function') {
            showRankDetail(rankName);
        }
    }

    // ════════════════════════════════════════════════════════
    //  SMART COOKIE JAR (RPM Wave 2C)
    //  Real achievement memory system. No fake data. No API calls.
    //  Inspired by David Goggins' Cookie Jar technique.
    // ════════════════════════════════════════════════════════

    let _cookieJarLastCookies = [];
    let _cookieJarEventHandler = null;
    let _cookieJarRenderPending = false;
    let _cookieJarMessageTimeout = null;

    /** Safely read Cookie Jar state from SafeStorage. */
    function _getCookieJarState() {
        try {
            const raw = SafeStorage.getItem('smart_padhai_cookie_jar_state', {});
            if (raw && typeof raw === 'object') return raw;
        } catch (e) { /* silent */ }
        return {};
    }

    /** Save Cookie Jar state to SafeStorage. */
    function _saveCookieJarState(state) {
        try {
            SafeStorage.setItem('smart_padhai_cookie_jar_state', state || {});
        } catch (e) { /* silent */ }
    }

    /** Show a temporary message inside the Cookie Jar modal. */
    function _showCookieJarMessage(message) {
        const el = _container?.querySelector('#cookieJarMessage');
        if (!el) return;
        el.textContent = message;
        el.classList.add('cookie-msg-show');
        if (_cookieJarMessageTimeout) clearTimeout(_cookieJarMessageTimeout);
        _cookieJarMessageTimeout = setTimeout(() => {
            el.classList.remove('cookie-msg-show');
        }, 1800);
    }

    /** Collect all real achievement data from app storage. Read-only. */
    function _getCookieJarDataSafe() {
        const data = {
            bestStreak: 0,
            currentStreak: 0,
            highestPP: 0,
            totalPP: 0,
            backlogCompletedCount: 0,
            backlogIsClean: false,
            reviewedCriticalCount: 0,
            autopsyCount: 0,
            highFocusCount: 0,
            completedNotebooks: 0,
            totalNotebooks: 0,
            todayPP: 0,
            hasBacklogPressure: false
        };

        try {
            // 1. StreakSystem
            if (window.StreakSystem && typeof window.StreakSystem.getStreakSummary === 'function') {
                const summary = window.StreakSystem.getStreakSummary();
                if (summary) {
                    data.bestStreak = Number(summary.bestStreak) || 0;
                    data.currentStreak = Number(summary.currentStreak) || 0;
                }
            }

            // 2. PP logs — find highest daily PP
            const ppLogs = _getPPLogsSafe();
            if (Array.isArray(ppLogs) && ppLogs.length > 0) {
                const dailyPP = {};
                let totalPP = 0;
                for (const log of ppLogs) {
                    const pts = Number(log.points) || 0;
                    totalPP += pts;
                    const dateKey = log.date || (log.timestamp ? new Date(log.timestamp).toISOString().split('T')[0] : null);
                    if (dateKey) {
                        dailyPP[dateKey] = (dailyPP[dateKey] || 0) + pts;
                    }
                }
                data.totalPP = totalPP;
                const dailyValues = Object.values(dailyPP);
                data.highestPP = dailyValues.length > 0 ? Math.max(...dailyValues) : 0;
            }

            // 3. Backlog — completed chapters & clean state
            const masterData = SafeStorage.getItem(MASTER_KEY, {});
            if (masterData && typeof masterData === 'object' && !Array.isArray(masterData)) {
                function toBool(v) { return v === true || v === 'true'; }
                let backlogPending = 0;
                let completedCount = 0;

                for (const chap in masterData) {
                    const entry = masterData[chap];
                    if (!entry || typeof entry !== 'object') continue;
                    if (entry._scheduledFor) continue;

                    const read = toBool(entry.read);
                    const notes = toBool(entry.notes);
                    const pyq = toBool(entry.pyq);
                    const started = read || notes || pyq;
                    const completed = read && notes && pyq;

                    if (completed) {
                        completedCount++;
                    } else if (started) {
                        backlogPending++;
                    }
                }
                data.backlogCompletedCount = completedCount;
                data.backlogIsClean = backlogPending === 0 && completedCount > 0;
                data.hasBacklogPressure = backlogPending > 0;
            }

            // 4. Memory decay — count recovered/reviewed critical chapters
            const decayData = SafeStorage.getItem('smart_padhai_memory_decay', {});
            if (decayData && typeof decayData === 'object' && !Array.isArray(decayData)) {
                let reviewedCritical = 0;
                for (const chapKey in decayData) {
                    const meta = decayData[chapKey];
                    if (!meta || typeof meta !== 'object') continue;
                    const ret = Number(meta.retention ?? 100);
                    // Count chapters that were critical (< 40) but have been reviewed since
                    if (Number.isFinite(ret) && meta.lastReviewed) {
                        if (ret >= 40) reviewedCritical++; // Recovered from decay
                    }
                }
                data.reviewedCriticalCount = reviewedCritical;
            }
            // Also check memoryMeta entries for reviewed chapters
            if (masterData && typeof masterData === 'object' && !Array.isArray(masterData)) {
                for (const chap in masterData) {
                    const entry = masterData[chap];
                    if (!entry || typeof entry !== 'object') continue;
                    if (entry.memoryMeta) {
                        const ret = Number(entry.memoryMeta.retention ?? 100);
                        if (Number.isFinite(ret) && ret >= 40 && entry.memoryMeta.lastReviewed) {
                            data.reviewedCriticalCount++;
                        }
                    }
                }
            }

            // 5. Autopsy reports
            data.autopsyCount = _getAutopsyReportsSafe().length;

            // 6. Session reviews — count high focus sessions
            const reviews = _getSessionReviews();
            if (Array.isArray(reviews)) {
                data.highFocusCount = reviews.filter(r => r && r.focusQuality === 'High').length;
            }

            // 7. Notebook data
            const notebookData = SafeStorage.getItem(NOTEBOOK_KEY, []);
            if (Array.isArray(notebookData)) {
                data.totalNotebooks = notebookData.length;
                data.completedNotebooks = notebookData.filter(row => row && row.done === true).length;
            }

            // 8. Today PP
            data.todayPP = _getTodayNetPPSafe();
        } catch (e) {
            console.warn('[SmartCookieJar] Data collection error:', e);
        }

        return data;
    }

    /** Generate all valid cookies from real data. Returns array of cookie objects with stable ids. */
    function _generateSmartCookies() {
        const data = _getCookieJarDataSafe();
        const cookies = [];

        // 1. STREAK COOKIE
        if (data.bestStreak >= 3) {
            cookies.push({
                id: 'streak_best',
                type: 'streak',
                text: `You built a ${data.bestStreak}-day streak.`,
                why: 'Consistency is not theory. You have already proved it.',
                useWhen: 'You feel like skipping today.',
                impactScore: data.bestStreak * 10
            });
        }

        // 2. PP COOKIE
        if (data.highestPP > 0) {
            cookies.push({
                id: 'pp_highest_day',
                type: 'pp',
                text: `You earned ${data.highestPP} PP in one day.`,
                why: 'That day proves you can create momentum fast.',
                useWhen: 'Today feels slow.',
                impactScore: data.highestPP / 10
            });
        }

        // 3. BACKLOG COOKIE
        if (data.backlogCompletedCount > 0 || data.backlogIsClean) {
            const countText = data.backlogCompletedCount > 0
                ? `You cleared ${data.backlogCompletedCount} backlog task${data.backlogCompletedCount > 1 ? 's' : ''}.`
                : 'You cleared serious backlog pressure before.';
            cookies.push({
                id: 'backlog_cleared',
                type: 'backlog',
                text: countText,
                why: 'Backlog is not permanent. It breaks when attacked.',
                useWhen: 'Pending tasks feel too many.',
                impactScore: data.backlogCompletedCount * 15
            });
        }

        // 4. MEMORY COOKIE
        if (data.reviewedCriticalCount > 0) {
            cookies.push({
                id: 'memory_reviewed',
                type: 'memory',
                text: `You recovered ${data.reviewedCriticalCount} weak chapter${data.reviewedCriticalCount > 1 ? 's' : ''} through revision.`,
                why: 'Memory can be rebuilt. Decay is not defeat.',
                useWhen: 'You feel like you forgot everything.',
                impactScore: data.reviewedCriticalCount * 20
            });
        }

        // 5. AUTOPSY COOKIE
        if (data.autopsyCount > 0) {
            cookies.push({
                id: 'autopsy_count',
                type: 'autopsy',
                text: `You analyzed ${data.autopsyCount} exam${data.autopsyCount > 1 ? 's' : ''} instead of emotionally reacting.`,
                why: 'That is how average scores become strategy.',
                useWhen: 'A test result hurts.',
                impactScore: data.autopsyCount * 20
            });
        }

        // 6. FOCUS COOKIE
        if (data.highFocusCount > 0) {
            cookies.push({
                id: 'focus_high_sessions',
                type: 'focus',
                text: `You logged ${data.highFocusCount} high-focus session${data.highFocusCount > 1 ? 's' : ''}.`,
                why: 'Focus is trainable, and you have trained it before.',
                useWhen: 'You feel distracted.',
                impactScore: data.highFocusCount * 8
            });
        }

        // 7. NOTEBOOK COOKIE
        if (data.completedNotebooks > 0) {
            cookies.push({
                id: 'notebook_completed',
                type: 'notebook',
                text: `You completed ${data.completedNotebooks} notebook${data.completedNotebooks > 1 ? 's' : ''}.`,
                why: 'Small physical work creates real academic control.',
                useWhen: 'Copy work feels boring.',
                impactScore: data.completedNotebooks * 10
            });
        }

        // 8. DEFAULT COOKIE — only if no other cookies exist
        if (cookies.length === 0) {
            cookies.push({
                id: 'default_cookie',
                type: 'default',
                text: 'Your Cookie Jar is waiting for proof.',
                why: 'Complete one mission today. The first cookie is earned, not given.',
                useWhen: 'You are starting from zero.',
                impactScore: 0
            });
        }

        return cookies;
    }

    /** Choose the featured cookie using priority logic and impact scores. */
    function _getFeaturedCookie(cookies) {
        if (!cookies || cookies.length === 0) return null;

        const data = _getCookieJarDataSafe();

        // Priority 1: If today PP is 0 → show Streak or PP cookie
        if (data.todayPP <= 0) {
            const streakCookie = cookies.find(c => c.type === 'streak');
            const ppCookie = cookies.find(c => c.type === 'pp');
            if (streakCookie) return streakCookie;
            if (ppCookie) return ppCookie;
        }

        // Priority 2: If backlog pressure exists → show Backlog cookie
        if (data.hasBacklogPressure) {
            const backlogCookie = cookies.find(c => c.type === 'backlog');
            if (backlogCookie) return backlogCookie;
        }

        // Priority 3: If memory critical chapters exist → show Memory cookie
        const criticalMem = _getCriticalMemoryChapter();
        if (criticalMem) {
            const memCookie = cookies.find(c => c.type === 'memory');
            if (memCookie) return memCookie;
        }

        // Priority 4: If recent autopsy exists → show Autopsy cookie
        if (data.autopsyCount > 0) {
            const autopsies = _getAutopsyReportsSafe();
            if (Array.isArray(autopsies) && autopsies.length > 0) {
                const latestAutopsy = autopsies[autopsies.length - 1];
                if (latestAutopsy && latestAutopsy.timestamp) {
                    const daysSince = (Date.now() - new Date(latestAutopsy.timestamp).getTime()) / (1000 * 60 * 60 * 24);
                    if (daysSince <= 14) {
                        const autopsyCookie = cookies.find(c => c.type === 'autopsy');
                        if (autopsyCookie) return autopsyCookie;
                    }
                }
            }
        }

        // Priority 5: If distracted/low focus pattern exists → show Focus cookie
        const reviews = _getSessionReviews();
        if (Array.isArray(reviews) && reviews.length >= 2) {
            const recentReviews = reviews.slice(-3);
            const lowFocusCount = recentReviews.filter(r => r && (r.focusQuality === 'Low' || r.focusQuality === 'Medium')).length;
            if (lowFocusCount >= 2) {
                const focusCookie = cookies.find(c => c.type === 'focus');
                if (focusCookie) return focusCookie;
            }
        }

        // Priority 6: Else show strongest cookie by impact score
        const nonDefault = cookies.filter(c => c.type !== 'default');
        if (nonDefault.length > 0) {
            nonDefault.sort((a, b) => b.impactScore - a.impactScore);
            return nonDefault[0];
        }

        return cookies[0]; // Default cookie
    }

    /** Render the Smart Cookie Jar modal content. */
    function _renderSmartCookieJar() {
        const modal = _container?.querySelector('#smartCookieJarModal');
        if (!modal) return;

        const cookies = _generateSmartCookies();
        _cookieJarLastCookies = cookies;

        if (!cookies || cookies.length === 0) return;

        // Determine which cookie to show: prefer saved state, fallback to featured
        const state = _getCookieJarState();
        let featured = null;

        if (state.currentCookieId) {
            featured = cookies.find(c => c.id === state.currentCookieId) || null;
        }

        if (!featured) {
            featured = _getFeaturedCookie(cookies);
            if (featured) {
                _saveCookieJarState({ currentCookieId: featured.id, lastUpdated: new Date().toISOString() });
            }
        }

        if (!featured) return;

        const unlockedCount = cookies.filter(c => c.type !== 'default').length;
        const isDefault = featured.type === 'default';
        const typeLabels = {
            streak: 'STREAK',
            pp: 'POWER',
            backlog: 'BACKLOG',
            memory: 'MEMORY',
            autopsy: 'AUTOPSY',
            focus: 'FOCUS',
            notebook: 'NOTEBOOK',
            default: 'START'
        };
        const typeLabel = typeLabels[featured.type] || 'COOKIE';

        const bodyEl = modal.querySelector('.scj-body');
        if (!bodyEl) return;

        bodyEl.innerHTML = `
            <div class="cookie-featured smart-cookie-card">
                <div class="cookie-jar-header">
                    <span class="cookie-jar-label">SMART COOKIE JAR</span>
                    <span class="cookie-jar-type-badge cookie-type-${featured.type}">${typeLabel}</span>
                </div>
                <div class="cookie-jar-subtitle">Proof you have done hard things before.</div>
                <div class="cookie-quote">\u201C${featured.text}\u201D</div>
                <div class="cookie-why">
                    <span class="cookie-why-label">Why it matters:</span>
                    ${featured.why}
                </div>
                <div class="cookie-use-when">
                    <span class="cookie-use-when-label">Use this when:</span>
                    ${featured.useWhen}
                </div>
            </div>
            <div class="cookie-unlocked-row">
                <span class="cookie-unlocked-count">${unlockedCount} cookie${unlockedCount !== 1 ? 's' : ''} unlocked</span>
            </div>
            <div id="cookieJarMessage" class="cookie-jar-message"></div>
            <div class="cookie-actions">
                ${unlockedCount > 1
                    ? '<button type="button" class="cookie-shuffle-btn" data-action="shuffle-cookie">Shuffle Cookie</button>'
                    : unlockedCount === 1
                        ? '<span class="cookie-only-one">Only one cookie unlocked so far.</span>'
                        : ''
                }
                ${isDefault
                    ? '<button type="button" class="cookie-action-btn cookie-action-timer" data-action="cookie-jar-action" data-target="timer">Start Timer</button>' +
                      '<button type="button" class="cookie-action-btn cookie-action-backlog" data-action="cookie-jar-action" data-target="backlog">Open Backlog</button>'
                    : '<button type="button" class="cookie-close-btn" data-action="close-cookie-jar">Got It</button>'
                }
            </div>
        `;
    }

    /** Open the Smart Cookie Jar modal. */
    function _openCookieJar() {
        const modal = _container?.querySelector('#smartCookieJarModal');
        if (!modal) return;

        // Reset to featured cookie on open
        _saveCookieJarState({ currentCookieId: null, lastUpdated: new Date().toISOString() });
        _renderSmartCookieJar();
        modal.style.display = 'flex';
        requestAnimationFrame(() => modal.classList.add('scj-open'));
    }

    /** Close the Smart Cookie Jar modal. */
    function _closeSmartCookieJar() {
        const modal = _container?.querySelector('#smartCookieJarModal');
        if (!modal) return;

        modal.classList.remove('scj-open');
        setTimeout(() => { modal.style.display = 'none'; }, 250);
    }

    /** Shuffle to another valid cookie. */
    function _shuffleSmartCookie() {
        const cookies = _generateSmartCookies();

        if (!cookies || cookies.length <= 1) {
            _showCookieJarMessage('Only one cookie unlocked so far.');
            return null;
        }

        const state = _getCookieJarState();
        const currentId = state.currentCookieId;

        // Find current cookie index in the generated list
        let currentIndex = cookies.findIndex(c => c.id === currentId);
        if (currentIndex < 0) currentIndex = 0;

        // Move to next cookie, wrapping around
        let nextIndex = (currentIndex + 1) % cookies.length;

        // Safety: avoid showing the same cookie immediately if possible
        if (cookies[nextIndex] && cookies[nextIndex].id === currentId && cookies.length > 1) {
            nextIndex = (nextIndex + 1) % cookies.length;
        }

        const nextCookie = cookies[nextIndex];
        if (!nextCookie) return null;

        _saveCookieJarState({
            currentCookieId: nextCookie.id,
            lastUpdated: new Date().toISOString()
        });

        _renderSmartCookieJar();

        // Shuffle flash animation
        const card = _container?.querySelector('.smart-cookie-card');
        if (card) {
            card.classList.remove('cookie-shuffle-flash');
            void card.offsetWidth; // force reflow
            card.classList.add('cookie-shuffle-flash');
        }

        return nextCookie;
    }

    /** Handle Cookie Jar action buttons. */
    function _handleCookieJarAction(target) {
        const action = target.dataset.target;
        _closeSmartCookieJar();

        if (action === 'timer') {
            // Scroll to focus timer card
            const timerCard = _container?.querySelector('.focus-timer-card');
            if (timerCard) {
                timerCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        } else if (action === 'backlog') {
            // Navigate to backlog route
            if (window.SpaRouter && typeof window.SpaRouter.navigate === 'function') {
                window.SpaRouter.navigate('backlog');
            }
        }
    }

    /** Start Smart Cookie Jar event listeners. */
    function _startCookieJarEventListeners() {
        _stopCookieJarEventListeners();
        _cookieJarEventHandler = () => {
            if (_cookieJarRenderPending) return;
            _cookieJarRenderPending = true;
            requestAnimationFrame(() => {
                try {
                    // Only re-render if modal is currently visible
                    const modal = _container?.querySelector('#smartCookieJarModal');
                    if (modal && modal.style.display !== 'none') {
                        _renderSmartCookieJar();
                    }
                } catch (e) { /* silent */ }
                _cookieJarRenderPending = false;
            });
        };
        window.addEventListener('smartPadhai:ppUpdated', _cookieJarEventHandler);
        window.addEventListener('smartPadhai:streakUpdated', _cookieJarEventHandler);
        window.addEventListener('smartPadhai:sessionReviewSaved', _cookieJarEventHandler);
        window.addEventListener('smartPadhai:memoryUpdated', _cookieJarEventHandler);
        window.addEventListener('smartPadhai:backlogUpdated', _cookieJarEventHandler);
        window.addEventListener('smartPadhai:autopsyUpdated', _cookieJarEventHandler);
    }

    /** Stop Smart Cookie Jar event listeners. */
    function _stopCookieJarEventListeners() {
        if (_cookieJarEventHandler) {
            window.removeEventListener('smartPadhai:ppUpdated', _cookieJarEventHandler);
            window.removeEventListener('smartPadhai:streakUpdated', _cookieJarEventHandler);
            window.removeEventListener('smartPadhai:sessionReviewSaved', _cookieJarEventHandler);
            window.removeEventListener('smartPadhai:memoryUpdated', _cookieJarEventHandler);
            window.removeEventListener('smartPadhai:backlogUpdated', _cookieJarEventHandler);
            window.removeEventListener('smartPadhai:autopsyUpdated', _cookieJarEventHandler);
            _cookieJarEventHandler = null;
        }
        _cookieJarRenderPending = false;
    }

    // ════════════════════════════════════════════════════════
    //  GRAPH ENGINE
    // ════════════════════════════════════════════════════════

    async function _initGraphEngine() {
        if (!window.GraphEngine) {
            console.warn('[DashboardRoute] GraphEngine not available on window yet.');
            return;
        }

        try {
            if (!_graphInitialized) {
                // First visit: full init (loads Supabase snapshots, records today, renders)
                await window.GraphEngine.init();
                _graphInitialized = true;
                console.log('[DashboardRoute] GraphEngine initialized (first visit)');
            } else {
                // Subsequent visits: just re-render dashboard with fresh data
                window.GraphEngine.renderDashboard();
                console.log('[DashboardRoute] GraphEngine re-rendered (return visit)');
            }
        } catch (err) {
            console.warn('[DashboardRoute] GraphEngine init/render failed:', err);
        }

        // Productivity Analytics Net PP Patch:
        // After GraphEngine renders (using positive-only pp_earned),
        // override the PP values with true net PP from logs.
        _renderProductivityNetPP();

        // Consistency Score Truth Patch (V2):
        // After GraphEngine renders, override consistency score with today's real data.
        _renderConsistencyScoreTruthPatch();

        // Productivity Reality Line:
        // Render data-driven quote strip after all productivity sections are initialized.
        _renderProductivityRealityLine();

        // Metric toggle and backfill buttons are wired via data-action delegation
    }

    // ════════════════════════════════════════════════════════
    //  TIMER ENGINE
    // ════════════════════════════════════════════════════════

    function _initTimerEngine() {
        if (window.TimerEngine) {
            // CRITICAL: Do NOT re-initialize TimerEngine. Just refresh UI.
            // The timer must survive route switches — only UI refresh, not reset.
            try {
                TimerEngine.updateUI();
                // Restore timer state if a timer was running before navigation
                TimerEngine.restoreTimerState();
            } catch (err) {
                console.warn('[DashboardRoute] TimerEngine UI refresh failed:', err);
            }
        }
    }

    // ════════════════════════════════════════════════════════
    //  PANIC PROTOCOL
    // ════════════════════════════════════════════════════════

   function _ensurePanicProtocolV2Loaded() {
        if (window.PanicProtocolV2) return Promise.resolve(true);

        if (_panicV2LoadPromise) return _panicV2LoadPromise;

        _panicV2LoadPromise = new Promise((resolve) => {
            try {
                const existing = document.querySelector(`script[src="${PANIC_V2_SCRIPT_PATH}"]`);
                if (existing) {
                    existing.addEventListener('load', () => resolve(Boolean(window.PanicProtocolV2)), { once: true });
                    existing.addEventListener('error', () => resolve(false), { once: true });
                    setTimeout(() => resolve(Boolean(window.PanicProtocolV2)), 0);
                    return;
                }

                const script = document.createElement('script');
                script.src = PANIC_V2_SCRIPT_PATH;
                script.defer = true;
                script.onload = () => resolve(Boolean(window.PanicProtocolV2));
                script.onerror = () => resolve(false);
                document.head.appendChild(script);
            } catch (error) {
                resolve(false);
            }
        });

        return _panicV2LoadPromise;
    }

   function _startPanicProtocol() {
        // V2A: prefer PanicProtocolV2 if loaded
        if (window.PanicProtocolV2) {
            try {
                const plan = PanicProtocolV2.generatePlan();
                _renderPanicV2Card(plan);
            } catch (err) {
                console.warn('[DashboardRoute] PanicProtocolV2.generatePlan() failed:', err);
                _renderPanicV2Card(null); // shows empty/fallback state
            }

            // Refresh every hour
            _panicInterval = setInterval(() => {
                if (window.PanicProtocolV2) {
                    try {
                        const plan = PanicProtocolV2.generatePlan();
                        _renderPanicV2Card(plan);
                    } catch (e) { /* silent */ }
                }
            }, 3600000);

            return; // V2A handled — skip V1
        }

        // V1 fallback (panicEngine.js still works if V2 not loaded)
        if (window.PanicProtocolEngine) {
            try {
                PanicProtocolEngine.run();
            } catch (err) {
                console.warn('[DashboardRoute] PanicProtocolEngine.run() failed:', err);
            }

            _panicInterval = setInterval(() => {
                if (window.PanicProtocolEngine) {
                    try { PanicProtocolEngine.refresh(); } catch (e) { /* silent */ }
                }
            }, 3600000);
        }
    }

   function _renderPanicV2Card(plan) {
        const card = _container ? _container.querySelector('#panicProtocolCard') : document.getElementById('panicProtocolCard');
        if (!card) return;
        _currentPanicV2Plan = plan || null;

        // ── Severity color data attribute ──
        const severity = plan?.severity || 'low';
        const planType = plan?.planType || 'NORMAL';
        card.setAttribute('data-severity', severity);
        card.setAttribute('data-plan', planType);
        card.classList.add('panic-v2-card');

        // ── No data / error state ──
        if (!plan || plan._lowConfidence) {
            const reason = plan?.reason || 'Add chapters to your syllabus to enable Panic Protocol V2.';
            const emptyBattlePlanHtml = _renderBattlePlan(plan?.dailyBattlePlan);
            const emptyAdaptivePlanHtml = _renderAdaptivePlan(plan?.adaptiveDayPlan, plan?.planType || 'NORMAL');
            const emptySyllabusTruthHtml = _renderSyllabusTruth(plan?.syllabusTruth);
            card.innerHTML = `
                <div class="panic-v2-header">
                    <h3 class="panic-v2-title">PANIC PROTOCOL ENGINE</h3>
                    <span class="panic-v2-mode">${_escHtml(plan?.modeLabel || 'Normal Mode')}</span>
                </div>
                <div class="panic-v2-empty">${_escHtml(reason)}</div>
                ${emptySyllabusTruthHtml}
                ${emptyBattlePlanHtml}
                ${emptyAdaptivePlanHtml}
                <div class="panic-v2-actions">
                    <button class="panic-v2-btn panic-v2-btn-primary primary" data-action="nav-syllabus">Open Syllabus</button>
                </div>
            `;
            return;
        }

        const {
            modeLabel, reason, daysLeft, examSubject,
            completionRate, backlogCount,
            rules, topChapters, alerts, dailyBattlePlan, adaptiveDayPlan, syllabusTruth
        } = plan;

        // ── Exam line ──
        let examLine = '';
        if (examSubject && daysLeft !== null) {
            examLine = ` · ${examSubject} exam in ${daysLeft} day${daysLeft !== 1 ? 's' : ''}`;
        } else if (daysLeft !== null) {
            examLine = ` · Exam in ${daysLeft} day${daysLeft !== 1 ? 's' : ''}`;
        }

        // ── Alerts HTML ──
        let alertsHtml = '';
        if (alerts && alerts.length) {
            alertsHtml = `<div class="panic-v2-alerts">${
                alerts.map(a => `<div class="panic-v2-alert">⚡ ${_escHtml(a)}</div>`).join('')
            }</div>`;
        }

        const syllabusTruthHtml = _renderSyllabusTruth(syllabusTruth);

        // ── Chapter list HTML ──
        const chaptersHtml = topChapters.length
            ? `<div class="panic-v2-list-label">Today's Priority</div>
               <div class="panic-v2-list">
                   ${topChapters.map((ch, i) => _renderChapterItem(ch, i)).join('')}
               </div>`
            : `<div class="panic-v2-empty" style="padding:8px 0 12px">No chapter candidates found. Keep logging study progress.</div>`;

        const battlePlanHtml = _renderBattlePlan(dailyBattlePlan);
        const adaptivePlanHtml = _renderAdaptivePlan(adaptiveDayPlan, planType);

        // ── Action buttons ──
        // Primary: Start Timer if chapters exist; else Open Syllabus
        const primaryBtn = topChapters.length
            ? `<button class="panic-v2-btn panic-v2-btn-primary primary" data-action="nav-timer">Start Timer</button>`
            : `<button class="panic-v2-btn panic-v2-btn-primary primary" data-action="nav-syllabus">Open Syllabus</button>`;
        const secondaryBtn = topChapters.length
            ? `<button class="panic-v2-btn panic-v2-btn-secondary" data-action="nav-syllabus">Syllabus</button>`
            : '';

        card.innerHTML = `
            <div class="panic-v2-header">
                <h3 class="panic-v2-title">PANIC PROTOCOL ENGINE</h3>
                <span class="panic-v2-mode">${_escHtml(modeLabel)}${examLine ? `<span style="font-weight:400;opacity:0.6;font-size:0.68rem"> ${_escHtml(examLine)}</span>` : ''}</span>
            </div>

            <p class="panic-v2-reason">${_escHtml(reason)}</p>

            <div class="panic-v2-method">
                <span class="panic-v2-method-label">Method:</span>
                <span>${_escHtml(rules.methodRatio)}</span>
            </div>

            ${alertsHtml}

            ${syllabusTruthHtml}

            ${chaptersHtml}

            ${battlePlanHtml}

            ${adaptivePlanHtml}

            <div class="panic-v2-rules">
                <div class="panic-v2-rule do-rule">
                    <span class="panic-v2-rule-icon">✅</span>
                    <span><strong>DO:</strong> ${_escHtml(rules.doRule)}</span>
                </div>
                <div class="panic-v2-rule dont-rule">
                    <span class="panic-v2-rule-icon">🚫</span>
                    <span><strong>DON'T:</strong> ${_escHtml(rules.dontRule)}</span>
                </div>
            </div>

            <div class="panic-v2-actions">
                ${primaryBtn}
                ${secondaryBtn}
            </div>
        `;
    }

    function _renderBattlePlan(dailyBattlePlan) {
        const plan = dailyBattlePlan || {};
        const blocks = Array.isArray(plan.blocks) ? plan.blocks : [];
        const isOpen = _isBattlePlanOpen();
        const openClass = isOpen ? 'is-open' : 'is-collapsed';
        const toggleLabel = isOpen ? 'Collapse' : 'Expand';

        if (!blocks.length) {
            return `
                <div class="panic-v2-battle-plan ${openClass}">
                    <button type="button" class="panic-v2-battle-header" data-action="toggle-panic-battle-plan" aria-expanded="${isOpen}">
                        <span>Today's Battle Plan</span>
                        <span class="panic-v2-battle-header-meta">
                            <span class="panic-v2-battle-total">No blocks yet</span>
                            <span class="panic-v2-battle-toggle">${toggleLabel}</span>
                        </span>
                    </button>
                    <div class="panic-v2-battle-body" ${isOpen ? '' : 'hidden'}>
                        <div class="panic-v2-empty panic-v2-battle-empty">Track syllabus and memory data to generate battle blocks.</div>
                    </div>
                </div>
            `;
        }

        const totalMinutes = Number.isFinite(Number(plan.totalMinutes)) ? Number(plan.totalMinutes) : blocks.reduce((sum, block) => sum + (Number(block.estimatedMinutes) || 0), 0);
        const blocksHtml = blocks.map((block, index) => {
            const blockNumber = Number(block.blockNumber) || index + 1;
            const chapterName = block.chapterName || 'Untitled Chapter';
            const subject = _normalizeSubjectLabel(block.subject);
            const sessionLabel = block.sessionLabel || 'Mixed Practice';
            const estimatedMinutes = Number(block.estimatedMinutes) || 40;
            const instruction = block.instruction || 'Alternate self-testing and problem solving. Avoid passive rereading.';

            return `
                <div class="panic-v2-block">
                    <div class="panic-v2-block-index">${blockNumber}</div>
                    <div class="panic-v2-block-main">
                        <div class="panic-v2-block-title">${_escHtml(chapterName)}</div>
                        <div class="panic-v2-block-meta">${_escHtml(subject)} · ${_escHtml(sessionLabel)} · ${estimatedMinutes} min</div>
                        <div class="panic-v2-block-instruction">${_escHtml(instruction)}</div>
                    </div>
                    <div class="panic-v2-block-actions">
                        <button type="button" class="panic-v2-start-block-btn" data-action="panic-start-block" data-block-index="${index}">Start Block</button>
                    </div>
                </div>
            `;
        }).join('');

        const checkpoint = plan.checkpoint || 'After each block, mark what you got wrong. Do not reread passively.';

        return `
            <div class="panic-v2-battle-plan ${openClass}">
                <button type="button" class="panic-v2-battle-header" data-action="toggle-panic-battle-plan" aria-expanded="${isOpen}">
                    <span>Today's Battle Plan</span>
                    <span class="panic-v2-battle-header-meta">
                        <span class="panic-v2-battle-total">Total: ${totalMinutes} min</span>
                        <span class="panic-v2-battle-toggle">${toggleLabel}</span>
                    </span>
                </button>
                <div class="panic-v2-battle-body" ${isOpen ? '' : 'hidden'}>
                    <div class="panic-v2-block-list">
                        ${blocksHtml}
                    </div>
                    <div class="panic-v2-checkpoint">
                        <strong>Checkpoint:</strong> ${_escHtml(checkpoint)}
                    </div>
                </div>
            </div>
        `;
    }

    function _normalizeSubjectLabel(subject) {
        const value = String(subject || '').trim();
        return (!value || value.toLowerCase() === 'unknown') ? 'General' : value;
    }

    function _isBattlePlanOpen() {
        try {
            const saved = window.localStorage ? window.localStorage.getItem(PANIC_BATTLE_OPEN_KEY) : null;
            return saved === null ? true : saved !== 'false';
        } catch (e) {
            return true;
        }
    }

    function _setBattlePlanOpen(isOpen) {
        try {
            if (window.localStorage) window.localStorage.setItem(PANIC_BATTLE_OPEN_KEY, isOpen ? 'true' : 'false');
        } catch (e) { /* safe: persistence optional */ }

        const plan = _currentPanicV2Plan;
        if (plan && !_abortController?.signal?.aborted) {
            _renderPanicV2Card(plan);
        }
    }

    function _handlePanicStartBlock(index) {
        const block = _currentPanicV2Plan?.dailyBattlePlan?.blocks?.[index];
        const timerCard = _container?.querySelector('.focus-timer-card') || document.querySelector('.focus-timer-card');
        if (!timerCard) return;

        const minutes = Number(block?.estimatedMinutes);
        const customInput = document.getElementById('customDuration');
        if (customInput && Number.isFinite(minutes) && minutes >= 1 && minutes <= 180) {
            customInput.value = String(Math.round(minutes));
        }

        timerCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        timerCard.classList.add('panic-target-glow');
        window.setTimeout(() => {
            timerCard.classList.remove('panic-target-glow');
        }, 1500);
    }

    function _renderSyllabusTruth(syllabusTruth) {
        if (!syllabusTruth) return '';
        const hasScope = Boolean(syllabusTruth.hasScope);
        const cls = syllabusTruth.isSelected ? 'is-selected' : 'is-warning';
        const text = syllabusTruth.isSelected
            ? (syllabusTruth.message || `Using selected ${syllabusTruth.subject || 'exam'} syllabus.`)
            : 'Exam syllabus not selected. Plan may include general tracked tasks.';
        const actions = hasScope
            ? `<button type="button" class="exam-scope-btn" data-action="open-exam-scope-modal">Edit Scope</button>
               <button type="button" class="exam-scope-btn exam-scope-btn-danger" data-action="clear-exam-scope">Clear</button>`
            : `<button type="button" class="exam-scope-btn" data-action="open-exam-scope-modal">Set Exam Scope</button>`;
        return `
            <div class="panic-v2-syllabus-truth ${cls} exam-scope-status">
                <span>${_escHtml(text)}</span>
                <div class="exam-scope-actions">${actions}</div>
            </div>
        `;
    }

    function _safeExamScopeChapterId(subject, chapterName) {
        const normalize = (value) => String(value || '')
            .trim()
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '_')
            .replace(/^_+|_+$/g, '');
        return `${normalize(subject || 'general')}__${normalize(chapterName || 'chapter')}`;
    }

    function _getExamScopeAcademicProfileSafe() {
        let profile = null;
        try {
            if (window.SMART_PADHAI_PROFILE && typeof window.SMART_PADHAI_PROFILE === 'object') {
                profile = window.SMART_PADHAI_PROFILE;
            }
            if ((!profile || Object.keys(profile).length === 0) && SafeStorage?.getItem) {
                profile = SafeStorage.getItem('smart_padhai_user_profile', null);
            }
        } catch (e) {
            profile = null;
        }

        if (!profile || typeof profile !== 'object') {
            return { classLevel: null, board: null, academicYear: null };
        }

        const rawClass = profile.classLevel ?? profile.class_level ?? profile.class ?? profile.grade ?? profile.standard;
        const classNum = Number(rawClass);
        return {
            classLevel: Number.isFinite(classNum) && classNum > 0 ? classNum : null,
            board: profile.board ? String(profile.board).trim().toUpperCase() : null,
            academicYear: (profile.academicYear || profile.academic_year) ? String(profile.academicYear || profile.academic_year).trim() : null
        };
    }

    function _examScopeEntryMatchesProfile(entry, profile) {
        if (!entry || typeof entry !== 'object' || entry.isSyllabus !== true) return false;

        if (entry.classLevel !== undefined && entry.classLevel !== null && entry.classLevel !== '' && profile?.classLevel) {
            if (Number(entry.classLevel) !== Number(profile.classLevel)) return false;
        }

        if (entry.board !== undefined && entry.board !== null && entry.board !== '' && profile?.board) {
            if (String(entry.board).trim().toUpperCase() !== profile.board) return false;
        }

        if (entry.academicYear !== undefined && entry.academicYear !== null && entry.academicYear !== '' && profile?.academicYear) {
            if (String(entry.academicYear).trim() !== profile.academicYear) return false;
        }

        return true;
    }

    function _getRealSyllabusChaptersForScope() {
        try {
            const masterData = SafeStorage.getItem(MASTER_KEY, {});
            if (!masterData || typeof masterData !== 'object' || Array.isArray(masterData)) return [];

            const profile = _getExamScopeAcademicProfileSafe();
            return Object.entries(masterData)
                .filter(([, raw]) => _examScopeEntryMatchesProfile(raw, profile))
                .map(([chapterKey, raw]) => ({
                    id: raw?.id || _safeExamScopeChapterId(raw?.subject || 'General', raw?.chapterName || raw?.chapter || raw?.name || chapterKey),
                    chapterName: raw?.chapterName || raw?.chapter || raw?.name || raw?.title || chapterKey,
                    subject: raw?.subject || 'General',
                    book: raw?.book || raw?.group || raw?.bookName || raw?.unit || '',
                    read: raw?.read === true || raw?.read === 'true',
                    notes: raw?.notes === true || raw?.notes === 'true',
                    pyq: raw?.pyq === true || raw?.pyq === 'true'
                }))
                .sort((a, b) => {
                    const subjectCompare = _normalizeSubjectLabel(a.subject).localeCompare(_normalizeSubjectLabel(b.subject));
                    if (subjectCompare) return subjectCompare;
                    const bookCompare = String(a.book || '').localeCompare(String(b.book || ''));
                    if (bookCompare) return bookCompare;
                    return String(a.chapterName || '').localeCompare(String(b.chapterName || ''));
                });
        } catch (e) {
            return [];
        }
    }

    function _getExamScopeChapters() {
        return _getRealSyllabusChaptersForScope();
    }

    function _getExamScopeSubjects(chapters) {
        const subjects = Array.from(new Set((chapters || []).map(ch => _normalizeSubjectLabel(ch.subject)).filter(Boolean))).sort();
        if (subjects.includes('Science')) return ['Science'].concat(subjects.filter(subject => subject !== 'Science'));
        return subjects;
    }

    function _refreshPanicV2Card() {
        if (!window.PanicProtocolV2) return;
        try {
            _renderPanicV2Card(window.PanicProtocolV2.generatePlan());
        } catch (e) { /* keep dashboard safe */ }
    }

    function _openExamScopeModal() {
        const chapters = _getExamScopeChapters();
        const subjects = _getExamScopeSubjects(chapters);
        const existing = window.PanicProtocolV2?.getExamScopeSafe ? window.PanicProtocolV2.getExamScopeSafe() : null;
        const preferredSubject = existing?.subject || _currentPanicV2Plan?.examSubject || (subjects.includes('Science') ? 'Science' : subjects[0] || 'General');
        _examScopeModalState = {
            subject: preferredSubject,
            examDate: existing?.examDate || '',
            selectedIds: new Set(existing?.selectedChapterIds || []),
            warning: ''
        };
        if (existing?.selectedChapterNames?.length) {
            chapters.forEach(chapter => {
                if (existing.selectedChapterNames.some(name => String(name).trim().toLowerCase() === String(chapter.chapterName).trim().toLowerCase())) {
                    _examScopeModalState.selectedIds.add(chapter.id || _safeExamScopeChapterId(chapter.subject, chapter.chapterName));
                }
            });
        }
        _renderExamScopeModal();
    }

    function _closeExamScopeModal() {
        const modal = _container?.querySelector('#examScopeModalOverlay') || document.getElementById('examScopeModalOverlay');
        if (modal) modal.remove();
    }

    function _renderExamScopeModal() {
        const chapters = _getExamScopeChapters();
        const subjects = _getExamScopeSubjects(chapters);
        const subject = _examScopeModalState.subject || subjects[0] || 'General';
        const subjectChapters = chapters.filter(ch => _normalizeSubjectLabel(ch.subject) === subject);
        const subjectOptions = subjects.length
            ? subjects.map(item => `<option value="${_escHtml(item)}" ${item === subject ? 'selected' : ''}>${_escHtml(item)}</option>`).join('')
            : '<option value="General">General</option>';
        const rows = subjectChapters.length
            ? subjectChapters.map(chapter => {
                const id = chapter.id || _safeExamScopeChapterId(chapter.subject, chapter.chapterName);
                const checked = _examScopeModalState.selectedIds.has(id) ? 'checked' : '';
                const bookMeta = chapter.book ? `${chapter.book} · ` : '';
                const meta = `${bookMeta}Read: ${chapter.read ? 'Done' : 'Pending'} · Notes: ${chapter.notes ? 'Done' : 'Pending'} · PYQ: ${chapter.pyq ? 'Done' : 'Pending'}`;
                return `
                    <label class="exam-scope-chapter-row">
                        <input type="checkbox" data-action="toggle-exam-scope-chapter" data-chapter-id="${_escHtml(id)}" ${checked}>
                        <span>
                            <strong>${_escHtml(chapter.chapterName)}</strong>
                            <span class="exam-scope-chapter-meta">${_escHtml(meta)}</span>
                        </span>
                    </label>
                `;
            }).join('')
            : '<div class="exam-scope-warning">No syllabus chapters found. Load syllabus from Syllabus page first.<br><button type="button" class="exam-scope-btn" data-action="nav-syllabus">Open Syllabus</button></div>';

        const html = `
            <div class="exam-scope-modal-overlay" id="examScopeModalOverlay">
                <div class="exam-scope-modal-card">
                    <div class="exam-scope-modal-header">
                        <div>
                            <h3>Set Exam Scope</h3>
                            <p>Select the chapters coming in your upcoming exam.</p>
                        </div>
                        <button type="button" class="exam-scope-btn" data-action="close-exam-scope-modal">Close</button>
                    </div>
                    <div class="exam-scope-field">
                        <label for="examScopeSubject">Subject</label>
                        <select id="examScopeSubject" class="exam-scope-input">${subjectOptions}</select>
                    </div>
                    <div class="exam-scope-field">
                        <label for="examScopeDate">Exam Date</label>
                        <input type="date" id="examScopeDate" class="exam-scope-input" value="${_escHtml(_examScopeModalState.examDate || '')}">
                    </div>
                    <div class="exam-scope-field">
                        <div class="exam-scope-actions exam-scope-modal-actions">
                            <button type="button" class="exam-scope-btn" data-action="exam-scope-select-all">Select All</button>
                            <button type="button" class="exam-scope-btn" data-action="exam-scope-clear-all">Clear</button>
                        </div>
                        <div class="exam-scope-chapter-list">${rows}</div>
                    </div>
                    ${_examScopeModalState.warning ? `<div class="exam-scope-warning">${_escHtml(_examScopeModalState.warning)}</div>` : ''}
                    <div class="exam-scope-footer">
                        <button type="button" class="exam-scope-btn" data-action="close-exam-scope-modal">Cancel</button>
                        <button type="button" class="exam-scope-btn exam-scope-btn-primary" data-action="save-exam-scope">Save Scope</button>
                    </div>
                </div>
            </div>
        `;
        _closeExamScopeModal();
        (_container || document.body).insertAdjacentHTML('beforeend', html);
    }

    function _saveExamScopeFromModal() {
        const subjectInput = document.getElementById('examScopeSubject');
        const dateInput = document.getElementById('examScopeDate');
        const subject = subjectInput?.value || _examScopeModalState.subject;
        const examDate = dateInput?.value || '';
        const chapters = _getExamScopeChapters().filter(chapter => _normalizeSubjectLabel(chapter.subject) === subject);
        const selected = chapters.filter(chapter => _examScopeModalState.selectedIds.has(chapter.id || _safeExamScopeChapterId(chapter.subject, chapter.chapterName)));
        if (!subject || selected.length === 0) {
            _examScopeModalState.warning = 'Select at least one chapter.';
            _renderExamScopeModal();
            return;
        }
        const scope = {
            subject,
            examDate,
            selectedChapterIds: selected.map(chapter => chapter.id || _safeExamScopeChapterId(chapter.subject, chapter.chapterName)),
            selectedChapterNames: selected.map(chapter => chapter.chapterName)
        };
        const saved = window.PanicProtocolV2?.saveExamScope ? window.PanicProtocolV2.saveExamScope(scope) : false;
        if (!saved) {
            _examScopeModalState.warning = 'Could not save exam scope. Try again.';
            _renderExamScopeModal();
            return;
        }
        _closeExamScopeModal();
        window.dispatchEvent(new CustomEvent('smartPadhai:examScopeUpdated'));
        _refreshPanicV2Card();
    }

    function _clearExamScope() {
        if (window.PanicProtocolV2?.clearExamScope) window.PanicProtocolV2.clearExamScope();
        window.dispatchEvent(new CustomEvent('smartPadhai:examScopeUpdated'));
        _refreshPanicV2Card();
    }

    function _renderAdaptivePlan(adaptiveDayPlan, planType) {
        const plan = adaptiveDayPlan || {};
        const days = Array.isArray(plan.days) ? plan.days : [];
        if (!days.length) return '';

        const isOpen = _isAdaptivePlanOpen(planType, plan.daysLeft);
        const openClass = isOpen ? 'is-open' : 'collapsed';
        const toggleLabel = isOpen ? 'Collapse' : 'Expand';
        const noChapterNote = plan.hasChapterData === false
            ? '<div class="panic-v2-adaptive-note">Track syllabus and memory data to generate chapter-specific plan.</div>'
            : '';

        const dayCards = days.map(day => {
            const chapters = Array.isArray(day.chapters) ? day.chapters.filter(Boolean).slice(0, 4) : [];
            const chaptersHtml = chapters.length
                ? `<div class="panic-v2-day-chapters">${chapters.map(chapter => _escHtml(chapter)).join(' · ')}</div>`
                : '';
            const method = day.blocks?.[0]?.method || day.method || '';
            const blocks = Array.isArray(day.blocks) ? day.blocks.slice(0, 4) : [];
            const blocksHtml = blocks.length
                ? `<div class="panic-v2-day-blocks">${blocks.map(block => `<span>${_escHtml(block.chapterName)} · ${_escHtml(block.method)} · ${Number(block.minutes) || 0} min</span>`).join('')}</div>`
                : '';
            const avoidHtml = day.avoid ? `<div class="panic-v2-day-avoid"><strong>Avoid:</strong> ${_escHtml(day.avoid)}</div>` : '';

            return `
                <div class="panic-v2-day-card">
                    <div class="panic-v2-day-top">
                        <span class="panic-v2-day-label">${_escHtml(day.label || `Day ${day.dayNumber || ''}`)}</span>
                        <span class="panic-v2-day-phase">${_escHtml(day.phase || 'Execute')}</span>
                    </div>
                    <div class="panic-v2-day-focus">${_escHtml(day.focus || 'Focused study block')}</div>
                    ${chaptersHtml}
                    ${method ? `<div class="panic-v2-day-method">${_escHtml(method)}</div>` : ''}
                    ${blocksHtml}
                    <div class="panic-v2-day-checkpoint"><strong>Checkpoint:</strong> ${_escHtml(day.checkpoint || 'Mark weak answers before moving on.')}</div>
                    ${avoidHtml}
                </div>
            `;
        }).join('');

        return `
            <div class="panic-v2-adaptive-plan ${openClass}">
                <button type="button" class="panic-v2-adaptive-header" data-action="toggle-panic-adaptive-plan" aria-expanded="${isOpen}">
                    <span>
                        <span class="panic-v2-adaptive-title">${_escHtml(plan.title || 'Adaptive Exam Plan')}</span>
                        <span class="panic-v2-adaptive-subtitle">${_escHtml(plan.subtitle || 'Follow this day-wise plan.')}</span>
                    </span>
                    <span class="panic-v2-timeline-toggle">${toggleLabel}</span>
                </button>
                <div class="panic-v2-adaptive-body" ${isOpen ? '' : 'hidden'}>
                    ${noChapterNote}
                    <div class="panic-v2-day-grid">
                        ${dayCards}
                    </div>
                    <div class="panic-v2-final-warning">${_escHtml(plan.finalWarning || 'Keep the plan focused and realistic.')}</div>
                </div>
            </div>
        `;
    }

    function _isAdaptivePlanOpen(planType, daysLeft) {
        try {
            const saved = window.localStorage ? window.localStorage.getItem(PANIC_ADAPTIVE_OPEN_KEY) : null;
            if (saved !== null) return saved !== 'false';
        } catch (e) { /* use default below */ }
        if (planType === 'NORMAL') return false;
        return !Number.isFinite(Number(daysLeft)) || Number(daysLeft) <= 7;
    }

    function _setAdaptivePlanOpen(isOpen) {
        try {
            if (window.localStorage) window.localStorage.setItem(PANIC_ADAPTIVE_OPEN_KEY, isOpen ? 'true' : 'false');
        } catch (e) { /* safe: persistence optional */ }

        const plan = _currentPanicV2Plan;
        if (plan && !_abortController?.signal?.aborted) {
            _renderPanicV2Card(plan);
        }
    }

    function _renderProtocolTimeline(protocolTimeline, planType) {
        const timeline = protocolTimeline || {};
        const days = Array.isArray(timeline.days) ? timeline.days : [];
        const isOpen = _isTimelineOpen(planType);
        const openClass = isOpen ? 'is-open' : 'collapsed';
        const toggleLabel = isOpen ? 'Collapse' : 'Expand';

        if (!days.length) return '';

        const stepsHtml = days.map((step, index) => {
            const hints = Array.isArray(step.chapterHints) ? step.chapterHints.filter(Boolean).slice(0, 3) : [];
            const hintsHtml = hints.length
                ? `<div class="panic-v2-timeline-chapters">${hints.map(hint => _escHtml(hint)).join(' · ')}</div>`
                : '';
            const ruleHtml = step.rule ? `<div class="panic-v2-timeline-rule">${_escHtml(step.rule)}</div>` : '';

            return `
                <div class="panic-v2-timeline-step">
                    <div class="panic-v2-timeline-marker">${index + 1}</div>
                    <div class="panic-v2-timeline-content">
                        <div class="panic-v2-timeline-top">
                            <span class="panic-v2-timeline-day">${_escHtml(step.dayLabel)}</span>
                            <span class="panic-v2-timeline-phase">${_escHtml(step.phase)}</span>
                        </div>
                        <div class="panic-v2-timeline-focus">${_escHtml(step.focus)}</div>
                        <div class="panic-v2-timeline-method">${_escHtml(step.method)}</div>
                        ${hintsHtml}
                        ${ruleHtml}
                    </div>
                </div>
            `;
        }).join('');

        return `
            <div class="panic-v2-timeline ${openClass}">
                <button type="button" class="panic-v2-timeline-header" data-action="toggle-panic-timeline" aria-expanded="${isOpen}">
                    <span>
                        <span class="panic-v2-timeline-title">${_escHtml(timeline.title || 'Protocol Timeline')}</span>
                        <span class="panic-v2-timeline-subtitle">${_escHtml(timeline.subtitle || 'Compact roadmap for this mode.')}</span>
                    </span>
                    <span class="panic-v2-timeline-toggle">${toggleLabel}</span>
                </button>
                <div class="panic-v2-timeline-body" ${isOpen ? '' : 'hidden'}>
                    <div class="panic-v2-timeline-list">
                        ${stepsHtml}
                    </div>
                    <div class="panic-v2-timeline-warning">${_escHtml(timeline.finalWarning || 'Keep the plan compact and focused.')}</div>
                </div>
            </div>
        `;
    }

    function _isTimelineOpen(planType) {
        try {
            const saved = window.localStorage ? window.localStorage.getItem(PANIC_TIMELINE_OPEN_KEY) : null;
            if (saved !== null) return saved !== 'false';
        } catch (e) { /* use default below */ }
        return planType !== 'NORMAL';
    }

    function _setTimelineOpen(isOpen) {
        try {
            if (window.localStorage) window.localStorage.setItem(PANIC_TIMELINE_OPEN_KEY, isOpen ? 'true' : 'false');
        } catch (e) { /* safe: persistence optional */ }

        const plan = _currentPanicV2Plan;
        if (plan && !_abortController?.signal?.aborted) {
            _renderPanicV2Card(plan);
        }
    }

    function _renderChapterItem(ch, index) {
        const rank = index + 1;
        const tagsHtml = (ch.reasonTags || []).map(tag => {
            const cls = _tagClass(tag);
            return `<span class="panic-v2-tag ${cls}">${_escHtml(tag)}</span>`;
        }).join('');
        const subject = _normalizeSubjectLabel(ch.subject);

        return `
            <div class="panic-v2-item panic-v2-priority-summary">
                <div class="panic-v2-rank">${rank}</div>
                <div class="panic-v2-chapter">
                    <div class="panic-v2-chapter-name">${_escHtml(ch.chapterName)}</div>
                    <div class="panic-v2-chapter-sub">
                        <span class="panic-v2-subject-badge">${_escHtml(subject)}</span>
                    </div>
                    ${tagsHtml ? `<div class="panic-v2-tags">${tagsHtml}</div>` : ''}
                </div>
            </div>
        `;
    }

    function _tagClass(tag) {
        const map = {
            'Memory Critical': 'tag-critical',
            'Backlog':         'tag-backlog',
            'Quick Win':       'tag-quickwin',
            'Autopsy Flag':    'tag-autopsy',
            'Not Started':     'tag-backlog'
        };
        return map[tag] || '';
    }

    function _escHtml(str) {
        if (str === null || str === undefined) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }


    // ════════════════════════════════════════════════════════
    //  DEV POINTS
    // ════════════════════════════════════════════════════════

    function _triggerDevPoints() {
        if (typeof triggerDevPoints === 'function') {
            triggerDevPoints();
        }
        // Check for rank change after dev points + refresh pulse score circle
        setTimeout(() => { _checkRankChange(); _renderWeeklyPPGoal(); _renderPPBreakdown(); _updatePulseScoreCircle(); }, 500);
    }

    // ════════════════════════════════════════════════════════
    //  TACTICAL DAILY DIRECTIVE
    //  Smart, data-based daily command for the student.
    //  Reads existing data only. No writes. No AI calls.
    // ════════════════════════════════════════════════════════

    /**
     * Get today's date as YYYY-MM-DD string.
     * FIX: Uses local time (not UTC) for correct day boundary matching.
     */
    function _getTodayDateKey() {
        return _getLocalDateKey();
    }

    /**
     * Safely read PP logs from SafeStorage.
     * Returns an array of log entries.
     */
    function _getPPLogsSafe() {
        try {
            const raw = SafeStorage.getItem('smart_padhai_pp_logs', []);
            if (!raw || !Array.isArray(raw)) return [];
            return raw;
        } catch (e) {
            return [];
        }
    }

    /**
     * Get today's earned PP from PPLogSystem or fallback.
     * FIX: No longer filters out negative values. Returns true net PP.
     */
    function _getDirectiveTodayPP() {
        try {
            if (typeof PPLogSystem !== 'undefined' && PPLogSystem.getTodayLogs) {
                const logs = PPLogSystem.getTodayLogs();
                if (Array.isArray(logs) && logs.length > 0) {
                    const total = logs.reduce((sum, log) => sum + (Number(log.points) || 0), 0);
                    return total;
                }
            }
        } catch (e) { /* fallback */ }
        // Fallback: use date-safe net PP
        return _getTodayNetPP();
    }

    /**
     * Get weekly PP earned from PPLogSystem or fallback.
     */
    function _getDirectiveWeeklyPP() {
        return _getWeeklyNetPPSafe();
    }

    function _getCurrentWeekNetPPSafe() {
        return _getWeeklyNetPPSafe();
    }

    function _getWeeklyPPGoalSafe() {
        try {
            const value = (typeof SafeStorage !== 'undefined' && SafeStorage?.getItem)
                ? SafeStorage.getItem('smart_padhai_weekly_pp_goal', 700)
                : 700;

            const goal = Number(value);
            return Number.isFinite(goal) && goal > 0 ? goal : 700;
        } catch (err) {
            console.warn('Weekly PP goal read failed:', err);
            return 700;
        }
    }

    function _setWeeklyPPGoalSafe(goal) {
        try {
            const cleanGoal = Math.round(Number(goal));
            if (!Number.isFinite(cleanGoal) || cleanGoal <= 0) {
                return { ok: false, message: 'Enter a valid weekly PP goal.' };
            }

            if (cleanGoal > 100000) {
                return { ok: false, message: 'Goal is too high. Keep it realistic.' };
            }

            if (typeof SafeStorage === 'undefined' || !SafeStorage?.setItem) {
                return { ok: false, message: 'Could not save weekly goal.' };
            }

            SafeStorage.setItem('smart_padhai_weekly_pp_goal', cleanGoal);

            window.dispatchEvent(new CustomEvent('smartPadhai:weeklyGoalUpdated', {
                detail: { goal: cleanGoal }
            }));

            return { ok: true, goal: cleanGoal };
        } catch (err) {
            console.error('Weekly PP goal save failed:', err);
            return { ok: false, message: 'Could not save weekly goal.' };
        }
    }

    /**
     * Get weekly PP goal from user-specific SafeStorage.
     */
    function _getDirectiveWeeklyGoal() {
        return _getWeeklyPPGoalSafe();
    }

    /**
     * Safely read backlog data from smartPadhaiData.
     * Returns { criticalCount, highCount, overdueCount, topCriticalTask }
     */
    function _analyzeBacklogForDirective() {
        const result = {
            criticalCount: 0,
            highCount: 0,
            overdueCount: 0,
            topCriticalTask: null
        };

        try {
            const masterData = SafeStorage.getItem(MASTER_KEY, {});
            if (!masterData || typeof masterData !== 'object' || Array.isArray(masterData)) return result;

            const today = new Date();
            today.setHours(0, 0, 0, 0);

            function toBool(v) { return v === true || v === 'true'; }

            for (const chap in masterData) {
                const entry = masterData[chap];
                if (!entry || typeof entry !== 'object') continue;
                if (entry._scheduledFor) continue; // Skip scheduled

                const read = toBool(entry.read);
                const notes = toBool(entry.notes);
                const pyq = toBool(entry.pyq);
                const started = read || notes || pyq;
                const completed = read && notes && pyq;

                if (!started || completed) continue; // Not a real backlog

                const doneCount = [read, notes, pyq].filter(Boolean).length;
                const leftCount = 3 - doneCount;

                if (leftCount === 2) {
                    result.criticalCount++;
                    if (!result.topCriticalTask) {
                        result.topCriticalTask = chap;
                    }
                } else if (leftCount === 1) {
                    result.highCount++;
                    if (!result.topCriticalTask) {
                        result.topCriticalTask = chap;
                    }
                }

                // Check overdue
                if (entry.dueDate) {
                    try {
                        const dueDate = new Date(entry.dueDate);
                        if (!isNaN(dueDate.getTime()) && dueDate < today) {
                            result.overdueCount++;
                        }
                    } catch (e) { /* skip */ }
                }
            }
        } catch (e) {
            console.warn('[DashboardRoute] Backlog analysis failed:', e);
        }

        return result;
    }

    /**
     * Safely read syllabus data for critical gaps.
     * Returns { criticalGaps, highRiskGaps, revisionPending, notesPending, topRiskChapter }
     */
    function _analyzeSyllabusForDirective() {
        const result = {
            criticalGaps: 0,
            highRiskGaps: 0,
            revisionPending: 0,
            notesPending: 0,
            topRiskChapter: null
        };

        try {
            // Check for syllabus gap analyzer data
            const gapData = SafeStorage.getItem('smart_padhai_syllabus_gaps', []);
            if (Array.isArray(gapData) && gapData.length > 0) {
                for (const gap of gapData) {
                    if (!gap || typeof gap !== 'object') continue;
                    const risk = (gap.riskLevel || '').toLowerCase();
                    if (risk === 'critical') {
                        result.criticalGaps++;
                        if (!result.topRiskChapter) {
                            result.topRiskChapter = gap.chapter || gap.title || null;
                        }
                    } else if (risk === 'high risk' || risk === 'high') {
                        result.highRiskGaps++;
                        if (!result.topRiskChapter) {
                            result.topRiskChapter = gap.chapter || gap.title || null;
                        }
                    }
                }
                return result;
            }

            // Fallback: scan smartPadhaiData for incomplete chapters marked as syllabus
            const masterData = SafeStorage.getItem(MASTER_KEY, {});
            if (!masterData || typeof masterData !== 'object' || Array.isArray(masterData)) return result;

            function toBool(v) { return v === true || v === 'true'; }

            for (const chap in masterData) {
                const entry = masterData[chap];
                if (!entry || typeof entry !== 'object') continue;
                if (!entry.isSyllabus) continue;

                const read = toBool(entry.read);
                const notes = toBool(entry.notes);
                const pyq = toBool(entry.pyq);

                if (!read && !notes && !pyq) {
                    // Untouched syllabus chapter - high risk
                    result.highRiskGaps++;
                    if (!result.topRiskChapter) {
                        result.topRiskChapter = chap;
                    }
                }
                if (!notes && (read || pyq)) result.notesPending++;
                if (!read) result.revisionPending++;
            }
        } catch (e) {
            console.warn('[DashboardRoute] Syllabus analysis failed:', e);
        }

        return result;
    }

    /**
     * Safely read session reviews for mood/focus patterns.
     * Returns { todayMood, avgFocus, isTiredPattern }
     */
    function _analyzeSessionReviewsForDirective() {
        const result = {
            todayMood: null,
            avgFocus: null,
            isTiredPattern: false
        };

        try {
            const reviews = _getSessionReviews();
            if (!reviews || !Array.isArray(reviews) || reviews.length === 0) return result;

            const today = _getTodayDateKey();
            const todayReviews = reviews.filter(r => r && r.date === today);

            if (todayReviews.length > 0) {
                // Find top mood today
                const moodCounts = {};
                todayReviews.forEach(r => {
                    if (r.mood) moodCounts[r.mood] = (moodCounts[r.mood] || 0) + 1;
                });
                const topMood = Object.entries(moodCounts).sort((a, b) => b[1] - a[1])[0];
                if (topMood) result.todayMood = topMood[0];

                // Calculate average focus
                const focusValues = { 'Low': 1, 'Medium': 2, 'High': 3 };
                const focusScores = todayReviews
                    .map(r => focusValues[r.focusQuality] || 0)
                    .filter(v => v > 0);
                if (focusScores.length > 0) {
                    result.avgFocus = focusScores.reduce((a, b) => a + b, 0) / focusScores.length;
                }

                // Check if tired pattern
                const tiredCount = todayReviews.filter(r => r.mood === 'Tired').length;
                result.isTiredPattern = tiredCount > todayReviews.length / 2;
            }
        } catch (e) {
            console.warn('[DashboardRoute] Session review analysis failed:', e);
        }

        return result;
    }

    /**
     * Generate the daily directive object based on priority rules.
     * Returns { status, primaryFocus, warning, command, quote, tone, links }
     */
    function _generateDailyDirective() {
        // Gather all data sources
        const backlog = _analyzeBacklogForDirective();
        const syllabus = _analyzeSyllabusForDirective();
        const todayPP = _getDirectiveTodayPP();
        const weeklyPP = _getDirectiveWeeklyPP();
        const weeklyGoal = _getDirectiveWeeklyGoal();
        const weeklyProgress = weeklyGoal > 0 ? (weeklyPP / weeklyGoal) * 100 : 0;
        const sessionReviews = _analyzeSessionReviewsForDirective();

        let streakData = { currentStreak: 0 };
        try {
            if (window.StreakSystem && typeof window.StreakSystem.getStreakSummary === 'function') {
                streakData = window.StreakSystem.getStreakSummary() || {};
            }
        } catch (e) { /* use default */ }
        const currentStreak = Number(streakData.currentStreak ?? streakData.streak ?? 0);

        // ── Priority Rules ──

        // Rule 1: Critical backlog tasks
        if (backlog.criticalCount > 0 || backlog.overdueCount > 0) {
            return {
                status: 'Backlog Pressure',
                primaryFocus: backlog.topCriticalTask || 'Highest-rank backlog task',
                warning: 'Backlog pressure rising.',
                command: 'Clear the top-ranked backlog task before starting lighter work.',
                quote: '"Delay is just backlog wearing a polite mask."',
                tone: 'danger',
                links: ['backlog']
            };
        }

        // Rule 2: Syllabus critical gaps
        if (syllabus.criticalGaps > 0 || syllabus.highRiskGaps > 0) {
            return {
                status: 'Syllabus Risk',
                primaryFocus: syllabus.topRiskChapter || 'Weakest syllabus chapter',
                warning: 'Weak chapter detected.',
                command: 'Fix the weakest syllabus gap today.',
                quote: '"Fix the weak link before the exam finds it."',
                tone: 'warning',
                links: ['syllabus']
            };
        }

        // Rule 3: No activity today
        if (todayPP === 0) {
            return {
                status: 'Low Activity',
                primaryFocus: 'First mission of the day',
                warning: 'No activity recorded today.',
                command: 'Complete one small task now to activate momentum.',
                quote: '"The first step breaks the inertia. Take it."',
                tone: 'recovery',
                links: ['backlog']
            };
        }

        // Rule 4: Weekly PP progress below 40%
        if (weeklyProgress < 40) {
            return {
                status: 'Momentum Building',
                primaryFocus: 'Weekly PP Goal',
                warning: 'Weekly goal progress is low.',
                command: 'Earn at least 100 PP today.',
                quote: '"Momentum is not magic. It is repeated action."',
                tone: 'warning',
                links: ['backlog', 'syllabus']
            };
        }

        // Rule 5: Good streak + active today
        if (currentStreak >= 3 && todayPP > 0) {
            return {
                status: 'Clean Momentum',
                primaryFocus: 'Maintain streak',
                warning: 'Do not break rhythm.',
                command: 'Complete one high-value task and protect the streak.',
                quote: '"Momentum is earned. Protect it."',
                tone: 'success',
                links: ['backlog', 'syllabus']
            };
        }

        // Rule 6: Session reviews show tired mood
        if (sessionReviews.isTiredPattern) {
            return {
                status: 'Recovery Mode',
                primaryFocus: 'Energy management',
                warning: 'Energy pattern is weak.',
                command: 'Use one lighter revision block before deep work.',
                quote: '"Restart small. Recover fast. Continue."',
                tone: 'recovery',
                links: ['syllabus']
            };
        }

        // Rule 7: Default
        return {
            status: 'Momentum Building',
            primaryFocus: "Today's top task",
            warning: 'Choose the difficult task first.',
            command: 'Complete one meaningful mission before checking comfort tasks.',
            quote: '"Discipline is not mood-based. Execute."',
            tone: 'stable',
            links: ['backlog', 'syllabus']
        };
    }

    /**
     * Render the Tactical Daily Directive card into the DOM.
     */
    function _renderDailyDirective() {
        const card = _container?.querySelector('#dailyDirectiveCard');
        if (!card) return;

        const directive = _generateDailyDirective();

        // Tone-based color map
        const toneColors = {
            danger:   { border: 'rgba(255, 76, 76, 0.6)', glow: 'rgba(255, 76, 76, 0.15)', text: '#FF4C4C', bg: 'rgba(255, 76, 76, 0.06)' },
            warning:  { border: 'rgba(255, 193, 7, 0.6)',  glow: 'rgba(255, 193, 7, 0.12)',  text: '#FFC107',  bg: 'rgba(255, 193, 7, 0.05)' },
            success:  { border: 'rgba(40, 167, 69, 0.6)',  glow: 'rgba(40, 167, 69, 0.12)',  text: '#28A745',  bg: 'rgba(40, 167, 69, 0.05)' },
            recovery: { border: 'rgba(0, 209, 255, 0.6)',  glow: 'rgba(0, 209, 255, 0.12)',  text: '#00d1ff',  bg: 'rgba(0, 209, 255, 0.05)' },
            stable:   { border: 'rgba(168, 85, 247, 0.5)', glow: 'rgba(168, 85, 247, 0.10)',  text: '#a855f7',  bg: 'rgba(168, 85, 247, 0.04)' }
        };
        const tone = toneColors[directive.tone] || toneColors.stable;

        // Check if navigation is available
        const canNavigate = window.SpaRouter && typeof window.SpaRouter.navigate === 'function';
        const showBacklogBtn = directive.links.includes('backlog');
        const showSyllabusBtn = directive.links.includes('syllabus');

        card.innerHTML = `
            <div class="tdd-inner" style="border-color: ${tone.border}; box-shadow: 0 0 30px ${tone.glow}, inset 0 0 20px ${tone.bg};">
                <div class="tdd-header">
                    <div class="tdd-title-row">
                        <span class="tdd-sword-icon">&#x2694;&#xFE0F;</span>
                        <h3 class="tdd-title">TACTICAL DAILY DIRECTIVE</h3>
                    </div>
                    <span class="tdd-status-badge" style="color: ${tone.text}; border-color: ${tone.border}; background: ${tone.bg};">
                        ${directive.status}
                    </span>
                </div>
                <div class="tdd-body">
                    <div class="tdd-left">
                        <div class="tdd-field">
                            <span class="tdd-icon">&#x1F3AF;</span>
                            <span class="tdd-label">Primary Focus:</span>
                            <span class="tdd-value">${directive.primaryFocus}</span>
                        </div>
                        <div class="tdd-field">
                            <span class="tdd-icon">&#x26A0;&#xFE0F;</span>
                            <span class="tdd-label">Warning:</span>
                            <span class="tdd-value" style="color: ${tone.text};">${directive.warning}</span>
                        </div>
                    </div>
                    <div class="tdd-center">
                        <span class="tdd-command-icon">&#x2694;&#xFE0F;</span>
                        <span class="tdd-command">${directive.command}</span>
                    </div>
                    <div class="tdd-right">
                        <button class="tdd-btn tdd-btn-backlog" data-action="directive-navigate" data-route="backlog" ${!canNavigate || !showBacklogBtn ? 'disabled' : ''}>
                            ${!canNavigate && showBacklogBtn ? 'Backlog Soon' : 'Open Backlog'}
                        </button>
                        <button class="tdd-btn tdd-btn-syllabus" data-action="directive-navigate" data-route="syllabus" ${!canNavigate || !showSyllabusBtn ? 'disabled' : ''}>
                            ${!canNavigate && showSyllabusBtn ? 'Syllabus Soon' : 'Open Syllabus'}
                        </button>
                    </div>
                </div>
                <div class="tdd-footer">
                    <span class="tdd-quote">${directive.quote}</span>
                    <span class="tdd-fire">&#x1F525;</span>
                </div>
            </div>
        `;
    }

    /**
     * Start listening for events that should trigger a directive refresh.
     */
    function _startDirectiveEventListeners() {
        if (!_abortController) return;
        const signal = _abortController.signal;

        const events = [
            'smartPadhai:ppUpdated',
            'smartPadhai:streakUpdated',
            'smartPadhai:timerSessionSaved',
            'smartPadhai:sessionReviewSaved',
            'smartPadhai:backlogUpdated',
            'smartPadhai:syllabusUpdated'
        ];

        events.forEach(eventName => {
            const handler = () => {
                try { _renderDailyDirective(); } catch (e) { /* silent */ }
                try { _renderWeeklyPPGoal(); } catch (e) { /* silent */ }
                try { _refreshSectionSummaries(); } catch (e) { /* silent */ }
                // FIX 7: Refresh Pulse Score Circle on PP/streak events
                try { _updatePulseScoreCircle(); } catch (e) { /* silent */ }
                // Refresh Optimal Study Window on data changes
                try { _renderOptimalStudyWindow(); } catch (e) { /* silent */ }
            };
            document.addEventListener(eventName, handler, { signal });
            _directiveEventHandlers.push({ event: eventName, handler });
        });
    }

    /**
     * Stop directive event listeners (cleanup on route switch).
     */
    function _stopDirectiveEventListeners() {
        _directiveEventHandlers.forEach(({ event, handler }) => {
            try { document.removeEventListener(event, handler); } catch (e) { /* silent */ }
        });
        _directiveEventHandlers = [];
    }

    // ════════════════════════════════════════════════════════
    //  DASHBOARD CLARITY & COMPACT MODE
    //  View toggle, collapsible sections, persistent state.
    //  (Constants defined at top of module for early access)
    // ════════════════════════════════════════════════════════

    // Section metadata: icon, title, summary getter
    const SECTION_META = {
        weeklyPPGoal: {
            icon: '&#9733;',
            title: 'Weekly PP Goal',
            getSummary: () => {
                try {
                    const wp = _getWeeklyNetPPSafe();
                    const wg = _getDirectiveWeeklyGoal();
                    if (wg > 0) return Math.min(100, Math.max(0, Math.round((wp / wg) * 100))) + '% complete';
                } catch (e) { /* fallback */ }
                return 'Weekly target status';
            }
        },
        weeklyRealityMirror: {
            icon: '&#128270;',
            title: 'Weekly Reality Mirror',
            getSummary: () => {
                try {
                    const verdictEl = document.getElementById('wrcVerdict');
                    if (verdictEl && verdictEl.textContent.trim()) return verdictEl.textContent.trim().substring(0, 30);
                    const scoreEl = document.getElementById('wrcScoreValue');
                    if (scoreEl && scoreEl.textContent.trim()) return 'Score: ' + scoreEl.textContent.trim();
                } catch (e) { /* fallback */ }
                return 'Weekly performance review';
            }
        },
        sessionInsights: {
            icon: '&#128221;',
            title: 'Session Insights',
            getSummary: () => {
                try {
                    const reviews = SafeStorage.getItem('smart_padhai_session_reviews', []);
                    if (Array.isArray(reviews)) {
                        const today = new Date().toISOString().split('T')[0];
                        const todayCount = reviews.filter(r => r && r.date === today).length;
                        if (todayCount > 0) return todayCount + ' review' + (todayCount !== 1 ? 's' : '') + ' today';
                    }
                } catch (e) { /* fallback */ }
                return 'Session quality log';
            }
        },
        weeklyInsights: {
            icon: '&#128200;',
            title: 'Weekly Insights',
            getSummary: () => {
                try {
                    if (window.StreakSystem && typeof StreakSystem.getStreakSummary === 'function') {
                        const s = StreakSystem.getStreakSummary();
                        if (s && s.activeDates) {
                            const now = new Date();
                            const prefix = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0');
                            const thisMonth = (s.activeDates || []).filter(d => typeof d === 'string' && d.startsWith(prefix)).length;
                            return thisMonth + ' active day' + (thisMonth !== 1 ? 's' : '') + ' this month';
                        }
                    }
                } catch (e) { /* fallback */ }
                return 'Weekly pattern summary';
            }
        },
        streakHeatmap: {
            icon: '&#128293;',
            title: 'Study Consistency Heatmap',
            getSummary: () => {
                return _selectedHeatmapRange + 'D consistency';
            }
        },
        optimalStudyWindow: {
            icon: '&#128336;',
            title: 'Optimal Study Window',
            getSummary: () => {
                try {
                    const analysis = _analyzeOptimalStudyWindows();
                    if (analysis.bestBucket) {
                        return _getTimeBucketLabel(analysis.bestBucket) + ' \u2014 best focus';
                    }
                } catch (e) { /* fallback */ }
                return 'Best study timing analysis';
            }
        },
        comebackCard: {
            icon: '&#128170;',
            title: 'Comeback Card',
            getSummary: () => {
                try {
                    if (window.ComebackSystem && typeof ComebackSystem.getStatus === 'function') {
                        const status = ComebackSystem.getStatus();
                        if (status) return status;
                    }
                    const data = SafeStorage.getItem('smart_padhai_comeback_data', null);
                    if (data && data.isActive) return 'Comeback Active';
                    if (data && data.daysSinceLastActive > 1) return 'At Risk';
                } catch (e) { /* fallback */ }
                return 'Recovery status';
            }
        },
        studyAutopsy: {
            icon: '&#128736;',
            title: 'Study Autopsy',
            getSummary: () => {
                try {
                    const reports = _getAutopsyReportsSafe();
                    if (Array.isArray(reports) && reports.length > 0) {
                        const latest = reports[reports.length - 1];
                        return latest.subject + ' — ' + latest.percentage + '% (' + latest.riskLabel + ')';
                    }
                } catch (e) { /* fallback */ }
                return 'Post-exam analysis';
            }
        },
        graphSection: {
            icon: '&#128202;',
            title: 'Productivity Analytics',
            getSummary: () => {
                return 'Focus, PP, sessions';
            }
        }
    };

    function _getDashboardViewMode() {
        try {
            const stored = SafeStorage.getItem(VIEW_MODE_KEY, null);
            if (stored === 'compact' || stored === 'full') return stored;
        } catch (e) { /* fallback */ }
        return 'full';
    }

    function _setDashboardViewMode(mode) {
        try {
            _dashboardViewMode = mode;
            SafeStorage.setItem(VIEW_MODE_KEY, mode);
        } catch (e) { /* silent */ }
    }

    function _getCollapsedSections() {
        try {
            const stored = SafeStorage.getItem(COLLAPSED_KEY, null);
            if (stored && typeof stored === 'object' && !Array.isArray(stored)) return stored;
        } catch (e) { /* fallback */ }
        return {};
    }

    function _saveCollapsedSections() {
        try {
            SafeStorage.setItem(COLLAPSED_KEY, _collapsedSections);
        } catch (e) { /* silent */ }
    }

    function _isSectionCollapsed(sectionId) {
        if (_collapsedSections[sectionId] === true) return true;
        if (_collapsedSections[sectionId] === false) return false;
        // Default: collapsed in compact mode, expanded in full mode
        return _dashboardViewMode === 'compact';
    }

    function _toggleDashboardSection(sectionId) {
        const wasCollapsed = _isSectionCollapsed(sectionId);
        _collapsedSections[sectionId] = !wasCollapsed;
        _saveCollapsedSections();

        const sectionEl = _container?.querySelector(`.dashboard-collapsible-section[data-section-id="${sectionId}"]`);
        if (!sectionEl) return;

        if (_collapsedSections[sectionId]) {
            sectionEl.classList.add('is-collapsed');
        } else {
            sectionEl.classList.remove('is-collapsed');
        }
        // Update arrow
        const arrow = sectionEl.querySelector('.dashboard-collapsible-arrow');
        if (arrow) arrow.textContent = _collapsedSections[sectionId] ? '\u25B6' : '\u25BC';
    }

    function _applyDashboardViewMode() {
        const wrapper = _container?.querySelector('.dashboard-wrapper');
        if (!wrapper) return;

        if (_dashboardViewMode === 'compact') {
            wrapper.classList.add('dashboard-compact-mode');
        } else {
            wrapper.classList.remove('dashboard-compact-mode');
        }

        // Update toggle buttons
        const btns = _container?.querySelectorAll('.dashboard-view-btn');
        if (btns) {
            btns.forEach(btn => {
                btn.classList.toggle('active', btn.dataset.viewMode === _dashboardViewMode);
            });
        }
    }

    function _getSectionSummary(sectionId) {
        const meta = SECTION_META[sectionId];
        if (meta && typeof meta.getSummary === 'function') {
            try { return meta.getSummary(); } catch (e) { /* fallback */ }
        }
        return '';
    }

    /**
     * Apply collapsed/expanded state to all collapsible sections in the DOM.
     * Called once after HTML render.
     */
    function _applyCollapsibleStates() {
        if (!_container) return;
        COLLAPSIBLE_SECTIONS.forEach(sectionId => {
            const sectionEl = _container.querySelector(`.dashboard-collapsible-section[data-section-id="${sectionId}"]`);
            if (!sectionEl) return;
            const isCollapsed = _isSectionCollapsed(sectionId);
            if (isCollapsed) {
                sectionEl.classList.add('is-collapsed');
            } else {
                sectionEl.classList.remove('is-collapsed');
            }
            const arrow = sectionEl.querySelector('.dashboard-collapsible-arrow');
            if (arrow) arrow.textContent = isCollapsed ? '\u25B6' : '\u25BC';
            const summary = sectionEl.querySelector('.dashboard-collapsible-summary');
            if (summary) {
                try { summary.textContent = _getSectionSummary(sectionId); } catch (e) { /* silent */ }
            }
        });
    }

    /**
     * Refresh all section summaries (called on data updates).
     */
    function _refreshSectionSummaries() {
        if (!_container) return;
        COLLAPSIBLE_SECTIONS.forEach(sectionId => {
            const summary = _container.querySelector(`.dashboard-collapsible-section[data-section-id="${sectionId}"] .dashboard-collapsible-summary`);
            if (summary) {
                try { summary.textContent = _getSectionSummary(sectionId); } catch (e) { /* silent */ }
            }
        });
    }

    // ════════════════════════════════════════════════════════
    //  WEEKLY REALITY MIRROR (Phase 9A Sprint 3B)
    //  Derived-only from SafeStorage. No Supabase writes.
    //  Multi-source merge, honest scoring, premium UI.
    // ════════════════════════════════════════════════════════

    /**
     * Build a per-day performance map for the last 7 days.
     * Merges: time_blocks_v1, productivity_snapshots_log,
     * pulse_engine_data, smartPadhaiData, notebook_matrix_data,
     * syllabus_master_tracker, badge_progress_v2.
     * Returns: { "YYYY-MM-DD": { ...dayData }, ... }
     * Never assigns lifetime PP as daily PP.
     */
    function _getWRMDateKeySafe(rawDate) {
        if (!rawDate) return '';
        const rawString = String(rawDate);
        if (rawString.includes('T')) {
            const parsed = new Date(rawString);
            if (isNaN(parsed.getTime())) return rawString.slice(0, 10);
            return _getLocalDateKey(parsed);
        }
        return rawString.slice(0, 10);
    }

    function _getWRMArraySafe(key) {
        try {
            if (typeof SafeStorage !== 'undefined' && SafeStorage?.getItem) {
                const value = SafeStorage.getItem(key, []);
                return Array.isArray(value) ? value : [];
            }
        } catch (e) { /* fallback */ }

        try {
            if (typeof localStorage === 'undefined') return [];
            const value = JSON.parse(localStorage.getItem(key) || '[]');
            return Array.isArray(value) ? value : [];
        } catch (e) {
            return [];
        }
    }

    /**
     * Build a per-day performance map for the current app week (Monday-Sunday).
     * Includes today using local-date keys and only counts dated current-week data.
     * Never assigns undated/lifetime/weekly totals to today.
     */
    function _buildDailyPerformanceMap() {
        const dayMap = {};
        const { start: weekStart, end: weekEnd } = _getCurrentWeekBounds();
        const todayKey = _getLocalDateKey(new Date());
        const weekStartKey = _getLocalDateKey(weekStart);
        const weekEndKey = _getLocalDateKey(weekEnd);

        // RPM Wave 2A: Confidence tracking flags
        let _hasProductivitySnapshots = false;
        let _hasDatedTimeBlocks = false;
        let _hasPPData = false;
        let _hasDatedFocusData = false;
        let _hasDatedSessionData = false;
        let _hasSyllabusDates = false;
        let _todayHasDatedActivity = false;

        let _notebookSnapshotTotal = 0;
        let _notebookHasDatedRows = false;

        function toBool(v) { return v === true || v === 'true'; }
        function isInWeek(dateKey) { return dateKey && dateKey >= weekStartKey && dateKey <= weekEndKey; }
        function getDay(dateKey) { return isInWeek(dateKey) ? dayMap[dateKey] : null; }
        function markToday(dateKey) { if (dateKey === todayKey) _todayHasDatedActivity = true; }

        // ── Initialize current week (Monday-Sunday) with local date keys ──
        const cursor = new Date(weekStart);
        while (_getLocalDateKey(cursor) <= weekEndKey) {
            const dateKey = _getLocalDateKey(cursor);
            dayMap[dateKey] = {
                date: dateKey,
                blocksPlanned: 0,
                blocksCompleted: 0,
                blocksMissed: 0,
                studyMinutes: 0,
                focusMinutesFromSnapshot: 0,
                sessionsCompleted: 0,
                ppEarned: 0,
                backlogCleared: 0,
                backlogPending: 0,
                notebookCompleted: 0,
                syllabusProgress: 0,
                score: 0,
                status: 'NO DATA',
                insight: ''
            };
            cursor.setDate(cursor.getDate() + 1);
        }

        // ── Source 1: productivity_snapshots_log (dated daily snapshots only) ──
        try {
            const snapshots = _getWRMArraySafe('productivity_snapshots_log');
            snapshots.forEach(snap => {
                if (!snap) return;
                const dateKey = _getWRMDateKeySafe(snap.snapshot_date || snap.date || snap.createdAt || snap.timestamp);
                const day = getDay(dateKey);
                if (!day) return;

                _hasProductivitySnapshots = true;
                markToday(dateKey);

                const sessions = Number(snap.sessions_completed || 0);
                const focusMinutes = Number(snap.focus_minutes || 0);
                const backlogCleared = Number(snap.backlogs_cleared || 0);

                if (Number.isFinite(sessions) && sessions > 0) {
                    day.blocksCompleted += sessions;
                }
                if (Number.isFinite(focusMinutes) && focusMinutes > 0) {
                    day.studyMinutes += focusMinutes;
                    day.focusMinutesFromSnapshot += focusMinutes;
                    _hasDatedFocusData = true;
                }
                if (Number.isFinite(backlogCleared) && backlogCleared > 0) {
                    day.backlogCleared += backlogCleared;
                }
            });
        } catch (e) { /* defensive */ }

        // ── Source 2: time_blocks_v1 (dated blocks only; no undated fallback to today) ──
        try {
            const blocksData = SafeStorage.getItem(TIME_BLOCKS_KEY, null);
            if (blocksData && typeof blocksData === 'object' && Array.isArray(blocksData.blocks)) {
                for (const block of blocksData.blocks) {
                    if (!block) continue;
                    const dateKey = _getWRMDateKeySafe(block.date || block.scheduledDate || block.day || block.started_at || block.completed_at);
                    const day = getDay(dateKey);
                    if (!day) continue;

                    _hasDatedTimeBlocks = true;
                    markToday(dateKey);

                    if (block.status === 'done' || block.completed === true) {
                        day.blocksCompleted++;
                    } else if (block.status === 'missed') {
                        day.blocksMissed++;
                    }
                    if (block.status === 'planned' || block.status === 'active' || block.status === 'done' || block.completed === true) {
                        day.blocksPlanned++;
                    }
                }
            }
        } catch (e) { /* defensive */ }

        // ── Source 3: focus/timer sessions (dated real sessions only) ──
        try {
            const focusSessions = _getWRMArraySafe('focus_sessions_log');
            focusSessions.forEach(session => {
                if (!session) return;
                const completed = session.completed !== false;
                const dateKey = _getWRMDateKeySafe(session.session_date || session.date || session.completed_at || session.completedAt || session.timestamp);
                const day = getDay(dateKey);
                if (!day || !completed) return;

                const minutes = Number(session.duration_minutes || session.minutes || session.focusMinutes || session.durationMinutes || 0);
                if (!Number.isFinite(minutes) || minutes <= 0) return;

                if (day.focusMinutesFromSnapshot > 0) {
                    day.studyMinutes = Math.max(0, day.studyMinutes - day.focusMinutesFromSnapshot);
                    day.focusMinutesFromSnapshot = 0;
                }
                day.studyMinutes += minutes;
                day.sessionsCompleted++;
                _hasDatedFocusData = true;
                _hasDatedSessionData = true;
                markToday(dateKey);
            });

            const timerSessions = _getWRMArraySafe('smart_padhai_timer_sessions');
            timerSessions.forEach(session => {
                if (!session) return;
                const dateKey = _getWRMDateKeySafe(session.date || session.createdAt || session.timestamp || session.completedAt || session.endedAt);
                const day = getDay(dateKey);
                if (!day) return;

                const minutes = Number(session.minutes || session.focusMinutes || session.durationMinutes || 0);
                if (!Number.isFinite(minutes) || minutes <= 0) return;

                if (day.focusMinutesFromSnapshot > 0) {
                    day.studyMinutes = Math.max(0, day.studyMinutes - day.focusMinutesFromSnapshot);
                    day.focusMinutesFromSnapshot = 0;
                }
                day.studyMinutes += minutes;
                day.sessionsCompleted++;
                _hasDatedFocusData = true;
                _hasDatedSessionData = true;
                markToday(dateKey);
            });
        } catch (e) { /* defensive */ }

        // ── Source 4: PP logs (per-day NET PP only; positive + negative) ──
        try {
            const logs = _getPPLogsForDateSafe();
            logs.forEach(log => {
                const dateKey = _getPPLogDateKeySafe(log);
                const day = getDay(dateKey);
                if (!day) return;

                day.ppEarned += _getPPLogPointsSafe(log);
                _hasPPData = true;
                markToday(dateKey);
            });
        } catch (e) { /* defensive */ }

        // ── Source 5: smartPadhaiData (dated backlog/syllabus activity only) ──
        try {
            const masterData = SafeStorage.getItem(MASTER_KEY, {});
            if (masterData && typeof masterData === 'object' && !Array.isArray(masterData)) {
                for (const chap in masterData) {
                    const entry = masterData[chap];
                    if (!entry || typeof entry !== 'object') continue;

                    const dateKey = _getWRMDateKeySafe(entry.completedAt || entry.completed_at || entry.lastUpdated || entry.updatedAt || entry.date);
                    const day = getDay(dateKey);
                    if (!day) continue;

                    const read = toBool(entry.read);
                    const notes = toBool(entry.notes);
                    const pyq = toBool(entry.pyq);
                    const completed = read && notes && pyq;
                    const started = read || notes || pyq;

                    if (completed) {
                        day.syllabusProgress++;
                        _hasSyllabusDates = true;
                        markToday(dateKey);

                        // A backlog is only cleared on this date if the completed item was actually started/backlogged.
                        if (started && !entry._scheduledFor) {
                            day.backlogCleared++;
                        }
                    }
                }
            }
        } catch (e) { /* defensive */ }

        // ── Source 6: notebook_matrix_data (dated rows only; no undated fallback) ──
        try {
            const notebookData = SafeStorage.getItem(NOTEBOOK_KEY, []);
            if (Array.isArray(notebookData)) {
                for (const row of notebookData) {
                    if (!row || row.done !== true) continue;
                    _notebookSnapshotTotal++;

                    const dateKey = _getWRMDateKeySafe(row.completedAt || row.completed_at || row.updatedAt || row.date);
                    const day = getDay(dateKey);
                    if (!day) continue;

                    day.notebookCompleted++;
                    _notebookHasDatedRows = true;
                    markToday(dateKey);
                }
            }
        } catch (e) { /* defensive */ }

        // ── Calculate scores per day ──
        for (const dateKey in dayMap) {
            const day = dayMap[dateKey];
            const hasAnyActivity = day.blocksCompleted > 0 || day.studyMinutes > 0 ||
                                   day.sessionsCompleted > 0 || day.ppEarned !== 0 ||
                                   day.syllabusProgress > 0 || day.notebookCompleted > 0 ||
                                   day.backlogCleared > 0 || day.blocksMissed > 0;

            if (!hasAnyActivity) {
                day.score = 0;
                day.status = 'NO DATA';
                continue;
            }

            const completionRatio = day.blocksPlanned > 0
                ? day.blocksCompleted / day.blocksPlanned
                : (day.sessionsCompleted > 0 || day.blocksCompleted > 0 ? 0.5 : 0);

            const completionScore = completionRatio * 3;
            const minutesScore = Math.min(day.studyMinutes / 180, 1) * 2;
            const sessionScore = Math.min(day.sessionsCompleted / 3, 1) * 1;
            const ppScore = Math.min(Math.max(0, day.ppEarned) / 80, 1) * 1;
            const backlogScore = Math.min(day.backlogCleared / 3, 1) * 1.5;
            const notebookScore = Math.min(day.notebookCompleted / 2, 1) * 0.8;
            const syllabusScore = Math.min(day.syllabusProgress / 3, 1) * 0.7;
            const missPenalty = Math.min(day.blocksMissed * 0.8, 3);

            const raw = completionScore + minutesScore + sessionScore + ppScore + backlogScore +
                        notebookScore + syllabusScore - missPenalty;
            day.score = Math.max(0, Math.min(10, Math.round(raw * 10) / 10));

            // Status mapping
            if (day.score === 0) day.status = 'SLIPPED';
            else if (day.score <= 3) day.status = 'SLIPPED';
            else if (day.score <= 5) day.status = 'LOW ENERGY';
            else if (day.score <= 7) day.status = 'STABLE';
            else if (day.score <= 9) day.status = 'FOCUSED';
            else day.status = 'PEAK';
        }

        return {
            dayMap,
            weekStartKey,
            weekEndKey,
            todayKey,
            confidenceFlags: {
                hasProductivitySnapshots: _hasProductivitySnapshots,
                hasDatedTimeBlocks: _hasDatedTimeBlocks,
                hasPPData: _hasPPData,
                hasDatedFocusData: _hasDatedFocusData,
                hasDatedSessionData: _hasDatedSessionData,
                hasNotebookDates: _notebookHasDatedRows,
                hasSyllabusDates: _hasSyllabusDates,
                todayHasDatedActivity: _todayHasDatedActivity,
                notebookSnapshotTotal: _notebookSnapshotTotal
            }
        };
    }

    /**
     * Calculate the full Weekly Reality Mirror report.
     * Uses _buildDailyPerformanceMap() for per-day data, then aggregates.
     * Returns a structured report object with score, verdict, target, etc.
     */
    function _calculateWeeklyReality() {
        const report = {
            hasData: false,
            weeklyScore: 0,
            weeklyScoreLabel: '',
            blocksCompleted: 0,
            blocksPlanned: 0,
            studyMinutes: 0,
            sessionsCompleted: 0,
            blocksMissed: 0,
            backlogCleared: 0,
            backlogPending: 0,
            notebookProgress: 0,
            syllabusProgress: 0,
            ppEarned: 0,      // Weekly PP only — NEVER lifetime
            streak: 0,
            dayBreakdown: [],  // [{ day, date, score, status }, ...]
            bestDay: null,
            weakestDay: null,
            verdict: '',
            nextWeekTarget: '',
            insight: '',
            // RPM Wave 2A: Data Confidence + Honest Wording
            dataConfidence: 'Low',
            dataConfidenceReasons: [],
            studyTimeIsEstimated: false,
            notebookSnapshotTotal: 0,
            weekStartKey: '',
            weekEndKey: '',
            todayKey: '',
            todayEntry: null,
            daysWithData: 0
        };

        try {
            const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

            // Build per-day map from current-week dated sources
            const buildResult = _buildDailyPerformanceMap();
            const dayMap = buildResult.dayMap;
            const cFlags = buildResult.confidenceFlags;
            report.weekStartKey = buildResult.weekStartKey;
            report.weekEndKey = buildResult.weekEndKey;
            report.todayKey = buildResult.todayKey;

            // ── Aggregate from current-week day map (Monday-Sunday, includes today) ──
            let totalScore = 0;
            let daysWithData = 0;
            let bestScore = -1;
            let worstScore = 11;

            const dayBreakdown = [];
            Object.keys(dayMap).sort().forEach(dateISO => {
                const dayDate = new Date(`${dateISO}T00:00:00`);
                const dayName = dayNames[dayDate.getDay()];
                const day = dayMap[dateISO] || { score: 0, status: 'NO DATA', blocksCompleted: 0, blocksPlanned: 0, blocksMissed: 0, studyMinutes: 0, sessionsCompleted: 0, ppEarned: 0, backlogCleared: 0, backlogPending: 0, notebookCompleted: 0, syllabusProgress: 0 };

                const dayEntry = {
                    day: dayName,
                    date: dateISO,
                    score: day.score,
                    status: day.status,
                    blocksCompleted: day.blocksCompleted,
                    studyMinutes: day.studyMinutes,
                    sessionsCompleted: day.sessionsCompleted,
                    ppEarned: day.ppEarned,
                    backlogCleared: day.backlogCleared,
                    notebookCompleted: day.notebookCompleted,
                    syllabusProgress: day.syllabusProgress
                };
                dayBreakdown.push(dayEntry);
                if (dateISO === report.todayKey) report.todayEntry = dayEntry;

                report.blocksCompleted += day.blocksCompleted;
                report.blocksPlanned += day.blocksPlanned;
                report.studyMinutes += day.studyMinutes;
                report.sessionsCompleted += day.sessionsCompleted;
                report.blocksMissed += day.blocksMissed;
                report.ppEarned += day.ppEarned;
                report.backlogCleared += day.backlogCleared;
                report.backlogPending += day.backlogPending;
                report.notebookProgress += day.notebookCompleted;
                report.syllabusProgress += day.syllabusProgress;

                if (day.status !== 'NO DATA') {
                    totalScore += day.score;
                    daysWithData++;
                    if (day.score > bestScore) {
                        bestScore = day.score;
                        report.bestDay = { day: dayName, score: day.score, blocksCompleted: day.blocksCompleted };
                    }
                    if (day.score < worstScore) {
                        worstScore = day.score;
                        report.weakestDay = { day: dayName, score: day.score, blocksCompleted: day.blocksCompleted };
                    }
                }
            });

            report.dayBreakdown = dayBreakdown;
            report.daysWithData = daysWithData;

            // ── Weekly score = average of days with data ──
            if (daysWithData > 0) {
                report.weeklyScore = Math.round((totalScore / daysWithData) * 10) / 10;
            }

            // ── Streak (RPM Wave 2A: prefer StreakSystem over PulseEngine) ──
            try {
                let streakVal = 0;
                if (window.StreakSystem?.getStreakSummary) {
                    const summary = window.StreakSystem.getStreakSummary();
                    streakVal = Number(summary?.currentStreak || 0);
                } else {
                    const pulseData = window.PulseEngine?.data || SafeStorage.getItem(PULSE_KEY, {});
                    if (pulseData && typeof pulseData === 'object') {
                        streakVal = Number(pulseData.streak ?? 0);
                    }
                }
                report.streak = Number.isFinite(streakVal) && streakVal >= 0 ? streakVal : 0;
            } catch (e) { /* defensive */ }

            // ── Has data? ──
            const hasAny = report.blocksCompleted > 0 || report.studyMinutes > 0 ||
                           report.sessionsCompleted > 0 || report.ppEarned !== 0 ||
                           report.syllabusProgress > 0 || report.notebookProgress > 0 ||
                           report.backlogCleared > 0 || report.blocksMissed > 0;
            report.hasData = hasAny;

            if (!hasAny) return report;

            // ── Weekly score label ──
            const s = report.weeklyScore;
            if (s >= 9) report.weeklyScoreLabel = 'Peak Week';
            else if (s >= 7) report.weeklyScoreLabel = 'Focused & Consistent';
            else if (s >= 5) report.weeklyScoreLabel = 'Stable but Inconsistent';
            else if (s >= 3) report.weeklyScoreLabel = 'Low Energy Week';
            else report.weeklyScoreLabel = 'Slipped Week';

            // ── Reality Verdict ──
            report.verdict = _generateVerdict(report);

            // ── Next Week Target ──
            report.nextWeekTarget = _generateNextWeekTarget(report);

            // ── Insight ──
            report.insight = _generateInsight(report);

            // ── RPM Wave 2A: Data Confidence ──
            const confidenceReasons = [];
            let sourceCount = 0;

            if (cFlags.hasProductivitySnapshots) {
                confidenceReasons.push('Productivity snapshots found');
                sourceCount++;
            }
            if (cFlags.hasDatedTimeBlocks) {
                confidenceReasons.push('Dated time blocks found');
                sourceCount++;
            }
            if (cFlags.hasPPData) {
                confidenceReasons.push('PP logs found');
                sourceCount++;
            }
            if (cFlags.hasDatedFocusData) {
                confidenceReasons.push('Dated focus data found');
                sourceCount++;
            }
            if (cFlags.hasDatedSessionData) {
                confidenceReasons.push('Dated session data found');
                sourceCount++;
            }
            if (cFlags.hasNotebookDates) {
                confidenceReasons.push('Notebook dates found');
                sourceCount++;
            }
            if (cFlags.hasSyllabusDates) {
                confidenceReasons.push('Syllabus dates found');
                sourceCount++;
            }
            if (!cFlags.hasNotebookDates && cFlags.notebookSnapshotTotal > 0) {
                confidenceReasons.push('Notebook dates missing');
            }
            if (!cFlags.hasDatedTimeBlocks && report.blocksCompleted > 0) {
                confidenceReasons.push('Time block dates missing');
            }
            if (!cFlags.todayHasDatedActivity) {
                confidenceReasons.push('Today has no dated activity yet.');
            }

            // High: 5+ days with data, PP logs or snapshots exist, time blocks have dates
            // Medium: 2-4 days with data, at least 2 data sources
            // Low: only 1 day with data, mostly snapshot, missing dates
            if (cFlags.todayHasDatedActivity && daysWithData >= 5 && sourceCount >= 3 && cFlags.hasDatedTimeBlocks) {
                report.dataConfidence = 'High';
            } else if (daysWithData >= 2 && sourceCount >= 2) {
                report.dataConfidence = 'Medium';
            } else {
                report.dataConfidence = 'Low';
            }
            report.dataConfidenceReasons = confidenceReasons;

            // ── RPM Wave 2A: Honest Wording ──
            // WRM no longer estimates focus minutes from block count; study minutes are dated source values only.
            report.studyTimeIsEstimated = false;
            report.notebookSnapshotTotal = cFlags.notebookSnapshotTotal;

        } catch (err) {
            console.warn('[DashboardRoute] Weekly Reality calculation error:', err);
        }

        return report;
    }

    function _getWeeklyRealityDebugSnapshot() {
        const buildResult = _buildDailyPerformanceMap();
        const report = _calculateWeeklyReality();
        return {
            todayKey: buildResult.todayKey,
            weekStartKey: buildResult.weekStartKey,
            weekEndKey: buildResult.weekEndKey,
            daysIncluded: Object.keys(buildResult.dayMap || {}).sort(),
            todayEntry: buildResult.dayMap?.[buildResult.todayKey] || null,
            sourceFlags: buildResult.confidenceFlags || {},
            dataConfidence: report.dataConfidence
        };
    }

    /**
     * Generate one honest verdict line about the week.
     */
    function _generateVerdict(r) {
        const completionRatio = r.blocksPlanned > 0 ? r.blocksCompleted / r.blocksPlanned : 0;

        if (r.weeklyScore >= 9) {
            return 'Peak performance. You executed at the highest level this week.';
        }
        if (r.weeklyScore >= 7) {
            if (r.blocksMissed > 0) {
                return 'Strong effort, but execution slipped because ' + r.blocksMissed + ' blocks were missed.';
            }
            return 'Good consistency. Now increase deep work time.';
        }
        if (r.weeklyScore >= 5) {
            if (r.backlogCleared > r.blocksCompleted) {
                return 'You cleared backlog well, but ignored planned timetable blocks.';
            }
            if (r.blocksMissed >= 3) {
                return 'Too many missed blocks dragging down an otherwise okay week.';
            }
            return 'Decent effort, but the gap between planned and done is too wide.';
        }
        if (r.weeklyScore >= 3) {
            if (r.studyMinutes < 60) {
                return 'Low study week. Restart with lighter targets.';
            }
            return 'Energy was low. Focus on showing up consistently, not perfectly.';
        }
        if (r.studyMinutes === 0 && r.blocksCompleted === 0) {
            return 'Almost no activity this week. Start small — even one block counts.';
        }
        return 'The week slipped away. Pick one subject and commit to it tomorrow.';
    }

    /**
     * Generate a practical next week target.
     */
    function _generateNextWeekTarget(r) {
        const completionRatio = r.blocksPlanned > 0 ? r.blocksCompleted / r.blocksPlanned : 0;

        if (r.weeklyScore >= 8) {
            if (r.streak >= 5) return 'Maintain your streak and try for a PEAK week.';
            return 'Complete 90% of planned blocks and aim for a PEAK week.';
        }
        if (completionRatio < 0.5 && r.blocksPlanned > 0) {
            return 'Complete 80% of planned blocks.';
        }
        if (r.blocksMissed >= 3) {
            return 'Miss zero blocks. Start each planned block on time.';
        }
        if (r.backlogPending > 2) {
            return 'Clear ' + Math.min(r.backlogPending, 3) + ' pending backlogs.';
        }
        if (r.studyMinutes < 90) {
            return 'Study at least 45 minutes for 5 days.';
        }
        if (r.notebookProgress === 0) {
            return 'Complete at least 2 notebook entries.';
        }
        if (r.syllabusProgress === 0) {
            return 'Finish at least 2 syllabus chapters.';
        }
        return 'Keep one subject as primary focus and go deep.';
    }

    /**
     * Generate one Alfred-style insight line.
     */
    function _generateInsight(r) {
        if (r.streak >= 7) {
            return 'A full week of consistency. The Architect operates on another level.';
        }
        if (r.streak >= 3) {
            return r.streak + '-day streak active. Momentum is building — protect it.';
        }
        if (r.weeklyScore >= 8) {
            return 'Execution rate: ' + r.weeklyScore + '/10. You plan it, you finish it.';
        }
        if (r.blocksCompleted >= 10) {
            return r.blocksCompleted + ' blocks completed. Solid volume — now push for consistency.';
        }
        if (r.blocksCompleted >= 5) {
            return 'Decent output. Tighten the gap between planned and done.';
        }
        if (r.blocksCompleted > 0) {
            return 'You showed up. Now raise the bar — more blocks, more finishes.';
        }
        return 'Some activity detected. Close the loop — finish what you start.';
    }

    /**
     * Get color class for a day based on score.
     */
    function _getDayColorClass(score) {
        if (score <= 0) return 'wrm-dot-nodata';
        if (score <= 3) return 'wrm-dot-slipped';
        if (score <= 5) return 'wrm-dot-low';
        if (score <= 7) return 'wrm-dot-stable';
        if (score <= 9) return 'wrm-dot-focused';
        return 'wrm-dot-peak';
    }

    /**
     * Render the Weekly Reality Mirror into the DOM.
     * Compact by default; click to expand full mirror panel.
     */
    function _renderWeeklyReportCard() {
        const card = _container?.querySelector('#weekly-report-card');
        if (!card) return;

        const report = _calculateWeeklyReality();

        if (!report.hasData) {
            card.innerHTML = `
                <div class="wrm-header" data-action="toggle-weekly-report" style="cursor: pointer;">
                    <span class="wrm-icon">\uD83D\uDD0D</span>
                    <span class="wrm-title">Weekly Reality Mirror · This week so far</span>
                </div>
                <div class="wrm-empty sp-empty-state">
                    <div class="wrm-empty-text sp-empty-state-title">Not Enough Data Yet</div>
                    <div class="wrm-empty-sub sp-empty-state-text">No dated current-week activity found yet. Today will appear here as soon as dated activity exists.</div>
                </div>
            `;
            return;
        }

        // ── 7-day dot graph ──
        const dotsHtml = report.dayBreakdown.map(d => {
            const colorClass = _getDayColorClass(d.score);
            const titleText = d.day + ': ' + d.score + '/10 (' + d.status + ')';
            return `<div class="wrm-dot-col">
                <div class="wrm-dot-label">${d.day}</div>
                <div class="wrm-dot ${colorClass}" title="${titleText}">
                    <span class="wrm-dot-score">${d.score > 0 ? d.score : '-'}</span>
                </div>
            </div>`;
        }).join('');

        // ── Study hours display ──
        const studyHours = Math.round(report.studyMinutes / 60 * 10) / 10;
        const studyDisplay = report.studyMinutes >= 60
            ? studyHours + 'h'
            : report.studyMinutes + 'm';

        // ── RPM Wave 2A: Data Confidence badge ──
        const confLevel = report.dataConfidence || 'Low';
        const confClass = confLevel === 'High' ? 'wrm-conf-high' : confLevel === 'Medium' ? 'wrm-conf-medium' : 'wrm-conf-low';
        const studyLabel = report.studyTimeIsEstimated ? 'Est. Study Time' : 'Study Time';

        // ── RPM Wave 2A: Estimated/partial warning line ──
        const showPartialWarning = confLevel === 'Low' || confLevel === 'Medium';

        // ── Compact summary ──
        card.innerHTML = `
            <div class="wrm-header" data-action="toggle-weekly-report" style="cursor: pointer;">
                <span class="wrm-icon">\uD83D\uDD0D</span>
                <span class="wrm-title">Weekly Reality Mirror · This week so far</span>
                <span class="wrm-conf-badge ${confClass}">${confLevel}</span>
                <span class="wrm-chevron" id="wrc-chevron">\u25B8</span>
            </div>
            <div class="wrm-score-bar">
                <div class="wrm-score-value">${report.weeklyScore}<span class="wrm-score-dim">/10</span></div>
                <div class="wrm-score-label">${report.weeklyScoreLabel}</div>
                <div class="wrm-score-streak">\uD83D\uDD25 ${report.streak}</div>
            </div>
            <div class="wrm-dots-row">
                ${dotsHtml}
            </div>
            <div class="wrm-verdict">\u201C${report.verdict}\u201D</div>
            ${showPartialWarning ? '<div class="wrm-partial-warning">Partial week data.</div>' : ''}
            <div class="wrm-detail" id="wrc-detail" style="display:none;">
                <div class="wrm-stats-grid">
                    <div class="wrm-stat-item">
                        <div class="wrm-stat-value">${report.blocksCompleted}<span class="wrm-stat-dim">/${report.blocksPlanned}</span></div>
                        <div class="wrm-stat-label">Blocks Done</div>
                    </div>
                    <div class="wrm-stat-item">
                        <div class="wrm-stat-value">${studyDisplay}</div>
                        <div class="wrm-stat-label">${studyLabel}</div>
                    </div>
                    <div class="wrm-stat-item">
                        <div class="wrm-stat-value">${report.blocksMissed}</div>
                        <div class="wrm-stat-label">Missed</div>
                    </div>
                    <div class="wrm-stat-item">
                        <div class="wrm-stat-value">${report.ppEarned !== 0 ? report.ppEarned : '\u2014'}</div>
                        <div class="wrm-stat-label">${report.ppEarned !== 0 ? 'Net PP' : 'PP'}</div>
                    </div>
                    <div class="wrm-stat-item">
                        <div class="wrm-stat-value">${report.backlogCleared}<span class="wrm-stat-dim">/${report.backlogPending}</span></div>
                        <div class="wrm-stat-label">Backlog Clr/Pnd</div>
                    </div>
                    <div class="wrm-stat-item">
                        <div class="wrm-stat-value">${report.notebookProgress}</div>
                        <div class="wrm-stat-label">Notebooks</div>
                    </div>
                    <div class="wrm-stat-item">
                        <div class="wrm-stat-value">${report.syllabusProgress}</div>
                        <div class="wrm-stat-label">Syllabus</div>
                    </div>
                    <div class="wrm-stat-item">
                        <div class="wrm-stat-value">${report.bestDay ? report.bestDay.day : '\u2014'}</div>
                        <div class="wrm-stat-label">Best Day</div>
                    </div>
                </div>
                ${report.weakestDay && report.weakestDay.score < 5 ? `<div class="wrm-weak-day">\u26A0\uFE0F Weakest: ${report.weakestDay.day} (${report.weakestDay.score}/10)</div>` : ''}
                <div class="wrm-insight">\uD83E\uDD16 ${report.insight}</div>
                <div class="wrm-target">\uD83C\uDFAF Next Week: ${report.nextWeekTarget}</div>
            </div>
        `;
    }

    /**
     * Toggle expand/collapse of the weekly reality mirror detail.
     */
    function _toggleWeeklyReportExpand() {
        const detail = _container?.querySelector('#wrc-detail');
        const chevron = _container?.querySelector('#wrc-chevron');
        if (!detail) return;

        const isExpanded = detail.style.display !== 'none';
        detail.style.display = isExpanded ? 'none' : 'block';
        if (chevron) {
            chevron.textContent = isExpanded ? '\u25B8' : '\u25BE';
        }
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING — Delegation + AbortController
    // ════════════════════════════════════════════════════════

    // ════════════════════════════════════════════════════════
    //  PP BREAKDOWN TOOLTIP (Sprint 9 — Discipline Economy)
    // ════════════════════════════════════════════════════════

    function _renderPPBreakdown() {
        const entriesEl = document.getElementById('ppBreakdownEntries');
        const netEl = document.getElementById('ppBreakdownNet');
        if (!entriesEl || !netEl) return;

        const breakdown = _getTodayPPBreakdownSafe();
        const netColor = breakdown.net > 0 ? '#00ff9d' : (breakdown.net < 0 ? '#ff4c4c' : '#6b7280');
        const netSign = breakdown.net > 0 ? '+' : '';

        entriesEl.innerHTML = `
            <div class="pp-entry-row">
                <span class="pp-entry-source">Earned</span>
                <span class="pp-entry-pts" style="color:#00ff9d;">+${breakdown.earned} PP</span>
            </div>
            <div class="pp-entry-row">
                <span class="pp-entry-source">Lost</span>
                <span class="pp-entry-pts" style="color:#ff4c4c;">-${breakdown.lost} PP</span>
            </div>
            <div class="pp-entry-row">
                <span class="pp-entry-source">Net</span>
                <span class="pp-entry-pts" style="color:${netColor};">${netSign}${breakdown.net} PP</span>
            </div>
        `;

        netEl.innerHTML = `<span class="pp-net-label">NET TODAY</span><span class="pp-net-value" style="color:${netColor};">${netSign}${breakdown.net} PP</span>`;
    }

    function _togglePPBreakdown() {
        const tooltip = document.getElementById('ppBreakdownTooltip');
        if (!tooltip) return;
        const isOpen = tooltip.classList.contains('pp-tooltip-open');
        if (isOpen) {
            tooltip.classList.remove('pp-tooltip-open');
        } else {
            _renderPPBreakdown();
            tooltip.classList.add('pp-tooltip-open');
        }
    }

    // ════════════════════════════════════════════════════════
    //  WEEKLY PP GOAL BAR (Sprint 9 — Discipline Economy)
    // ════════════════════════════════════════════════════════

    function _renderWeeklyPPGoal() {
        const weeklyPP = _getCurrentWeekNetPPSafe();
        const goal = _getWeeklyPPGoalSafe();
        const pct = goal > 0
            ? Math.min(100, Math.max(0, (weeklyPP / goal) * 100))
            : 0;

        const currentEl = document.getElementById('wpgCurrentValue');
        const goalEl = document.getElementById('wpgGoalValue');
        const fillEl = document.getElementById('wpgBarFill');
        const pctEl = document.getElementById('wpgPct');
        const statusEl = document.getElementById('wpgStatus');

        if (currentEl) currentEl.textContent = weeklyPP;
        if (goalEl) goalEl.textContent = goal;
        if (fillEl) fillEl.style.width = pct + '%';
        if (pctEl) pctEl.textContent = Math.round(pct) + '%';

        // Status message
        let statusMsg = '';
        let statusColor = '';
        if (pct >= 100) { statusMsg = 'Weekly target conquered.'; statusColor = '#00ff9d'; }
        else if (pct >= 76) { statusMsg = 'One final push.'; statusColor = '#00d4ff'; }
        else if (pct >= 41) { statusMsg = 'Momentum building.'; statusColor = '#f59e0b'; }
        else { statusMsg = 'Engine cold. Start moving.'; statusColor = '#ff4c4c'; }

        if (statusEl) {
            statusEl.textContent = statusMsg;
            statusEl.style.color = statusColor;
        }

        // Check weekly goal celebration
        if (pct >= 100 && typeof PPLogSystem !== 'undefined' && PPLogSystem.getCurrentWeekKey) {
            const weekKey = 'weekly_goal_' + PPLogSystem.getCurrentWeekKey();
            if (PPLogSystem.isCelebrationShown && PPLogSystem.markCelebrationShown && !PPLogSystem.isCelebrationShown(weekKey)) {
                PPLogSystem.markCelebrationShown(weekKey);
                _triggerCelebration('WEEKLY TARGET CONQUERED', `${weeklyPP} / ${goal} PP`, 'Discipline target achieved.');
            }
        }
    }

    // ════════════════════════════════════════════════════════
    //  CONFETTI SYSTEM (Sprint 9 — Discipline Economy)
    //  Lightweight canvas-based neon particle confetti.
    // ════════════════════════════════════════════════════════

    let _confettiAnimFrame = null;

    function _triggerConfetti() {
        const canvas = document.getElementById('spConfettiCanvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        canvas.style.display = 'block';

        const particles = [];
        const colors = ['#00d4ff', '#00ff9d', '#ffd700', '#ff4c4c', '#a855f7', '#ffffff'];
        const particleCount = 80;

        for (let i = 0; i < particleCount; i++) {
            particles.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height * 0.3 - canvas.height * 0.1,
                vx: (Math.random() - 0.5) * 6,
                vy: Math.random() * 3 + 2,
                size: Math.random() * 4 + 2,
                color: colors[Math.floor(Math.random() * colors.length)],
                alpha: 1,
                decay: Math.random() * 0.015 + 0.008,
                rotation: Math.random() * 360,
                rotationSpeed: (Math.random() - 0.5) * 10
            });
        }

        let startTime = Date.now();
        const duration = 1800; // 1.8 seconds

        function animate() {
            const elapsed = Date.now() - startTime;
            if (elapsed > duration) {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                canvas.style.display = 'none';
                if (_confettiAnimFrame) cancelAnimationFrame(_confettiAnimFrame);
                _confettiAnimFrame = null;
                return;
            }

            ctx.clearRect(0, 0, canvas.width, canvas.height);

            particles.forEach(p => {
                p.x += p.vx;
                p.vy += 0.08; // gravity
                p.y += p.vy;
                p.alpha -= p.decay;
                p.rotation += p.rotationSpeed;

                if (p.alpha <= 0) return;

                ctx.save();
                ctx.globalAlpha = Math.max(0, p.alpha);
                ctx.translate(p.x, p.y);
                ctx.rotate(p.rotation * Math.PI / 180);
                ctx.fillStyle = p.color;
                ctx.shadowBlur = 6;
                ctx.shadowColor = p.color;
                // Draw a small diamond/spark shape
                ctx.beginPath();
                ctx.moveTo(0, -p.size);
                ctx.lineTo(p.size * 0.6, 0);
                ctx.lineTo(0, p.size);
                ctx.lineTo(-p.size * 0.6, 0);
                ctx.closePath();
                ctx.fill();
                ctx.restore();
            });

            _confettiAnimFrame = requestAnimationFrame(animate);
        }

        if (_confettiAnimFrame) cancelAnimationFrame(_confettiAnimFrame);
        animate();
    }

    // ════════════════════════════════════════════════════════
    //  CELEBRATION MODAL (Sprint 9 — Discipline Economy)
    // ════════════════════════════════════════════════════════

    function _triggerCelebration(header, main, detail) {
        const overlay = document.getElementById('spCelebrationOverlay');
        const headerEl = document.getElementById('spCelebHeader');
        const mainEl = document.getElementById('spCelebMain');
        const detailEl = document.getElementById('spCelebDetail');
        if (!overlay) return;

        if (headerEl) headerEl.textContent = header;
        if (mainEl) mainEl.textContent = main;
        if (detailEl) detailEl.textContent = detail;

        overlay.classList.add('sp-celeb-open');
        _triggerConfetti();
    }

    function _closeCelebration() {
        const overlay = document.getElementById('spCelebrationOverlay');
        if (overlay) overlay.classList.remove('sp-celeb-open');
    }

    // ── Rank change detection for level-up celebration ──
    let _lastKnownRank = null;

    function _checkRankChange() {
        if (!window.PulseEngine || !PulseEngine.data) return;
        const currentRank = PulseEngine.data.level;
        if (_lastKnownRank === null) {
            _lastKnownRank = currentRank;
            return;
        }
        if (currentRank !== _lastKnownRank) {
            const celebKey = 'rank_' + currentRank;
            if (typeof PPLogSystem !== 'undefined' && !PPLogSystem.isCelebrationShown(celebKey)) {
                PPLogSystem.markCelebrationShown(celebKey);
                _triggerCelebration('RANK ASCENDED', `${_lastKnownRank} → ${currentRank}`, 'Discipline level increased. +100 PP Bonus');
                // Bonus PP for rank up
                if (typeof PulseEngine.addPoints === 'function') {
                    PulseEngine.addPoints(100, 'mission', { rewardId: 'rank_bonus_' + currentRank, isDev: true });
                }
            }
            _lastKnownRank = currentRank;
        }
    }

    // ════════════════════════════════════════════════════════
    //  STREAK HEATMAP — Phase 2 (REAL PP DATA ONLY)
    //  Uses smart_padhai_pp_logs from localStorage.
    //  No fake data. No random values.
    //  DEFINED AT IIFE LEVEL so init() can call them.
    // ════════════════════════════════════════════════════════

    /**
     * Safely read PP logs from localStorage.
     * Returns an array (may be empty). Defensive against malformed data.
     */
    function _getPPLogs() {
        try {
            const raw = SafeStorage.getItem('smart_padhai_pp_logs', []);
            if (!raw) return [];
            if (!Array.isArray(raw)) return [];
            return raw;
        } catch (e) {
            console.warn('[DashboardRoute] Error reading PP logs:', e);
            return [];
        }
    }

    /**
     * Build a map of { "YYYY-MM-DD": { pp: number, actions: number } }
     * for the last `rangeDays` days from today.
     */
    function _getDailyPPMap(rangeDays) {
        const logs = _getPPLogs();
        const map = {};
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        // Initialize all days in range
        for (let i = 0; i < rangeDays; i++) {
            const d = new Date(today);
            d.setDate(d.getDate() - i);
            const key = d.toISOString().split('T')[0];
            map[key] = { pp: 0, actions: 0 };
        }

        // Aggregate logs by date
        if (logs.length > 0) {
            for (const log of logs) {
                if (!log || typeof log !== 'object') continue;
                const date = log.date;
                if (!date || typeof date !== 'string') continue;
                const dateKey = date.split('T')[0]; // Handle ISO or YYYY-MM-DD
                if (!map[dateKey]) continue; // Outside selected range
                const pts = Number(log.points);
                if (Number.isFinite(pts)) {
                    map[dateKey].pp += pts;
                    map[dateKey].actions += 1;
                }
            }
        }

        return map;
    }

    /**
     * Calculate current streak: count consecutive active days backwards from today.
     * Streak System V2: For today, uses Qualified Study Day rule.
     * For historical days, uses qualified days log or legacy PP > 0 fallback.
     */
    function _calculateCurrentStreak(dailyMap) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayKey = _getLocalDateKey(today);

        // Streak System V2: Check if StreakSystem is available for today's qualification
        const streakSummary = _getStreakSystemSummarySafe();
        const todayQualified = streakSummary?.todayQualified || false;

        // For today: only count if qualified (not just PP > 0)
        if (streakSummary && streakSummary.todayQualified !== undefined) {
            let streak = 0;

            if (todayQualified) {
                streak = 1;
                let d = new Date(today);
                d.setDate(d.getDate() - 1);
                // Walk backwards using qualified log or legacy fallback
                while (true) {
                    const key = _getLocalDateKey(d);
                    const entry = dailyMap[key];
                    // Check if this date has qualification data
                    if (window.StreakSystem && typeof window.StreakSystem.getQualificationForDate === 'function') {
                        const qual = window.StreakSystem.getQualificationForDate(key);
                        if (qual) {
                            if (qual.qualifies) { streak++; d.setDate(d.getDate() - 1); }
                            else break;
                        } else if (entry && entry.pp > 0) {
                            // Legacy fallback: no qualification data, but PP > 0
                            streak++; d.setDate(d.getDate() - 1);
                        } else {
                            break;
                        }
                    } else if (entry && entry.pp > 0) {
                        streak++; d.setDate(d.getDate() - 1);
                    } else {
                        break;
                    }
                }
            } else {
                // Today not qualified — count pending streak (days before today)
                let d = new Date(today);
                d.setDate(d.getDate() - 1);
                while (true) {
                    const key = _getLocalDateKey(d);
                    const entry = dailyMap[key];
                    if (window.StreakSystem && typeof window.StreakSystem.getQualificationForDate === 'function') {
                        const qual = window.StreakSystem.getQualificationForDate(key);
                        if (qual) {
                            if (qual.qualifies) { streak++; d.setDate(d.getDate() - 1); }
                            else break;
                        } else if (entry && entry.pp > 0) {
                            streak++; d.setDate(d.getDate() - 1);
                        } else {
                            break;
                        }
                    } else if (entry && entry.pp > 0) {
                        streak++; d.setDate(d.getDate() - 1);
                    } else {
                        break;
                    }
                }
            }
            return streak;
        }

        // Legacy fallback: any PP > 0 counts
        let streak = 0;
        let d = new Date(today);
        while (true) {
            const key = d.toISOString().split('T')[0];
            const entry = dailyMap[key];
            if (entry && entry.pp > 0) {
                streak++;
                d.setDate(d.getDate() - 1);
            } else {
                break;
            }
        }
        return streak;
    }

    /**
     * Calculate best streak: longest continuous chain of active days in the range.
     * Streak System V2: For today, respects qualification.
     */
    function _calculateBestStreak(dailyMap) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const keys = Object.keys(dailyMap).sort();
        if (keys.length === 0) return 0;

        const todayKey = _getLocalDateKey(today);
        const streakSummary = _getStreakSystemSummarySafe();
        const todayQualified = streakSummary?.todayQualified || false;

        let best = 0;
        let current = 0;
        for (let i = 0; i < keys.length; i++) {
            const key = keys[i];
            let isActive = dailyMap[key].pp > 0;

            // For today: override with qualification check
            if (key === todayKey && streakSummary && streakSummary.todayQualified !== undefined) {
                isActive = todayQualified;
            } else if (window.StreakSystem && typeof window.StreakSystem.getQualificationForDate === 'function') {
                const qual = window.StreakSystem.getQualificationForDate(key);
                if (qual) isActive = qual.qualifies;
            }

            if (isActive) {
                current++;
                if (current > best) best = current;
            } else {
                current = 0;
            }
        }
        return best;
    }

    /**
     * Get active days count within the current heatmap range.
     */
    function _getActiveDaysInRange(dailyMap) {
        return Object.values(dailyMap).filter(d => d.pp > 0).length;
    }

    /**
     * Get the intensity level for a daily PP value.
     */
    function _getHeatmapIntensity(dailyPP) {
        if (dailyPP <= 0) return { level: 0, label: 'No Activity', cssClass: 'hm-cell-empty' };
        if (dailyPP <= 30) return { level: 1, label: 'Low Discipline', cssClass: 'hm-cell-low' };
        if (dailyPP <= 80) return { level: 2, label: 'Medium Discipline', cssClass: 'hm-cell-medium' };
        if (dailyPP <= 150) return { level: 3, label: 'High Discipline', cssClass: 'hm-cell-high' };
        return { level: 4, label: 'Beast Mode', cssClass: 'hm-cell-beast' };
    }

    /**
     * Format a date string for display (e.g., "June 2")
     */
    function _formatHeatmapDate(dateStr) {
        try {
            const d = new Date(dateStr + 'T00:00:00');
            const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            return months[d.getMonth()] + ' ' + d.getDate();
        } catch (e) {
            return dateStr;
        }
    }

    /**
     * Safely get streak summary from global StreakSystem.
     * READ ONLY — does not call refreshStreak(). Returns null if unavailable.
     */
    function _getStreakSystemSummarySafe() {
        try {
            if (!window.StreakSystem) return null;

            if (typeof window.StreakSystem.getStreakSummary === 'function') {
                return window.StreakSystem.getStreakSummary();
            }

            if (typeof window.StreakSystem.getStreakData === 'function') {
                return window.StreakSystem.getStreakData();
            }

            return null;
        } catch (err) {
            console.warn('[DashboardRoute] StreakSystem summary read failed:', err);
            return null;
        }
    }

    /**
     * Streak System V2: Update the hero streak pill (#streakDisplay)
     * with the real streak count from StreakSystem and qualification status.
     * Shows: streak number + status text (Secured / At Risk / Almost / Recovery)
     * Safe — catches all errors, never throws.
     */
    function _updateHeroStreakDisplay() {
        let streak = 0;
        let statusText = '';
        let statusClass = '';

        try {
            // Refresh streak engine once if available (idempotent, safe to call)
            if (window.StreakSystem && typeof window.StreakSystem.refreshStreak === 'function') {
                window.StreakSystem.refreshStreak();
            }

            if (window.StreakSystem && typeof window.StreakSystem.getStreakSummary === 'function') {
                const summary = window.StreakSystem.getStreakSummary();
                const todayQualified = summary?.todayQualified || false;
                const todayQuality = summary?.todayQuality || 'none';

                if (todayQualified) {
                    // Today is qualified — show full streak count
                    streak = Number(summary?.currentStreak || 0);
                    if (todayQuality === 'recovery') {
                        statusText = 'Recovery';
                        statusClass = 'streak-recovery';
                    } else if (todayQuality === 'elite') {
                        statusText = 'Elite';
                        statusClass = 'streak-qualified';
                    } else if (todayQuality === 'strong') {
                        statusText = 'Strong';
                        statusClass = 'streak-qualified';
                    } else {
                        statusText = 'Secured';
                        statusClass = 'streak-qualified';
                    }
                } else {
                    // Today NOT qualified — show pending streak + at-risk status
                    // "pending streak" = how many consecutive days before today
                    streak = Number(summary?.currentStreak || 0);
                    if (todayQuality === 'almost') {
                        statusText = 'Almost Secured';
                        statusClass = 'streak-almost';
                    } else if (streak > 0) {
                        statusText = 'At Risk';
                        statusClass = 'streak-at-risk';
                    } else {
                        statusText = '';
                        statusClass = '';
                    }
                }
            } else if (window.PulseEngine?.data?.streak != null) {
                streak = Number(window.PulseEngine.data.streak || 0);
            }
        } catch (err) {
            console.warn('[DashboardRoute] Hero streak update failed:', err);
        }

        const el = document.getElementById('streakDisplay');
        if (el) {
            // Remove old status classes
            el.classList.remove('streak-qualified', 'streak-almost', 'streak-at-risk', 'streak-recovery');
            if (statusClass) el.classList.add(statusClass);

            if (statusText) {
                el.innerHTML = `\uD83D\uDD25 ${streak} <span class="streak-status">${statusText}</span>`;
            } else {
                el.textContent = `\uD83D\uDD25 ${streak}`;
            }
        }
    }

    /**
     * Start listening for StreakSystem updates.
     * Streak System V2: Listens to all activity events that affect qualification.
     * When any event fires, refreshes streak + re-renders heatmap and hero pill.
     * Avoids recursion via render guard.
     */
    function _startStreakEventListener() {
        _stopStreakEventListener();
        _streakEventHandler = () => {
            if (_isRenderingHeatmap) return;
            if (_container) {
                // Refresh StreakSystem qualification before re-rendering
                if (window.StreakSystem && typeof window.StreakSystem.refreshStreak === 'function') {
                    try { window.StreakSystem.refreshStreak(); } catch (e) { /* safe */ }
                }
                _renderStreakHeatmap(_selectedHeatmapRange || 30);
                _updateHeroStreakDisplay();
            }
        };
        window.addEventListener('smartPadhai:streakUpdated', _streakEventHandler);
        window.addEventListener('smartPadhai:ppUpdated', _streakEventHandler);
        window.addEventListener('smartPadhai:sessionReviewSaved', _streakEventHandler);
        window.addEventListener('smartPadhai:timerSessionSaved', _streakEventHandler);
        window.addEventListener('smartPadhai:syllabusUpdated', _streakEventHandler);
        window.addEventListener('smartPadhai:backlogUpdated', _streakEventHandler);
    }

    /**
     * Stop listening for StreakSystem and PP updates.
     */
    function _stopStreakEventListener() {
        if (_streakEventHandler) {
            window.removeEventListener('smartPadhai:streakUpdated', _streakEventHandler);
            window.removeEventListener('smartPadhai:ppUpdated', _streakEventHandler);
            window.removeEventListener('smartPadhai:sessionReviewSaved', _streakEventHandler);
            window.removeEventListener('smartPadhai:timerSessionSaved', _streakEventHandler);
            window.removeEventListener('smartPadhai:syllabusUpdated', _streakEventHandler);
            window.removeEventListener('smartPadhai:backlogUpdated', _streakEventHandler);
            _streakEventHandler = null;
        }
    }

    /**
     * Start listening for ComebackSystem and PP updates.
     * Listens for all 4 events so the comeback card always stays in sync.
     * Also re-renders heatmap since comeback affects streak data.
     */
    function _startComebackEventListener() {
        _stopComebackEventListener();
        _comebackEventHandler = () => {
            if (_container && !_isRenderingHeatmap) {
                try {
                    _renderComebackCard();
                    _renderStreakHeatmap(_selectedHeatmapRange || 30);
                } catch (e) {
                    console.warn('[DashboardRoute] Comeback event handler failed:', e);
                }
            }
        };
        window.addEventListener('smartPadhai:ppUpdated', _comebackEventHandler);
        window.addEventListener('smartPadhai:streakUpdated', _comebackEventHandler);
        window.addEventListener('smartPadhai:comebackUpdated', _comebackEventHandler);
        window.addEventListener('smartPadhai:comebackCompleted', _comebackEventHandler);
    }

    /**
     * Stop listening for ComebackSystem and PP updates.
     */
    function _stopComebackEventListener() {
        if (_comebackEventHandler) {
            window.removeEventListener('smartPadhai:ppUpdated', _comebackEventHandler);
            window.removeEventListener('smartPadhai:streakUpdated', _comebackEventHandler);
            window.removeEventListener('smartPadhai:comebackUpdated', _comebackEventHandler);
            window.removeEventListener('smartPadhai:comebackCompleted', _comebackEventHandler);
            _comebackEventHandler = null;
        }
    }

    /**
     * Render the Streak Heatmap into #streakHeatmapCard.
     * Streak System V2: Uses Qualified Study Day for today's cell.
     * Uses StreakSystem for official streak values, PP logs for cell intensity.
     * Includes render guard to prevent infinite recursion with streakUpdated event.
     */
    function _renderStreakHeatmap(rangeDays) {
        // Render guard: prevent re-entrant rendering
        if (_isRenderingHeatmap) return;
        _isRenderingHeatmap = true;

        try {
        _selectedHeatmapRange = rangeDays;
        const card = _container?.querySelector('#streakHeatmapCard');
        if (!card) { _isRenderingHeatmap = false; return; }

        const dailyMap = _getDailyPPMap(rangeDays);

        // Get official streak values from StreakSystem (preferred) or fallback
        const streakSummary = _getStreakSystemSummarySafe();
        let currentStreak, bestStreak, activeDaysThisMonth;

        if (streakSummary) {
            currentStreak = streakSummary.currentStreak || 0;
            bestStreak = streakSummary.bestStreak || 0;
            activeDaysThisMonth = streakSummary.activeDaysThisMonth || 0;
        } else {
            // Fallback: calculate locally from PP data
            currentStreak = _calculateCurrentStreak(dailyMap);
            bestStreak = _calculateBestStreak(dailyMap);
            activeDaysThisMonth = 0;
        }

        // Active days in current range (always from PP logs for this range)
        const activeDays = _getActiveDaysInRange(dailyMap);

        // Get StreakSystem activeDates set for tooltip enhancement
        const streakActiveDates = new Set(streakSummary?.activeDates || []);

        // Streak System V2: Get today's qualification info
        const todayKey = _getLocalDateKey();
        const todayQualified = streakSummary?.todayQualified || false;
        const todayQuality = streakSummary?.todayQuality || 'none';

        // Build cells from oldest to newest (left to right)
        const sortedKeys = Object.keys(dailyMap).sort();
        const cellsHtml = sortedKeys.map(dateKey => {
            const entry = dailyMap[dateKey];
            const isToday = dateKey === todayKey;
            let intensity = _getHeatmapIntensity(entry.pp);
            let extraClass = '';
            let qualificationStatus = '';

            // Streak System V2: For today's cell, override with qualification
            if (isToday && streakSummary && streakSummary.todayQualified !== undefined) {
                if (todayQualified) {
                    // Today is qualified — use normal intensity from PP
                    const isStreakActive = streakActiveDates.has(dateKey);
                    qualificationStatus = todayQuality === 'recovery' ? 'Qualified (Recovery)'
                        : todayQuality === 'elite' ? 'Qualified (Elite)'
                        : todayQuality === 'strong' ? 'Qualified (Strong)'
                        : 'Qualified';
                } else {
                    // Today NOT qualified — force inactive/muted regardless of PP
                    if (todayQuality === 'almost') {
                        intensity = { level: 0, label: 'Almost Secured', cssClass: 'hm-cell-almost' };
                        extraClass = 'hm-cell-almost';
                        qualificationStatus = 'Almost Secured';
                    } else {
                        intensity = { level: 0, label: 'Not Secured', cssClass: 'hm-cell-empty' };
                        qualificationStatus = 'Not Secured';
                    }
                }
            } else {
                // Historical days: check qualification log
                if (window.StreakSystem && typeof window.StreakSystem.getQualificationForDate === 'function') {
                    const qual = window.StreakSystem.getQualificationForDate(dateKey);
                    if (qual && !qual.qualifies && entry.pp > 0) {
                        // Has PP but not qualified — show as low/muted
                        qualificationStatus = 'Not Qualified';
                    } else if (qual && qual.qualifies) {
                        qualificationStatus = 'Qualified';
                    }
                }
            }

            const dateLabel = _formatHeatmapDate(dateKey);
            const isStreakActive = streakActiveDates.has(dateKey);
            const streakLabel = isStreakActive && (isToday ? todayQualified : entry.pp > 0) ? 'Active Streak Day' : '';

            // Build tooltip text with qualification info
            const tooltipParts = [dateLabel, `${entry.pp} PP`, `${entry.actions} actions`, intensity.label];
            if (qualificationStatus) tooltipParts.push(qualificationStatus);
            if (streakLabel) tooltipParts.push(streakLabel);
            const tooltipText = tooltipParts.filter(Boolean).join('\n');

            const dataStreak = isStreakActive && (isToday ? todayQualified : entry.pp > 0) ? 'data-streak="true"' : '';
            const dataQual = qualificationStatus ? `data-qualification="${qualificationStatus}"` : '';

            return `<div class="hm-cell ${intensity.cssClass} ${extraClass}" data-date="${dateKey}" data-pp="${entry.pp}" data-actions="${entry.actions}" data-label="${intensity.label}" ${dataStreak} ${dataQual} title="${tooltipText}"></div>`;
        }).join('');

        // Synced indicator: show if StreakSystem V2 is available
        const syncedLine = streakSummary
            ? '<div class="hm-sync-line">Synced with Streak System V2 (Qualified Study Day)</div>'
            : '';

        // Qualification hint for today
        let qualHint = '';
        if (streakSummary && streakSummary.todayQualified !== undefined && !todayQualified) {
            if (window.StreakSystem && typeof window.StreakSystem.getTodayQualificationSummary === 'function') {
                try {
                    const qualSum = window.StreakSystem.getTodayQualificationSummary();
                    if (qualSum.missing && qualSum.missing.length > 0) {
                        qualHint = `<div class="hm-qual-hint">Need 20 net PP + one real study signal</div>`;
                    }
                } catch (e) { /* safe */ }
            }
        }

        card.innerHTML = `
            <div class="hm-header">
                <div class="hm-title-area">
                    <span class="hm-title">STUDY CONSISTENCY HEATMAP</span>
                    <span class="hm-subtitle">Your discipline pattern, not your excuses.</span>
                </div>
                <div class="hm-range-controls">
                    <button class="hm-range-btn ${rangeDays === 7 ? 'hm-range-active' : ''}" data-action="heatmap-range" data-range="7">7D</button>
                    <button class="hm-range-btn ${rangeDays === 14 ? 'hm-range-active' : ''}" data-action="heatmap-range" data-range="14">14D</button>
                    <button class="hm-range-btn ${rangeDays === 30 ? 'hm-range-active' : ''}" data-action="heatmap-range" data-range="30">30D</button>
                </div>
            </div>
            <div class="hm-grid">${cellsHtml}</div>
            <div class="hm-legend">
                <span class="hm-legend-label">Less</span>
                <span class="hm-legend-cell hm-cell-empty"></span>
                <span class="hm-legend-cell hm-cell-low"></span>
                <span class="hm-legend-cell hm-cell-medium"></span>
                <span class="hm-legend-cell hm-cell-high"></span>
                <span class="hm-legend-cell hm-cell-beast"></span>
                <span class="hm-legend-label">More</span>
            </div>
            <div class="hm-stats">
                <div class="hm-stat">
                    <span class="hm-stat-value">${currentStreak}</span>
                    <span class="hm-stat-label">Current Streak</span>
                </div>
                <div class="hm-stat">
                    <span class="hm-stat-value">${bestStreak}</span>
                    <span class="hm-stat-label">Best Streak</span>
                </div>
                <div class="hm-stat">
                    <span class="hm-stat-value">${activeDays}</span>
                    <span class="hm-stat-label">Active Days</span>
                </div>
            </div>
            ${qualHint}
            ${activeDays === 0 ? '<div class="hm-empty"><span class="sp-empty-state-icon">🔥</span><h3 class="sp-empty-state-title">No Activity Yet</h3><p class="sp-empty-state-text">Complete one mission to activate Pulse and light up the grid.</p></div>' : ''}
            ${syncedLine}
        `;

        // Attach hover events for tooltip using event delegation (safe: uses AbortController)
        _attachHeatmapTooltipEvents();

        } finally {
            _isRenderingHeatmap = false;
        }
    }

    /**
     * Attach mouseover/mouseout events on heatmap cells for tooltip.
     * Streak System V2: Shows qualification status in tooltip.
     * Uses _abortController.signal for proper cleanup on route change.
     */
    function _attachHeatmapTooltipEvents() {
        const grid = _container?.querySelector('.hm-grid');
        if (!grid) return;

        const signal = _abortController?.signal;
        if (!signal) return;

        grid.addEventListener('mouseover', (e) => {
            const cell = e.target.closest('.hm-cell');
            if (!cell) return;
            const tooltip = document.getElementById('hmTooltip');
            if (!tooltip) return;

            const date = cell.dataset.date || '';
            const pp = cell.dataset.pp || '0';
            const actions = cell.dataset.actions || '0';
            const label = cell.dataset.label || '';
            const dateLabel = _formatHeatmapDate(date);
            const qualification = cell.dataset.qualification || '';

            const isStreak = cell.dataset.streak === 'true';
            const streakHtml = isStreak ? '<div class="hm-tip-streak">Active Streak Day</div>' : '';
            const qualHtml = qualification ? `<div class="hm-tip-qual">${qualification}</div>` : '';

            // Streak System V2: For today, show detailed qualification breakdown
            let detailHtml = '';
            if (date === _getLocalDateKey() && window.StreakSystem && typeof window.StreakSystem.getTodayQualificationSummary === 'function') {
                try {
                    const q = window.StreakSystem.getTodayQualificationSummary();
                    detailHtml = `
                        <div class="hm-tip-detail">
                            <div>Net PP: ${q.todayNetPP}</div>
                            <div>Focus: ${q.focusMinutes} min</div>
                            <div>Tasks: ${q.completedTasks}</div>
                            <div>Reviews: ${q.sessionReviews}</div>
                        </div>
                    `;
                } catch (err) { /* safe */ }
            }

            tooltip.innerHTML = `
                <div class="hm-tip-date">${dateLabel}</div>
                <div class="hm-tip-pp">${pp} PP</div>
                <div class="hm-tip-actions">${actions} actions</div>
                <div class="hm-tip-label">${label}</div>
                ${qualHtml}
                ${streakHtml}
                ${detailHtml}
            `;
            tooltip.style.display = 'block';

            // Position near cell
            const rect = cell.getBoundingClientRect();
            tooltip.style.left = (rect.left + rect.width / 2) + 'px';
            tooltip.style.top = (rect.bottom + 6) + 'px';
        }, { signal });

        grid.addEventListener('mouseout', (e) => {
            const cell = e.target.closest('.hm-cell');
            if (!cell) return;
            const tooltip = document.getElementById('hmTooltip');
            if (!tooltip) return;
            // Small delay to allow moving to tooltip
            setTimeout(() => {
                if (!tooltip.matches(':hover')) {
                    tooltip.style.display = 'none';
                }
            }, 150);
        }, { signal });
    }


    // ════════════════════════════════════════════════════════
    //  COMEBACK CARD — Streak recovery reward system
    // ════════════════════════════════════════════════════════

    /**
     * Render the Comeback Card into #comebackCard.
     * Uses ComebackSystem for status, StreakSystem for streak data.
     * All progress numbers come from REAL PP logs (not stale stored values).
     */
    function _renderComebackCard() {
        const card = _container?.querySelector('#comebackCard');
        if (!card) return;

        // Get comeback summary (safe — returns default if ComebackSystem missing)
        let summary;
        try {
            if (window.ComebackSystem && typeof window.ComebackSystem.getComebackSummary === 'function') {
                summary = window.ComebackSystem.getComebackSummary();
            }
        } catch (e) {
            console.warn('[DashboardRoute] ComebackSystem read failed:', e);
        }

        if (!summary) {
            // ComebackSystem not available — show stable card with streak info
            const streakVal = _getStreakSystemSummarySafe()?.currentStreak || 0;
            card.innerHTML = `
                <div class="cb-card cb-stable">
                    <div class="cb-header">
                        <span class="cb-icon">⚡</span>
                        <span class="cb-title">STREAK STABLE</span>
                    </div>
                    <div class="cb-body">
                        <div class="cb-message">Current streak: ${streakVal} days. Keep the chain alive.</div>
                    </div>
                </div>
            `;
            return;
        }

        const { status, gapDays, requiredActions, completedActions, rewardClaimed, message } = summary;

        let html = '';

        switch (status) {
            case 'stable': {
                const streakVal = _getStreakSystemSummarySafe()?.currentStreak || 0;
                html = `
                    <div class="cb-card cb-stable">
                        <div class="cb-header">
                            <span class="cb-icon">⚡</span>
                            <span class="cb-title">STREAK STABLE</span>
                        </div>
                        <div class="cb-body">
                            <div class="cb-message">Current streak: ${streakVal} days. Keep the chain alive.</div>
                        </div>
                    </div>
                `;
                break;
            }

            case 'at_risk':
                html = `
                    <div class="cb-card cb-at-risk">
                        <div class="cb-header">
                            <span class="cb-icon">⚠️</span>
                            <span class="cb-title">STREAK AT RISK</span>
                        </div>
                        <div class="cb-body">
                            <div class="cb-message">No activity recorded today.</div>
                            <div class="cb-sub">Complete one mission to keep momentum.</div>
                        </div>
                    </div>
                `;
                break;

            case 'available': {
                // Show real progress even before starting — count comes from real PP logs
                const progressPct = requiredActions > 0 ? Math.min(100, Math.round((completedActions / requiredActions) * 100)) : 0;
                html = `
                    <div class="cb-card cb-comeback">
                        <div class="cb-header">
                            <span class="cb-icon">🔥</span>
                            <span class="cb-title">COMEBACK INITIATED</span>
                        </div>
                        <div class="cb-body">
                            <div class="cb-message">You returned after ${gapDays} inactive day${gapDays !== 1 ? 's' : ''}.</div>
                            <div class="cb-progress">
                                <div class="cb-progress-bar">
                                    <div class="cb-progress-fill" style="width: ${progressPct}%"></div>
                                </div>
                                <div class="cb-progress-text">${completedActions}/${requiredActions} actions</div>
                            </div>
                            <div class="cb-reward">Reward: +50 PP</div>
                            <button class="cb-btn" data-action="start-comeback">Start Comeback</button>
                        </div>
                    </div>
                `;
                break;
            }

            case 'active': {
                // completedActions comes from real PP logs via getComebackSummary
                const progressPct = Math.min(100, Math.round((completedActions / requiredActions) * 100));
                html = `
                    <div class="cb-card cb-active">
                        <div class="cb-header">
                            <span class="cb-icon">⚔️</span>
                            <span class="cb-title">COMEBACK CHALLENGE ACTIVE</span>
                        </div>
                        <div class="cb-body">
                            <div class="cb-progress">
                                <div class="cb-progress-bar">
                                    <div class="cb-progress-fill" style="width: ${progressPct}%"></div>
                                </div>
                                <div class="cb-progress-text">${completedActions}/${requiredActions} actions</div>
                            </div>
                            <div class="cb-reward">Reward: +50 PP</div>
                        </div>
                    </div>
                `;
                break;
            }

            case 'completed':
                html = `
                    <div class="cb-card cb-completed">
                        <div class="cb-header">
                            <span class="cb-icon">✅</span>
                            <span class="cb-title">COMEBACK SECURED</span>
                        </div>
                        <div class="cb-body">
                            <div class="cb-message">You recovered after ${gapDays} inactive day${gapDays !== 1 ? 's' : ''}.</div>
                            <div class="cb-reward-earned">Reward earned: +50 PP</div>
                        </div>
                    </div>
                `;
                break;

            case 'expired':
                html = `
                    <div class="cb-card cb-expired">
                        <div class="cb-header">
                            <span class="cb-icon">⏰</span>
                            <span class="cb-title">COMEBACK EXPIRED</span>
                        </div>
                        <div class="cb-body">
                            <div class="cb-message">Try again tomorrow.</div>
                        </div>
                    </div>
                `;
                break;

            default:
                html = '';
        }

        card.innerHTML = html;
    }


    // ════════════════════════════════════════════════════════
    //  SESSION REVIEW — Phase 2 (Dashboard-Safe, Manual Trigger)
    //  All logic self-contained in dashboardRoute.js.
    //  Does NOT integrate with timerEngine or missionControl.
    //  DEFINED AT IIFE LEVEL so init() can call them.
    // ════════════════════════════════════════════════════════

    /**
     * Get session reviews from localStorage.
     */
    function _getSessionReviews() {
        try {
            const raw = SafeStorage.getItem('smart_padhai_session_reviews', []);
            if (!raw) return [];
            if (!Array.isArray(raw)) return [];
            return raw;
        } catch (e) {
            return [];
        }
    }

    /**
     * Save a session review to localStorage.
     */
    function _saveSessionReview(review) {
        const reviews = _getSessionReviews();
        reviews.push(review);
        SafeStorage.setItem('smart_padhai_session_reviews', reviews);
    }

    /**
     * Get session review status map.
     */
    function _getSessionReviewStatus() {
        try {
            return SafeStorage.getItem('smart_padhai_session_review_status', {}) || {};
        } catch (e) {
            return {};
        }
    }

    /**
     * Mark a session review status.
     */
    function _markSessionReviewStatus(key, status) {
        const map = _getSessionReviewStatus();
        map[key] = status;
        SafeStorage.setItem('smart_padhai_session_review_status', map);
    }

    /**
     * Open the session review modal.
     */
    function _openSessionReviewModal(sessionLog) {
        const modal = document.getElementById('sessionReviewModal');
        if (!modal) return;
        // Reset form state and remember the timer session this review belongs to.
        _reviewFormState = { focusQuality: null, difficulty: null, mood: null };
        _activeSessionReviewContext = sessionLog || null;
        // Reset pill selection UI
        modal.querySelectorAll('.sr-pill').forEach(p => p.classList.remove('sr-pill-active'));
        // Reset note
        const note = document.getElementById('srNoteInput');
        if (note) note.value = '';
        // Hide warning
        const warning = document.getElementById('srWarning');
        if (warning) warning.style.display = 'none';
        // Show modal
        modal.style.display = 'flex';
    }

    /**
     * Close the session review modal.
     */
    function _closeSessionReviewModal() {
        const modal = document.getElementById('sessionReviewModal');
        if (modal) modal.style.display = 'none';
        _activeSessionReviewContext = null;
    }

    /**
     * Handle pill selection in session review modal.
     */
    function _selectReviewPill(group, value, targetEl) {
        _reviewFormState[group] = value;
        // Deactivate siblings in same group
        const modal = document.getElementById('sessionReviewModal');
        if (modal) {
            modal.querySelectorAll(`.sr-pill[data-group="${group}"]`).forEach(p => p.classList.remove('sr-pill-active'));
        }
        targetEl.classList.add('sr-pill-active');
        // Hide warning
        const warning = document.getElementById('srWarning');
        if (warning) warning.style.display = 'none';
    }

    /**
     * Save review from modal form.
     */
    function _saveSessionReviewFromModal() {
        const { focusQuality, difficulty, mood } = _reviewFormState;
        const noteEl = document.getElementById('srNoteInput');
        const note = noteEl ? noteEl.value.trim() : '';

        // Validation: at least focusQuality OR mood must be selected
        if (!focusQuality && !mood) {
            const warning = document.getElementById('srWarning');
            if (warning) warning.style.display = 'block';
            return;
        }

        const review = {
            id: 'session_review_' + Date.now(),
            date: _getLocalDateKey(new Date()),
            createdAt: new Date().toISOString(),
            sessionId: _activeSessionReviewContext?.id || '',
            focusQuality: focusQuality || '',
            difficulty: difficulty || '',
            mood: mood || '',
            note: note,
            source: 'session_review'
        };

        _saveSessionReview(review);
        _closeSessionReviewModal();
        _renderSessionInsights();

        try {
            window.dispatchEvent(new CustomEvent('smartPadhai:sessionReviewSaved', { detail: review }));
            window.dispatchEvent(new CustomEvent('smartPadhai:dashboardDataUpdated', { detail: { source: 'session_review', review } }));
        } catch (e) { /* defensive */ }

        try {
            _renderProductivityNetPP();
            _renderTodaySessionCountTruth();
            _renderConsistencyScoreTruthPatch();
            _renderWeeklyReportCard();
            _refreshSectionSummaries();
        } catch (e) { /* defensive */ }

        console.log('[DashboardRoute] Session review saved:', review.id);
    }

    /**
     * Render the Session Insights card into #sessionInsightsCard.
     */
    function _renderSessionInsights() {
        const card = _container?.querySelector('#sessionInsightsCard');
        if (!card) return;

        const reviews = _getSessionReviews();
        const today = _getLocalDateKey(new Date());
        const todayReviews = reviews.filter(r => r.date === today);

        if (todayReviews.length === 0 && reviews.length === 0) {
            card.innerHTML = `
                <div class="si-header">
                    <span class="si-icon">&#x1F4CB;</span>
                    <span class="si-title">SESSION REVIEW</span>
                </div>
                <div class="si-subtitle">Log the result before moving to the next mission.</div>
                <div class="si-empty sp-empty-state"><span class="sp-empty-state-icon">📋</span><h3 class="sp-empty-state-title">No Session Reviews</h3><p class="sp-empty-state-text">Log a session to generate insights and track your study patterns.</p></div>
                <button class="si-log-btn" data-action="open-session-review">Log Session Review</button>
            `;
            return;
        }

        // Calculate insights from today's reviews
        const focusValues = { 'Low': 1, 'Medium': 2, 'High': 3 };
        const focusScores = todayReviews.map(r => focusValues[r.focusQuality] || 0).filter(v => v > 0);
        const avgFocus = focusScores.length > 0
            ? (focusScores.reduce((a, b) => a + b, 0) / focusScores.length)
            : 0;
        const avgFocusLabel = avgFocus >= 2.5 ? 'High' : avgFocus >= 1.5 ? 'Medium' : 'Low';

        const hardSessions = todayReviews.filter(r => r.difficulty === 'Hard').length;

        // Top mood
        const moodCounts = {};
        todayReviews.forEach(r => {
            if (r.mood) moodCounts[r.mood] = (moodCounts[r.mood] || 0) + 1;
        });
        const topMood = Object.entries(moodCounts).sort((a, b) => b[1] - a[1])[0];
        const topMoodLabel = topMood ? topMood[0] : '\u2014';

        // Smart line
        let smartLine = 'Keep tracking. Patterns become power.';
        const highFocusCount = todayReviews.filter(r => r.focusQuality === 'High').length;
        const tiredCount = todayReviews.filter(r => r.mood === 'Tired').length;
        if (highFocusCount > todayReviews.length / 2) {
            smartLine = 'Focus quality strong today.';
        } else if (tiredCount > todayReviews.length / 2) {
            smartLine = 'Energy dropping. Add recovery before the next deep session.';
        }

        card.innerHTML = `
            <div class="si-header">
                <span class="si-icon">&#x1F4CB;</span>
                <span class="si-title">SESSION REVIEW</span>
            </div>
            <div class="si-subtitle">Log the result before moving to the next mission.</div>
            <div class="si-insights-grid">
                <div class="si-insight-item">
                    <span class="si-insight-value">${todayReviews.length}</span>
                    <span class="si-insight-label">Reviews Today</span>
                </div>
                <div class="si-insight-item">
                    <span class="si-insight-value">${avgFocusLabel}</span>
                    <span class="si-insight-label">Avg Focus</span>
                </div>
                <div class="si-insight-item">
                    <span class="si-insight-value">${hardSessions}</span>
                    <span class="si-insight-label">Hard Sessions</span>
                </div>
                <div class="si-insight-item">
                    <span class="si-insight-value">${topMoodLabel}</span>
                    <span class="si-insight-label">Top Mood</span>
                </div>
            </div>
            <div class="si-smart-line">${smartLine}</div>
            <button class="si-log-btn" data-action="open-session-review">Log Session Review</button>
        `;
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING — Delegation + AbortController
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {
    // ── PP Trend Graph Refresh ──
    const refreshPPTrend = () => {
      const ppTrendContainer = container.querySelector('#ppTrendGraph');
      if (ppTrendContainer && window.PPTrendGraph) {
        window.PPTrendGraph.render(ppTrendContainer);
      }
    };
    document.addEventListener('smartPadhai:ppUpdated', refreshPPTrend, { signal });

    // ── Productivity Analytics Net PP Patch ──
    // Re-render net PP values when PP changes (add or deduct)
    document.addEventListener('smartPadhai:ppUpdated', () => {
        _renderWeeklyPPGoal();
        _renderPPBreakdown();
        _updatePulseScoreCircle();
        _renderProductivityNetPP();
        _renderTodaySessionCountTruth();
        _renderConsistencyScoreTruthPatch();
        _renderProductivityRealityLine();
        _refreshSectionSummaries();
    }, { signal });

    window.addEventListener('smartPadhai:weeklyGoalUpdated', () => {
        _renderWeeklyPPGoal();
        _refreshSectionSummaries();
    }, { signal });

    const _renderTodaySessionCountTruth = () => {
        const todayEl = document.getElementById('ge-today-sessions');
        const deltaEl = document.getElementById('ge-delta-sessions');
        if (!todayEl && !deltaEl) return;

        const todayCount = _getTodayRealSessionCountSafe();
        const yesterdayCount = _getRealSessionCountForDateSafe(_getOffsetLocalDateKey(-1));
        const delta = todayCount - yesterdayCount;

        if (todayEl) todayEl.textContent = String(todayCount);
        if (deltaEl) {
            deltaEl.textContent = delta > 0 ? '+' + delta : String(delta);
            deltaEl.className = delta > 0 ? 'ge-delta ge-delta-up' : (delta < 0 ? 'ge-delta ge-delta-down' : 'ge-delta ge-delta-neutral');
        }
    };

    const refreshDashboardTruth = () => {
        _renderWeeklyPPGoal();
        _renderPPBreakdown();
        _updatePulseScoreCircle();
        _renderProductivityNetPP();
        _renderTodaySessionCountTruth();
        _renderConsistencyScoreTruthPatch();
        _renderProductivityRealityLine();
        _renderWeeklyReportCard();
        _refreshSectionSummaries();
    };

    const persistTimerSessionAndRefresh = (event) => {
        const detail = event?.detail || {};
        const sessionDetail = detail.session || detail.sessionLog || detail;
        const savedLog = _saveCompletedTimerSessionLogSafe(sessionDetail);
        if (savedLog) {
            try {
                window.dispatchEvent(new CustomEvent('smartPadhai:dashboardDataUpdated', { detail: { source: 'timer_session', log: savedLog } }));
            } catch (e) { /* defensive */ }
            _openSessionReviewModal(savedLog);
        }
        refreshDashboardTruth();
    };

    document.addEventListener('smartPadhai:timerSessionSaved', persistTimerSessionAndRefresh, { signal });
    window.addEventListener('smartPadhai:timerSessionSaved', persistTimerSessionAndRefresh, { signal });

    // ── Consistency Score Truth Patch (V2): Event-driven refresh ──
    // Re-render consistency score when any relevant activity changes.
    // These events signal that today's real data may have changed,
    // so the consistency score must reflect the new truth.
    const _truthRefreshEvents = [
        'smartPadhai:timerSessionSaved',
        'smartPadhai:sessionReviewSaved',
        'smartPadhai:dashboardDataUpdated',
        'smartPadhai:backlogUpdated',
        'smartPadhai:syllabusUpdated'
    ];
    _truthRefreshEvents.forEach(eventName => {
        document.addEventListener(eventName, refreshDashboardTruth, { signal });
    });

    // ── Phase 9 Syllabus Progress Circle Refresh ──
    // Re-calculate progress circle when syllabus/profile/dashboard data changes.
    // Uses AbortController signal so listeners auto-cleanup on route change.
    const _refreshSyllabusProgress = () => {
        _updateDashboardCircles();
    };

    window.addEventListener('smartPadhai:syllabusUpdated', _refreshSyllabusProgress, { signal });
    window.addEventListener('smartPadhai:profileUpdated', _refreshSyllabusProgress, { signal });
    window.addEventListener('smartPadhai:dashboardDataUpdated', _refreshSyllabusProgress, { signal });

    // ── Hero display name refresh on profile/account change ──
    const _refreshHeroName = () => { _updateHeroDisplayName(); };
    window.addEventListener('smartPadhai:profileUpdated', _refreshHeroName, { signal });
    window.addEventListener('smartPadhai:dashboardDataUpdated', _refreshHeroName, { signal });

        // ── CLICK DELEGATION ──
        container.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;

            switch (action) {
                case 'toggle-ghost':
                    _toggleFocusMode();
                    break;

                case 'exit-focus-mode':
                    _exitFocusMode();
                    break;

                case 'open-cookie-jar':
                    _openCookieJar();
                    break;

                case 'close-cookie-jar':
                    e.stopPropagation();
                    _closeSmartCookieJar();
                    return;

                case 'shuffle-cookie':
                    e.stopPropagation();
                    e.preventDefault();
                    _shuffleSmartCookie();
                    return;

                case 'cookie-jar-action':
                    e.stopPropagation();
                    e.preventDefault();
                    _handleCookieJarAction(target);
                    return;

                case 'open-rank-modal':
                    _openRankModal();
                    break;

                case 'close-rank-modal':
                    _closeRankModal();
                    break;

                case 'trigger-dev-points':
                    _triggerDevPoints();
                    break;

                case 'timer-preset':
                    if (window.TimerEngine) {
                        TimerEngine.selectDuration(parseInt(target.dataset.minutes, 10));
                    }
                    break;

                case 'timer-custom': {
                    const customInput = document.getElementById('customDuration');
                    if (customInput) {
                        const val = parseInt(customInput.value, 10);
                        if (val >= 1 && val <= 180) {
                            if (window.TimerEngine) TimerEngine.selectDuration(val);
                            customInput.value = '';
                        }
                    }
                    break;
                }

                case 'timer-label':
                    if (window.TimerEngine) {
                        TimerEngine.selectLabel(target.dataset.label);
                    }
                    break;

                case 'timer-toggle':
                    if (window.TimerEngine) TimerEngine.toggle();
                    break;

                case 'timer-reset':
                    if (window.TimerEngine) TimerEngine.reset();
                    break;

                case 'nav-syllabus':
                    e.preventDefault();
                    if (window.SpaRouter && typeof window.SpaRouter.navigate === 'function') {
                        window.SpaRouter.navigate('/syllabus');
                    }
                    break;

                case 'nav-timer': {
                    e.preventDefault();
                    const timerCard = container.querySelector('.focus-timer-card');
                    if (timerCard) {
                        timerCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                    break;
                }

                case 'toggle-panic-battle-plan':
                    e.preventDefault();
                    _setBattlePlanOpen(!_isBattlePlanOpen());
                    break;

                case 'toggle-panic-timeline':
                    e.preventDefault();
                    _setTimelineOpen(!_isTimelineOpen(_currentPanicV2Plan?.planType || 'NORMAL'));
                    break;

                case 'toggle-panic-adaptive-plan':
                    e.preventDefault();
                    _setAdaptivePlanOpen(!_isAdaptivePlanOpen(_currentPanicV2Plan?.planType || 'NORMAL', _currentPanicV2Plan?.adaptiveDayPlan?.daysLeft));
                    break;

                case 'panic-start-block': {
                    e.preventDefault();
                    const blockIndex = parseInt(target.dataset.blockIndex, 10);
                    if (Number.isFinite(blockIndex)) _handlePanicStartBlock(blockIndex);
                    break;
                }

                case 'open-exam-scope-modal':
                    e.preventDefault();
                    _openExamScopeModal();
                    break;

                case 'close-exam-scope-modal':
                    e.preventDefault();
                    _closeExamScopeModal();
                    break;

                case 'save-exam-scope':
                    e.preventDefault();
                    _saveExamScopeFromModal();
                    break;

                case 'clear-exam-scope':
                    e.preventDefault();
                    _clearExamScope();
                    break;

                case 'exam-scope-select-all': {
                    e.preventDefault();
                    const subject = document.getElementById('examScopeSubject')?.value || _examScopeModalState.subject;
                    _examScopeModalState.subject = subject;
                    _examScopeModalState.examDate = document.getElementById('examScopeDate')?.value || _examScopeModalState.examDate || '';
                    _getExamScopeChapters()
                        .filter(chapter => _normalizeSubjectLabel(chapter.subject) === subject)
                        .forEach(chapter => {
                            _examScopeModalState.selectedIds.add(chapter.id || _safeExamScopeChapterId(chapter.subject, chapter.chapterName));
                        });
                    _examScopeModalState.warning = '';
                    _renderExamScopeModal();
                    break;
                }

                case 'exam-scope-clear-all': {
                    e.preventDefault();
                    const subject = document.getElementById('examScopeSubject')?.value || _examScopeModalState.subject;
                    _examScopeModalState.subject = subject;
                    _examScopeModalState.examDate = document.getElementById('examScopeDate')?.value || _examScopeModalState.examDate || '';
                    _getExamScopeChapters()
                        .filter(chapter => _normalizeSubjectLabel(chapter.subject) === subject)
                        .forEach(chapter => {
                            _examScopeModalState.selectedIds.delete(chapter.id || _safeExamScopeChapterId(chapter.subject, chapter.chapterName));
                        });
                    _examScopeModalState.warning = '';
                    _renderExamScopeModal();
                    break;
                }

                case 'toggle-exam-scope-chapter':
                    // Actual checkbox state is handled by the delegated change listener.
                    break;

                case 'ge-metric': {
                    // Toggle active metric button
                    const metricBtns = container.querySelectorAll('.ge-metric-btn');
                    metricBtns.forEach(b => b.classList.remove('active'));
                    target.classList.add('active');
                    if (window.GraphEngine) GraphEngine.renderWeekBars();
                    break;
                }

                case 'ge-backfill':
                    if (window.GraphEngine) {
                        GraphEngine.backfillThisWeek().then(() => {
                            GraphEngine.renderDashboard();
                            // Productivity Analytics Net PP Patch: override after backfill re-render
                            _renderProductivityNetPP();
                            // Consistency Score Truth Patch (V2): override after backfill re-render
                            _renderConsistencyScoreTruthPatch();
                            // Productivity Reality Line: refresh after backfill re-render
                            _renderProductivityRealityLine();
                        });
                    }
                    break;

                case 'show-rank-detail':
                    _showRankDetail(target.dataset.rank);
                    break;

                case 'toggle-weekly-report':
                    _toggleWeeklyReportExpand();
                    break;

                case 'toggle-pp-breakdown':
                    _togglePPBreakdown();
                    break;

                case 'edit-weekly-goal': {
                    const editor = document.getElementById('wpgGoalEditor');
                    const input = document.getElementById('wpgGoalInput');
                    const currentGoal = _getWeeklyPPGoalSafe();
                    if (editor && input) {
                        editor.classList.toggle('wpg-editor-open');
                        if (editor.classList.contains('wpg-editor-open')) {
                            input.value = currentGoal;
                            input.focus();
                            input.select();
                        }
                    } else {
                        const promptValue = prompt('Set weekly PP goal', currentGoal);
                        if (promptValue === null) break;
                        const result = _setWeeklyPPGoalSafe(promptValue);
                        if (!result.ok) {
                            alert(result.message || 'Enter a valid weekly PP goal.');
                            break;
                        }
                        _renderWeeklyPPGoal();
                    }
                    break;
                }

                case 'save-weekly-goal': {
                    const input = document.getElementById('wpgGoalInput');
                    const editor = document.getElementById('wpgGoalEditor');
                    if (input) {
                        const result = _setWeeklyPPGoalSafe(input.value);
                        if (!result.ok) {
                            alert(result.message || 'Enter a valid weekly PP goal.');
                            break;
                        }
                        _renderWeeklyPPGoal();
                        if (editor) editor.classList.remove('wpg-editor-open');
                    }
                    break;
                }

                case 'cancel-weekly-goal': {
                    const editor = document.getElementById('wpgGoalEditor');
                    if (editor) editor.classList.remove('wpg-editor-open');
                    break;
                }

                case 'close-celebration':
                    _closeCelebration();
                    break;

                // ── Phase 2: Session Review & Heatmap ──
                case 'open-session-review':
                    _openSessionReviewModal();
                    break;

                case 'close-session-review':
                    _closeSessionReviewModal();
                    break;

                case 'session-review-pill': {
                    // Handle pill selection for focus quality, difficulty, mood
                    const group = target.dataset.group;
                    const value = target.dataset.value;
                    _selectReviewPill(group, value, target);
                    break;
                }

                case 'save-session-review':
                    _saveSessionReviewFromModal();
                    break;

                case 'skip-session-review':
                    _closeSessionReviewModal();
                    break;

                case 'heatmap-range': {
                    const rangeDays = parseInt(target.dataset.range, 10);
                    _renderStreakHeatmap(rangeDays);
                    // Update active button
                    const rangeBtns = container.querySelectorAll('.hm-range-btn');
                    rangeBtns.forEach(b => b.classList.remove('hm-range-active'));
                    target.classList.add('hm-range-active');
                    break;
                }

                case 'start-comeback':
                    if (window.ComebackSystem && typeof window.ComebackSystem.startComeback === 'function') {
                        try {
                            window.ComebackSystem.startComeback();
                        } catch (err) {
                            console.warn('[DashboardRoute] Start comeback failed:', err);
                        }
                    }
                    _renderComebackCard();
                    break;

                case 'directive-navigate': {
                    const route = target.dataset.route;
                    if (route && window.SpaRouter && typeof window.SpaRouter.navigate === 'function') {
                        window.SpaRouter.navigate('/' + route);
                    }
                    break;
                }

                case 'ashukari-action': {
                    const actionTarget = target.dataset.target;
                    if (actionTarget) _handleAshukariAction(actionTarget);
                    break;
                }

                // ── Dashboard Clarity: View Mode Toggle ──
                case 'set-dashboard-view': {
                    const mode = target.dataset.viewMode;
                    if (mode === 'full' || mode === 'compact') {
                        const prevMode = _dashboardViewMode;
                        _setDashboardViewMode(mode);
                        _applyDashboardViewMode();
                        // On first switch to compact, auto-collapse secondary sections
                        if (mode === 'compact' && !_compactInitialized) {
                            COLLAPSIBLE_SECTIONS.forEach(id => {
                                if (_collapsedSections[id] === undefined) {
                                    _collapsedSections[id] = true;
                                }
                            });
                            _saveCollapsedSections();
                            _applyCollapsibleStates();
                            try { SafeStorage.setItem(COMPACT_INIT_KEY, true); } catch (e) { /* silent */ }
                            _compactInitialized = true;
                        } else {
                            _applyCollapsibleStates();
                        }
                    }
                    break;
                }

                // ── Dashboard Clarity: Toggle Collapsible Section ──
                case 'toggle-dashboard-section': {
                    const sectionId = target.closest('.dashboard-collapsible-section')?.dataset.sectionId
                                   || target.dataset.sectionId;
                    if (sectionId) {
                        _toggleDashboardSection(sectionId);
                    }
                    break;
                }

                // ── Study Autopsy Actions ──
                case 'open-autopsy-modal':
                    _openAutopsyModal();
                    break;

                case 'close-autopsy-modal':
                    _closeAutopsyModal();
                    break;

                case 'generate-autopsy-report':
                    _handleAutopsyFormSubmission();
                    break;

                case 'view-autopsy-report': {
                    const reportId = target.dataset.reportId;
                    if (reportId) _viewAutopsyReport(reportId);
                    break;
                }

                case 'delete-autopsy-report': {
                    const delReportId = target.dataset.reportId;
                    if (delReportId) _handleDeleteAutopsyReport(delReportId, target);
                    break;
                }

                case 'toggle-autopsy-pill': {
                    target.classList.toggle('autopsy-pill-active');
                    break;
                }

                case 'close-autopsy-report':
                    _closeAutopsyReportModal();
                    break;

                default:
                    break;
            }
        }, { signal });

        container.addEventListener('change', (e) => {
            const target = e.target;
            if (!target) return;

            if (target.id === 'examScopeSubject') {
                _examScopeModalState.subject = target.value;
                _examScopeModalState.examDate = document.getElementById('examScopeDate')?.value || _examScopeModalState.examDate || '';
                _examScopeModalState.warning = '';
                _renderExamScopeModal();
                return;
            }

            if (target.id === 'examScopeDate') {
                _examScopeModalState.examDate = target.value || '';
                return;
            }

            if (target.dataset?.action === 'toggle-exam-scope-chapter') {
                const chapterId = target.dataset.chapterId;
                if (!chapterId) return;
                if (target.checked) {
                    _examScopeModalState.selectedIds.add(chapterId);
                } else {
                    _examScopeModalState.selectedIds.delete(chapterId);
                }
                _examScopeModalState.warning = '';
            }
        }, { signal });

        // ── KEYBOARD: Escape to close modals + exit focus mode ──
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                // RPM Wave 1: Escape exits Focus Activated Mode
                _exitFocusMode();
                _closeRankModal();
                // Close PP breakdown tooltip
                const tooltip = document.getElementById('ppBreakdownTooltip');
                if (tooltip) tooltip.classList.remove('pp-tooltip-open');
                // Close celebration
                _closeCelebration();
                // Close weekly goal editor
                const editor = document.getElementById('wpgGoalEditor');
                if (editor) editor.classList.remove('wpg-editor-open');
                // Close session review modal
                _closeSessionReviewModal();
                // Close autopsy modal
                _closeAutopsyModal();
                // Close autopsy report modal
                _closeAutopsyReportModal();
                // Close Smart Cookie Jar modal (RPM Wave 2C)
                _closeSmartCookieJar();
                // Close Exam Scope modal
                _closeExamScopeModal();
                // Close heatmap tooltip
                const hmTooltip = document.getElementById('hmTooltip');
                if (hmTooltip) hmTooltip.style.display = 'none';
            }
        }, { signal });

        // ── OUTSIDE CLICK: Close PP tooltip ──
        document.addEventListener('click', (e) => {
            const tooltip = document.getElementById('ppBreakdownTooltip');
            const trigger = _container?.querySelector('.pp-breakdown-trigger');
            if (tooltip && tooltip.classList.contains('pp-tooltip-open')) {
                if (!tooltip.contains(e.target) && !trigger?.contains(e.target)) {
                    tooltip.classList.remove('pp-tooltip-open');
                }
            }
            // Close heatmap tooltip on outside click
            const hmTooltip = document.getElementById('hmTooltip');
            if (hmTooltip && hmTooltip.style.display === 'block') {
                if (!hmTooltip.contains(e.target) && !e.target.classList.contains('hm-cell')) {
                    hmTooltip.style.display = 'none';
                }
            }
            // Close Smart Cookie Jar on overlay click (RPM Wave 2C)
            // Only close when clicking the backdrop itself (e.target.id === modal id),
            // NOT when clicking anything inside the card — prevents shuffle/action
            // button clicks from closing the modal after innerHTML replace detaches
            // the original target from the DOM.
            if (e.target.id === 'smartCookieJarModal') {
                _closeSmartCookieJar();
            }
            if (e.target.id === 'examScopeModalOverlay') {
                _closeExamScopeModal();
            }
        }, { signal });
    }

    // ════════════════════════════════════════════════════════
    //  HTML RENDER — Phase 7D Reordered Hierarchy
    //  1. Hero action card (hint with pulse dot)
    //  2. Summary strip (master-header compacted)
    //  3. Key stats grid (4 SVG circle stats)
    //  4. Productivity graph section (GraphEngine)
    //  5. Secondary widgets grid (timer, badges, quote, panic)
    // ════════════════════════════════════════════════════════

    function _renderHTML() {
        return `
<div class="dashboard-wrapper">

    <!-- Ascension overlay (global, but referenced by PulseEngine) -->
    <div id="ascension-overlay" style="display:none;">
        <div class="ascension-content">
            <img src="./assets/The all seeing Eye.png" class="ascension-img" alt="Architect Ascension">
            <h1 class="ascension-quote">The Universe is under your Design, Architect</h1>
        </div>
    </div>

    <!-- Ghost HUD (legacy, hidden by Focus Mode) -->
    <div class="ghost-hud" style="display:none;">Distraction Disabled. Focus Active.</div>

    <!-- Focus Mode Overlay (RPM Wave 1) -->
    <div id="focusModeOverlay" class="focus-mode-overlay">
        <div class="focus-mode-panel">
            <div class="focus-mode-title">DISTRACTION DISABLED</div>
            <div class="focus-mode-subtitle">FOCUS ACTIVATED</div>
            <button class="focus-mode-exit-btn" data-action="exit-focus-mode">Exit Focus Mode</button>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- 0. QUICK WIN / NEXT ACTION STRIP                    -->
    <!-- ═══════════════════════════════════════════════════ -->
    <div class="quickwin-strip ashukari-strip focus-blur-target">
        <!-- Ashukari Smart Next Step renders here -->
    </div>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- 1. HERO COMMAND CARD — Premium identity             -->
    <!-- ═══════════════════════════════════════════════════ -->
    <header id="header">
        <div class="master-header">
            <!-- Left Column: Identity + Techniques + Rank + PP -->
            <div class="hero-left">
                <h2 class="hero-title"><span id="hero-user-name" class="hero-user-name">Student</span></h2>
                <div class="hero-techniques" id="badgeContainer">
                    <p style="color:#666; font-size:0.7rem;">No Active Techniques</p>
                </div>
                <div class="hero-rank-pill" data-action="open-rank-modal" style="cursor: pointer;">
                    <span id="hero-rank-icon-el" class="hero-rank-icon">🛡️</span>
                    <span id="global-level-display">Initiate</span>
                </div>
                <div class="hero-pp-section">
                    <div class="pulse-bar-container">
                        <div id="global-pulse-fill"></div>
                    </div>
                    <small class="pp-counter"><span id="global-pp-display">0</span> / <span id="xp-needed">0 PP</span></small>
                    <div class="hero-actions-row">
                    <button id="ghostBtn" class="ghost-button-style" data-action="toggle-ghost">Ghost Mode</button>
                    <button id="cookie-jar-trigger" data-action="open-cookie-jar" class="cookie-btn-pro">
                        <div class="btn-glow"></div>
                        <span class="btn-content">
                            <i class="fas fa-cookie-bite cookie-icon">\uD83C\uDF6A</i>
                            <span class="btn-text">The Cookie Jar</span>
                        </span>
                        <div class="btn-border-shine"></div>
                    </button>
                </div>
                </div>

            </div>

            <!-- Right Column: Shard + Pills + Buttons -->
            <div class="hero-right">
                <div class="hero-shard-wrapper">
                    <img id="main-shard-badge" src="./assets/Iniate rank.png" alt="Master Rank Shard">
                </div>
                <div class="hero-pills-row">
                    <div class="hero-pill" id="streakDisplay">\uD83D\uDD25 0</div>
                    <div class="hero-pill">\uD83C\uDFC6 <span id="trophy-pp-display">0</span></div>
                </div>

            </div>

            <div id="toast-container"></div>
        </div>
    </header>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- COMMAND QUOTE STRIP                                 -->
    <!-- ═══════════════════════════════════════════════════ -->
    <div class="hero-quote-strip focus-blur-target">
        <span class="hero-quote-icon">\uD83D\uDCAC</span>
        <div class="hero-quote-content">
            <span id="quoteText">"I never lose. I either win or learn."</span>
            <span id="quoteAuthor">\u2014 Nelson Mandela</span>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- 2. TACTICAL DAILY DIRECTIVE — Smart daily command   -->
    <!-- ═══════════════════════════════════════════════════ -->
    <section class="dash-directive-section focus-blur-target">
        <div id="dailyDirectiveCard" class="tdd-card"></div>
    </section>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- DASHBOARD VIEW TOGGLE — Full View / Compact Mode   -->
    <!-- ═══════════════════════════════════════════════════ -->
    <div class="dashboard-view-toggle focus-blur-target">
        <span class="dashboard-view-label">Dashboard View:</span>
        <button class="dashboard-view-btn active" data-action="set-dashboard-view" data-view-mode="full">Full View</button>
        <button class="dashboard-view-btn" data-action="set-dashboard-view" data-view-mode="compact">Compact Mode</button>
    </div>

    <!-- Dev Button -->
    <button data-action="trigger-dev-points" class="focus-blur-target" style="background: #ff0055; color: white; border: none; padding: 5px 10px; border-radius: 5px; cursor: pointer; font-family: monospace; font-size: 10px;">
        +1000 PP [DEV]
    </button>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- 3. KEY STATS GRID — 4 SVG circle stats             -->
    <!-- ═══════════════════════════════════════════════════ -->
    <section class="dash-stats-section focus-blur-target">
        <div class="stats-grid" id="grid">
            <!-- BACKLOG CIRCLE -->
            <div class="stat-square" id="backlog-square">
                <h4>Backlog</h4>
                <div class="progress-container">
                    <svg class="progress-ring" width="120" height="120">
                        <circle class="progress-ring__circle-bg" stroke="#222" stroke-width="10" fill="transparent" r="50" cx="60" cy="60"/>
                        <circle id="backlogCircle" class="progress-ring__circle" stroke="#FF4C4C" stroke-width="10" stroke-linecap="round" fill="transparent" r="50" cx="60" cy="60"/>
                    </svg>
                    <div class="progress-text" id="backlog-text" style="color: #FF4C4C;">0</div>
                    <div class="circle-hover-msg" id="backlog-hover">Loading...</div>
                </div>
            </div>
            <!-- PROGRESS CIRCLE -->
            <div class="stat-square" id="progress-square">
                <h4>Progress</h4>
                <div class="progress-container">
                    <svg class="progress-ring" width="120" height="120">
                        <circle class="progress-ring__circle-bg" stroke="#222" stroke-width="10" fill="transparent" r="50" cx="60" cy="60"/>
                        <circle id="progressCircle" class="progress-ring__circle" stroke="#007BFF" stroke-width="10" stroke-linecap="round" fill="transparent" r="50" cx="60" cy="60"/>
                    </svg>
                    <div class="progress-text" id="progress-text" style="color: #007BFF;">0%</div>
                    <div class="progress-subtext" id="progress-subtext" style="color: #555; font-size: 0.55rem; margin-top: 2px;"></div>
                    <div class="circle-hover-msg" id="progress-hover">Loading...</div>
                </div>
            </div>
            <!-- NOTEBOOKS CIRCLE -->
            <div class="stat-square" id="notebook-square">
                <h4>Notebooks</h4>
                <div class="progress-container">
                    <svg class="progress-ring" width="120" height="120">
                        <circle class="progress-ring__circle-bg" stroke="#222" stroke-width="10" fill="transparent" r="50" cx="60" cy="60"/>
                        <circle id="notebookCircle" class="progress-ring__circle" stroke="#FFC107" stroke-width="10" stroke-linecap="round" fill="transparent" r="50" cx="60" cy="60"/>
                    </svg>
                    <div class="progress-text" id="notebook-text" style="color: #FFC107;">0/0</div>
                    <div class="circle-hover-msg" id="notebook-hover">Loading...</div>
                </div>
            </div>
            <!-- PULSE SCORE CIRCLE -->
            <div class="stat-square" id="pulse-square">
                <h4>Pulse Score</h4>
                <div class="progress-container">
                    <svg class="progress-ring" width="120" height="120">
                        <circle class="progress-ring__circle-bg" stroke="#222" stroke-width="10" fill="transparent" r="50" cx="60" cy="60"/>
                        <circle id="scoreCircle" class="progress-ring__circle" stroke="#28A745" stroke-width="10" stroke-linecap="round" fill="transparent" r="50" cx="60" cy="60"/>
                    </svg>
                    <div class="progress-text" id="pulse-text" style="color: #28A745;">0</div>
                    <div class="circle-hover-msg" id="pulse-hover">Loading...</div>
                    <!-- PP Breakdown Info Icon -->
                    <button class="pp-breakdown-trigger" data-action="toggle-pp-breakdown" title="PP Breakdown">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
                    </button>
                </div>
                <!-- PP Breakdown Tooltip -->
                <div class="pp-breakdown-tooltip" id="ppBreakdownTooltip">
                    <div class="pp-tooltip-header">
                        <span class="pp-tooltip-title">PULSE BREAKDOWN</span>
                        <span class="pp-tooltip-sub">Today's Discipline Economy</span>
                    </div>
                    <div class="pp-tooltip-entries" id="ppBreakdownEntries"></div>
                    <div class="pp-tooltip-divider"></div>
                    <div class="pp-tooltip-net" id="ppBreakdownNet"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- PERFORMANCE ANALYTICS GROUP                         -->
    <!-- ═══════════════════════════════════════════════════ -->
    <div class="dashboard-section-group focus-blur-target">
        <div class="dashboard-section-group-header">
            <span class="dashboard-section-group-title">PERFORMANCE ANALYTICS</span>
            <span class="dashboard-section-group-subtitle">Weekly discipline and progress signals.</span>
        </div>

        <!-- 3a. WEEKLY PP GOAL BAR — Collapsible -->
        <div class="dashboard-collapsible-section" data-section-id="weeklyPPGoal">
            <div class="dashboard-collapsible-header" data-action="toggle-dashboard-section" data-section-id="weeklyPPGoal">
                <span class="dashboard-collapsible-icon">&#9733;</span>
                <span class="dashboard-collapsible-title">Weekly PP Goal</span>
                <span class="dashboard-collapsible-summary">Weekly target status</span>
                <span class="dashboard-collapsible-arrow">&#9660;</span>
            </div>
            <div class="dashboard-collapsible-body">
                <section class="dash-weekly-pp-goal-section">
                    <div class="wpg-card" id="weeklyPPGoalCard">
                        <div class="wpg-header">
                            <div class="wpg-title-area">
                                <svg class="wpg-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                                <span class="wpg-label">Weekly PP Goal</span>
                            </div>
                            <div class="wpg-goal-edit-area">
                                <span class="wpg-current-value" id="wpgCurrentValue">0</span>
                                <span class="wpg-separator">/</span>
                                <span class="wpg-goal-value" id="wpgGoalValue">700</span>
                                <span class="wpg-goal-unit">PP</span>
                                <button class="wpg-edit-btn" data-action="edit-weekly-goal" title="Edit Goal">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                </button>
                            </div>
                        </div>
                        <div class="wpg-bar-container">
                            <div class="wpg-bar-track">
                                <div class="wpg-bar-fill" id="wpgBarFill"></div>
                                <div class="wpg-milestone" style="left:25%"><span>25%</span></div>
                                <div class="wpg-milestone" style="left:50%"><span>50%</span></div>
                                <div class="wpg-milestone" style="left:75%"><span>75%</span></div>
                                <div class="wpg-milestone" style="left:100%"><span>100%</span></div>
                            </div>
                            <span class="wpg-pct" id="wpgPct">0%</span>
                        </div>
                        <div class="wpg-status" id="wpgStatus"></div>
                        <div class="wpg-goal-editor" id="wpgGoalEditor">
                            <input type="number" class="wpg-goal-input" id="wpgGoalInput" placeholder="700" min="1" max="100000" />
                            <button class="wpg-goal-save" data-action="save-weekly-goal">Set</button>
                            <button class="wpg-goal-cancel" data-action="cancel-weekly-goal">Cancel</button>
                        </div>
                    </div>
                </section>
            </div>
        </div>

        <!-- 3b. WEEKLY REALITY MIRROR — Collapsible -->
        <div class="dashboard-collapsible-section" data-section-id="weeklyRealityMirror">
            <div class="dashboard-collapsible-header" data-action="toggle-dashboard-section" data-section-id="weeklyRealityMirror">
                <span class="dashboard-collapsible-icon">&#128270;</span>
                <span class="dashboard-collapsible-title">Weekly Reality Mirror</span>
                <span class="dashboard-collapsible-summary">Weekly performance review</span>
                <span class="dashboard-collapsible-arrow">&#9660;</span>
            </div>
            <div class="dashboard-collapsible-body">
                <section class="dash-weekly-report-section">
                    <div id="weekly-report-card" class="wrc-card"></div>
                </section>
            </div>
        </div>

    </div><!-- /PERFORMANCE ANALYTICS GROUP -->

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- STUDY INTELLIGENCE GROUP                           -->
    <!-- ═══════════════════════════════════════════════════ -->
    <div class="dashboard-section-group focus-blur-target">
        <div class="dashboard-section-group-header">
            <span class="dashboard-section-group-title">STUDY INTELLIGENCE</span>
            <span class="dashboard-section-group-subtitle">Patterns, consistency, and recovery signals.</span>
        </div>

        <!-- 3c. SESSION INSIGHTS — Collapsible -->
        <div class="dashboard-collapsible-section" data-section-id="sessionInsights">
            <div class="dashboard-collapsible-header" data-action="toggle-dashboard-section" data-section-id="sessionInsights">
                <span class="dashboard-collapsible-icon">&#128221;</span>
                <span class="dashboard-collapsible-title">Session Insights</span>
                <span class="dashboard-collapsible-summary">Session quality log</span>
                <span class="dashboard-collapsible-arrow">&#9660;</span>
            </div>
            <div class="dashboard-collapsible-body">
                <section class="dash-session-insights-section">
                    <div class="si-card" id="sessionInsightsCard"></div>
                </section>
            </div>
        </div>

        <!-- 3d. STUDY CONSISTENCY HEATMAP — Collapsible -->
        <div class="dashboard-collapsible-section" data-section-id="streakHeatmap">
            <div class="dashboard-collapsible-header" data-action="toggle-dashboard-section" data-section-id="streakHeatmap">
                <span class="dashboard-collapsible-icon">&#128293;</span>
                <span class="dashboard-collapsible-title">Study Consistency Heatmap</span>
                <span class="dashboard-collapsible-summary">30D consistency</span>
                <span class="dashboard-collapsible-arrow">&#9660;</span>
            </div>
            <div class="dashboard-collapsible-body">
                <section class="dash-heatmap-section">
                    <div class="hm-card" id="streakHeatmapCard"></div>
                    <div class="hm-tooltip" id="hmTooltip" style="display:none;"></div>
                </section>
            </div>
        </div>

        <!-- 3e. COMEBACK CARD — HIDDEN (RPM Wave 1: Removed from Dashboard) -->
        <div class="dashboard-collapsible-section" data-section-id="comebackCard" style="display:none;">
            <div class="dashboard-collapsible-header" data-action="toggle-dashboard-section" data-section-id="comebackCard">
                <span class="dashboard-collapsible-icon">&#128170;</span>
                <span class="dashboard-collapsible-title">Comeback Card</span>
                <span class="dashboard-collapsible-summary">Recovery status</span>
                <span class="dashboard-collapsible-arrow">&#9660;</span>
            </div>
            <div class="dashboard-collapsible-body">
                <section class="dash-comeback-section">
                    <div id="comebackCard"></div>
                </section>
            </div>
        </div>

        <!-- 3f. OPTIMAL STUDY WINDOW — Collapsible -->
        <div class="dashboard-collapsible-section" data-section-id="optimalStudyWindow">
            <div class="dashboard-collapsible-header" data-action="toggle-dashboard-section" data-section-id="optimalStudyWindow">
                <span class="dashboard-collapsible-icon">&#128336;</span>
                <span class="dashboard-collapsible-title">Optimal Study Window</span>
                <span class="dashboard-collapsible-summary">Best study timing analysis</span>
                <span class="dashboard-collapsible-arrow">&#9660;</span>
            </div>
            <div class="dashboard-collapsible-body">
                <section class="dash-optimal-window-section">
                    <div id="optimalStudyWindowCard" class="osw-card"></div>
                </section>
            </div>
        </div>

        <!-- 3g. STUDY AUTOPSY — Collapsible -->
        <div class="dashboard-collapsible-section" data-section-id="studyAutopsy">
            <div class="dashboard-collapsible-header" data-action="toggle-dashboard-section" data-section-id="studyAutopsy">
                <span class="dashboard-collapsible-icon">&#128736;</span>
                <span class="dashboard-collapsible-title">Study Autopsy</span>
                <span class="dashboard-collapsible-summary">Post-exam analysis</span>
                <span class="dashboard-collapsible-arrow">&#9660;</span>
            </div>
            <div class="dashboard-collapsible-body">
                <section class="dash-autopsy-section">
                    <div id="studyAutopsyCard" class="study-autopsy-card"></div>
                </section>
            </div>
        </div>

    </div><!-- /STUDY INTELLIGENCE GROUP -->

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- 3e. SESSION REVIEW MODAL — Phase 2                  -->
    <!-- ═══════════════════════════════════════════════════ -->
    <div class="sr-modal-overlay focus-blur-target" id="sessionReviewModal" style="display:none;">
        <div class="sr-modal-card">
            <div class="sr-modal-header">
                <span class="sr-modal-title">SESSION REVIEW</span>
                <span class="sr-modal-sub">Log the result before moving to the next mission.</span>
            </div>
            <div class="sr-modal-body">
                <!-- Focus Quality -->
                <div class="sr-field">
                    <label class="sr-field-label">Focus Quality</label>
                    <div class="sr-pill-group">
                        <button class="sr-pill" data-action="session-review-pill" data-group="focusQuality" data-value="Low">Low</button>
                        <button class="sr-pill" data-action="session-review-pill" data-group="focusQuality" data-value="Medium">Medium</button>
                        <button class="sr-pill" data-action="session-review-pill" data-group="focusQuality" data-value="High">High</button>
                    </div>
                </div>
                <!-- Difficulty -->
                <div class="sr-field">
                    <label class="sr-field-label">Difficulty</label>
                    <div class="sr-pill-group">
                        <button class="sr-pill" data-action="session-review-pill" data-group="difficulty" data-value="Easy">Easy</button>
                        <button class="sr-pill" data-action="session-review-pill" data-group="difficulty" data-value="Normal">Normal</button>
                        <button class="sr-pill" data-action="session-review-pill" data-group="difficulty" data-value="Hard">Hard</button>
                    </div>
                </div>
                <!-- Mood -->
                <div class="sr-field">
                    <label class="sr-field-label">Mood</label>
                    <div class="sr-pill-group">
                        <button class="sr-pill" data-action="session-review-pill" data-group="mood" data-value="Focused">&#x1F624; Focused</button>
                        <button class="sr-pill" data-action="session-review-pill" data-group="mood" data-value="Okay">&#x1F610; Okay</button>
                        <button class="sr-pill" data-action="session-review-pill" data-group="mood" data-value="Tired">&#x1F635; Tired</button>
                    </div>
                </div>
                <!-- Quick Note -->
                <div class="sr-field">
                    <label class="sr-field-label">Quick Note</label>
                    <textarea class="sr-note-input" id="srNoteInput" placeholder="What worked? What distracted you?" rows="2"></textarea>
                </div>
                <!-- Inline Warning -->
                <div class="sr-warning" id="srWarning" style="display:none;">Select at least Focus Quality or Mood to save.</div>
            </div>
            <div class="sr-modal-footer">
                <button class="sr-btn sr-btn-skip" data-action="skip-session-review">Skip</button>
                <button class="sr-btn sr-btn-save" data-action="save-session-review">Save Review</button>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- STUDY AUTOPSY MODAL                                 -->
    <!-- ═══════════════════════════════════════════════════ -->
    <div class="autopsy-modal-overlay focus-blur-target" id="autopsyModal" style="display:none;">
        <div class="autopsy-modal-card">
            <div class="autopsy-modal-header">
                <span class="autopsy-modal-title">STUDY AUTOPSY</span>
                <span class="autopsy-modal-sub">Turn exam results into a recovery plan.</span>
            </div>
            <div class="autopsy-modal-body">
                <div class="autopsy-form-grid">
                    <!-- Subject -->
                    <div class="autopsy-field">
                        <label class="autopsy-field-label">Subject *</label>
                        <select class="autopsy-input" id="autopsySubject">
                            <option value="">Select subject</option>
                            <option value="Physics">Physics</option>
                            <option value="Chemistry">Chemistry</option>
                            <option value="Biology">Biology</option>
                            <option value="Maths">Maths</option>
                            <option value="SST">SST</option>
                            <option value="English">English</option>
                            <option value="Hindi">Hindi</option>
                            <option value="CS">CS</option>
                            <option value="Other">Other</option>
                        </select>
                        <span class="autopsy-field-error" id="autopsySubjectError"></span>
                    </div>
                    <!-- Exam Name -->
                    <div class="autopsy-field">
                        <label class="autopsy-field-label">Exam Name</label>
                        <input type="text" class="autopsy-input" id="autopsyExamName" placeholder="Unit Test 1 / Pre-board / Weekly Test" />
                    </div>
                    <!-- Exam Date -->
                    <div class="autopsy-field">
                        <label class="autopsy-field-label">Exam Date</label>
                        <input type="date" class="autopsy-input" id="autopsyExamDate" />
                    </div>
                    <!-- Score -->
                    <div class="autopsy-field">
                        <label class="autopsy-field-label">Score *</label>
                        <input type="number" class="autopsy-input" id="autopsyScore" placeholder="e.g. 58" min="0" />
                        <span class="autopsy-field-error" id="autopsyScoreError"></span>
                    </div>
                    <!-- Total Marks -->
                    <div class="autopsy-field">
                        <label class="autopsy-field-label">Total Marks *</label>
                        <input type="number" class="autopsy-input" id="autopsyTotalMarks" placeholder="e.g. 100" min="1" />
                        <span class="autopsy-field-error" id="autopsyTotalMarksError"></span>
                    </div>
                    <!-- Time Issue -->
                    <div class="autopsy-field">
                        <label class="autopsy-field-label">Time Issue</label>
                        <select class="autopsy-input" id="autopsyTimeIssue">
                            <option value="No issue">No issue</option>
                            <option value="Slight time pressure">Slight time pressure</option>
                            <option value="Major time pressure">Major time pressure</option>
                            <option value="Could not finish paper">Could not finish paper</option>
                        </select>
                    </div>
                </div>
                <!-- Weak Chapters -->
                <div class="autopsy-field" style="margin-top:12px;">
                    <label class="autopsy-field-label">Weak Chapters</label>
                    <textarea class="autopsy-textarea" id="autopsyWeakChapters" placeholder="Organic Chemistry, Electricity, Circles..." rows="2"></textarea>
                </div>
                <!-- Wrong Areas -->
                <div class="autopsy-field" style="margin-top:8px;">
                    <label class="autopsy-field-label">Questions Not Answered / Wrong Areas</label>
                    <textarea class="autopsy-textarea" id="autopsyWrongAreas" placeholder="Could not solve numericals, forgot definitions, time ran out..." rows="2"></textarea>
                </div>
                <!-- Mistake Types (multi-select pills) -->
                <div class="autopsy-field" style="margin-top:12px;">
                    <label class="autopsy-field-label">Mistake Type (select all that apply)</label>
                    <div class="autopsy-pill-group" id="autopsyMistakePills">
                        <button class="autopsy-pill" data-action="toggle-autopsy-pill" data-mistake="Concept gap">Concept gap</button>
                        <button class="autopsy-pill" data-action="toggle-autopsy-pill" data-mistake="Memory loss">Memory loss</button>
                        <button class="autopsy-pill" data-action="toggle-autopsy-pill" data-mistake="Silly mistakes">Silly mistakes</button>
                        <button class="autopsy-pill" data-action="toggle-autopsy-pill" data-mistake="Time management">Time management</button>
                        <button class="autopsy-pill" data-action="toggle-autopsy-pill" data-mistake="Calculation errors">Calculation errors</button>
                        <button class="autopsy-pill" data-action="toggle-autopsy-pill" data-mistake="Question interpretation">Question interpretation</button>
                        <button class="autopsy-pill" data-action="toggle-autopsy-pill" data-mistake="Lack of practice">Lack of practice</button>
                    </div>
                </div>
                <!-- Section Time Split (optional) -->
                <div class="autopsy-field" style="margin-top:12px;">
                    <label class="autopsy-field-label">Section Time Split <span style="color:#666;font-size:0.7rem;">(optional)</span></label>
                    <div class="autopsy-form-grid" style="grid-template-columns:1fr 1fr;">
                        <div class="autopsy-field" style="margin:0;">
                            <input type="text" class="autopsy-input" id="autopsyMCQTime" placeholder="MCQ time (e.g. 15 min)" />
                        </div>
                        <div class="autopsy-field" style="margin:0;">
                            <input type="text" class="autopsy-input" id="autopsyTheoryTime" placeholder="Theory time (e.g. 30 min)" />
                        </div>
                        <div class="autopsy-field" style="margin:0;">
                            <input type="text" class="autopsy-input" id="autopsyNumericalTime" placeholder="Numerical time (e.g. 45 min)" />
                        </div>
                        <div class="autopsy-field" style="margin:0;">
                            <input type="text" class="autopsy-input" id="autopsyLongAnsTime" placeholder="Long answer time (e.g. 30 min)" />
                        </div>
                    </div>
                </div>
                <!-- Inline Warning -->
                <div class="autopsy-warning" id="autopsyWarning" style="display:none;"></div>
            </div>
            <div class="autopsy-modal-footer">
                <button class="autopsy-btn autopsy-btn-cancel" data-action="close-autopsy-modal">Cancel</button>
                <button class="autopsy-btn autopsy-btn-generate" data-action="generate-autopsy-report">Generate Report</button>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- AUTOPSY REPORT VIEW MODAL                           -->
    <!-- ═══════════════════════════════════════════════════ -->
    <div class="autopsy-modal-overlay focus-blur-target" id="autopsyReportModal" style="display:none;">
        <div class="autopsy-modal-card autopsy-report-modal-card">
            <div id="autopsyReportContent"></div>
            <div class="autopsy-modal-footer">
                <button class="autopsy-btn autopsy-btn-cancel" data-action="close-autopsy-report">Close</button>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- SMART COOKIE JAR MODAL (RPM Wave 2C)                -->
    <!-- ═══════════════════════════════════════════════════ -->
    <div class="scj-modal-overlay focus-blur-target" id="smartCookieJarModal" style="display:none;">
        <div class="scj-modal-card">
            <div class="scj-modal-header">
                <span class="scj-modal-title">SMART COOKIE JAR</span>
                <button type="button" class="scj-close-x" data-action="close-cookie-jar">&times;</button>
            </div>
            <div class="scj-body">
                <!-- Cookie content rendered by _renderSmartCookieJar() -->
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- PRODUCTIVITY ANALYTICS GROUP                        -->
    <!-- ═══════════════════════════════════════════════════ -->
    <div class="dashboard-section-group focus-blur-target">
        <div class="dashboard-section-group-header">
            <span class="dashboard-section-group-title">PRODUCTIVITY ANALYTICS</span>
            <span class="dashboard-section-group-subtitle">Focus, sessions, and performance trends.</span>
        </div>

        <div class="dashboard-collapsible-section" data-section-id="graphSection">
            <div class="dashboard-collapsible-header" data-action="toggle-dashboard-section" data-section-id="graphSection">
                <span class="dashboard-collapsible-icon">&#128202;</span>
                <span class="dashboard-collapsible-title">Productivity Analytics</span>
                <span class="dashboard-collapsible-summary">Focus, PP, sessions</span>
                <span class="dashboard-collapsible-arrow">&#9660;</span>
            </div>
            <div class="dashboard-collapsible-body">
                <section class="dash-graph-section">
                    <div class="dash-section-label">Productivity</div>
        <!-- Productivity Reality Line -->
        <div class="productivity-reality-line" id="productivityRealityLine">
          <div class="productivity-reality-icon">&#9889;</div>
          <div class="productivity-reality-body">
            <div class="productivity-reality-text">Small honest actions become visible progress.</div>
            <div class="productivity-reality-meta">Productivity signal</div>
          </div>
        </div>
        <div class="ge-dashboard">
            <!-- Today vs Yesterday -->
            <div class="ge-section-card">
                <div class="ge-section-title"><span class="ge-title-dot"></span> Today vs Yesterday</div>
                <div class="ge-compare-grid">
                    <div class="ge-compare-item"><div class="ge-compare-label">NET PP</div><div class="ge-compare-value" id="ge-today-pp">0</div><div class="ge-delta ge-delta-neutral" id="ge-delta-pp">0</div></div>
                    <div class="ge-compare-item"><div class="ge-compare-label">Focus Min</div><div class="ge-compare-value" id="ge-today-focus">0 min</div><div class="ge-delta ge-delta-neutral" id="ge-delta-focus">0</div></div>
                    <div class="ge-compare-item"><div class="ge-compare-label">Sessions</div><div class="ge-compare-value" id="ge-today-sessions">0</div><div class="ge-delta ge-delta-neutral" id="ge-delta-sessions">0</div></div>
                    <div class="ge-compare-item"><div class="ge-compare-label">Backlogs</div><div class="ge-compare-value" id="ge-today-backlogs">0</div><div class="ge-delta ge-delta-neutral" id="ge-delta-backlogs">0</div></div>
                </div>
            </div>

            <!-- Consistency Score -->
            <div class="ge-section-card ge-consistency-card">
                <div class="ge-section-title"><span class="ge-title-dot"></span> Consistency Score</div>
                <div class="ge-consistency-ring-wrap">
                    <svg class="ge-consistency-ring" width="100" height="100">
                        <circle stroke="#222" stroke-width="8" fill="transparent" r="42" cx="50" cy="50"/>
                        <circle id="ge-consistency-ring" stroke="var(--accent-blue)" stroke-width="8" stroke-linecap="round" fill="transparent" r="42" cx="50" cy="50" style="stroke-dasharray: 263.9; stroke-dashoffset: 263.9;"/>
                    </svg>
                    <span class="ge-consistency-value" id="ge-consistency-value">0</span>
                </div>
                <div class="ge-score-breakdown">
                    <div class="ge-score-row"><span class="ge-sr-label">PP (30)</span><span class="ge-sr-value" id="ge-score-pp">0/30</span></div>
                    <div class="ge-score-row"><span class="ge-sr-label">Focus (25)</span><span class="ge-sr-value" id="ge-score-focus">0/25</span></div>
                    <div class="ge-score-row"><span class="ge-sr-label">Sessions (25)</span><span class="ge-sr-value" id="ge-score-sessions">0/25</span></div>
                    <div class="ge-score-row"><span class="ge-sr-label">Backlog Cleared (20)</span><span class="ge-sr-value" id="ge-score-backlogs">0/20</span></div>
                </div>
            </div>
            <!-- This Week vs Last Week -->
            <div class="ge-section-card">
                <div class="ge-section-title"><span class="ge-title-dot"></span> This Week vs Last Week</div>
                <div class="ge-compare-grid">
                    <div class="ge-compare-item"><div class="ge-compare-label">NET PP</div><div class="ge-compare-value" id="ge-week-pp">0</div><div class="ge-delta ge-delta-neutral" id="ge-week-delta-pp">0</div></div>
                    <div class="ge-compare-item"><div class="ge-compare-label">Focus Min</div><div class="ge-compare-value" id="ge-week-focus">0 min</div><div class="ge-delta ge-delta-neutral" id="ge-week-delta-focus">0</div></div>
                    <div class="ge-compare-item"><div class="ge-compare-label">Sessions</div><div class="ge-compare-value" id="ge-week-sessions">0</div><div class="ge-delta ge-delta-neutral" id="ge-week-delta-sessions">0</div></div>
                    <div class="ge-compare-item"><div class="ge-compare-label">Backlogs / Avg Score</div><div class="ge-compare-value" id="ge-week-backlogs">0</div><div class="ge-compare-sub" id="ge-week-consistency">0/100</div></div>
                </div>

            </div>


           <!-- PP Trend Graph -->
<div id="ppTrendGraph" class="pp-trend-card"></div>



            <!-- Weekly Bar Chart -->
            <div class="ge-section-card ge-bars-section">
                <div class="ge-bars-header">
                    <div class="ge-section-title" style="margin:0;"><span class="ge-title-dot"></span> Weekly Performance</div>
                    <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                        <div class="ge-metric-toggle">
                            <button class="ge-metric-btn active" data-action="ge-metric" data-metric="focus_minutes">Focus</button>
                            <button class="ge-metric-btn" data-action="ge-metric" data-metric="pp_earned">PP</button>
                            <button class="ge-metric-btn" data-action="ge-metric" data-metric="sessions_completed">Sessions</button>
                            <button class="ge-metric-btn" data-action="ge-metric" data-metric="consistency_score">Score</button>
                        </div>
                        <button id="ge-backfill-btn" data-action="ge-backfill" class="ge-backfill-btn">Backfill This Week</button>
                    </div>
                </div>
                <div class="ge-week-bars" id="ge-week-bars">
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Mon</span></div>
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Tue</span></div>
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Wed</span></div>
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Thu</span></div>
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Fri</span></div>
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Sat</span></div>
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Sun</span></div>
                </div>
                <div class="ge-bars-summary">
                    <div class="ge-bars-stat"><span class="ge-bs-label" id="ge-bar-metric-label">Focus</span><span class="ge-bs-value" id="ge-bar-total">0</span></div>
                    <div class="ge-bars-stat"><span class="ge-bs-label">Sessions</span><span class="ge-bs-value" id="ge-bar-sessions">0</span></div>
                    <div class="ge-bars-stat"><span class="ge-bs-label">Avg Score</span><span class="ge-bs-value" id="ge-bar-avg-score">0</span></div>
                </div>
            </div>
        </div>


    </section>
            </div>
        </div>
    </div><!-- /PRODUCTIVITY ANALYTICS GROUP -->

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- 5. SECONDARY WIDGETS GRID                          -->
    <!-- Timer, Panic Protocol                              -->
    <!-- ═══════════════════════════════════════════════════ -->
    <section class="dash-widgets-grid">

        <!-- Focus Timer Card -->
        <div class="focus-timer-card">
            <div class="timer-header">
                <span class="timer-label">Focus Timer</span>
                <span class="timer-session-badge" id="todaySessionsCount">0</span>
                <span class="timer-session-sub">today</span>
            </div>
            <div class="timer-display-wrapper">
                <div class="timer-display"><span id="focusMinutes">25</span>:<span id="focusSeconds">00</span></div>
                <div class="timer-progress-track">
                    <div class="timer-progress-bar" id="timerProgressBar"></div>
                </div>
            </div>
            <div class="preset-row">
                <button class="preset-btn" data-action="timer-preset" data-minutes="5">5m</button>
                <button class="preset-btn" data-action="timer-preset" data-minutes="15">15m</button>
                <button class="preset-btn selected" data-action="timer-preset" data-minutes="25">25m</button>
                <button class="preset-btn" data-action="timer-preset" data-minutes="45">45m</button>
                <button class="preset-btn" data-action="timer-preset" data-minutes="60">60m</button>
            </div>
            <div class="custom-duration-row">
                <input type="number" id="customDuration" placeholder="min" min="1" max="180">
                <button id="customDurationBtn" data-action="timer-custom">Set</button>
            </div>
            <div class="label-chips-row">
                <button class="label-chip" data-action="timer-label" data-label="Maths">Maths</button>
                <button class="label-chip" data-action="timer-label" data-label="Physics">Physics</button>
                <button class="label-chip" data-action="timer-label" data-label="Chemistry">Chemistry</button>
                <button class="label-chip" data-action="timer-label" data-label="Revision">Revision</button>
                <button class="label-chip" data-action="timer-label" data-label="Backlog">Backlog</button>
                <button class="label-chip selected" data-action="timer-label" data-label="Other">Other</button>
            </div>
            <div class="timer-controls">
                <button id="focusStartBtn" data-action="timer-toggle">Start Focus</button>
                <button id="focusResetBtn" data-action="timer-reset">Reset</button>
            </div>
            <div class="timer-today-stats">
                <span>Focus: <strong id="todayFocusMinutes">0</strong> min</span>
            </div>
        </div>

    </section>

    <section class="dash-panic-full-section">
        <!-- Panic Protocol -->
        <div class="panic-card focus-blur-target" id="panicProtocolCard">
            <div class="panic-header">
                <h3 class="panic-title">PANIC PROTOCOL ENGINE</h3>
                <span id="panicModeIndicator" class="mode-fresh">Fresh Start Mode</span>
            </div>
            <div class="panic-controls">
                <p id="panicActivationToast" style="font-size:0.8rem;"></p>
            </div>
            <ul id="panicTaskList"></ul>
        </div>
    </section>

    <!-- Confetti Canvas -->
    <canvas id="spConfettiCanvas" class="sp-confetti-canvas focus-blur-target"></canvas>

    <!-- Celebration Modal -->
    <div class="sp-celebration-overlay focus-blur-target" id="spCelebrationOverlay">
        <div class="sp-celebration-card" id="spCelebrationCard">
            <div class="sp-celeb-header" id="spCelebHeader">RANK ASCENDED</div>
            <div class="sp-celeb-body">
                <div class="sp-celeb-main" id="spCelebMain">Operator → War Machine</div>
                <div class="sp-celeb-detail" id="spCelebDetail">+100 PP Bonus</div>
            </div>
            <button class="sp-celeb-btn" data-action="close-celebration">Continue</button>
        </div>
    </div>

</div>

<!-- Rank Modal (outside wrapper for z-index) -->
<!-- Rank Modal — Premium Rank Journey -->
<div id="rank-modal" class="modal-overlay rank-journey-overlay" style="display:none;">
    <div class="rank-journey-modal">

        <!-- Close Button (top-right, always accessible) -->
        <button class="rank-journey-close" data-action="close-rank-modal" aria-label="Close">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M2 2L14 14M14 2L2 14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
        </button>

        <!-- Header: Title + Current Status -->
        <div class="rank-journey-header">
            <div class="rank-journey-title-row">
                <span class="rank-journey-icon">🏔️</span>
                <h2 class="rank-journey-title">RANK JOURNEY</h2>
            </div>
            <p class="rank-journey-subtitle">Rise through discipline. Every PP moves you closer to the next command level.</p>
            <div class="rank-journey-current-status" id="rank-current-status">
                <!-- Populated dynamically: "Current Rank: Operator • 1,200 PP • Next: War Machine" -->
            </div>
        </div>

        <!-- Journey Timeline -->
        <div class="rank-journey-timeline-section">
            <div class="rj-timeline-track">
                <div class="rj-timeline-fill" id="rank-timeline-fill"></div>
            </div>
            <div class="rj-nodes-row" id="rank-list-container">
                <!-- Populated by openRankModal() -->
            </div>
        </div>

        <!-- Next Rank Progress -->
        <!-- // <div class="rank-journey-progress-section" id="rank-next-progress">
        //     <div class="rj-progress-label" id="rank-progress-label">Next Rank Progress</div>
        //     <div class="rj-progress-numbers" id="rank-progress-numbers">1,200 / 5,000 PP</div>
        //     <div class="rj-progress-bar-track">
        //         <div class="rj-progress-bar-fill" id="rank-progress-fill"></div>
        //     </div>
        //     <div class="rj-progress-needed" id="rank-progress-needed">3,800 PP more needed</div>
        // </div>  -->

        <!-- Selected Rank Detail Panel -->
        <div class="rank-journey-detail-panel" id="rank-detail-panel">
            <!-- Populated by showRankDetail() -->
        </div>

        <!-- Motivational Footer -->
        <div class="rank-journey-footer">
            <p class="rank-journey-footer-text">Every PP is proof of execution.</p>
        </div>
    </div>
</div>

<!-- Alfred Notification (fixed position) -->
<div id="alfred-card">
    <div id="alfred-badge"><span>SYST_AUTH // SUCCESS</span></div>
    <div id="alfred-text">System ready.</div>
</div>`;
    }

    // ════════════════════════════════════════════════════════
    //  OPTIMAL STUDY WINDOW — Analysis & Rendering
    //  Reads PP logs, session reviews, and focus sessions to
    //  determine best/weak study time windows.
    // ════════════════════════════════════════════════════════

    const TIME_BUCKETS = {
        earlyMorning: { label: 'Early Morning', range: '5:00 AM \u2013 8:00 AM', start: 5, end: 8 },
        morning:      { label: 'Morning',        range: '8:00 AM \u2013 12:00 PM', start: 8, end: 12 },
        afternoon:    { label: 'Afternoon',      range: '12:00 PM \u2013 4:00 PM', start: 12, end: 16 },
        evening:      { label: 'Evening',        range: '4:00 PM \u2013 8:00 PM', start: 16, end: 20 },
        night:        { label: 'Night',          range: '8:00 PM \u2013 11:30 PM', start: 20, end: 23.5 },
        lateNight:    { label: 'Late Night',     range: '11:30 PM \u2013 2:00 AM', start: 23.5, end: 26 }
    };

    /**
     * Get the time bucket key for a given Date object.
     * Returns one of: earlyMorning, morning, afternoon, evening, night, lateNight, or null.
     */
    function _getTimeBucket(date) {
        if (!date || !(date instanceof Date) || isNaN(date.getTime())) return null;
        const h = date.getHours() + date.getMinutes() / 60;
        if (h >= 5 && h < 8) return 'earlyMorning';
        if (h >= 8 && h < 12) return 'morning';
        if (h >= 12 && h < 16) return 'afternoon';
        if (h >= 16 && h < 20) return 'evening';
        if (h >= 20 && h < 23.5) return 'night';
        if (h >= 23.5 || h < 2) return 'lateNight';
        return null;
    }

    /**
     * Get the human-readable label for a time bucket key.
     */
    function _getTimeBucketLabel(bucket) {
        return TIME_BUCKETS[bucket]?.label || 'Unknown';
    }

    /**
     * Get the time range string for a time bucket key.
     */
    function _getTimeBucketRange(bucket) {
        return TIME_BUCKETS[bucket]?.range || '';
    }

    /**
     * Safely read session reviews from SafeStorage.
     * Returns array of review objects with { id, date, focusQuality, difficulty, mood, note, createdAt }.
     */
    function _getSessionReviewsSafe() {
        try {
            const raw = SafeStorage.getItem('smart_padhai_session_reviews', []);
            if (!raw || !Array.isArray(raw)) return [];
            return raw;
        } catch (e) {
            return [];
        }
    }

    /**
     * Safely read focus session logs from SafeStorage.
     * Returns array of { id, session_date, duration_minutes, label, completed, pp_earned, started_at, completed_at }.
     */
    function _getFocusSessionsSafe() {
        try {
            const raw = SafeStorage.getItem('focus_sessions_log', []);
            if (!raw || !Array.isArray(raw)) return [];
            return raw;
        } catch (e) {
            return [];
        }
    }

    function _getSessionDateKeyFromValueSafe(value) {
        if (!value) return '';
        const rawDate = String(value);
        if (rawDate.includes('T')) {
            const parsed = new Date(rawDate);
            if (isNaN(parsed.getTime())) return rawDate.slice(0, 10);
            return _getLocalDateKey(parsed);
        }
        return rawDate.slice(0, 10);
    }

    function _getSessionMinutesSafe(item) {
        if (!item) return 0;
        const minutes = Number(item.focusMinutes || item.minutes || item.durationMinutes || item.duration_minutes || 0);
        return Number.isFinite(minutes) ? minutes : 0;
    }

    function _normalizeCompletedTimerSessionLogSafe(item) {
        if (!item || item.completed === false) return null;
        const minutes = _getSessionMinutesSafe(item);
        if (minutes <= 0) return null;

        const completedAt = item.completedAt || item.completed_at || item.endedAt || item.createdAt || item.timestamp || new Date().toISOString();
        const dateKey = _getSessionDateKeyFromValueSafe(item.date || item.session_date || completedAt);
        if (!dateKey) return null;

        return {
            id: item.id || item.sessionId || item.session_id || `session_${Date.now()}`,
            date: dateKey,
            createdAt: item.createdAt || item.started_at || item.timestamp || new Date().toISOString(),
            completedAt,
            minutes,
            focusMinutes: minutes,
            category: item.category || item.label || item.subject || 'Focus',
            completed: true,
            source: 'focus_timer'
        };
    }

    function _saveCompletedTimerSessionLogSafe(item) {
        try {
            if (typeof SafeStorage === 'undefined' || !SafeStorage?.getItem || !SafeStorage?.setItem) return null;

            const sessionLog = _normalizeCompletedTimerSessionLogSafe(item);
            if (!sessionLog) return null;

            const sessions = SafeStorage.getItem('smart_padhai_timer_sessions', []);
            const safeSessions = Array.isArray(sessions) ? sessions : [];
            const alreadySaved = safeSessions.some(existing => {
                if (!existing) return false;
                if ((sessionLog.id && existing.id === sessionLog.id) ||
                    (sessionLog.completedAt && (existing.completedAt === sessionLog.completedAt || existing.completed_at === sessionLog.completedAt))) {
                    return true;
                }
                const existingCompletedAt = existing.completedAt || existing.completed_at;
                if (!existingCompletedAt || !sessionLog.completedAt) return false;
                return Math.abs(new Date(existingCompletedAt).getTime() - new Date(sessionLog.completedAt).getTime()) < 2000;
            });

            if (!alreadySaved) {
                safeSessions.push(sessionLog);
                SafeStorage.setItem('smart_padhai_timer_sessions', safeSessions);
            }

            return sessionLog;
        } catch (err) {
            console.warn('Timer session log save failed:', err);
            return null;
        }
    }

    function _collectDatedSessionKeysForDateSafe(dateKey) {
        const sessionKeys = new Set();
        if (typeof SafeStorage === 'undefined' || !SafeStorage?.getItem) return sessionKeys;

        const timerSessions = SafeStorage.getItem('smart_padhai_timer_sessions', []);
        const sessionReviews = SafeStorage.getItem('smart_padhai_session_reviews', []);

        if (Array.isArray(timerSessions)) {
            timerSessions.forEach(item => {
                if (!item || item.completed !== true || _getSessionMinutesSafe(item) <= 0) return;
                const rawDate = item.date || item.completedAt || item.completed_at || item.createdAt || item.timestamp;
                if (!rawDate || _getSessionDateKeyFromValueSafe(rawDate) !== dateKey) return;
                sessionKeys.add(item.sessionId || item.session_id || item.id || `${dateKey}:timer:${item.completedAt || item.createdAt}`);
            });
        }

        if (Array.isArray(sessionReviews)) {
            sessionReviews.forEach(item => {
                if (!item) return;
                const rawDate = item.date || item.savedAt || item.createdAt || item.timestamp;
                if (!rawDate || _getSessionDateKeyFromValueSafe(rawDate) !== dateKey) return;
                sessionKeys.add(item.sessionId || item.session_id || item.id || `${dateKey}:review:${item.createdAt || item.savedAt}`);
            });
        }

        return sessionKeys;
    }

    function _getRealSessionCountForDateSafe(dateKey) {
        try {
            if (!dateKey) return 0;
            return _collectDatedSessionKeysForDateSafe(dateKey).size;
        } catch (err) {
            console.warn('Session count failed:', err);
            return 0;
        }
    }

    function _getOffsetLocalDateKey(offsetDays) {
        const d = new Date();
        d.setDate(d.getDate() + offsetDays);
        return _getLocalDateKey(d);
    }

    function _getTodayRealSessionCountSafe() {
        return _getRealSessionCountForDateSafe(_getLocalDateKey(new Date()));
    }

    /**
     * Extract a Date object from an ISO timestamp string.
     * Returns a Date object or null.
     */
    function _parseTimestamp(ts) {
        if (!ts) return null;
        try {
            const d = new Date(ts);
            if (!isNaN(d.getTime())) return d;
        } catch (e) { /* ignore */ }
        return null;
    }

    /**
     * Score a single study bucket based on its aggregated data.
     *
     * Scoring formula:
     *   PP earned in bucket
     *   + High focus reviews: +30 each
     *   + Medium focus reviews: +15 each
     *   + Low focus reviews: -10 each
     *   + Focused mood: +20 each
     *   + Okay mood: +5 each
     *   + Tired mood: -15 each
     *   + Hard difficulty + completed: +15 each
     *   + Easy difficulty: +5 each
     *   + Consistency bonus: +10 if 2+ days, +20 if 3+ days
     */
    function _scoreStudyBucket(bucketData) {
        if (!bucketData) return 0;

        let score = 0;

        // Base: PP earned in this bucket
        score += bucketData.totalPP || 0;

        // Focus quality bonuses from session reviews
        const focusCounts = bucketData.focusCounts || {};
        score += (focusCounts.High || 0) * 30;
        score += (focusCounts.Medium || 0) * 15;
        score += (focusCounts.Low || 0) * -10;

        // Mood bonuses from session reviews
        const moodCounts = bucketData.moodCounts || {};
        score += (moodCounts.Focused || 0) * 20;
        score += (moodCounts.Okay || 0) * 5;
        score += (moodCounts.Tired || 0) * -15;

        // Difficulty bonuses from session reviews
        const diffCounts = bucketData.difficultyCounts || {};
        score += (diffCounts.Hard || 0) * 15;
        score += (diffCounts.Easy || 0) * 5;

        // Consistency: unique days with activity in this bucket
        const uniqueDays = bucketData.uniqueDays || 0;
        if (uniqueDays >= 3) score += 20;
        else if (uniqueDays >= 2) score += 10;

        return score;
    }

    /**
     * Determine confidence level based on total usable data points.
     * Returns 'Low', 'Medium', or 'High'.
     */
    function _getConfidenceLevel(totalUsableData) {
        if (totalUsableData >= 7) return 'High';
        if (totalUsableData >= 3) return 'Medium';
        return 'Low';
    }

    /**
     * Analyze all study data and return optimal study window analysis.
     *
     * Returns {
     *   bestBucket: string | null,
     *   bestScore: number,
     *   weakBucket: string | null,
     *   weakScore: number,
     *   bestFor: string,
     *   suggestion: string,
     *   confidence: 'Low' | 'Medium' | 'High',
     *   totalUsableData: number,
     *   unclassifiedCount: number,
     *   bucketScores: { [bucketKey]: { score, totalPP, ... } }
     * }
     */
    function _analyzeOptimalStudyWindows() {
        // ── Gather data ──
        const ppLogs = _getPPLogsForDateSafe();
        const reviews = _getSessionReviewsSafe();
        const focusSessions = _getFocusSessionsSafe();

        // ── Initialize bucket accumulators ──
        const buckets = {};
        for (const key of Object.keys(TIME_BUCKETS)) {
            buckets[key] = {
                totalPP: 0,
                focusCounts: {},
                moodCounts: {},
                difficultyCounts: {},
                uniqueDays: new Set(),
                sessionCount: 0,
                reviewCount: 0,
                labels: new Set()
            };
        }

        let totalUsableData = 0;
        let unclassifiedCount = 0;

        // ── Process PP logs ──
        for (const log of ppLogs) {
            if (!log) continue;
            const ts = _parseTimestamp(log.timestamp || log.createdAt);
            const bucketKey = ts ? _getTimeBucket(ts) : null;

            const points = Number(log.points || 0);
            if (!Number.isFinite(points)) continue;

            if (!bucketKey || !buckets[bucketKey]) {
                unclassifiedCount++;
                totalUsableData++;
                continue;
            }

            buckets[bucketKey].totalPP += points;
            if (ts) {
                buckets[bucketKey].uniqueDays.add(_getLocalDateKey(ts));
            }
            totalUsableData++;
        }

        // ── Process session reviews ──
        for (const rev of reviews) {
            if (!rev) continue;
            const ts = _parseTimestamp(rev.createdAt);
            const bucketKey = ts ? _getTimeBucket(ts) : null;

            if (!bucketKey || !buckets[bucketKey]) {
                unclassifiedCount++;
                totalUsableData++;
                continue;
            }

            if (rev.focusQuality) {
                buckets[bucketKey].focusCounts[rev.focusQuality] = (buckets[bucketKey].focusCounts[rev.focusQuality] || 0) + 1;
            }
            if (rev.mood) {
                buckets[bucketKey].moodCounts[rev.mood] = (buckets[bucketKey].moodCounts[rev.mood] || 0) + 1;
            }
            if (rev.difficulty) {
                buckets[bucketKey].difficultyCounts[rev.difficulty] = (buckets[bucketKey].difficultyCounts[rev.difficulty] || 0) + 1;
            }
            if (ts) {
                buckets[bucketKey].uniqueDays.add(_getLocalDateKey(ts));
            }
            buckets[bucketKey].reviewCount++;
            totalUsableData++;
        }

        // ── Process focus sessions ──
        for (const session of focusSessions) {
            if (!session) continue;
            const ts = _parseTimestamp(session.started_at || session.completed_at);
            const bucketKey = ts ? _getTimeBucket(ts) : null;

            if (!bucketKey || !buckets[bucketKey]) {
                unclassifiedCount++;
                totalUsableData++;
                continue;
            }

            if (session.label) {
                buckets[bucketKey].labels.add(session.label);
            }
            if (session.completed) {
                buckets[bucketKey].sessionCount++;
            }
            if (ts) {
                buckets[bucketKey].uniqueDays.add(_getLocalDateKey(ts));
            }
            totalUsableData++;
        }

        // ── Score each bucket ──
        const bucketScores = {};
        let bestBucket = null;
        let bestScore = -Infinity;
        let weakBucket = null;
        let weakScore = Infinity;

        for (const key of Object.keys(TIME_BUCKETS)) {
            const data = buckets[key];
            data.uniqueDays = data.uniqueDays.size;
            const score = _scoreStudyBucket(data);
            bucketScores[key] = { score, ...data, labels: [...data.labels] };

            const hasActivity = data.totalPP !== 0 || data.reviewCount > 0 || data.sessionCount > 0;
            if (hasActivity) {
                if (score > bestScore) {
                    bestScore = score;
                    bestBucket = key;
                }
                if (score < weakScore) {
                    weakScore = score;
                    weakBucket = key;
                }
            }
        }

        // If no activity at all
        if (!bestBucket) {
            if (totalUsableData > 0 && unclassifiedCount > 0) {
                return {
                    bestBucket: null, bestScore: 0, weakBucket: null, weakScore: 0,
                    bestFor: 'Not enough timed data yet',
                    suggestion: 'Your activity logs lack timestamps. Complete focus sessions with the timer to get accurate time analysis.',
                    confidence: 'Low', totalUsableData, unclassifiedCount, bucketScores
                };
            }
            return {
                bestBucket: null, bestScore: 0, weakBucket: null, weakScore: 0,
                bestFor: 'Not enough data yet',
                suggestion: 'Complete at least 3 focus sessions or session reviews to unlock your best study window.',
                confidence: 'Low', totalUsableData: 0, unclassifiedCount: 0, bucketScores
            };
        }

        // ── Determine "Best For" label ──
        const bestData = bucketScores[bestBucket];
        let bestFor = '';

        const highFocus = (bestData.focusCounts?.High || 0);
        const totalFocus = highFocus + (bestData.focusCounts?.Medium || 0) + (bestData.focusCounts?.Low || 0);
        const hasHighFocus = totalFocus > 0 && (highFocus / totalFocus) >= 0.5;

        const hasRevision = bestData.labels?.includes('Revision') || (bestData.reviewCount > 0 && bestData.sessionCount === 0);

        const subjectLabels = (bestData.labels || []).filter(l => !['Revision', 'Backlog', 'Other'].includes(l));
        const topSubject = subjectLabels.length > 0
            ? subjectLabels.sort((a, b) =>
                subjectLabels.filter(x => x === b).length - subjectLabels.filter(x => x === a).length
            )[0]
            : null;

        if (hasHighFocus && topSubject) {
            bestFor = 'Deep Work + ' + topSubject;
        } else if (hasHighFocus) {
            bestFor = 'Deep Work';
        } else if (hasRevision && topSubject) {
            bestFor = 'Revision + ' + topSubject;
        } else if (hasRevision) {
            bestFor = 'Revision';
        } else if (topSubject) {
            bestFor = topSubject;
        } else if (bestData.sessionCount > 0) {
            bestFor = 'Mixed Study';
        } else {
            bestFor = 'Light Tasks';
        }

        // ── Determine suggestion ──
        const confidence = _getConfidenceLevel(totalUsableData);
        let suggestion = '';

        if (confidence === 'Low') {
            suggestion = 'Track 3\u20135 more sessions before trusting this fully.';
        } else {
            if (bestBucket === 'night' || bestBucket === 'lateNight') {
                suggestion = 'Keep difficult chapters and deep work at night.';
            } else if (bestBucket === 'morning' || bestBucket === 'earlyMorning') {
                suggestion = 'Use morning for hard concepts before distractions rise.';
            } else if (bestBucket === 'evening') {
                suggestion = 'Your evening focus is strong \u2014 protect it from interruptions.';
            } else if (bestBucket === 'afternoon') {
                suggestion = 'Afternoon works for you \u2014 guard it with a short nap beforehand.';
            }

            if (weakBucket && weakBucket !== bestBucket) {
                const weakData = bucketScores[weakBucket];
                const tiredCount = weakData.moodCounts?.Tired || 0;
                const totalMood = (weakData.moodCounts?.Focused || 0) + (weakData.moodCounts?.Okay || 0) + tiredCount;

                if (weakBucket === 'afternoon') {
                    suggestion += ' Use afternoon for light revision or breaks.';
                } else if (tiredCount > 0 && totalMood > 0 && (tiredCount / totalMood) >= 0.4) {
                    suggestion += ' Avoid heavy study during your weak window \u2014 use it for revision.';
                }
            }
        }

        return {
            bestBucket, bestScore, weakBucket, weakScore,
            bestFor, suggestion, confidence, totalUsableData, unclassifiedCount, bucketScores
        };
    }

    /**
     * Render the Optimal Study Window card into #optimalStudyWindowCard.
     */
    function _renderOptimalStudyWindow() {
        const card = _container?.querySelector('#optimalStudyWindowCard');
        if (!card) return;

        const analysis = _analyzeOptimalStudyWindows();
        const isEmpty = !analysis.bestBucket;

        const bestTimeLabel = analysis.bestBucket
            ? _getTimeBucketRange(analysis.bestBucket)
            : 'Not enough data yet';

        const bestFor = analysis.bestFor || 'Not enough data yet';

        const weakLabel = analysis.weakBucket
            ? _getTimeBucketRange(analysis.weakBucket)
            : 'Not enough data yet';

        const confClass = analysis.confidence === 'High' ? 'osw-conf-high'
            : analysis.confidence === 'Medium' ? 'osw-conf-medium'
            : 'osw-conf-low';

        let confDetail = '';
        if (analysis.confidence === 'Low') {
            confDetail = ' \u2014 complete more sessions to improve accuracy.';
        } else if (analysis.confidence === 'Medium') {
            confDetail = ' \u2014 based on ' + analysis.totalUsableData + ' sessions';
        } else {
            confDetail = ' \u2014 based on ' + analysis.totalUsableData + ' sessions';
        }
        if (analysis.unclassifiedCount > 0 && analysis.totalUsableData > 0) {
            confDetail += ' (' + analysis.unclassifiedCount + ' untimed)';
        }

        // ── Mini bar chart ──
        const maxScore = Math.max(1, ...Object.values(analysis.bucketScores || {}).map(b => Math.max(0, b.score || 0)));
        let barsHTML = '';
        const hasAnyBarData = Object.values(analysis.bucketScores || {}).some(b => (b.score || 0) !== 0);

        if (hasAnyBarData) {
            for (const key of Object.keys(TIME_BUCKETS)) {
                const score = analysis.bucketScores?.[key]?.score || 0;
                const barWidth = maxScore > 0 ? Math.max(0, Math.round((Math.max(0, score) / maxScore) * 100)) : 0;
                const isBest = key === analysis.bestBucket;
                const isWeak = key === analysis.weakBucket && analysis.weakBucket !== analysis.bestBucket;
                const barClass = isBest ? 'osw-bar-best' : isWeak ? 'osw-bar-weak' : '';
                const shortLabel = TIME_BUCKETS[key].label.length > 8
                    ? TIME_BUCKETS[key].label.substring(0, 8) + '.'
                    : TIME_BUCKETS[key].label;
                barsHTML += `
                    <div class="osw-bar-row ${barClass}">
                        <span class="osw-bar-label">${shortLabel}</span>
                        <div class="osw-bar-track">
                            <div class="osw-bar-fill" style="width:${barWidth}%"></div>
                        </div>
                        <span class="osw-bar-value">${Math.round(score)}</span>
                    </div>`;
            }
        }

        const emptyIcon = isEmpty ? '<div class="osw-empty-icon">&#9201;</div>' : '';

        card.innerHTML = `
            <div class="osw-card-inner ${isEmpty ? 'osw-empty-state' : ''}">
                ${emptyIcon}
                <div class="osw-title">OPTIMAL STUDY WINDOW</div>
                <div class="osw-subtitle">Your best study timing, based on real activity.</div>

                <div class="osw-section">
                    <span class="osw-label">Best Focus Time:</span>
                    <span class="osw-value osw-value-best">${bestTimeLabel}</span>
                </div>

                <div class="osw-section">
                    <span class="osw-label">Best For:</span>
                    <span class="osw-value">${bestFor}</span>
                </div>

                <div class="osw-section">
                    <span class="osw-label">Weak Window:</span>
                    <span class="osw-value osw-value-weak">${weakLabel}</span>
                </div>

                <div class="osw-section">
                    <span class="osw-label">Suggestion:</span>
                    <span class="osw-value osw-suggestion">${analysis.suggestion}</span>
                </div>

                <div class="osw-section">
                    <span class="osw-label">Confidence:</span>
                    <span class="osw-value ${confClass}">${analysis.confidence}${confDetail}</span>
                </div>

                ${hasAnyBarData ? `
                <div class="osw-bars">
                    <div class="osw-bars-title">Time Window Scores</div>
                    ${barsHTML}
                </div>` : ''}
            </div>
        `;
    }

    // ════════════════════════════════════════════════════════
    //  STUDY AUTOPSY — Post-Exam Analysis System (Phase 1)
    //  Reads existing app data to generate rule-based reports.
    //  No API calls. No fake data. Honest analysis.
    // ════════════════════════════════════════════════════════

    const AUTOPSY_KEY = 'smart_padhai_exam_autopsies';

    // ── Selected mistake types state ──
    let _autopsySelectedMistakes = [];

    // ── Autopsy localStorage helpers ──

    function _getAutopsyReportsSafe() {
        try {
            const raw = SafeStorage.getItem(AUTOPSY_KEY, []);
            if (Array.isArray(raw)) return raw;
        } catch (e) { /* fallback */ }
        return [];
    }

    function _saveAutopsyReport(report) {
        try {
            const reports = _getAutopsyReportsSafe();
            reports.push(report);
            SafeStorage.setItem(AUTOPSY_KEY, reports);
        } catch (e) {
            console.warn('[StudyAutopsy] Failed to save report:', e);
        }
    }

    function _deleteAutopsyReport(reportId) {
        try {
            let reports = _getAutopsyReportsSafe();
            reports = reports.filter(r => r.id !== reportId);
            SafeStorage.setItem(AUTOPSY_KEY, reports);
        } catch (e) {
            console.warn('[StudyAutopsy] Failed to delete report:', e);
        }
    }

    // ── Autopsy modal open/close ──

    function _openAutopsyModal() {
        _autopsySelectedMistakes = [];
        const modal = document.getElementById('autopsyModal');
        if (modal) {
            modal.style.display = 'flex';
            // Clear previous form state
            const subject = document.getElementById('autopsySubject');
            const examName = document.getElementById('autopsyExamName');
            const examDate = document.getElementById('autopsyExamDate');
            const score = document.getElementById('autopsyScore');
            const totalMarks = document.getElementById('autopsyTotalMarks');
            const timeIssue = document.getElementById('autopsyTimeIssue');
            const weakChapters = document.getElementById('autopsyWeakChapters');
            const wrongAreas = document.getElementById('autopsyWrongAreas');
            if (subject) subject.value = '';
            if (examName) examName.value = '';
            if (examDate) examDate.value = _getLocalDateKey();
            if (score) score.value = '';
            if (totalMarks) totalMarks.value = '';
            if (timeIssue) timeIssue.value = 'No issue';
            if (weakChapters) weakChapters.value = '';
            if (wrongAreas) wrongAreas.value = '';
            // Clear section time split
            ['autopsyMCQTime','autopsyTheoryTime','autopsyNumericalTime','autopsyLongAnsTime'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = '';
            });
            // Clear pills
            const pills = document.querySelectorAll('#autopsyMistakePills .autopsy-pill');
            pills.forEach(p => p.classList.remove('autopsy-pill-active'));
            // Clear errors
            ['autopsySubjectError','autopsyScoreError','autopsyTotalMarksError'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.textContent = '';
            });
            const warning = document.getElementById('autopsyWarning');
            if (warning) { warning.style.display = 'none'; warning.textContent = ''; }
        }
    }

    function _closeAutopsyModal() {
        const modal = document.getElementById('autopsyModal');
        if (modal) modal.style.display = 'none';
    }

    function _closeAutopsyReportModal() {
        const modal = document.getElementById('autopsyReportModal');
        if (modal) modal.style.display = 'none';
    }

    // ── Collect and validate form data ──

    function _collectAutopsyFormData() {
        const subject = document.getElementById('autopsySubject')?.value?.trim() || '';
        const examName = document.getElementById('autopsyExamName')?.value?.trim() || '';
        const examDate = document.getElementById('autopsyExamDate')?.value || '';
        const score = document.getElementById('autopsyScore')?.value?.trim() || '';
        const totalMarks = document.getElementById('autopsyTotalMarks')?.value?.trim() || '';
        const timeIssue = document.getElementById('autopsyTimeIssue')?.value || 'No issue';
        const weakChaptersRaw = document.getElementById('autopsyWeakChapters')?.value?.trim() || '';
        const wrongAreas = document.getElementById('autopsyWrongAreas')?.value?.trim() || '';
        const mcqTime = document.getElementById('autopsyMCQTime')?.value?.trim() || '';
        const theoryTime = document.getElementById('autopsyTheoryTime')?.value?.trim() || '';
        const numericalTime = document.getElementById('autopsyNumericalTime')?.value?.trim() || '';
        const longAnsTime = document.getElementById('autopsyLongAnsTime')?.value?.trim() || '';

        // Collect active mistake pills
        const mistakeTypes = [];
        document.querySelectorAll('#autopsyMistakePills .autopsy-pill-active').forEach(pill => {
            const m = pill.dataset.mistake;
            if (m) mistakeTypes.push(m);
        });

        // Parse weak chapters
        const weakChapters = weakChaptersRaw
            ? weakChaptersRaw.split(',').map(s => s.trim()).filter(s => s.length > 0)
            : [];

        return {
            subject, examName, examDate,
            score: score !== '' ? Number(score) : null,
            totalMarks: totalMarks !== '' ? Number(totalMarks) : null,
            timeIssue, weakChapters, wrongAreas, mistakeTypes,
            sectionTimeSplit: {
                mcqTime, theoryTime, numericalTime, longAnsTime
            }
        };
    }

    function _validateAutopsyForm(data) {
        const errors = [];
        // Clear previous errors
        ['autopsySubjectError','autopsyScoreError','autopsyTotalMarksError'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.textContent = '';
        });

        if (!data.subject) {
            errors.push('Subject is required.');
            const el = document.getElementById('autopsySubjectError');
            if (el) el.textContent = 'Subject is required.';
        }
        if (data.score === null || data.score === undefined || isNaN(data.score)) {
            errors.push('Score is required.');
            const el = document.getElementById('autopsyScoreError');
            if (el) el.textContent = 'Score is required.';
        }
        if (data.totalMarks === null || data.totalMarks === undefined || isNaN(data.totalMarks) || data.totalMarks <= 0) {
            errors.push('Total marks must be greater than 0.');
            const el = document.getElementById('autopsyTotalMarksError');
            if (el) el.textContent = 'Total marks must be greater than 0.';
        }
        if (data.score !== null && data.totalMarks !== null && !isNaN(data.score) && !isNaN(data.totalMarks) && data.score > data.totalMarks) {
            errors.push('Score cannot exceed total marks.');
            const el = document.getElementById('autopsyScoreError');
            if (el) el.textContent = 'Score cannot exceed total marks.';
        }
        return errors;
    }

    // ── Data source readers ──

    function _getSubjectPrepData(subject, examDate) {
        const masterData = SafeStorage.getItem(MASTER_KEY, {});
        const trackerData = SafeStorage.getItem('syllabus_master_tracker', {});
        const chapters = [];

        if (!subject || !masterData || typeof masterData !== 'object') return chapters;

        const subjectLower = subject.toLowerCase();
        for (const chapName in masterData) {
            const entry = masterData[chapName];
            if (!entry || typeof entry !== 'object') continue;
            // Match by chapter name containing subject or entry having subject field
            const chapLower = chapName.toLowerCase();
            const entrySubject = (entry.subject || '').toLowerCase();
            if (chapLower.includes(subjectLower) || entrySubject === subjectLower || entrySubject.includes(subjectLower)) {
                chapters.push({
                    name: chapName,
                    read: entry.read === true || entry.read === 'true',
                    notes: entry.notes === true || entry.notes === 'true',
                    pyq: entry.pyq === true || entry.pyq === 'true',
                    revised: entry.revised === true || entry.revised === 'true',
                    lastUpdated: entry.lastUpdated || null,
                    _rawEntry: entry
                });
            }
        }
        return chapters;
    }

    function _getRetentionEvidence(subject, weakChapters, examDate) {
        const evidence = [];
        let lowRetentionChapters = [];
        let avgRetention = null;
        let totalRetention = 0;
        let retentionCount = 0;

        try {
            const memoryDecayData = SafeStorage.getItem('smart_padhai_memory_decay', {});
            const masterData = SafeStorage.getItem(MASTER_KEY, {});
            const subjectLower = subject ? subject.toLowerCase() : '';

            // Check weak chapters for retention data
            if (weakChapters && weakChapters.length > 0) {
                weakChapters.forEach(chapName => {
                    const chapLower = chapName.toLowerCase();
                    // Try to find in memory decay data
                    if (memoryDecayData && typeof memoryDecayData === 'object') {
                        const meta = memoryDecayData[chapName];
                        if (meta && meta.retention !== undefined && meta.retention !== null) {
                            totalRetention += meta.retention;
                            retentionCount++;
                            if (meta.retention < 40) {
                                lowRetentionChapters.push(chapName + ' (' + meta.retention + '%)');
                            }
                        }
                    }
                    // Also check masterData for this chapter
                    const entry = masterData && masterData[chapName];
                    if (entry && entry.memoryMeta) {
                        const ret = entry.memoryMeta.retention;
                        if (ret !== undefined && ret !== null) {
                            totalRetention += ret;
                            retentionCount++;
                            if (ret < 40) {
                                if (!lowRetentionChapters.some(c => c.startsWith(chapName))) {
                                    lowRetentionChapters.push(chapName + ' (' + ret + '%)');
                                }
                            }
                        }
                    }
                });
            }

            // Also check all subject chapters for retention
            const subjectChapters = _getSubjectPrepData(subject, examDate);
            subjectChapters.forEach(chap => {
                if (memoryDecayData && typeof memoryDecayData === 'object' && memoryDecayData[chap.name]) {
                    const meta = memoryDecayData[chap.name];
                    if (meta.retention !== undefined && meta.retention !== null) {
                        totalRetention += meta.retention;
                        retentionCount++;
                        if (meta.retention < 40 && !lowRetentionChapters.some(c => c.startsWith(chap.name))) {
                            lowRetentionChapters.push(chap.name + ' (' + meta.retention + '%)');
                        }
                    }
                }
            });

            if (retentionCount > 0) {
                avgRetention = Math.round(totalRetention / retentionCount);
            }

            if (lowRetentionChapters.length > 0) {
                evidence.push('Memory-critical chapters detected: ' + lowRetentionChapters.join(', '));
            }
            if (avgRetention !== null && avgRetention < 50) {
                evidence.push('Average retention for related chapters is estimated low (' + avgRetention + '%)');
            }
        } catch (e) {
            // silent
        }

        return {
            evidence,
            avgRetention,
            lowRetentionChapters,
            hasData: evidence.length > 0
        };
    }

    function _getBacklogEvidence(subject) {
        const evidence = [];
        let criticalCount = 0;
        let highCount = 0;
        let subjectTaskCount = 0;

        try {
            const timelineData = SafeStorage.getItem('backlog_timeline', []);
            if (Array.isArray(timelineData)) {
                const subjectLower = subject ? subject.toLowerCase() : '';
                timelineData.forEach(task => {
                    if (!task || typeof task !== 'object') return;
                    const taskSubject = (task.subject || '').toLowerCase();
                    const taskTitle = (task.title || task.name || '').toLowerCase();
                    if (taskSubject === subjectLower || taskTitle.includes(subjectLower)) {
                        subjectTaskCount++;
                        if (task.priority === 'critical') criticalCount++;
                        if (task.priority === 'high') highCount++;
                    }
                });
            }

            // Also check master data for backlog
            const masterData = SafeStorage.getItem(MASTER_KEY, {});
            function toBool(v) { return v === true || v === 'true'; }
            if (masterData && typeof masterData === 'object') {
                const subjectLower = subject ? subject.toLowerCase() : '';
                for (const chap in masterData) {
                    const entry = masterData[chap];
                    if (!entry || typeof entry !== 'object') continue;
                    const chapLower = chap.toLowerCase();
                    const entrySubject = (entry.subject || '').toLowerCase();
                    if (chapLower.includes(subjectLower) || entrySubject === subjectLower) {
                        const read = toBool(entry.read);
                        const notes = toBool(entry.notes);
                        const pyq = toBool(entry.pyq);
                        const started = read || notes || pyq;
                        const completed = read && notes && pyq;
                        if (started && !completed) {
                            subjectTaskCount++;
                        }
                    }
                }
            }

            if (criticalCount > 0 || highCount > 0) {
                evidence.push(criticalCount + ' critical and ' + highCount + ' high-priority backlog tasks were still open for ' + subject);
            }
            if (subjectTaskCount > 0) {
                evidence.push(subjectTaskCount + ' incomplete subject tasks found in backlog');
            }
        } catch (e) {
            // silent
        }

        return {
            evidence,
            criticalCount,
            highCount,
            subjectTaskCount,
            hasData: evidence.length > 0
        };
    }

    function _getConsistencyEvidence(subject, examDate) {
        const evidence = [];
        let finalWeekPP = 0;
        let prevWeekPP = 0;
        let dropPercent = null;

        try {
            const logs = _getPPLogsForDateSafe();
            if (!logs || logs.length === 0) {
                return { evidence, finalWeekPP, prevWeekPP, dropPercent, hasData: false };
            }

            // Parse exam date
            const examD = examDate ? new Date(examDate) : new Date();
            if (isNaN(examD.getTime())) return { evidence, finalWeekPP, prevWeekPP, dropPercent, hasData: false };

            const subjectLower = subject ? subject.toLowerCase() : '';

            // Final 7 days before exam
            const finalWeekEnd = new Date(examD);
            const finalWeekStart = new Date(examD);
            finalWeekStart.setDate(finalWeekStart.getDate() - 7);

            // Previous 7 days (8-14 days before exam)
            const prevWeekEnd = new Date(finalWeekStart);
            const prevWeekStart = new Date(finalWeekStart);
            prevWeekStart.setDate(prevWeekStart.getDate() - 7);

            logs.forEach(log => {
                if (!log || !log.date) return;
                const logDate = new Date(log.date);
                if (isNaN(logDate.getTime())) return;
                const points = Number(log.points || 0);
                const source = (log.source || log.title || '').toLowerCase();

                const isSubjectMatch = !subjectLower || source.includes(subjectLower);

                if (logDate >= finalWeekStart && logDate < finalWeekEnd && isSubjectMatch) {
                    finalWeekPP += points;
                }
                if (logDate >= prevWeekStart && logDate < prevWeekEnd && isSubjectMatch) {
                    prevWeekPP += points;
                }
            });

            // Also count all PP (not just subject-matched) if subject filter yields nothing
            if (finalWeekPP === 0 && prevWeekPP === 0) {
                logs.forEach(log => {
                    if (!log || !log.date) return;
                    const logDate = new Date(log.date);
                    if (isNaN(logDate.getTime())) return;
                    const points = Number(log.points || 0);

                    if (logDate >= finalWeekStart && logDate < finalWeekEnd) {
                        finalWeekPP += points;
                    }
                    if (logDate >= prevWeekStart && logDate < prevWeekEnd) {
                        prevWeekPP += points;
                    }
                });
            }

            if (prevWeekPP > 0 || finalWeekPP > 0) {
                if (prevWeekPP > 0) {
                    dropPercent = Math.round(((prevWeekPP - finalWeekPP) / prevWeekPP) * 100);
                    if (dropPercent > 20) {
                        evidence.push('Final week activity dropped ' + dropPercent + '% compared to the previous week');
                    } else if (dropPercent < -20) {
                        evidence.push('Final week activity increased ' + Math.abs(dropPercent) + '% compared to the previous week');
                    } else {
                        evidence.push('Final week activity was relatively consistent with the previous week');
                    }
                } else {
                    evidence.push('Final week PP: ' + finalWeekPP + '. Not enough PP history for previous week comparison.');
                }
            }
        } catch (e) {
            // silent
        }

        return {
            evidence,
            finalWeekPP,
            prevWeekPP,
            dropPercent,
            hasData: evidence.length > 0
        };
    }

    function _getSessionReviewEvidence(subject, examDate) {
        const evidence = [];
        let avgFocus = null;
        let tiredCount = 0;
        let hardCount = 0;
        let lowFocusCount = 0;

        try {
            const reviews = SafeStorage.getItem('smart_padhai_session_reviews', []);
            if (!Array.isArray(reviews) || reviews.length === 0) {
                return { evidence, avgFocus, tiredCount, hardCount, lowFocusCount, hasData: false };
            }

            const examD = examDate ? new Date(examDate) : new Date();
            if (isNaN(examD.getTime())) return { evidence, avgFocus, tiredCount, hardCount, lowFocusCount, hasData: false };

            // Get reviews from 14 days before exam
            const cutoffDate = new Date(examD);
            cutoffDate.setDate(cutoffDate.getDate() - 14);

            const relevantReviews = reviews.filter(r => {
                if (!r || !r.date) return false;
                const rd = new Date(r.date);
                if (isNaN(rd.getTime())) return false;
                return rd >= cutoffDate && rd <= examD;
            });

            if (relevantReviews.length === 0) {
                return { evidence, avgFocus, tiredCount, hardCount, lowFocusCount, hasData: false };
            }

            // Calculate metrics
            let focusSum = 0;
            let focusCount = 0;
            const focusMap = { 'High': 3, 'Medium': 2, 'Low': 1 };

            relevantReviews.forEach(r => {
                if (r.focusQuality) {
                    const fv = focusMap[r.focusQuality] || 0;
                    if (fv > 0) { focusSum += fv; focusCount++; }
                    if (r.focusQuality === 'Low') lowFocusCount++;
                }
                if (r.mood === 'Tired') tiredCount++;
                if (r.difficulty === 'Hard') hardCount++;
            });

            if (focusCount > 0) {
                avgFocus = focusSum / focusCount;
            }

            if (tiredCount > 0) {
                evidence.push(tiredCount + ' session(s) before exam were marked as Tired mood');
            }
            if (lowFocusCount > 0) {
                evidence.push(lowFocusCount + ' session(s) before exam had Low focus quality');
            }
            if (hardCount > 2) {
                evidence.push('Multiple sessions before exam were marked as Hard difficulty');
            }
            if (avgFocus !== null && avgFocus < 2) {
                evidence.push('Average focus quality before exam was below medium level');
            }
        } catch (e) {
            // silent
        }

        return {
            evidence,
            avgFocus,
            tiredCount,
            hardCount,
            lowFocusCount,
            hasData: evidence.length > 0
        };
    }

    // ── Core analysis logic ──

    function _generateStudyAutopsy(formData) {
        const { subject, examName, examDate, score, totalMarks, timeIssue, weakChapters, wrongAreas, mistakeTypes, sectionTimeSplit } = formData;

        const percentage = totalMarks > 0 ? Math.round((score / totalMarks) * 100) : 0;

        // Grade label
        let gradeLabel = 'Critical';
        if (percentage >= 90) gradeLabel = 'Excellent';
        else if (percentage >= 75) gradeLabel = 'Strong';
        else if (percentage >= 60) gradeLabel = 'Decent';
        else if (percentage >= 40) gradeLabel = 'Weak';

        // Gather evidence from data sources
        const prepData = _getSubjectPrepData(subject, examDate);
        const retentionData = _getRetentionEvidence(subject, weakChapters, examDate);
        const backlogData = _getBacklogEvidence(subject);
        const consistencyData = _getConsistencyEvidence(subject, examDate);
        const sessionData = _getSessionReviewEvidence(subject, examDate);

        // Subject prep summary
        let completedChapters = 0;
        let startedChapters = 0;
        function toBool(v) { return v === true || v === 'true'; }
        prepData.forEach(ch => {
            const read = toBool(ch.read);
            const notes = toBool(ch.notes);
            const pyq = toBool(ch.pyq);
            if (read && notes && pyq) completedChapters++;
            else if (read || notes || pyq) startedChapters++;
        });

        // Build context for cause detection
        const context = {
            percentage, gradeLabel, subject, score, totalMarks,
            timeIssue, weakChapters, mistakeTypes, wrongAreas,
            prepData, completedChapters, startedChapters,
            retentionData, backlogData, consistencyData, sessionData
        };

        // Detect primary cause
        const primaryCause = _detectPrimaryCause(context);

        // Build secondary causes
        const secondaryCauses = [];
        if (percentage < 60 && weakChapters.length > 0) {
            secondaryCauses.push('Weak chapters were identified but not sufficiently prepared');
        }
        if (backlogData.criticalCount > 0 || backlogData.highCount > 0) {
            secondaryCauses.push('Unresolved high-priority backlog items in ' + subject);
        }
        if (consistencyData.dropPercent !== null && consistencyData.dropPercent > 20) {
            secondaryCauses.push('Activity dropped ' + consistencyData.dropPercent + '% in the final week');
        }
        if (timeIssue === 'Major time pressure' || timeIssue === 'Could not finish paper') {
            secondaryCauses.push('Time management was a significant issue during the exam');
        }
        if (sessionData.tiredCount > 0) {
            secondaryCauses.push('Tired sessions detected before the exam');
        }
        if (retentionData.lowRetentionChapters.length > 0) {
            secondaryCauses.push('Memory decay was detected in key chapters before the exam');
        }
        // Limit to 4 secondary causes
        while (secondaryCauses.length > 4) secondaryCauses.pop();

        // Build evidence list
        const evidence = [];
        if (retentionData.evidence.length > 0) evidence.push(...retentionData.evidence);
        if (backlogData.evidence.length > 0) evidence.push(...backlogData.evidence);
        if (consistencyData.evidence.length > 0) evidence.push(...consistencyData.evidence);
        if (sessionData.evidence.length > 0) evidence.push(...sessionData.evidence);
        if (timeIssue && timeIssue !== 'No issue') evidence.push('Student reported: ' + timeIssue);
        if (mistakeTypes.length > 0) evidence.push('Mistake types reported: ' + mistakeTypes.join(', '));
        if (wrongAreas) evidence.push('Specific wrong areas: ' + wrongAreas);
        if (completedChapters > 0 || startedChapters > 0) {
            evidence.push('Chapter preparation: ' + completedChapters + ' completed, ' + startedChapters + ' partially done out of ' + prepData.length + ' tracked chapters');
        }

        // Generate recovery plan
        const recoveryPlan = _generateRecoveryPlan(context);

        // Risk label
        const riskLabel = _getAutopsyRiskLabel({ percentage, primaryCause, secondaryCauses, mistakeTypes, timeIssue, backlogData, retentionData });

        // Pattern note (basic)
        let patternNote = '';
        const allReports = _getAutopsyReportsSafe();
        if (allReports.length >= 2) {
            const allMistakes = [];
            allReports.forEach(r => {
                if (r.mistakeTypes && Array.isArray(r.mistakeTypes)) {
                    allMistakes.push(...r.mistakeTypes);
                }
            });
            // Also add current
            if (mistakeTypes) allMistakes.push(...mistakeTypes);
            // Find most common
            const freq = {};
            allMistakes.forEach(m => { freq[m] = (freq[m] || 0) + 1; });
            const sorted = Object.entries(freq).sort((a, b) => b[1] - a[1]);
            if (sorted.length > 0 && sorted[0][1] >= 2) {
                patternNote = 'Pattern detected: "' + sorted[0][0] + '" appears in multiple exams.';
            }
        }

        // Build report object
        const report = {
            id: 'autopsy_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8),
            createdAt: new Date().toISOString(),
            examDate: examDate || _getLocalDateKey(),
            subject,
            examName: examName || 'Exam',
            score,
            totalMarks,
            percentage,
            gradeLabel,
            weakChapters,
            wrongAreas,
            mistakeTypes,
            timeIssue,
            sectionTimeSplit,
            primaryCause,
            secondaryCauses,
            evidence,
            recoveryPlan,
            riskLabel,
            patternNote,
            // Raw data summaries for future reference
            _dataSummary: {
                trackedChapters: prepData.length,
                completedChapters,
                startedChapters,
                avgRetention: retentionData.avgRetention,
                backlogCritical: backlogData.criticalCount,
                backlogHigh: backlogData.highCount,
                finalWeekPP: consistencyData.finalWeekPP,
                prevWeekPP: consistencyData.prevWeekPP,
                ppDropPercent: consistencyData.dropPercent,
                tiredSessionsBeforeExam: sessionData.tiredCount,
                avgFocusBeforeExam: sessionData.avgFocus,
                retentionDataAvailable: retentionData.hasData,
                backlogDataAvailable: backlogData.hasData,
                consistencyDataAvailable: consistencyData.hasData,
                sessionReviewDataAvailable: sessionData.hasData
            }
        };

        return report;
    }

    function _detectPrimaryCause(context) {
        const { percentage, weakChapters, timeIssue, mistakeTypes, backlogData, consistencyData, retentionData } = context;

        // Priority 1: Low retention + weak score
        if (percentage < 60 && retentionData.lowRetentionChapters.length > 0) {
            return 'Low retention before exam';
        }

        // Priority 2: Critical/high backlog
        if (backlogData.criticalCount > 0 || backlogData.highCount > 0) {
            return 'Unresolved backlog pressure';
        }

        // Priority 3: Final week consistency drop
        if (consistencyData.dropPercent !== null && consistencyData.dropPercent > 30) {
            return 'Final week consistency drop';
        }

        // Priority 4: Time management
        if (timeIssue === 'Major time pressure' || timeIssue === 'Could not finish paper') {
            return 'Paper time management failure';
        }

        // Priority 5: Silly mistakes
        if (mistakeTypes && mistakeTypes.includes('Silly mistakes')) {
            return 'Execution errors despite preparation';
        }

        // Default
        return 'Mixed preparation gap';
    }

    function _generateRecoveryPlan(context) {
        const plan = [];
        const { percentage, mistakeTypes, weakChapters, retentionData, backlogData, timeIssue } = context;

        // Memory-based recovery
        if (retentionData.lowRetentionChapters.length > 0) {
            plan.push('Review memory-critical chapters first (retention below 40%)');
        }

        // Weak chapter recovery
        if (weakChapters && weakChapters.length > 0) {
            plan.push('Solve 20 PYQs from weak chapters: ' + weakChapters.slice(0, 3).join(', '));
        }

        // Mistake-based recommendations
        if (mistakeTypes) {
            if (mistakeTypes.includes('Concept gap')) {
                plan.push('Rebuild chapter foundations — re-read theory and solve conceptual questions');
            }
            if (mistakeTypes.includes('Memory loss')) {
                plan.push('Activate spaced repetition cycle for decayed chapters');
            }
            if (mistakeTypes.includes('Silly mistakes')) {
                plan.push('Add a checking ritual: review answers for 5 minutes before submitting');
            }
            if (mistakeTypes.includes('Time management')) {
                plan.push('Practice timed mocks to improve pacing');
            }
            if (mistakeTypes.includes('Calculation errors')) {
                plan.push('Daily calculation drills — 15 minutes of numerical practice');
            }
            if (mistakeTypes.includes('Question interpretation')) {
                plan.push('Practice reading questions carefully — underline key words before solving');
            }
            if (mistakeTypes.includes('Lack of practice')) {
                plan.push('Complete PYQ sets and practice papers before next exam');
            }
        }

        // Time issue
        if (timeIssue === 'Major time pressure' || timeIssue === 'Could not finish paper') {
            plan.push('Add one timed practice session per week');
        }

        // Backlog recovery
        if (backlogData.criticalCount > 0 || backlogData.highCount > 0) {
            plan.push('Clear high-priority backlog tasks in ' + context.subject + ' before starting new topics');
        }

        // Recheck
        if (weakChapters && weakChapters.length > 0) {
            plan.push('Recheck these chapters after 3 days to confirm retention improvement');
        }

        // Limit plan items
        while (plan.length > 6) plan.pop();

        return plan;
    }

    function _getAutopsyRiskLabel(report) {
        const { percentage, primaryCause, secondaryCauses, mistakeTypes, timeIssue, backlogData, retentionData } = report;
        const causeCount = (secondaryCauses ? secondaryCauses.length : 0) + 1;

        // Critical
        if (percentage < 40 || (backlogData && (backlogData.criticalCount > 0) && retentionData && retentionData.lowRetentionChapters && retentionData.lowRetentionChapters.length > 0)) {
            return 'Critical';
        }

        // High Risk
        if (percentage < 60 || causeCount >= 3) {
            return 'High Risk';
        }

        // Moderate Risk
        if (percentage < 75 || causeCount >= 2) {
            return 'Moderate Risk';
        }

        // Low Risk
        return 'Low Risk';
    }

    // ── Handle form submission ──

    function _handleAutopsyFormSubmission() {
        const formData = _collectAutopsyFormData();
        const errors = _validateAutopsyForm(formData);

        if (errors.length > 0) {
            const warning = document.getElementById('autopsyWarning');
            if (warning) {
                warning.textContent = errors.join(' ');
                warning.style.display = 'block';
            }
            return;
        }

        // Clear warnings
        const warning = document.getElementById('autopsyWarning');
        if (warning) { warning.style.display = 'none'; warning.textContent = ''; }

        // Generate report
        const report = _generateStudyAutopsy(formData);

        // Save report
        _saveAutopsyReport(report);

        // Close form modal
        _closeAutopsyModal();

        // Re-render autopsy card
        _renderStudyAutopsyCard();

        // Show the generated report
        _viewAutopsyReport(report.id);

        // Dispatch event
        try {
            document.dispatchEvent(new CustomEvent('smartPadhai:autopsyReportGenerated', { detail: { reportId: report.id } }));
        } catch (e) { /* silent */ }
    }

    // ── View report ──

    function _viewAutopsyReport(reportId) {
        const reports = _getAutopsyReportsSafe();
        const report = reports.find(r => r.id === reportId);
        if (!report) return;

        const contentEl = document.getElementById('autopsyReportContent');
        if (!contentEl) return;

        contentEl.innerHTML = _renderAutopsyReportHTML(report);

        const modal = document.getElementById('autopsyReportModal');
        if (modal) modal.style.display = 'flex';
    }

    function _renderAutopsyReportHTML(report) {
        // Risk badge color
        let riskColor = '#00ff9d';
        if (report.riskLabel === 'Critical') riskColor = '#ff4c4c';
        else if (report.riskLabel === 'High Risk') riskColor = '#ff9f1a';
        else if (report.riskLabel === 'Moderate Risk') riskColor = '#00bcd4';

        // Evidence list
        let evidenceHTML = '';
        if (report.evidence && report.evidence.length > 0) {
            evidenceHTML = report.evidence.map(e => '<li class="autopsy-evidence-item">' + e + '</li>').join('');
        } else {
            evidenceHTML = '<li class="autopsy-evidence-item">Limited data available. More app usage will improve future autopsy accuracy.</li>';
        }

        // Recovery plan
        let recoveryHTML = '';
        if (report.recoveryPlan && report.recoveryPlan.length > 0) {
            recoveryHTML = report.recoveryPlan.map((step, i) => '<li class="autopsy-recovery-item"><span class="autopsy-recovery-num">' + (i + 1) + '</span>' + step + '</li>').join('');
        }

        // Secondary causes
        let secCausesHTML = '';
        if (report.secondaryCauses && report.secondaryCauses.length > 0) {
            secCausesHTML = report.secondaryCauses.map(c => '<li class="autopsy-evidence-item">' + c + '</li>').join('');
        }

        // Pattern note
        let patternHTML = '';
        if (report.patternNote) {
            patternHTML = '<div class="autopsy-pattern-note">' + report.patternNote + '</div>';
        }

        // Data honesty notes
        let honestyNotes = [];
        if (report._dataSummary) {
            if (!report._dataSummary.retentionDataAvailable) honestyNotes.push('Retention data not available yet. Mark chapters reviewed to improve future autopsies.');
            if (!report._dataSummary.consistencyDataAvailable) honestyNotes.push('Not enough PP history for consistency comparison.');
            if (!report._dataSummary.sessionReviewDataAvailable) honestyNotes.push('Session review data is limited.');
            if (!report._dataSummary.backlogDataAvailable) honestyNotes.push('No matching backlog tasks found.');
        }
        let honestyHTML = '';
        if (honestyNotes.length > 0) {
            honestyHTML = '<div class="autopsy-honesty-section"><div class="autopsy-honesty-title">Data Availability</div>' + honestyNotes.map(n => '<div class="autopsy-honesty-item">' + n + '</div>').join('') + '</div>';
        }

        // Next command
        let nextCommand = 'Fix the weakest chapter before starting new topics.';
        if (report.mistakeTypes && report.mistakeTypes.includes('Memory loss')) {
            nextCommand = 'Start a review cycle for decayed chapters today.';
        } else if (report.mistakeTypes && report.mistakeTypes.includes('Time management')) {
            nextCommand = 'Complete one timed practice session this week.';
        } else if (report.percentage >= 75) {
            nextCommand = 'Maintain consistency. Review spacing to prevent decay.';
        }

        return `
            <div class="autopsy-report-card">
                <div class="autopsy-report-header">
                    <div class="autopsy-report-title">STUDY AUTOPSY REPORT</div>
                    <div class="autopsy-report-subject">${report.subject} — ${report.examName}</div>
                    <div class="autopsy-report-score">Score: ${report.score} / ${report.totalMarks}</div>
                    <div class="autopsy-report-percentage">Percentage: ${report.percentage}%</div>
                    <div class="autopsy-report-status">Status: <strong>${report.gradeLabel}</strong></div>
                    <span class="autopsy-risk-badge" style="border-color:${riskColor}; color:${riskColor};">${report.riskLabel}</span>
                </div>

                <div class="autopsy-report-section">
                    <div class="autopsy-report-section-title">Primary Cause</div>
                    <div class="autopsy-primary-cause">${report.primaryCause}</div>
                </div>

                ${report.secondaryCauses && report.secondaryCauses.length > 0 ? `
                <div class="autopsy-report-section">
                    <div class="autopsy-report-section-title">Contributing Factors</div>
                    <ul class="autopsy-evidence-list">${secCausesHTML}</ul>
                </div>` : ''}

                <div class="autopsy-report-section">
                    <div class="autopsy-report-section-title">Evidence</div>
                    <ul class="autopsy-evidence-list">${evidenceHTML}</ul>
                </div>

                <div class="autopsy-report-section">
                    <div class="autopsy-report-section-title">Recovery Plan</div>
                    <ol class="autopsy-recovery-list">${recoveryHTML}</ol>
                </div>

                <div class="autopsy-report-section">
                    <div class="autopsy-report-section-title">Next Command</div>
                    <div class="autopsy-next-command">"${nextCommand}"</div>
                </div>

                ${patternHTML}
                ${honestyHTML}

                <div class="autopsy-report-meta">
                    Generated: ${new Date(report.createdAt).toLocaleString()} | Exam date: ${report.examDate || 'Not specified'}
                </div>
            </div>
        `;
    }

    // ── Delete report ──

    function _handleDeleteAutopsyReport(reportId, targetEl) {
        // Inline confirmation
        const existing = targetEl.parentElement.querySelector('.autopsy-delete-confirm');
        if (existing) {
            // Second click = confirm delete
            _deleteAutopsyReport(reportId);
            _renderStudyAutopsyCard();
            return;
        }

        // First click = show confirmation
        const confirm = document.createElement('span');
        confirm.className = 'autopsy-delete-confirm';
        confirm.textContent = ' Click again to confirm';
        confirm.style.cssText = 'color:#ff4c4c; font-size:0.65rem; margin-left:4px;';
        targetEl.parentNode.insertBefore(confirm, targetEl.nextSibling);

        // Auto-remove confirmation after 3 seconds
        setTimeout(() => {
            if (confirm.parentNode) confirm.remove();
        }, 3000);
    }

    // ── Render Study Autopsy Card ──

    function _renderStudyAutopsyCard() {
        const card = document.getElementById('studyAutopsyCard');
        if (!card) return;

        const reports = _getAutopsyReportsSafe();
        const hasReports = Array.isArray(reports) && reports.length > 0;

        // Latest report summary
        let latestHTML = '';
        if (hasReports) {
            const latest = reports[reports.length - 1];
            let riskColor = '#00ff9d';
            if (latest.riskLabel === 'Critical') riskColor = '#ff4c4c';
            else if (latest.riskLabel === 'High Risk') riskColor = '#ff9f1a';
            else if (latest.riskLabel === 'Moderate Risk') riskColor = '#00bcd4';

            latestHTML = `
                <div class="autopsy-latest">
                    <div class="autopsy-latest-label">Latest Autopsy:</div>
                    <div class="autopsy-latest-summary">
                        <span class="autopsy-latest-subject">${latest.subject}</span>
                        <span class="autopsy-latest-pct"> — ${latest.percentage}%</span>
                    </div>
                    <div class="autopsy-latest-detail">
                        <span class="autopsy-risk-badge autopsy-risk-badge-sm" style="border-color:${riskColor}; color:${riskColor};">${latest.riskLabel}</span>
                        <span class="autopsy-latest-cause">Cause: ${latest.primaryCause}</span>
                    </div>
                    <button class="autopsy-view-btn" data-action="view-autopsy-report" data-report-id="${latest.id}">View Report</button>
                </div>
            `;
        } else {
            latestHTML = `
                <div class="autopsy-empty sp-empty-state">
                    <div class="autopsy-empty-icon sp-empty-state-icon">&#128736;</div>
                    <h3 class="sp-empty-state-title">No Autopsy Reports</h3>
                    <div class="autopsy-empty-text sp-empty-state-text">Analyze your next test to unlock patterns and build a recovery plan.</div>
                </div>
            `;
        }

        // Pattern note
        let patternHTML = '';
        if (hasReports && reports.length >= 2) {
            const allMistakes = [];
            reports.forEach(r => {
                if (r.mistakeTypes && Array.isArray(r.mistakeTypes)) {
                    allMistakes.push(...r.mistakeTypes);
                }
            });
            const freq = {};
            allMistakes.forEach(m => { freq[m] = (freq[m] || 0) + 1; });
            const sorted = Object.entries(freq).sort((a, b) => b[1] - a[1]);
            if (sorted.length > 0 && sorted[0][1] >= 2) {
                patternHTML = '<div class="autopsy-pattern-note">Pattern detected: "' + sorted[0][0] + '" appears in multiple exams.</div>';
            }
        }

        // Previous reports (compact list)
        let historyHTML = '';
        if (hasReports && reports.length > 1) {
            const previousReports = reports.slice(0, -1).reverse(); // newest first, excluding latest
            const historyItems = previousReports.slice(0, 5).map(r => {
                let riskColor = '#00ff9d';
                if (r.riskLabel === 'Critical') riskColor = '#ff4c4c';
                else if (r.riskLabel === 'High Risk') riskColor = '#ff9f1a';
                else if (r.riskLabel === 'Moderate Risk') riskColor = '#00bcd4';

                return `
                    <div class="autopsy-history-item">
                        <span class="autopsy-hist-subject">${r.subject}</span>
                        <span class="autopsy-hist-pct">${r.percentage}%</span>
                        <span class="autopsy-risk-badge autopsy-risk-badge-xs" style="border-color:${riskColor}; color:${riskColor};">${r.riskLabel}</span>
                        <span class="autopsy-hist-date">${r.examDate || '—'}</span>
                        <button class="autopsy-hist-view" data-action="view-autopsy-report" data-report-id="${r.id}">View</button>
                        <button class="autopsy-hist-delete" data-action="delete-autopsy-report" data-report-id="${r.id}">Delete</button>
                    </div>
                `;
            }).join('');

            historyHTML = `
                <div class="autopsy-history">
                    <div class="autopsy-history-title">Previous Reports</div>
                    <div class="autopsy-history-list">${historyItems}</div>
                </div>
            `;
        }

        card.innerHTML = `
            <div class="study-autopsy-card-inner">
                <div class="study-autopsy-header">
                    <div class="study-autopsy-title">STUDY AUTOPSY</div>
                    <div class="study-autopsy-subtitle">Turn exam results into a recovery plan.</div>
                </div>
                <button class="study-autopsy-create-btn" data-action="open-autopsy-modal">
                    <span class="study-autopsy-create-icon">&#128736;</span>
                    Create Autopsy Report
                </button>
                ${latestHTML}
                ${patternHTML}
                ${historyHTML}
            </div>
        `;
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();
