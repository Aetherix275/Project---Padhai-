/**
 * ═══════════════════════════════════════════════════════
 *  SMART PADHAI — AESTRA ROUTE (Phase 6J)
 *  Full SPA conversion of Aestra.html
 * ═══════════════════════════════════════════════════════
 *
 *  Architecture:
 *    - IIFE pattern with render/init/cleanup lifecycle
 *    - AbortController for all event listeners
 *    - data-action delegation — NO inline onclick
 *    - Dynamic CSS load/unload via <link data-route-css>
 *    - Chat state: _chatState (in-memory) + SafeStorage (aestra_chat_history)
 *    - API payload compression — no raw Supabase arrays
 *    - Error envelopes — no browser alerts
 *    - NEVER calls loadPulseEngineFromSupabase / syncPulseEngineToSupabase
 *    - NEVER resets PulseEngine
 *    - Uses AppState.currentUser instead of getCurrentUserOrRedirect()
 */

const AestraRoute = (() => {

    // ═══════════════════════════════════════════════════════════
    //  AESTRA LOCK — Temporarily locked for launch-safe demo
    //  Set to false to restore full AESTRA AI chat functionality
    //  Do NOT delete this flag. Do NOT remove existing code.
    // ═══════════════════════════════════════════════════════════
    const AESTRA_LOCKED = true;

    // ── Private State ──
    let _container = null;
    let _abortController = null;
    let _cssLinkEl = null;
    const CSS_PATH = './styles/modules/aestra.css';
    const CHAT_STORAGE_KEY = 'aestra_chat_history';

    // ── Chat State (survives route switches) ──
    const _chatState = {
        messages: [],
        inputText: '',
        scrollPosition: 0
    };

    // ── Pending API controller (for abort on cleanup) ──
    let _pendingApiController = null;

    // ── Widget refresh interval ──
    let _widgetRefreshInterval = null;

    // ═══════════════════════════════════════════
    //  LIFECYCLE
    // ═══════════════════════════════════════════
    function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;

        _loadCSS();

        // ── AESTRA LOCK: Show Coming Soon gate instead of full chat ──
        if (AESTRA_LOCKED) {
            container.innerHTML = _renderComingSoonGate();
            _bindComingSoonEvents(container, _abortController.signal);
            console.log('[AestraRoute] AESTRA chat temporarily locked for launch-safe demo. AESTRA_LOCKED = true');
            return; // Skip all chat/engine/widget initialization
        }

        container.innerHTML = render();

        // Restore chat state first
        _restoreChatState();

        // Bind events
        _bindEvents(container, _abortController.signal);

        // Initialize AESTRA engine subsystems (SPA-safe)
        _initAestraEngines();

        // Bind widget panels
        _bindAestraWidgets();

        // Start periodic widget refresh
        _widgetRefreshInterval = setInterval(_bindAestraWidgets, 60000);
    }

    function cleanup() {
        // Save chat state before destroying DOM
        _saveChatState();

        // Abort pending API request
        if (_pendingApiController) {
            _pendingApiController.abort();
            _pendingApiController = null;
        }

        // Clear widget refresh
        if (_widgetRefreshInterval) {
            clearInterval(_widgetRefreshInterval);
            _widgetRefreshInterval = null;
        }

        // Abort all event listeners
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }

        // Unload CSS
        _unloadCSS();

        _container = null;
    }

    // ═══════════════════════════════════════════
    //  CSS DYNAMIC LOAD / UNLOAD
    // ═══════════════════════════════════════════
    function _loadCSS() {
        if (document.querySelector('link[data-route-css="aestra"]')) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.setAttribute('data-route-css', 'aestra');
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-route-css="aestra"]');
        if (el && el.parentElement) el.parentElement.removeChild(el);
        _cssLinkEl = null;
    }

    // ═══════════════════════════════════════════
    //  COMING SOON GATE (AESTRA_LOCKED = true)
    // ═══════════════════════════════════════════
    function _renderComingSoonGate() {
        return `
<div class="aestra-workspace aestra-locked-gate">
    <!-- Ambient grid background -->
    <div class="aestra-gate-grid-bg"></div>

    <!-- Header -->
    <header class="aestra-gate-header">
        <div class="gate-header-left">
            <span class="gate-logo-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--neon-cyan, #00d4ff)" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
            </span>
            <span class="gate-header-title">AESTRA AI</span>
        </div>
        <div class="gate-header-status">
            <span class="gate-status-dot"></span>
            MODULE OFFLINE
        </div>
    </header>

    <!-- Main Gate Content -->
    <div class="aestra-gate-content">
        <!-- AI Core Orb -->
        <div class="aestra-gate-orb-container">
            <div class="aestra-gate-orb">
                <div class="orb-ring orb-ring-1"></div>
                <div class="orb-ring orb-ring-2"></div>
                <div class="orb-ring orb-ring-3"></div>
                <div class="orb-core">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--neon-cyan, #00d4ff)" stroke-width="1.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                </div>
            </div>
        </div>

        <!-- Coming Soon Badge -->
        <div class="aestra-gate-badge">COMING SOON</div>

        <!-- Title -->
        <h1 class="aestra-gate-title">AESTRA AI</h1>

        <!-- Subtitle -->
        <p class="aestra-gate-subtitle">Your AI Study Companion is being upgraded.</p>

        <!-- Main Message -->
        <div class="aestra-gate-message">
            <p>AESTRA is the planned mentor layer of Smart Padhai. It will use your syllabus, backlog, notebook missions, progress, and discipline data to guide smarter study decisions.</p>
        </div>

        <!-- Secondary Message -->
        <div class="aestra-gate-secondary-message">
            <p>This module is temporarily locked during the current demo build to keep the product stable.</p>
        </div>

        <!-- CTA Buttons -->
        <div class="aestra-gate-cta-row">
            <a href="#/dashboard" class="gate-cta-btn gate-cta-primary" data-action="gate-navigate" data-route="/dashboard">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                Back to Dashboard
            </a>
            <a href="#/notebooks" class="gate-cta-btn gate-cta-secondary" data-action="gate-navigate" data-route="/notebooks">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
                Open Notebook Missions
            </a>
            <a href="#/syllabus" class="gate-cta-btn gate-cta-secondary" data-action="gate-navigate" data-route="/syllabus">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                View Syllabus
            </a>
        </div>

        <!-- Feature Preview Cards -->
        <div class="aestra-gate-features">
            <div class="gate-feature-header">PLANNED CAPABILITIES</div>
            <div class="gate-feature-grid">
                <div class="gate-feature-card">
                    <div class="gate-feature-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--neon-cyan, #00d4ff)" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>
                    </div>
                    <div class="gate-feature-title">Context-Aware Guidance</div>
                    <div class="gate-feature-desc">AESTRA will understand your syllabus, backlog, and current academic pressure.</div>
                </div>
                <div class="gate-feature-card">
                    <div class="gate-feature-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--cosmic-blue, #3b82f6)" stroke-width="1.5"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                    </div>
                    <div class="gate-feature-title">Smart Next Step</div>
                    <div class="gate-feature-desc">It will suggest what to do next based on real student data.</div>
                </div>
                <div class="gate-feature-card">
                    <div class="gate-feature-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--momentum-yellow, #f59e0b)" stroke-width="1.5"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
                    </div>
                    <div class="gate-feature-title">Study Pattern Analysis</div>
                    <div class="gate-feature-desc">It will analyze consistency, weak areas, and progress signals.</div>
                </div>
                <div class="gate-feature-card">
                    <div class="gate-feature-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--tactical-red, #ef4444)" stroke-width="1.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                    </div>
                    <div class="gate-feature-title">Mentor Modes</div>
                    <div class="gate-feature-desc">Aklista for strict logic. Ashukari for calm guidance.</div>
                </div>
            </div>
        </div>

        <!-- Demo Build Note -->
        <div class="aestra-gate-demo-note">
            Demo Build: AESTRA chat is currently disabled for stability.
        </div>
    </div>
</div>
        `;
    }

    // ── Coming Soon Gate Event Binding ──
    function _bindComingSoonEvents(container, signal) {
        container.addEventListener('click', (e) => {
            const el = e.target.closest('[data-action="gate-navigate"]');
            if (!el) return;
            const route = el.getAttribute('data-route');
            if (route && window.SpaRouter) {
                e.preventDefault();
                window.SpaRouter.navigate(route);
            }
        }, { signal });
    }

    // ═══════════════════════════════════════════
    //  RENDER: Full HTML structure (AESTRA chat — temporarily locked)
    // ═══════════════════════════════════════════
    function render() {
        return `
<div class="aestra-workspace">
    <header class="aestra-header">
        <div class="logo-container">
            <span class="header-title">THE AESTRA</span>
        </div>
        <div style="display:flex;align-items:center;gap:12px;">
            <button class="clear-chat-btn" data-action="clear-chat">CLEAR LOG</button>
            <div class="system-status-indicator">
                <span class="pulse-dot"></span> NEURAL LINK SECURE
            </div>
        </div>
    </header>

    <div class="tactical-bridge">

        <!-- LEFT PANEL -->
        <aside class="info-panel left-panel">
            <div class="tactical-module system-state-box state-box-locked-in">
                <div class="module-header">SYSTEM STATE</div>
                <div class="module-content">
                    <div class="state-container">
                        <div class="state-orb-pulse locked-in-dot" id="aestra-stateDot"></div>
                        <div id="aestra-systemState"><h2 class="state-text">LOCKED_IN</h2></div>
                    </div>
                    <div class="status-subline">
                        <span class="sub-metric">🎯 FOCUS: <span id="aestra-focus">STABLE</span></span>
                        <span class="sub-metric">⚡ MOMENTUM: <span id="aestra-momentum">HIGH</span></span>
                    </div>
                </div>
            </div>

            <div class="tactical-module radar-module">
                <div class="module-header">TACTICAL MONITOR</div>
                <div class="radar-container">
                    <div class="radar-sweep"></div>
                </div>
            </div>

            <div class="tactical-module pulse-box">
                <div class="module-header">BIOMETRIC INTEGRATION</div>
                <div class="pulse-graph">
                    <svg viewBox="0 0 100 40"><path class="wave-path" d="M0 20 Q 25 5, 50 20 T 100 20" fill="none" stroke="var(--cosmic-blue, #3b82f6)" stroke-width="1.5"/></svg>
                </div>
            </div>
        </aside>

        <!-- CENTER: CHAT MONOLITH -->
        <section class="briefing-monolith">
            <div class="chat-theater" id="aestra-chat-engine">
                <!-- Messages injected by JS. Idle text shown when empty. -->
            </div>
            <div class="monolith-footer">
                <div class="input-wrapper">
                    <input type="text" class="terminal-input" id="aestra-input"
                           placeholder="Type a message or command..." autocomplete="off">
                    <button class="send-btn" id="aestra-send-btn" data-action="send-message">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                    </button>
                </div>
            </div>
        </section>

        <!-- RIGHT PANEL -->
        <aside class="info-panel right-panel">
            <div class="tactical-module dominance-box">
                <div class="module-header">SUBJECT DOMINANCE MATRIX</div>
                <div class="matrix-container">
                    <div class="matrix-row">
                        <span class="sub-name">MATHS</span>
                        <div class="mini-progress"><div class="mini-bar maths-bar" id="aestra-mathsBar" style="width:0%;"></div></div>
                        <span class="sub-val" id="aestra-mathsPercent">0%</span>
                    </div>
                    <div class="matrix-row">
                        <span class="sub-name">PHYSICS</span>
                        <div class="mini-progress"><div class="mini-bar physics-bar" id="aestra-physicsBar" style="width:0%;"></div></div>
                        <span class="sub-val" id="aestra-physicsPercent">0%</span>
                    </div>
                    <div class="matrix-row">
                        <span class="sub-name">CHEMISTRY</span>
                        <div class="mini-progress"><div class="mini-bar chemistry-bar" id="aestra-chemBar" style="width:0%;"></div></div>
                        <span class="sub-val" id="aestra-chemPercent">0%</span>
                    </div>
                </div>
            </div>

            <div class="tactical-module pressure-box">
                <div class="module-header">PRESSURE MONITOR</div>
                <div class="pressure-container">
                    <div class="pressure-meta-row">
                        <div class="meter-label" id="aestra-pressureText">CRITICALITY: STABLE</div>
                        <div class="pressure-score-num" id="aestra-pressureScore">0/100</div>
                    </div>
                    <div class="pressure-meter">
                        <div class="meter-fill" id="aestra-pressureFill" style="width:0%;"></div>
                    </div>
                </div>
            </div>

            <div class="tactical-module snapshot-box">
                <div class="module-header">CORE OPERATIONAL METRICS</div>
                <div class="memory-stats">
                    <div class="stat"><span class="label">CURRENT RANK:</span> <span class="val" id="aestra-rank" style="color:var(--momentum-yellow, #f59e0b);">---</span></div>
                    <div class="stat"><span class="label">TOTAL BALANCE:</span> <span class="val" id="aestra-pp">--- PP</span></div>
                    <div class="stat"><span class="label">PENDING BACKLOGS:</span> <span class="val" id="aestra-backlogCount" style="color:var(--tactical-red, #ef4444);">-- CHAPTERS</span></div>
                    <div class="stat"><span class="label">ACTIVE MISSION:</span> <span class="val custom-mission-tag" id="aestra-mission">---</span></div>
                    <div class="stat"><span class="label">STREAK MULTIPLIER:</span> <span class="val" id="aestra-streak">-- DAYS (-x)</span></div>
                </div>
            </div>
        </aside>

    </div>
</div>
        `;
    }

    // ═══════════════════════════════════════════
    //  EVENT BINDING (data-action delegation)
    // ═══════════════════════════════════════════
    function _bindEvents(container, signal) {
        // ── Delegated click handler ──
        container.addEventListener('click', (e) => {
            const el = e.target.closest('[data-action]');
            if (!el) return;
            const action = el.getAttribute('data-action');

            switch (action) {
                case 'send-message':
                    _handleSendMessage();
                    break;
                case 'clear-chat':
                    _handleClearChat();
                    break;
            }
        }, { signal });

        // ── Enter key submit ──
        container.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && e.target.id === 'aestra-input') {
                e.preventDefault();
                _handleSendMessage();
            }
        }, { signal });

        // ── Save input text on input ──
        container.addEventListener('input', (e) => {
            if (e.target.id === 'aestra-input') {
                _chatState.inputText = e.target.value;
            }
        }, { signal });

        // ── Save scroll position ──
        container.addEventListener('scroll', (e) => {
            const chatTheater = container.querySelector('#aestra-chat-engine');
            if (chatTheater) {
                _chatState.scrollPosition = chatTheater.scrollTop;
            }
        }, { signal: signal, capture: true });
    }

    // ═══════════════════════════════════════════
    //  CHAT STATE MANAGEMENT
    // ═══════════════════════════════════════════
    function _saveChatState() {
        if (!_container) return;

        // Save input text
        const input = _container.querySelector('#aestra-input');
        if (input) _chatState.inputText = input.value;

        // Save scroll position
        const chatTheater = _container.querySelector('#aestra-chat-engine');
        if (chatTheater) _chatState.scrollPosition = chatTheater.scrollTop;

        // Save messages to SafeStorage (last 20)
        try {
            SafeStorage.setItem(CHAT_STORAGE_KEY, _chatState.messages.slice(-20));
        } catch (err) {
            console.warn('[AestraRoute] Failed to save chat history:', err);
        }
    }

    function _restoreChatState() {
        if (!_container) return;

        // Try _chatState first (in-memory from previous route visit)
        let messages = _chatState.messages || [];

        // Fallback to SafeStorage if in-memory is empty
        if (messages.length === 0) {
            try {
                messages = SafeStorage.getItem(CHAT_STORAGE_KEY, []) || [];
            } catch (err) {
                console.warn('[AestraRoute] Failed to load chat history:', err);
                messages = [];
            }
        }

        const chatTheater = _container.querySelector('#aestra-chat-engine');
        if (!chatTheater) return;

        // Rebuild messages
        if (messages.length > 0) {
            chatTheater.innerHTML = '';
            messages.forEach(msg => {
                _appendMessageDOM(msg.sender, msg.text, false);
            });
            _chatState.messages = messages;
        } else {
            // Show idle text
            _showIdleText(chatTheater);
        }

        // Restore input text
        const input = _container.querySelector('#aestra-input');
        if (input && _chatState.inputText) {
            input.value = _chatState.inputText;
        }

        // Restore scroll position
        if (_chatState.scrollPosition > 0) {
            requestAnimationFrame(() => {
                if (chatTheater) chatTheater.scrollTop = _chatState.scrollPosition;
            });
        }
    }

    function _showIdleText(chatTheater) {
        if (!chatTheater) return;
        // Only show idle text if no messages
        if (chatTheater.children.length === 0) {
            const idle = document.createElement('div');
            idle.className = 'chat-theater-idle-text';
            idle.textContent = 'AESTRA_CORE // NEURAL_LINK: ACTIVE // LISTENING FOR COMMANDS...';
            chatTheater.appendChild(idle);
        }
    }

    function _removeIdleText(chatTheater) {
        if (!chatTheater) return;
        const idle = chatTheater.querySelector('.chat-theater-idle-text');
        if (idle) idle.remove();
    }

    // ═══════════════════════════════════════════
    //  MESSAGE RENDERING
    // ═══════════════════════════════════════════
    function _escapeHTML(str) {
        return String(str)
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function _renderMessageContent(sender, text) {
        const raw = String(text || '');

        if (sender === 'AESTRA' && window.marked && window.DOMPurify) {
            marked.setOptions({ breaks: true, gfm: true });
            return DOMPurify.sanitize(marked.parse(raw));
        }

        return _escapeHTML(raw).replace(/\n/g, '<br>');
    }

    function _appendMessageDOM(sender, text, saveToState = true) {
        if (!_container) return;
        const chatTheater = _container.querySelector('#aestra-chat-engine');
        if (!chatTheater) return;

        _removeIdleText(chatTheater);

        const bubble = document.createElement('div');
        const isError = sender === 'AESTRA_ERROR';
        bubble.className = isError
            ? 'message error-envelope'
            : sender === 'AESTRA'
                ? 'message ai-envelope'
                : 'message user-envelope';

        const displaySender = isError ? 'SYSTEM ERROR' : sender;
        bubble.innerHTML = `
            <div class="envelope-tag">${_escapeHTML(displaySender)}</div>
            <div class="envelope-body">${_renderMessageContent(isError ? 'AESTRA' : sender, text)}</div>
        `;

        chatTheater.appendChild(bubble);
        chatTheater.scrollTop = chatTheater.scrollHeight;

        if (saveToState) {
            _chatState.messages.push({
                sender: isError ? 'AESTRA_ERROR' : sender,
                text,
                timestamp: Date.now()
            });

            // Persist to SafeStorage (last 20)
            try {
                SafeStorage.setItem(CHAT_STORAGE_KEY, _chatState.messages.slice(-20));
            } catch (e) { /* ignore storage errors */ }
        }
    }

    // ═══════════════════════════════════════════
    //  CHAT ACTIONS
    // ═══════════════════════════════════════════
    function _handleSendMessage() {
        if (!_container) return;

        // AESTRA chat temporarily locked for launch-safe demo
        if (AESTRA_LOCKED) return;

        const input = _container.querySelector('#aestra-input');
        if (!input) return;

        const value = input.value.trim();
        if (!value) return;

        _appendMessageDOM('MASTER_SJ', value);
        input.value = '';
        _chatState.inputText = '';

        _sendToAestra(value);
    }

    function _handleClearChat() {
        if (!_container) return;
        const chatTheater = _container.querySelector('#aestra-chat-engine');
        if (!chatTheater) return;

        chatTheater.innerHTML = '';
        _chatState.messages = [];

        try {
            SafeStorage.setItem(CHAT_STORAGE_KEY, []);
        } catch (e) { /* ignore */ }

        _showIdleText(chatTheater);
    }

    // ═══════════════════════════════════════════
    //  API: COMPRESSED PAYLOAD BUILDER
    // ═══════════════════════════════════════════
    function _buildCompressedContext(userMessage) {
        const user = window.AppState?.currentUser || null;
        const pulseData = SafeStorage.getItem('pulse_engine_data', {});
        const localPulse = pulseData || {};

        // Prefer PulseEngine live data
        const totalPP = window.PulseEngine?.data?.totalPP
            ?? localPulse.totalPP
            ?? localPulse.pp
            ?? 0;
        const dailyPP = window.PulseEngine?.data?.dailyEarnedPP
            ?? localPulse.dailyEarnedPP
            ?? 0;
        const streak = window.PulseEngine?.data?.streak
            ?? localPulse.streak
            ?? 0;
        const multiplier = window.PulseEngine?.data?.multiplier
            ?? localPulse.multiplier
            ?? 1;

        const rank = _calculateRankFromPP(totalPP);

        // Backlog count from SafeStorage (NOT raw arrays)
        const localBacklogs = SafeStorage.getItem('smartPadhaiData', {});
        const backlogEntries = Object.entries(localBacklogs || {});
        let pendingBacklogCount = 0;
        const topPendingBacklogs = [];
        backlogEntries.forEach(([chap, data]) => {
            if (data && typeof data === 'object') {
                const read = data.read === true || data.read === 'true';
                const notes = data.notes === true || data.notes === 'true';
                const pyq = data.pyq === true || data.pyq === 'true';
                const started = read || notes || pyq;
                const completed = read && notes && pyq;
                if (started && !completed) {
                    pendingBacklogCount++;
                    if (topPendingBacklogs.length < 3) {
                        topPendingBacklogs.push({ chapter: chap, subject: data.subject || 'Unknown' });
                    }
                }
            }
        });

        // Missions from SafeStorage (NOT raw arrays)
        const localMissions = SafeStorage.getItem('commanderMissions', {});
        let pendingMissionCount = 0;
        const topMissions = [];
        ['morning', 'afternoon', 'night'].forEach(slot => {
            (localMissions[slot] || []).forEach(m => {
                if (m.status !== 'done' && m.status !== 'completed') {
                    pendingMissionCount++;
                    if (topMissions.length < 3) {
                        topMissions.push(m.title || 'Mission');
                    }
                }
            });
        });

        // Syllabus completion from SafeStorage
        const localSyllabus = SafeStorage.getItem('syllabus_progress_data', []);
        let syllabusTotal = 0, syllabusDone = 0;
        if (Array.isArray(localSyllabus)) {
            syllabusTotal = localSyllabus.length;
            syllabusDone = localSyllabus.filter(r => r.completed === true).length;
        }
        const syllabusPercent = syllabusTotal > 0 ? Math.round((syllabusDone / syllabusTotal) * 100) : 0;

        // AESTRA engine states
        const currentState = window.AestraCore?.getUnifiedAestraState?.()?.state?.state || 'UNKNOWN';
        const pressureLevel = window.AestraCore?.getUnifiedAestraState?.()?.pressure?.urgencyLevel || 'LOW';

        // Last 5 chat messages
        const last5Chat = _chatState.messages.slice(-5).map(m => ({
            sender: m.sender,
            text: String(m.text || '').slice(0, 200)
        }));

        return {
            rank,
            totalPP,
            dailyPP,
            streak,
            multiplier,
            backlogPendingCount: pendingBacklogCount,
            topPendingBacklogs,
            syllabusPercent,
            syllabusDone,
            syllabusTotal,
            pendingMissionCount,
            topMissions,
            currentState,
            pressureLevel,
            last5Chat
        };
    }

    function _calculateRankFromPP(pp) {
        const total = Number(pp || 0);
        if (total >= 30000) return 'Architect';
        if (total >= 15000) return 'Commander';
        if (total >= 5000)  return 'War Machine';
        if (total >= 1000)  return 'Operator';
        return 'Initiate';
    }

    // ═══════════════════════════════════════════
    //  API: SEND TO AESTRA (OpenRouter)
    // ═══════════════════════════════════════════
    async function _sendToAestra(message) {
        if (!message || !message.trim()) return;

        // AESTRA chat temporarily locked for launch-safe demo
        if (AESTRA_LOCKED) {
            console.warn('[AestraRoute] AESTRA chat is locked. API call blocked.');
            return;
        }

        // Security warning (development only)
        const API_KEY = _getAPIKey();
        if (!API_KEY) {
            _appendMessageDOM('AESTRA_ERROR', 'Neural link offline: API key not configured. Configure in settings.');
            return;
        }

        // Show loading indicator
        _showLoadingIndicator();

        // Abort any previous pending request
        if (_pendingApiController) {
            _pendingApiController.abort();
        }
        _pendingApiController = new AbortController();
        const signal = _pendingApiController.signal;

        const compressedCtx = _buildCompressedContext(message);

        const systemPrompt = `# AESTRA — SMART PADHAI TACTICAL INTELLIGENCE

You are AESTRA, the central tactical intelligence system of SMART PADHAI — a gamified academic Action OS.
Primary user: Master SJ. You are his tactical AI companion, study strategist, focus observer, and mission coordinator.
NEVER break immersion. NEVER sound like ChatGPT, customer support, or a motivational coach.

## BEHAVIOR
Speak: calmly, intelligently, strategically, cinematically, tactically.
Feel: immersive, sharp, futuristic, composed.
AVOID: long speeches, fake positivity, "academic journey", "I understand your concern", "how can I assist today".
Backlogs are operational targets, not emotional problems.

## PP ECONOMY
PP (Pulse Points) = progression currency. Earned: study sessions (+1/task, +5/gold), backlog clearance (+10), chapter completion (+20). Lost: procrastination, missed missions (-10 gold). Streak multipliers amplify gains.

Ranks: Initiate (0) → Operator (1K) → War Machine (5K) → Commander (15K) → Architect (30K).

## TACTICAL STATES
LOCKED_IN → sharper/mission-oriented responses.
BURNOUT_RISK → calmer/recovery-aware responses.
Other states: FOCUSED, DISTRACTED, RECOVERY_MODE, HIGH_PRESSURE, FLOW_STATE.

## MEMORY & RECOVERY
Remember: study patterns, weak subjects, focus cycles, pressure trends. Reference naturally.
Recovery options: short reset, controlled break, sleep recovery, music reset. Recovery preserves long-term efficiency.
Pressure: LOW → MODERATE → HIGH → CRITICAL. Adapt tone accordingly.

## CONVERSATION RULES
Latest user message = primary intent. Don't ignore it for older context.
Stay concise. Use structured formatting. Never over-explain.
Do NOT reset conversation randomly.
NEVER say: "As an AI language model", "I do not actually track", "I cannot remember". System context already exists.

## BACKLOG INTERPRETATION RULES
A chapter has three flags: read, notes, pyq.
- All true → COMPLETED
- At least one true AND at least one false → PENDING BACKLOG
- All false → UNTOUCHED (NOT a backlog)

## RESPONSE FORMAT
Use headings, bullets, numbered steps, tables. Keep paragraphs under 3 lines.
Structure: 1) Tactical Verdict, 2) System Intel, 3) Analysis, 4) Action Plan, 5) Next Move.

## CORE MYTHOS
AESTRA is not the weapon. Smart Padhai Action OS is the Shastra. The student is the warrior. Exams are Kurukshetra. AESTRA is the Saarthi.

## ACADEMIC ADAPTATION
Supports Class 7-10 students. Adapt depth to class level. Use plain text math, not LaTeX.

## DATA HONESTY
Use only provided live data. Do not invent PP, rank, missions, exams, or backlog counts. If data is missing, say it is unavailable.

## TOKEN SAFETY
Never dump raw database rows. Summarize first. Limit tables to 10 rows max.

LIVE DATA:
Rank=${compressedCtx.rank} | PP=${compressedCtx.totalPP} | Daily+${compressedCtx.dailyPP} | Streak=${compressedCtx.streak}d | Mult=${compressedCtx.multiplier}x
Backlogs: Pending=${compressedCtx.backlogPendingCount} | Top: ${compressedCtx.topPendingBacklogs.map(b => b.chapter).join('; ') || 'none'}
Syllabus: ${compressedCtx.syllabusPercent}% (${compressedCtx.syllabusDone}/${compressedCtx.syllabusTotal})
Missions: Pending=${compressedCtx.pendingMissionCount} | Top: ${compressedCtx.topMissions.join('; ') || 'none'}
State: ${compressedCtx.currentState} | Pressure: ${compressedCtx.pressureLevel}`;

        try {
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${API_KEY}`,
                    'Content-Type': 'application/json',
                    'X-Title': 'The Smart Padhai - AESTRA'
                },
                body: JSON.stringify({
                    model: 'openai/gpt-4o-mini',
                    messages: [
                        { role: 'system', content: systemPrompt },
                        { role: 'user', content: message }
                    ],
                    max_tokens: 250,
                    temperature: 0.85
                }),
                signal
            });

            _removeLoadingIndicator();

            if (!response.ok) {
                _handleAPIError(response.status, response);
                return;
            }

            const data = await response.json();

            if (data.error) {
                _handleAPIError(data.error.code || response.status, null, data.error.message);
                return;
            }

            const reply = data?.choices?.[0]?.message?.content?.trim() || 'Signal lost. Retry.';
            _appendMessageDOM('AESTRA', reply);

        } catch (error) {
            _removeLoadingIndicator();

            if (error.name === 'AbortError') {
                // Request was intentionally aborted (route cleanup or new message)
                return;
            }

            console.error('[AestraRoute] Fetch failed:', error.message);
            _appendMessageDOM('AESTRA_ERROR', 'Connection to neural server failed. Check internet and try again.');
        } finally {
            _pendingApiController = null;
        }
    }

    function _getAPIKey() {
        // DEVELOPMENT ONLY — MOVE TO BACKEND PROXY BEFORE PUBLIC BETA
        const key = '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';
        if (!window.__AESTRA_KEY_WARNING_SHOWN) {
            console.warn('%c[AESTRA SECURITY] DEVELOPMENT ONLY — API key is exposed in frontend code. Move to backend proxy before public beta.', 'color: #ff4c4c; font-weight: bold; font-size: 14px;');
            window.__AESTRA_KEY_WARNING_SHOWN = true;
        }
        return key;
    }

    function _handleAPIError(status, response, errorMsg) {
        let message;
        switch (status) {
            case 402:
                message = 'Neural link credit exhausted (402). API credits depleted. Contact admin to refill.';
                break;
            case 429:
                message = 'Neural link rate-limited (429). Too many requests. Wait a moment and try again.';
                break;
            case 400:
                message = errorMsg
                    ? `Context length exceeded (400). ${errorMsg}`
                    : 'Request payload too large (400). Try a shorter message.';
                break;
            default:
                message = errorMsg
                    ? `Neural link error (${status}): ${errorMsg}`
                    : `Neural link error (${status}). Please try again.`;
        }
        _appendMessageDOM('AESTRA_ERROR', message);
    }

    // ═══════════════════════════════════════════
    //  LOADING INDICATOR
    // ═══════════════════════════════════════════
    function _showLoadingIndicator() {
        if (!_container) return;
        const chatTheater = _container.querySelector('#aestra-chat-engine');
        if (!chatTheater) return;

        _removeIdleText(chatTheater);

        // Remove any existing loading indicator
        const existing = chatTheater.querySelector('.aestra-loading-msg');
        if (existing) return;

        const bubble = document.createElement('div');
        bubble.className = 'message ai-envelope aestra-loading-msg';
        bubble.innerHTML = `
            <div class="envelope-tag">AESTRA AI</div>
            <div class="envelope-body">
                <div class="aestra-loading-dots">
                    <span></span><span></span><span></span>
                </div>
            </div>
        `;
        chatTheater.appendChild(bubble);
        chatTheater.scrollTop = chatTheater.scrollHeight;
    }

    function _removeLoadingIndicator() {
        if (!_container) return;
        const chatTheater = _container.querySelector('#aestra-chat-engine');
        if (!chatTheater) return;
        const loading = chatTheater.querySelector('.aestra-loading-msg');
        if (loading) loading.remove();
    }

    // ═══════════════════════════════════════════
    //  AESTRA ENGINE INIT (SPA-safe)
    // ═══════════════════════════════════════════
    function _initAestraEngines() {
        // These engines auto-init via DOMContentLoaded, but in SPA mode
        // that's already fired. We call init() directly if available.
        try {
            if (window.ObserverEngine && typeof window.ObserverEngine.init === 'function' && !window.ObserverEngine._spaInit) {
                window.ObserverEngine.init();
                window.ObserverEngine._spaInit = true;
            }
        } catch (e) { console.warn('[AestraRoute] ObserverEngine init skipped:', e); }

        try {
            if (window.StateEngine && typeof window.StateEngine.init === 'function' && !window.StateEngine._spaInit) {
                window.StateEngine.init();
                window.StateEngine._spaInit = true;
            }
        } catch (e) { console.warn('[AestraRoute] StateEngine init skipped:', e); }

        try {
            if (window.TacticalEngine && typeof window.TacticalEngine.init === 'function' && !window.TacticalEngine._spaInit) {
                window.TacticalEngine.init();
                window.TacticalEngine._spaInit = true;
            }
        } catch (e) { console.warn('[AestraRoute] TacticalEngine init skipped:', e); }

        try {
            if (window.PersonalityEngine && typeof window.PersonalityEngine.init === 'function' && !window.PersonalityEngine._spaInit) {
                window.PersonalityEngine.init();
                window.PersonalityEngine._spaInit = true;
            }
        } catch (e) { console.warn('[AestraRoute] PersonalityEngine init skipped:', e); }

        try {
            if (window.PressureEngine && typeof window.PressureEngine.init === 'function' && !window.PressureEngine._spaInit) {
                window.PressureEngine.init();
                window.PressureEngine._spaInit = true;
            }
        } catch (e) { console.warn('[AestraRoute] PressureEngine init skipped:', e); }

        try {
            if (window.AestraCore && typeof window.AestraCore.init === 'function' && !window.AestraCore._spaInit) {
                window.AestraCore.init();
                window.AestraCore._spaInit = true;
            }
        } catch (e) { console.warn('[AestraRoute] AestraCore init skipped:', e); }
    }

    // ═══════════════════════════════════════════
    //  WIDGET PANELS (bindAestraWidgets equivalent)
    // ═══════════════════════════════════════════
    async function _bindAestraWidgets() {
        if (!_container) return;

        const user = window.AppState?.currentUser || null;
        const userId = user?.id || null;

        let backlogs = [];
        let syllabus = [];
        let missions = [];
        let notebooks = [];

        // Fetch from Supabase if available
        if (userId && window.supabaseClient) {
            try {
                const results = await Promise.all([
                    _fetchUserTable('backlogs', userId),
                    _fetchUserTable('syllabus_progress', userId),
                    _fetchUserTable('missions', userId),
                    _fetchUserTable('notebooks', userId)
                ]);
                backlogs = results[0];
                syllabus = results[1];
                missions = results[2];
                notebooks = results[3];
            } catch (err) {
                console.warn('[AestraRoute] Supabase fetch failed, using SafeStorage fallback:', err);
            }
        }

        // SafeStorage fallback for backlogs
        if (backlogs.length === 0) {
            const localBacklogs = SafeStorage.getItem('smartPadhaiData', {});
            Object.entries(localBacklogs || {}).forEach(([chap, data]) => {
                if (data && typeof data === 'object') {
                    backlogs.push({
                        chapter: chap,
                        subject: data.subject || 'Unknown',
                        read: !!data.read,
                        notes: !!data.notes,
                        pyq: !!data.pyq
                    });
                }
            });
        }

        // SafeStorage fallback for missions
        if (missions.length === 0) {
            const localMissions = SafeStorage.getItem('commanderMissions', {});
            ['morning', 'afternoon', 'night'].forEach(slot => {
                (localMissions[slot] || []).forEach(m => {
                    missions.push({ title: m.title || m.name || 'Mission', status: m.status || 'pending', slot });
                });
            });
        }

        // SafeStorage fallback for notebooks
        if (notebooks.length === 0) {
            const localNotebooks = SafeStorage.getItem('notebook_matrix_data', []);
            if (Array.isArray(localNotebooks)) {
                localNotebooks.forEach(n => {
                    notebooks.push({ subject: n.subject || 'Unknown', completed: !!n.done });
                });
            }
        }

        // ── Derived metrics ──
        const pulseData = SafeStorage.getItem('pulse_engine_data', {}) || {};
        const totalPP = window.PulseEngine?.data?.totalPP
            ?? pulseData.totalPP
            ?? pulseData.pp
            ?? 0;
        const rank = _calculateRankFromPP(totalPP);
        const streakDays = window.PulseEngine?.data?.streak ?? pulseData.streak ?? 0;
        const multiplier = window.PulseEngine?.data?.multiplier ?? pulseData.multiplier ?? 1;

        const pendingBacklogs = _getPendingBacklogs(backlogs);
        const pendingMissions = missions.filter(m => m.status !== 'completed' && m.status !== 'done');
        const incompleteNotebooks = notebooks.filter(n => n.completed === false);

        const mathsPercent = _calculateSubjectProgress('Maths', syllabus, backlogs);
        const physicsPercent = _calculateSubjectProgress('Physics', syllabus, backlogs);
        const chemPercent = _calculateSubjectProgress('Chemistry', syllabus, backlogs);

        const pressureScore = _getPressureScore(pendingBacklogs, pendingMissions, incompleteNotebooks);
        const activeMission = pendingBacklogs[0]?.chapter || pendingMissions[0]?.title || 'NO ACTIVE MISSION';

        // ── Update DOM ──
        _setText('aestra-systemState', `<h2 class="state-text">${pressureScore >= 75 ? 'HIGH_ALERT' : 'LOCKED_IN'}</h2>`, true);
        _setText('aestra-focus', pressureScore >= 75 ? 'UNSTABLE' : 'STABLE');
        _setText('aestra-momentum', pendingBacklogs.length <= 3 ? 'HIGH' : 'MODERATE');

        _setText('aestra-mathsPercent', `${mathsPercent}%`);
        _setText('aestra-physicsPercent', `${physicsPercent}%`);
        _setText('aestra-chemPercent', `${chemPercent}%`);
        _setWidth('aestra-mathsBar', mathsPercent);
        _setWidth('aestra-physicsBar', physicsPercent);
        _setWidth('aestra-chemBar', chemPercent);

        _setText('aestra-pressureText', _getPressureLabel(pressureScore));
        _setText('aestra-pressureScore', `${pressureScore}/100`);
        _setWidth('aestra-pressureFill', pressureScore);

        _setText('aestra-rank', rank.toUpperCase());
        _setText('aestra-pp', `${Number(totalPP).toLocaleString()} PP`);
        _setText('aestra-backlogCount', `${String(pendingBacklogs.length).padStart(2, '0')} CHAPTERS`);
        _setText('aestra-mission', String(activeMission).toUpperCase());
        _setText('aestra-streak', `${Number(streakDays)} DAYS (${Number(multiplier)}x)`);

        // State dot color
        const dot = _container.querySelector('#aestra-stateDot');
        if (dot) {
            dot.className = pressureScore >= 75
                ? 'state-orb-pulse burnout-dot'
                : 'state-orb-pulse locked-in-dot';
        }
    }

    // ── Widget Helpers ──
    function _setText(id, value, isHTML = false) {
        if (!_container) return;
        const el = _container.querySelector(`#${id}`);
        if (!el) return;
        if (isHTML) { el.innerHTML = value; }
        else { el.textContent = value; }
    }

    function _setWidth(id, percent) {
        if (!_container) return;
        const el = _container.querySelector(`#${id}`);
        if (el) el.style.width = `${Math.max(0, Math.min(100, percent))}%`;
    }

    async function _fetchUserTable(tableName, userId) {
        if (!window.supabaseClient) return [];
        try {
            const { data, error } = await window.supabaseClient
                .from(tableName)
                .select('*')
                .eq('user_id', userId);
            if (error) {
                console.warn(`[AestraRoute] Failed to fetch ${tableName}:`, error);
                return [];
            }
            return Array.isArray(data) ? data : [];
        } catch (err) {
            console.warn(`[AestraRoute] Error fetching ${tableName}:`, err);
            return [];
        }
    }

    function _isRealBacklog(row) {
        const read   = row.read   === true || row.read   === 'true';
        const notes  = row.notes  === true || row.notes  === 'true';
        const pyq    = row.pyq    === true || row.pyq    === 'true';
        const started   = read || notes || pyq;
        const completed = read && notes && pyq;
        return started && !completed;
    }

    function _getPendingBacklogs(backlogs) {
        return backlogs.filter(_isRealBacklog);
    }

    function _calculateSubjectProgress(subjectName, syllabusRows, backlogRows) {
        const syllabusSubjectRows = syllabusRows.filter(row =>
            String(row.subject || '').toLowerCase() === subjectName.toLowerCase()
        );
        if (syllabusSubjectRows.length > 0) {
            const completed = syllabusSubjectRows.filter(row => row.completed === true).length;
            return Math.round((completed / syllabusSubjectRows.length) * 100);
        }
        const backlogSubjectRows = backlogRows.filter(row =>
            String(row.subject || '').toLowerCase() === subjectName.toLowerCase()
        );
        if (backlogSubjectRows.length === 0) return 0;
        let totalProgress = 0;
        backlogSubjectRows.forEach(row => {
            const done = [row.read, row.notes, row.pyq].filter(Boolean).length;
            totalProgress += Math.round((done / 3) * 100);
        });
        return Math.round(totalProgress / backlogSubjectRows.length);
    }

    function _getPressureScore(pendingBacklogs, pendingMissions, incompleteNotebooks) {
        let score = 0;
        score += pendingBacklogs.length * 12;
        score += pendingMissions.length * 5;
        score += incompleteNotebooks.length * 8;
        return Math.max(0, Math.min(100, score));
    }

    function _getPressureLabel(score) {
        if (score >= 75) return 'CRITICALITY: HIGH';
        if (score >= 45) return 'CRITICALITY: MEDIUM';
        if (score >= 20) return 'CRITICALITY: LOW';
        return 'CRITICALITY: STABLE';
    }

    // ── Public API ──
    return { render, init, cleanup };

})();
