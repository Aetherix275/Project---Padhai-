/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — MISSION CONTROL ROUTE MODULE (Sprint 8)
 *  The student's daily command center: main mission, mission list,
 *  gold targets, failed tasks, focus score, and tactical actions.
 * ═══════════════════════════════════════════════════════════════════
 *
 *  CONSTRAINTS:
 *    1. Use SafeStorage for all data reads (auto user_{id}_ prefix)
 *    2. All events use data-action + delegation + AbortController
 *    3. No inline onclick handlers
 *    4. CSS loaded dynamically on init, unloaded on cleanup
 *    5. Do NOT break existing pages or modify protected files
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear timers
 * ═══════════════════════════════════════════════════════════════════
 */

const MissionControlRoute = (() => {

    // ── Private state ──
    let _container = null;
    let _abortController = null;
    let _cssLinkEl = null;

    const CSS_PATH = './styles/modules/missionControl.css';
    const STORAGE_KEY = 'mission_control_data';

    // ── Category definitions with icons and recommended ranges ──
    const CATEGORIES = {
        'Deep Work':      { icon: '\u2694\uFE0F', color: '#00d4ff', min: 90, max: 240 },
        'Revision':       { icon: '\uD83D\uDCD6', color: '#00ff9d', min: 30, max: 120 },
        'Backlog':        { icon: '\uD83D\uDCE6', color: '#a855f7', min: 30, max: 120 },
        'Test Practice':  { icon: '\uD83D\uDCDD', color: '#f59e0b', min: 30, max: 90  },
        'Break':          { icon: '\u2615',       color: '#8b949e', min: 20, max: 45  },
        'Family Time':    { icon: '\uD83C\uDFE0', color: '#f472b6', min: 0,  max: 0   },
        'Exercise':       { icon: '\uD83D\uDCAA', color: '#ef4444', min: 30, max: 60  },
        'Other':          { icon: '\uD83D\uDCC1', color: '#6b7280', min: 0,  max: 0   }
    };

    // ── Priority colors ──
    const PRIORITY_COLORS = {
        'Critical': '#ff4c4c',
        'High':     '#f59e0b',
        'Normal':   '#00d4ff',
        'Low':      '#6b7280'
    };

    // ── Status colors ──
    const STATUS_COLORS = {
        'Pending':            '#6b7280',
        'Active':             '#00d4ff',
        'Completed':          '#00ff9d',
        'Failed':             '#ff4c4c',
        'Moved to Backlog':   '#a855f7'
    };

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════

    async function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;

        // 1. Load CSS
        _loadCSS();

        // 2. Render HTML
        container.innerHTML = _renderHTML();

        // 3. Load data and render dynamic sections
        _loadAndRender();

        // 4. Bind events
        _bindEvents(container, _abortController.signal);

        console.log('[MissionControlRoute] Initialized (Sprint 8 — Mission Control)');
    }

    function cleanup() {
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }
        _unloadCSS();
        _container = null;
        console.log('[MissionControlRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.missionControlCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-mission-control-css]');
        if (el) { el.remove(); _cssLinkEl = null; }
    }

    // ════════════════════════════════════════════════════════
    //  DATA MANAGEMENT
    // ════════════════════════════════════════════════════════

    function _getData() {
        const saved = SafeStorage.getItem(STORAGE_KEY, null);
        if (saved && typeof saved === 'object' && saved.missions) return saved;

        // Default sample data
        return _getDefaultData();
    }

    function _saveData(data) {
        SafeStorage.setItem(STORAGE_KEY, data);
    }

    function _getDefaultData() {
        return {
            missions: [
                {
                    id: 'mission_1',
                    title: 'Reproduction NCERT Reading',
                    subject: 'Biology',
                    category: 'Deep Work',
                    estimatedMinutes: 45,
                    priority: 'Critical',
                    status: 'Active',
                    isGoldTarget: false,
                    createdAt: new Date().toISOString()
                },
                {
                    id: 'mission_2',
                    title: 'Physics Electricity Numericals',
                    subject: 'Physics',
                    category: 'Deep Work',
                    estimatedMinutes: 60,
                    priority: 'High',
                    status: 'Pending',
                    isGoldTarget: false,
                    createdAt: new Date().toISOString()
                },
                {
                    id: 'mission_3',
                    title: 'Maths Circles Practice',
                    subject: 'Mathematics',
                    category: 'Test Practice',
                    estimatedMinutes: 30,
                    priority: 'Normal',
                    status: 'Pending',
                    isGoldTarget: false,
                    createdAt: new Date().toISOString()
                },
                {
                    id: 'mission_4',
                    title: 'SST Federalism Revision',
                    subject: 'Social Science',
                    category: 'Revision',
                    estimatedMinutes: 40,
                    priority: 'Normal',
                    status: 'Pending',
                    isGoldTarget: false,
                    createdAt: new Date().toISOString()
                },
                {
                    id: 'mission_5',
                    title: 'English Writing Practice',
                    subject: 'English',
                    category: 'Test Practice',
                    estimatedMinutes: 30,
                    priority: 'Low',
                    status: 'Pending',
                    isGoldTarget: false,
                    createdAt: new Date().toISOString()
                },
                {
                    id: 'mission_6',
                    title: 'Chemistry Organic Reactions',
                    subject: 'Chemistry',
                    category: 'Deep Work',
                    estimatedMinutes: 90,
                    priority: 'High',
                    status: 'Pending',
                    isGoldTarget: false,
                    createdAt: new Date().toISOString()
                }
            ],
            goldTargets: [
                {
                    id: 'gold_1',
                    title: 'Solve 25 Biology MCQs',
                    rewardPoints: 50,
                    completed: false
                },
                {
                    id: 'gold_2',
                    title: 'Complete one mock test',
                    rewardPoints: 100,
                    completed: false
                },
                {
                    id: 'gold_3',
                    title: 'Revise weak chapter',
                    rewardPoints: 75,
                    completed: false
                }
            ],
            failedTasks: []
        };
    }

    // ════════════════════════════════════════════════════════
    //  HELPERS
    // ════════════════════════════════════════════════════════

    function _formatMinutes(totalMinutes) {
        if (!totalMinutes || totalMinutes <= 0) return '0m';
        const h = Math.floor(totalMinutes / 60);
        const m = totalMinutes % 60;
        if (h > 0 && m > 0) return `${h}h ${m}m`;
        if (h > 0) return `${h}h`;
        return `${m}m`;
    }

    function _generateId() {
        return 'mc_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    }

    function _getTodayFormatted() {
        const d = new Date();
        const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
        const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
        return `${days[d.getDay()]}, ${months[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
    }

    function _getMainMission(data) {
        // Priority: Active > Critical > first Pending
        const active = data.missions.find(m => m.status === 'Active');
        if (active) return active;
        const critical = data.missions.find(m => m.priority === 'Critical' && m.status !== 'Completed' && m.status !== 'Failed');
        if (critical) return critical;
        const pending = data.missions.find(m => m.status === 'Pending');
        return pending || null;
    }

    function _calcFocusScore(data) {
        const total = data.missions.length;
        if (total === 0) return 0;
        const completed = data.missions.filter(m => m.status === 'Completed').length;
        const failed = data.missions.filter(m => m.status === 'Failed').length;
        const active = data.missions.filter(m => m.status === 'Active').length;
        const backlog = data.missions.filter(m => m.status === 'Moved to Backlog').length;

        // Weighted score
        const completionPct = (completed / total) * 100;
        const disciplinePct = Math.max(0, 100 - (failed / total) * 100);
        const breakPct = Math.min(100, (active / total) * 200); // active work is good
        const backlogPct = Math.max(0, 100 - (backlog / total) * 100);

        const score = Math.round(
            (completionPct * 0.40) +
            (disciplinePct * 0.25) +
            (breakPct * 0.15) +
            (backlogPct * 0.20)
        );

        return Math.max(0, Math.min(100, score));
    }

    function _getScoreGrade(score) {
        if (score >= 90) return { label: 'S-RANK', color: '#ffd700' };
        if (score >= 75) return { label: 'ELITE', color: '#00ff9d' };
        if (score >= 55) return { label: 'OPERATOR', color: '#00d4ff' };
        if (score >= 35) return { label: 'RECRUIT', color: '#f59e0b' };
        return { label: 'INITIATE', color: '#ff4c4c' };
    }

    function _getScoreBreakdown(data) {
        const total = data.missions.length || 1;
        const completed = data.missions.filter(m => m.status === 'Completed').length;
        const failed = data.missions.filter(m => m.status === 'Failed').length;
        const active = data.missions.filter(m => m.status === 'Active').length;
        const backlog = data.missions.filter(m => m.status === 'Moved to Backlog').length;

        return {
            completion: Math.round((completed / total) * 100),
            discipline: Math.round(Math.max(0, 100 - (failed / total) * 100)),
            breakBalance: Math.round(Math.min(100, (active / total) * 200)),
            backlogControl: Math.round(Math.max(0, 100 - (backlog / total) * 100))
        };
    }

    // ════════════════════════════════════════════════════════
    //  RENDER
    // ════════════════════════════════════════════════════════

    function _renderHTML() {
        return `
        <div class="mc-wrapper">
            <!-- ═══ HEADER ═══ -->
            <div class="mc-header">
                <div class="mc-header-left">
                    <h1 class="mc-title">MISSION CONTROL</h1>
                    <p class="mc-subtitle">Command your day before it commands you.</p>
                </div>
                <div class="mc-header-right">
                    <div class="mc-date-display" id="mcDateDisplay"></div>
                    <button class="mc-add-btn" data-action="mc-add-mission" title="Add New Mission">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                        <span>New Mission</span>
                    </button>
                </div>
            </div>

            <!-- ═══ MAIN MISSION CARD ═══ -->
            <div class="mc-main-mission" id="mcMainMission"></div>

            <!-- ═══ STATS ROW ═══ -->
            <div class="mc-stats-row" id="mcStatsRow"></div>

            <!-- ═══ MISSION LIST ═══ -->
            <div class="mc-section">
                <div class="mc-section-header">
                    <h2 class="mc-section-title">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                        MISSION BOARD
                    </h2>
                    <div class="mc-filter-row" id="mcFilterRow">
                        <button class="mc-filter-btn active" data-filter="all">All</button>
                        <button class="mc-filter-btn" data-filter="Pending">Pending</button>
                        <button class="mc-filter-btn" data-filter="Active">Active</button>
                        <button class="mc-filter-btn" data-filter="Completed">Completed</button>
                        <button class="mc-filter-btn" data-filter="Failed">Failed</button>
                    </div>
                </div>
                <div class="mc-mission-list" id="mcMissionList"></div>
            </div>

            <!-- ═══ BOTTOM GRID: Gold Targets + Failed Tasks + Focus Score ═══ -->
            <div class="mc-bottom-grid">
                <!-- GOLD TARGETS -->
                <div class="mc-section mc-gold-section">
                    <div class="mc-section-header">
                        <h2 class="mc-section-title mc-gold-title">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            GOLD TARGETS
                        </h2>
                    </div>
                    <div class="mc-gold-list" id="mcGoldList"></div>
                </div>

                <!-- FAILED TASKS -->
                <div class="mc-section mc-failed-section">
                    <div class="mc-section-header">
                        <h2 class="mc-section-title mc-failed-title">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
                            FAILURE REVIEW
                        </h2>
                    </div>
                    <div class="mc-failed-list" id="mcFailedList"></div>
                </div>

                <!-- FOCUS SCORE -->
                <div class="mc-section mc-focus-section">
                    <div class="mc-section-header">
                        <h2 class="mc-section-title mc-focus-title">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>
                            FOCUS SCORE
                        </h2>
                    </div>
                    <div class="mc-focus-card" id="mcFocusCard"></div>
                </div>
            </div>

            <!-- ═══ ADD MISSION MODAL ═══ -->
            <div class="mc-modal-overlay" id="mcAddModal">
                <div class="mc-modal-card">
                    <div class="mc-modal-header">
                        <h3>NEW MISSION</h3>
                        <button class="mc-modal-close" data-action="mc-close-modal">&times;</button>
                    </div>
                    <div class="mc-modal-body">
                        <div class="mc-form-group">
                            <label>Mission Title</label>
                            <input type="text" id="mcNewTitle" class="mc-input" placeholder="e.g. Complete Reproduction Chapter" />
                        </div>
                        <div class="mc-form-row">
                            <div class="mc-form-group">
                                <label>Subject</label>
                                <input type="text" id="mcNewSubject" class="mc-input" placeholder="e.g. Biology" />
                            </div>
                            <div class="mc-form-group">
                                <label>Category</label>
                                <select id="mcNewCategory" class="mc-select">
                                    ${Object.entries(CATEGORIES).map(([k, v]) => `<option value="${k}">${v.icon} ${k}</option>`).join('')}
                                </select>
                            </div>
                        </div>
                        <div class="mc-form-row">
                            <div class="mc-form-group">
                                <label>Estimated Time (min)</label>
                                <input type="number" id="mcNewTime" class="mc-input" placeholder="60" min="5" max="480" />
                            </div>
                            <div class="mc-form-group">
                                <label>Priority</label>
                                <select id="mcNewPriority" class="mc-select">
                                    <option value="Critical">Critical</option>
                                    <option value="High">High</option>
                                    <option value="Normal" selected>Normal</option>
                                    <option value="Low">Low</option>
                                </select>
                            </div>
                        </div>
                        <div class="mc-modal-actions">
                            <button class="mc-btn mc-btn-ghost" data-action="mc-close-modal">Cancel</button>
                            <button class="mc-btn mc-btn-primary" data-action="mc-save-new-mission">Deploy Mission</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        `;
    }

    // ════════════════════════════════════════════════════════
    //  DYNAMIC RENDERING
    // ════════════════════════════════════════════════════════

    function _loadAndRender() {
        const data = _getData();

        // Date
        const dateEl = document.getElementById('mcDateDisplay');
        if (dateEl) dateEl.textContent = _getTodayFormatted();

        _renderMainMission(data);
        _renderStatsRow(data);
        _renderMissionList(data);
        _renderGoldList(data);
        _renderFailedList(data);
        _renderFocusCard(data);
    }

    function _renderMainMission(data) {
        const el = document.getElementById('mcMainMission');
        if (!el) return;

        const mission = _getMainMission(data);
        if (!mission) {
            el.innerHTML = `
                <div class="mc-main-empty">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    <p>No active mission. Deploy one now!</p>
                </div>
            `;
            return;
        }

        const cat = CATEGORIES[mission.category] || CATEGORIES['Other'];
        const priColor = PRIORITY_COLORS[mission.priority] || PRIORITY_COLORS['Normal'];

        el.innerHTML = `
            <div class="mc-main-inner">
                <div class="mc-main-left">
                    <div class="mc-main-label">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>
                        MAIN MISSION
                    </div>
                    <h2 class="mc-main-title">${_escHtml(mission.title)}</h2>
                    <div class="mc-main-meta">
                        <span class="mc-main-subject">${_escHtml(mission.subject)}</span>
                        <span class="mc-main-cat-pill" style="background: ${cat.color}15; color: ${cat.color}; border-color: ${cat.color}40;">
                            ${cat.icon} ${mission.category}
                        </span>
                        <span class="mc-main-priority" style="color: ${priColor};">${mission.priority}</span>
                    </div>
                </div>
                <div class="mc-main-right">
                    <div class="mc-main-info-grid">
                        <div class="mc-main-info-item">
                            <span class="mc-info-label">Est. Time</span>
                            <span class="mc-info-value">${_formatMinutes(mission.estimatedMinutes)}</span>
                        </div>
                        <div class="mc-main-info-item">
                            <span class="mc-info-label">Deadline</span>
                            <span class="mc-info-value mc-deadline">Today</span>
                        </div>
                        <div class="mc-main-info-item">
                            <span class="mc-info-label">Status</span>
                            <span class="mc-info-value mc-status-pill" style="color: ${STATUS_COLORS[mission.status] || '#6b7280'};">${mission.status}</span>
                        </div>
                    </div>
                    <div class="mc-main-actions">
                        <button class="mc-btn mc-btn-start" data-action="mc-start-mission" data-id="${mission.id}">Start Mission</button>
                        <button class="mc-btn mc-btn-done" data-action="mc-done-mission" data-id="${mission.id}">Mark Done</button>
                        <button class="mc-btn mc-btn-backlog" data-action="mc-backlog-mission" data-id="${mission.id}">Move to Backlog</button>
                    </div>
                </div>
            </div>
        `;
    }

    function _renderStatsRow(data) {
        const el = document.getElementById('mcStatsRow');
        if (!el) return;

        const total = data.missions.length;
        const completed = data.missions.filter(m => m.status === 'Completed').length;
        const active = data.missions.filter(m => m.status === 'Active').length;
        const failed = data.missions.filter(m => m.status === 'Failed').length;
        const goldCompleted = data.goldTargets.filter(g => g.completed).length;
        const goldTotal = data.goldTargets.length;
        const focusScore = _calcFocusScore(data);

        el.innerHTML = `
            <div class="mc-stat-card mc-stat-missions">
                <div class="mc-stat-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                </div>
                <div class="mc-stat-value">${completed + active}<span class="mc-stat-total">/${total}</span></div>
                <div class="mc-stat-label">Missions</div>
                <div class="mc-progress"><div class="mc-progress-fill" style="width: ${total ? (completed / total * 100) : 0}%; background: linear-gradient(90deg, #00d4ff, #00ff9d);"></div></div>
            </div>
            <div class="mc-stat-card mc-stat-gold">
                <div class="mc-stat-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                </div>
                <div class="mc-stat-value">${goldCompleted}<span class="mc-stat-total">/${goldTotal}</span></div>
                <div class="mc-stat-label">Gold Targets</div>
                <div class="mc-progress"><div class="mc-progress-fill" style="width: ${goldTotal ? (goldCompleted / goldTotal * 100) : 0}%; background: linear-gradient(90deg, #f59e0b, #ffd700);"></div></div>
            </div>
            <div class="mc-stat-card mc-stat-failed">
                <div class="mc-stat-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
                </div>
                <div class="mc-stat-value">${failed}</div>
                <div class="mc-stat-label">Failed</div>
                <div class="mc-progress"><div class="mc-progress-fill" style="width: ${total ? (failed / total * 100) : 0}%; background: linear-gradient(90deg, #ff4c4c, #ff6b6b);"></div></div>
            </div>
            <div class="mc-stat-card mc-stat-focus">
                <div class="mc-stat-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>
                </div>
                <div class="mc-stat-value">${focusScore}<span class="mc-stat-pct">%</span></div>
                <div class="mc-stat-label">Focus Score</div>
                <div class="mc-progress"><div class="mc-progress-fill" style="width: ${focusScore}%; background: linear-gradient(90deg, #3b82f6, #00d4ff);"></div></div>
            </div>
        `;
    }

    function _renderMissionList(data, filter) {
        const el = document.getElementById('mcMissionList');
        if (!el) return;

        let missions = data.missions;
        if (filter && filter !== 'all') {
            missions = missions.filter(m => m.status === filter);
        }

        if (missions.length === 0) {
            el.innerHTML = `
                <div class="mc-empty-state">
                    <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    <p>No missions found. Deploy your first mission!</p>
                </div>
            `;
            return;
        }

        el.innerHTML = missions.map(m => {
            const cat = CATEGORIES[m.category] || CATEGORIES['Other'];
            const priColor = PRIORITY_COLORS[m.priority] || PRIORITY_COLORS['Normal'];
            const statusColor = STATUS_COLORS[m.status] || STATUS_COLORS['Pending'];

            return `
            <div class="mc-mission-card" data-mission-id="${m.id}">
                <div class="mc-mission-left">
                    <div class="mc-mission-cat-dot" style="background: ${cat.color}; box-shadow: 0 0 8px ${cat.color}40;"></div>
                    <div class="mc-mission-info">
                        <div class="mc-mission-title-row">
                            <span class="mc-mission-title ${m.status === 'Completed' ? 'mc-done' : ''}">${_escHtml(m.title)}</span>
                            <span class="mc-mission-priority-pill" style="background: ${priColor}18; color: ${priColor}; border-color: ${priColor}40;">${m.priority}</span>
                        </div>
                        <div class="mc-mission-meta-row">
                            <span class="mc-mission-subject">${_escHtml(m.subject)}</span>
                            <span class="mc-mission-cat-text" style="color: ${cat.color};">${cat.icon} ${m.category}</span>
                            <span class="mc-mission-time">${_formatMinutes(m.estimatedMinutes)}</span>
                            <span class="mc-mission-status-badge" style="background: ${statusColor}18; color: ${statusColor}; border-color: ${statusColor}40;">${m.status}</span>
                        </div>
                    </div>
                </div>
                <div class="mc-mission-actions">
                    ${m.status === 'Pending' ? `<button class="mc-action-btn mc-action-start" data-action="mc-start-mission" data-id="${m.id}" title="Start">Start</button>` : ''}
                    ${m.status !== 'Completed' && m.status !== 'Failed' ? `<button class="mc-action-btn mc-action-done" data-action="mc-done-mission" data-id="${m.id}" title="Done">Done</button>` : ''}
                    ${m.status !== 'Completed' && m.status !== 'Failed' ? `<button class="mc-action-btn mc-action-backlog" data-action="mc-backlog-mission" data-id="${m.id}" title="Backlog">Backlog</button>` : ''}
                    ${m.status !== 'Completed' && m.status !== 'Failed' ? `<button class="mc-action-btn mc-action-fail" data-action="mc-fail-mission" data-id="${m.id}" title="Fail">Fail</button>` : ''}
                    ${m.status === 'Failed' ? `<button class="mc-action-btn mc-action-retry" data-action="mc-retry-mission" data-id="${m.id}" title="Retry">Retry</button>` : ''}
                    <button class="mc-action-btn mc-action-delete" data-action="mc-delete-mission" data-id="${m.id}" title="Delete">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                    </button>
                </div>
            </div>
            `;
        }).join('');
    }

    function _renderGoldList(data) {
        const el = document.getElementById('mcGoldList');
        if (!el) return;

        if (data.goldTargets.length === 0) {
            el.innerHTML = `<div class="mc-empty-state mc-empty-sm"><p>No gold targets set.</p></div>`;
            return;
        }

        el.innerHTML = data.goldTargets.map(g => `
            <div class="mc-gold-item ${g.completed ? 'mc-gold-done' : ''}" data-gold-id="${g.id}">
                <label class="mc-gold-check">
                    <input type="checkbox" ${g.completed ? 'checked' : ''} data-action="mc-toggle-gold" data-id="${g.id}" />
                    <span class="mc-gold-checkmark"></span>
                </label>
                <div class="mc-gold-info">
                    <span class="mc-gold-title ${g.completed ? 'mc-done' : ''}">${_escHtml(g.title)}</span>
                    <span class="mc-gold-reward">${g.rewardPoints} pts</span>
                </div>
                <span class="mc-gold-status ${g.completed ? 'mc-gold-status-done' : 'mc-gold-status-pending'}">${g.completed ? 'Claimed' : 'Available'}</span>
            </div>
        `).join('');
    }

    function _renderFailedList(data) {
        const el = document.getElementById('mcFailedList');
        if (!el) return;

        const failedMissions = data.missions.filter(m => m.status === 'Failed');
        const failedItems = data.failedTasks || [];

        if (failedMissions.length === 0 && failedItems.length === 0) {
            el.innerHTML = `<div class="mc-empty-state mc-empty-sm"><p>No failures today. Stay strong!</p></div>`;
            return;
        }

        let html = '';

        // Render from failed missions
        failedMissions.forEach(m => {
            const reason = m.failReason || 'Time shortage';
            html += `
            <div class="mc-failed-item" data-failed-id="${m.id}">
                <div class="mc-failed-info">
                    <span class="mc-failed-title">${_escHtml(m.title)}</span>
                    <span class="mc-failed-reason">${_escHtml(reason)}</span>
                </div>
                <div class="mc-failed-actions">
                    <button class="mc-action-btn mc-action-retry" data-action="mc-retry-mission" data-id="${m.id}">Retry Today</button>
                    <button class="mc-action-btn mc-action-tomorrow" data-action="mc-move-tomorrow" data-id="${m.id}">Tomorrow</button>
                    <button class="mc-action-btn mc-action-backlog" data-action="mc-backlog-mission" data-id="${m.id}">Backlog</button>
                </div>
            </div>
            `;
        });

        el.innerHTML = html;
    }

    function _renderFocusCard(data) {
        const el = document.getElementById('mcFocusCard');
        if (!el) return;

        const score = _calcFocusScore(data);
        const grade = _getScoreGrade(score);
        const breakdown = _getScoreBreakdown(data);

        // SVG ring
        const radius = 54;
        const circumference = 2 * Math.PI * radius;
        const offset = circumference - (score / 100) * circumference;

        el.innerHTML = `
            <div class="mc-focus-visual">
                <svg class="mc-focus-ring" viewBox="0 0 120 120">
                    <circle cx="60" cy="60" r="${radius}" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="8"/>
                    <circle cx="60" cy="60" r="${radius}" fill="none" stroke="${grade.color}" stroke-width="8"
                        stroke-dasharray="${circumference}" stroke-dashoffset="${offset}"
                        stroke-linecap="round" transform="rotate(-90 60 60)"
                        style="filter: drop-shadow(0 0 6px ${grade.color}60); transition: stroke-dashoffset 0.8s ease;"/>
                </svg>
                <div class="mc-focus-center">
                    <div class="mc-focus-score" style="color: ${grade.color}; text-shadow: 0 0 20px ${grade.color}40;">${score}<span class="mc-focus-pct">%</span></div>
                    <div class="mc-focus-grade" style="color: ${grade.color};">${grade.label}</div>
                </div>
            </div>
            <div class="mc-focus-breakdown">
                <div class="mc-breakdown-item">
                    <span class="mc-breakdown-label">Mission Completion</span>
                    <div class="mc-breakdown-bar"><div class="mc-breakdown-fill" style="width: ${breakdown.completion}%; background: #00ff9d;"></div></div>
                    <span class="mc-breakdown-pct">${breakdown.completion}%</span>
                </div>
                <div class="mc-breakdown-item">
                    <span class="mc-breakdown-label">Time Discipline</span>
                    <div class="mc-breakdown-bar"><div class="mc-breakdown-fill" style="width: ${breakdown.discipline}%; background: #00d4ff;"></div></div>
                    <span class="mc-breakdown-pct">${breakdown.discipline}%</span>
                </div>
                <div class="mc-breakdown-item">
                    <span class="mc-breakdown-label">Break Balance</span>
                    <div class="mc-breakdown-bar"><div class="mc-breakdown-fill" style="width: ${breakdown.breakBalance}%; background: #3b82f6;"></div></div>
                    <span class="mc-breakdown-pct">${breakdown.breakBalance}%</span>
                </div>
                <div class="mc-breakdown-item">
                    <span class="mc-breakdown-label">Backlog Control</span>
                    <div class="mc-breakdown-bar"><div class="mc-breakdown-fill" style="width: ${breakdown.backlogControl}%; background: #a855f7;"></div></div>
                    <span class="mc-breakdown-pct">${breakdown.backlogControl}%</span>
                </div>
            </div>
        `;
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING (delegation via AbortController)
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {
        container.addEventListener('click', (e) => {
            const btn = e.target.closest('[data-action]');
            if (!btn) return;
            const action = btn.dataset.action;
            const id = btn.dataset.id;

            switch (action) {
                case 'mc-add-mission':      _openAddModal(); break;
                case 'mc-close-modal':       _closeAddModal(); break;
                case 'mc-save-new-mission':  _saveNewMission(); break;
                case 'mc-start-mission':     _changeStatus(id, 'Active'); break;
                case 'mc-done-mission':      _changeStatus(id, 'Completed'); break;
                case 'mc-fail-mission':      _changeStatus(id, 'Failed'); break;
                case 'mc-backlog-mission':   _changeStatus(id, 'Moved to Backlog'); break;
                case 'mc-retry-mission':     _changeStatus(id, 'Active'); break;
                case 'mc-move-tomorrow':     _moveToTomorrow(id); break;
                case 'mc-delete-mission':    _deleteMission(id); break;
                case 'mc-toggle-gold':       _toggleGold(id); break;
            }
        }, { signal });

        // Filter buttons
        container.addEventListener('click', (e) => {
            const btn = e.target.closest('[data-filter]');
            if (!btn) return;
            const filter = btn.dataset.filter;
            _setActiveFilter(btn);
            const data = _getData();
            _renderMissionList(data, filter);
        }, { signal });

        // Close modal on overlay click
        const modal = container.querySelector('#mcAddModal');
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) _closeAddModal();
            }, { signal });
        }

        // Escape key closes modal
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') _closeAddModal();
        }, { signal });
    }

    function _openAddModal() {
        const modal = document.getElementById('mcAddModal');
        if (modal) {
            modal.classList.add('mc-modal-open');
            const titleInput = document.getElementById('mcNewTitle');
            if (titleInput) setTimeout(() => titleInput.focus(), 100);
        }
    }

    function _closeAddModal() {
        const modal = document.getElementById('mcAddModal');
        if (modal) {
            modal.classList.remove('mc-modal-open');
            // Reset form
            const titleInput = document.getElementById('mcNewTitle');
            const subjectInput = document.getElementById('mcNewSubject');
            const timeInput = document.getElementById('mcNewTime');
            if (titleInput) titleInput.value = '';
            if (subjectInput) subjectInput.value = '';
            if (timeInput) timeInput.value = '';
        }
    }

    function _saveNewMission() {
        const title = document.getElementById('mcNewTitle')?.value?.trim();
        const subject = document.getElementById('mcNewSubject')?.value?.trim();
        const category = document.getElementById('mcNewCategory')?.value;
        const time = parseInt(document.getElementById('mcNewTime')?.value) || 45;
        const priority = document.getElementById('mcNewPriority')?.value;

        if (!title) {
            const input = document.getElementById('mcNewTitle');
            if (input) { input.style.borderColor = '#ff4c4c'; input.focus(); setTimeout(() => input.style.borderColor = '', 2000); }
            return;
        }

        const data = _getData();
        data.missions.push({
            id: _generateId(),
            title,
            subject: subject || 'General',
            category: category || 'Other',
            estimatedMinutes: Math.max(5, Math.min(480, time)),
            priority: priority || 'Normal',
            status: 'Pending',
            isGoldTarget: false,
            createdAt: new Date().toISOString()
        });

        _saveData(data);
        _closeAddModal();
        _loadAndRender();
    }

    function _changeStatus(id, newStatus) {
        if (!id) return;
        const data = _getData();
        const mission = data.missions.find(m => m.id === id);
        if (!mission) return;

        mission.status = newStatus;

        // If failing, add a reason
        if (newStatus === 'Failed') {
            mission.failReason = mission.failReason || 'Time shortage';
        }

        _saveData(data);
        _loadAndRender();
    }

    function _deleteMission(id) {
        if (!id) return;
        const data = _getData();
        data.missions = data.missions.filter(m => m.id !== id);
        _saveData(data);
        _loadAndRender();
    }

    function _toggleGold(id) {
        if (!id) return;
        const data = _getData();
        const gold = data.goldTargets.find(g => g.id === id);
        if (!gold) return;
        gold.completed = !gold.completed;
        _saveData(data);
        _loadAndRender();
    }

    function _moveToTomorrow(id) {
        if (!id) return;
        const data = _getData();
        const mission = data.missions.find(m => m.id === id);
        if (!mission) return;
        mission.status = 'Pending';
        mission.failReason = '';
        _saveData(data);
        _loadAndRender();
    }

    function _setActiveFilter(btn) {
        const container = btn.closest('.mc-filter-row');
        if (!container) return;
        container.querySelectorAll('.mc-filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
    }

    // ════════════════════════════════════════════════════════
    //  HTML ESCAPE
    // ════════════════════════════════════════════════════════

    function _escHtml(str) {
        const div = document.createElement('div');
        div.textContent = str || '';
        return div.innerHTML;
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();

// Make globally accessible
window.MissionControlRoute = MissionControlRoute;
