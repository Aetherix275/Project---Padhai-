/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — SYLLABUS ROUTE MODULE (Phase 7E-2B + Gap Analyzer)
 *  Full SPA conversion of Syllabus Tracker + Gap Analyzer
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear state
 *
 *  Data: SafeStorage-first, Supabase mirror second
 *  Events: All via event delegation + AbortController. Zero inline onclick.
 *  CSS: Loaded dynamically from styles/modules/syllabus.css
 *
 *  PP Safety:
 *    - Mastery (+20 PP) only when transitioning non-mastered → mastered
 *    - Unique rewardId prevents duplicate PP
 *    - Never calls loadPulseEngineFromSupabase() or syncPulseEngineToSupabase()
 *
 *  Gap Analyzer:
 *    - Analyzes syllabus chapters for weak/incomplete areas
 *    - Calculates gap scores and risk levels
 *    - Provides actionable suggestions
 *    - Supports risk-level and subject filtering
 *    - Optional safe backlog integration
 * ═══════════════════════════════════════════════════════════════════
 */

const SyllabusRoute = (() => {

    // ── Private state ──
    let _container = null;
    let _abortController = null;
    let _currentClass = 10;
    let _academicProfile = null;
    let _toastTimeout = null;
    let _cssLinkEl = null;

    // Gap Analyzer state
    let _gapFilter = 'all';
    let _gapSubject = 'all';
    let _gapChaptersCache = [];   // cached normalized chapters for current view

    // Memory Decay state
    let _memoryFilter = 'all';

    // Gap Analyzer collapse state
    const GAP_ANALYZER_COLLAPSE_KEY = "syllabus_gap_analyzer_expanded";
    let _isGapAnalyzerExpanded = !!SafeStorage.getItem(GAP_ANALYZER_COLLAPSE_KEY, false);

    const CSS_PATH = './styles/modules/syllabus.css';
    const MASTER_KEY = 'smartPadhaiData';
    const TRACKER_KEY = 'syllabus_master_tracker';
    const CLASS_KEY = 'userClass';
    const BACKLOG_TIMELINE_KEY = 'backlog_timeline';
    const MEMORY_DECAY_KEY = 'smart_padhai_memory_decay';

    // ── Syllabus Preset Registry ──
    const _SYLLABUS_PRESETS = {
        CBSE_7_2026_27: {
            board: 'CBSE',
            classLevel: 7,
            academicYear: '2026-27',
            sourceType: 'NCERT/Draft Preset',
            verificationNote: 'Draft preset based on common NCERT structure. Verify with school.',
            subjects: {
                Science: {
                    General: [
                        'Nutrition in Plants',
                        'Nutrition in Animals',
                        'Heat',
                        'Acids, Bases and Salts',
                        'Physical and Chemical Changes',
                        'Respiration in Organisms',
                        'Transportation in Animals and Plants',
                        'Reproduction in Plants',
                        'Motion and Time',
                        'Electric Current and its Effects',
                        'Light',
                        'Forests: Our Lifeline',
                        'Wastewater Story'
                    ]
                },
                Maths: {
                    Standard: [
                        'Integers',
                        'Fractions and Decimals',
                        'Data Handling',
                        'Simple Equations',
                        'Lines and Angles',
                        'The Triangle and its Properties',
                        'Comparing Quantities',
                        'Rational Numbers',
                        'Perimeter and Area',
                        'Algebraic Expressions',
                        'Exponents and Powers',
                        'Symmetry',
                        'Visualising Solid Shapes'
                    ]
                },
                SocialScience: {
                    History: ['Tracing Changes Through a Thousand Years', 'New Kings and Kingdoms', 'The Delhi Sultans', 'The Mughal Empire', 'Tribes, Nomads and Settled Communities'],
                    Geography: ['Environment', 'Inside Our Earth', 'Our Changing Earth', 'Air', 'Water', 'Natural Vegetation and Wildlife'],
                    PoliticalScience: ['On Equality', 'Role of the Government in Health', 'How the State Government Works', 'Growing up as Boys and Girls', 'Women Change the World']
                },
                English: {
                    Honeycomb: ['School selected English literature chapters'],
                    Grammar: ['School selected English grammar topics']
                },
                Hindi: {
                    VasantOrSchoolText: ['School selected Hindi textbook chapters'],
                    Grammar: ['School selected Hindi grammar topics']
                }
            }
        },
        CBSE_8_2026_27: {
            board: 'CBSE',
            classLevel: 8,
            academicYear: '2026-27',
            sourceType: 'NCERT/Draft Preset',
            verificationNote: 'Draft preset based on common NCERT structure. Verify with school.',
            subjects: {
                Science: {
                    General: [
                        'Crop Production and Management',
                        'Microorganisms: Friend and Foe',
                        'Coal and Petroleum',
                        'Combustion and Flame',
                        'Conservation of Plants and Animals',
                        'Reproduction in Animals',
                        'Reaching the Age of Adolescence',
                        'Force and Pressure',
                        'Friction',
                        'Sound',
                        'Chemical Effects of Electric Current',
                        'Some Natural Phenomena',
                        'Light'
                    ]
                },
                Maths: {
                    Standard: [
                        'Rational Numbers',
                        'Linear Equations in One Variable',
                        'Understanding Quadrilaterals',
                        'Data Handling',
                        'Squares and Square Roots',
                        'Cubes and Cube Roots',
                        'Comparing Quantities',
                        'Algebraic Expressions and Identities',
                        'Mensuration',
                        'Exponents and Powers',
                        'Direct and Inverse Proportions',
                        'Factorisation',
                        'Introduction to Graphs'
                    ]
                },
                SocialScience: {
                    History: ['How, When and Where', 'From Trade to Territory', 'Ruling the Countryside', 'Tribals, Dikus and the Vision of a Golden Age', 'When People Rebel'],
                    Geography: ['Resources', 'Land, Soil, Water, Natural Vegetation and Wildlife Resources', 'Mineral and Power Resources', 'Agriculture', 'Industries', 'Human Resources'],
                    PoliticalScience: ['The Indian Constitution', 'Understanding Secularism', 'Parliament and the Making of Laws', 'Judiciary', 'Understanding Marginalisation']
                },
                English: {
                    Honeydew: ['School selected English literature chapters'],
                    Grammar: ['School selected English grammar topics']
                },
                Hindi: {
                    VasantOrSchoolText: ['School selected Hindi textbook chapters'],
                    Grammar: ['School selected Hindi grammar topics']
                }
            }
        },
        CBSE_9_2026_27: {
            board: 'CBSE',
            classLevel: 9,
            academicYear: '2026-27',
            verificationStatus: 'verified',
            sourceType: 'CBSE Official PDF',
            sourceLabel: 'CBSE Academic Curriculum 2026-27',
            lastVerified: '2026-06-05',
            verificationNote: 'Chapter data imported from CBSE official 2026-27 curriculum PDFs.',
            subjectVerification: {
                Maths: { status: 'verified', sourceFile: 'Maths_SecP1IX_2026-27.pdf' },
                Science: { status: 'verified', sourceFile: 'ScienceSt_SecP1_2026-27.pdf' },
                SocialScience: { status: 'verified', sourceFile: 'SocialScience_SecP1IX_2026-27.pdf' }
            },
            subjects: {
                Science: {
                    Physics: ['Motion', 'Force and Laws of Motion', 'Work, Energy and Simple Machines', 'Sound'],
                    Chemistry: ['Exploring Mixtures and their Separation', 'Atoms and Molecules', 'Structure of an Atom'],
                    Biology: ['Cell', 'Tissues', 'Reproduction', 'Diversity'],
                    EarthScience: ['Earth as a System: Energy, Matter and Life']
                },
                Maths: {
                    NumberSystem: ['Number System'],
                    Algebra: ['Introduction to Polynomials', 'Sequences and Progressions', 'Exploring Algebraic Identities', 'Linear Equations in Two Variables'],
                    CoordinateGeometry: ['Coordinate Geometry'],
                    Geometry: ["Introduction to Euclid's Geometry: Axioms and Postulates", 'Lines and Angles', 'Triangles – Congruence Theorems', '4-gons (Quadrilaterals)', 'Circles'],
                    Mensuration: ['Area and Perimeter', 'Surface Area and Volume'],
                    StatisticsAndProbability: ['Statistics', 'Introduction to Probability']
                },
                SocialScience: {
                    History: ['The French Revolution', 'Socialism in Europe and the Russian Revolution', 'Nazism and the Rise of Hitler', 'Forest Society and Colonialism', 'Pastoralists in the Modern World'],
                    Geography: ['India - Size and Location', 'Physical Features of India', 'Drainage', 'Climate', 'Natural Vegetation and Wildlife', 'Population'],
                    PoliticalScience: ['What is Democracy? Why Democracy?', 'Constitutional Design', 'Electoral Politics', 'Working of Institutions', 'Democratic Rights'],
                    Economics: ['The Story of Village Palampur', 'People as Resource', 'Poverty as a Challenge', 'Food Security in India']
                }
            }
        },
        CBSE_10_2026_27: {
            board: 'CBSE',
            classLevel: 10,
            academicYear: '2026-27',
            verificationStatus: 'verified',
            sourceType: 'CBSE Official PDF',
            sourceLabel: 'CBSE Academic Curriculum 2026-27',
            lastVerified: '2026-06-05',
            verificationNote: 'Chapter data imported from CBSE official 2026-27 curriculum PDFs.',
            subjectVerification: {
                Maths: { status: 'verified', sourceFile: 'Maths_SecP1X_2026-27.pdf' },
                Science: { status: 'verified', sourceFile: 'Science_SecP1_2026-27.pdf' },
                SocialScience: { status: 'verified', sourceFile: 'SocialScience_SecP1X_2026-27.pdf' }
            },
            subjects: {
                Science: {
                    Chemistry: ['Chemical Reactions and Equations', 'Acids, Bases and Salts', 'Metals and Non-metals', 'Carbon and its Compounds', 'Periodic Classification of Elements'],
                    Biology: ['Life Processes', 'Control and Coordination', 'Reproduction', 'Heredity', 'Evolution'],
                    Physics: ['Light – Reflection and Refraction', 'The Human Eye and the Colourful World', 'Electricity', 'Magnetic Effects of Electric Current', 'Electric Motor and Electric Generator'],
                    NaturalResources: ['Our Environment']
                },
                Maths: {
                    NumberSystems: ['Real Numbers'],
                    Algebra: ['Polynomials', 'Pair of Linear Equations in Two Variables', 'Quadratic Equations', 'Arithmetic Progressions'],
                    CoordinateGeometry: ['Coordinate Geometry'],
                    Geometry: ['Triangles', 'Circles'],
                    Trigonometry: ['Introduction to Trigonometry', 'Trigonometric Identities', 'Heights and Distances'],
                    Mensuration: ['Areas Related to Circles', 'Surface Areas and Volumes'],
                    StatisticsAndProbability: ['Statistics', 'Probability']
                },
                SocialScience: {
                    History: ['The Rise of Nationalism in Europe', 'Nationalism in India', 'The Making of a Global World', 'The Age of Industrialisation', 'Print Culture and the Modern World'],
                    Geography: ['Resources and Development', 'Forest and Wildlife Resources', 'Water Resources', 'Agriculture', 'Minerals and Energy Resources', 'Manufacturing Industries', 'Lifelines of National Economy'],
                    PoliticalScience: ['Power-sharing', 'Federalism', 'Gender, Religion and Caste', 'Political Parties', 'Outcomes of Democracy'],
                    Economics: ['Development', 'Sectors of the Indian Economy', 'Money and Credit', 'Globalisation and the Indian Economy', 'Consumer Rights']
                },
                English: {
                    FirstFlight: ['A Letter to God', 'Nelson Mandela: Long Walk to Freedom', 'Two Stories about Flying', 'From the Diary of Anne Frank', 'Glimpses of India', 'Mijbil the Otter', 'Madam Rides the Bus', 'The Sermon at Benares', 'The Proposal'],
                    FootprintsWithoutFeet: ['A Triumph of Surgery', "The Thief's Story", 'The Midnight Visitor', 'A Question of Trust', 'Footprints Without Feet', 'The Making of a Scientist', 'The Necklace', 'Bholi', 'The Book That Saved the Earth']
                },
                Hindi: {
                    KshitijOrSparsh: ['School selected Hindi textbook chapters'],
                    Grammar: ['School selected Hindi grammar topics']
                },
                ComputerApplications: {
                    Theory: ['Networking', 'HTML', 'Cyber Ethics', 'Scratch or Python Basics', 'Office Tools']
                }
            }
        }
    };

    // Backward-compatible class → subjects map for older helpers/integrations.
    const _SYLLABUS_DATA = Object.values(_SYLLABUS_PRESETS).reduce((map, preset) => {
        map[preset.classLevel] = preset.subjects;
        return map;
    }, {});

    const _SYLLABUS_PRESET_META = Object.values(_SYLLABUS_PRESETS).reduce((map, preset) => {
        map[preset.classLevel] = {
            board: preset.board,
            academicYear: preset.academicYear,
            sourceType: preset.sourceType,
            verificationStatus: preset.verificationStatus || '',
            sourceLabel: preset.sourceLabel || '',
            lastVerified: preset.lastVerified || '',
            subjectVerification: preset.subjectVerification || {},
            verificationNote: preset.verificationNote || '',
            presetKey: `${preset.board}_${preset.classLevel}_${String(preset.academicYear).replace(/[^0-9A-Za-z]+/g, '_')}`
        };
        return map;
    }, {});

    function _normalizeClassLevel(value) {
        const parsed = parseInt(String(value ?? '').replace(/[^0-9]/g, ''), 10);
        return Number.isFinite(parsed) && parsed > 0 ? parsed : 10;
    }

    function _getAcademicProfileSafe() {
        try {
            const rawProfile = (typeof window !== 'undefined' && window.SMART_PADHAI_PROFILE)
                ? window.SMART_PADHAI_PROFILE
                : (typeof SafeStorage !== 'undefined' && SafeStorage?.getItem
                    ? SafeStorage.getItem('smart_padhai_user_profile', null)
                    : null);

            const profile = rawProfile && typeof rawProfile === 'object' ? rawProfile : {};
            const classLevel = _normalizeClassLevel(profile.classLevel || profile.class || profile.grade || profile.standard);
            const board = String(profile.board || 'CBSE').trim().toUpperCase() || 'CBSE';
            const academicYear = String(profile.academicYear || profile.academic_year || '2026-27').trim() || '2026-27';

            return { classLevel, board, academicYear };
        } catch (err) {
            console.warn('[SyllabusRoute] Academic profile read failed:', err);
            return { classLevel: 10, board: 'CBSE', academicYear: '2026-27' };
        }
    }

    function _normalizeBoard(value) {
        return String(value || 'CBSE').trim().toUpperCase().replace(/[^0-9A-Z]+/g, '_') || 'CBSE';
    }

    function _normalizeAcademicYear(value) {
        return String(value || '2026-27').trim().replace(/[^0-9A-Za-z]+/g, '_') || '2026_27';
    }

    function _getPresetKey(profile) {
        const safeProfile = profile || _academicProfile || _getAcademicProfileSafe();
        const board = _normalizeBoard(safeProfile.board);
        const classLevel = _normalizeClassLevel(safeProfile.classLevel);
        const academicYear = _normalizeAcademicYear(safeProfile.academicYear);
        return `${board}_${classLevel}_${academicYear}`;
    }

    function _getActivePreset(classLevel) {
        const baseProfile = _academicProfile || _getAcademicProfileSafe();
        const profile = {
            ...baseProfile,
            classLevel: classLevel ? _normalizeClassLevel(classLevel) : _normalizeClassLevel(baseProfile.classLevel || _currentClass)
        };
        return _SYLLABUS_PRESETS[_getPresetKey(profile)] || null;
    }

    function _getPresetMetaSafe(classLevel) {
        const activePreset = _getActivePreset(classLevel);
        if (activePreset) {
            return {
                board: activePreset.board,
                classLevel: activePreset.classLevel,
                academicYear: activePreset.academicYear,
                sourceType: activePreset.sourceType,
                verificationStatus: activePreset.verificationStatus || '',
                sourceLabel: activePreset.sourceLabel || '',
                lastVerified: activePreset.lastVerified || '',
                subjectVerification: activePreset.subjectVerification || {},
                verificationNote: activePreset.verificationNote || '',
                presetKey: _getPresetKey(activePreset)
            };
        }

        const profile = {
            ...(_academicProfile || _getAcademicProfileSafe()),
            classLevel: classLevel ? _normalizeClassLevel(classLevel) : _normalizeClassLevel(_currentClass)
        };

        return {
            board: profile.board || 'CBSE',
            classLevel: profile.classLevel,
            academicYear: profile.academicYear || '2026-27',
            sourceType: 'No Preset',
            verificationStatus: '',
            sourceLabel: '',
            lastVerified: '',
            subjectVerification: {},
            verificationNote: '',
            presetKey: _getPresetKey(profile)
        };
    }

    function _dispatchSyllabusUpdated() {
        try {
            window.dispatchEvent(new CustomEvent('smartPadhai:syllabusUpdated', {
                detail: {
                    classLevel: _currentClass,
                    profile: _academicProfile,
                    presetMeta: _getPresetMetaSafe(_currentClass)
                }
            }));
        } catch (e) { /* defensive */ }
    }

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════

    async function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;

        // 1. Load CSS
        _loadCSS();

        // 2. Try loading from Supabase (best-effort merge)
        await _loadFromSupabase();

        // 3. Render full UI
        container.innerHTML = renderFullUI();

        // 4. Read profile and auto-select supported syllabus preset
        _academicProfile = _getAcademicProfileSafe();
        if (_academicProfile.classLevel && _getActivePreset(_academicProfile.classLevel)) {
            _selectClass(_academicProfile.classLevel, true); // profile-backed preset; no manual selection needed
        } else {
            _currentClass = _academicProfile.classLevel || 10;
            _showUnsupportedPresetMessage(`Preset not available yet for Class ${_currentClass} · ${_academicProfile.board} · ${_academicProfile.academicYear}.`);
            _renderPresetStatusLine(_currentClass);
            _dispatchSyllabusUpdated();
        }

        // 5. Bind events
        _bindEvents(container, _abortController.signal);

        console.log('[SyllabusRoute] Initialized');
    }

    function cleanup() {
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }
        if (_toastTimeout) {
            clearTimeout(_toastTimeout);
            _toastTimeout = null;
        }
        // Remove confirm overlays
        document.querySelectorAll('.syl-confirm-overlay').forEach(el => el.remove());
        // Remove toast
        document.querySelectorAll('.syl-toast').forEach(el => el.remove());
        _unloadCSS();
        _container = null;
        _gapFilter = 'all';
        _gapSubject = 'all';
        _gapChaptersCache = [];
        _memoryFilter = 'all';
        _academicProfile = null;
        console.log('[SyllabusRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.syllabusCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-syllabus-css]');
        if (el) { el.remove(); _cssLinkEl = null; }
    }

    // ════════════════════════════════════════════════════════
    //  SUPABASE SYNC
    // ════════════════════════════════════════════════════════

    function _getUserId() {
        return window.AppState?.currentUser?.id || localStorage.getItem('_current_user_id');
    }

    async function _loadFromSupabase() {
        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) return;

        try {
            const { data, error } = await window.supabaseClient
                .from('syllabus_progress')
                .select('*')
                .eq('user_id', userId);

            if (error) {
                console.error('[SyllabusRoute] Supabase load query failed:', error);
                return;
            }
            if (!data || data.length === 0) return;

            const local = SafeStorage.getItem(MASTER_KEY, {});

            // Defensive: local must be a plain object
            if (typeof local !== 'object' || local === null || Array.isArray(local)) {
                console.warn('[SyllabusRoute] Local masterData corrupted in Supabase merge, resetting');
                return;
            }

            let merged = false;

            // Merge ALL rows chapter-by-chapter — NEVER overwrite local with only one row
            data.forEach(row => {
                const chapter = row.chapter;
                if (!chapter) return;

                const localEntry = local[chapter];
                const cloudRead = !!row.read;
                const cloudNotes = !!row.notes;
                const cloudRevised = !!row.revised;
                const cloudPyq = !!row.pyq;

                if (!localEntry || typeof localEntry !== 'object') {
                    // Cloud-only chapter — add to local with all 4 fields
                    local[chapter] = {
                        read: cloudRead,
                        notes: cloudNotes,
                        revised: cloudRevised,
                        pyq: cloudPyq,
                        subject: row.subject || '',
                        book: row.book || '',
                        classLevel: row.class_level || '',
                        board: row.board || 'CBSE',
                        academicYear: row.academic_year || '2026-27',
                        lastUpdated: row.updated_at || new Date().toLocaleDateString(),
                        isSyllabus: true
                    };
                    merged = true;
                } else {
                    // Both exist — compare 4-field progress counts
                    const localDone = [localEntry.read, localEntry.notes, localEntry.revised, localEntry.pyq].filter(Boolean).length;
                    const cloudDone = [cloudRead, cloudNotes, cloudRevised, cloudPyq].filter(Boolean).length;

                    // SAFE MERGE: Only accept cloud data when local has NO progress at all
                    // This prevents stale Supabase data from overwriting user's recent edits
                    if (localDone === 0 && cloudDone > 0) {
                        local[chapter] = {
                            ...localEntry,  // preserve _scheduledFor, isSyllabus, etc.
                            read: cloudRead,
                            notes: cloudNotes,
                            revised: cloudRevised,
                            pyq: cloudPyq,
                            isSyllabus: true,
                            lastUpdated: row.updated_at || localEntry.lastUpdated
                        };
                        merged = true;
                    }
                }
            });

            if (merged) {
                SafeStorage.setItem(MASTER_KEY, local);
                console.log(`[SyllabusRoute] Merged ${data.length} rows from Supabase. Local chapters: ${Object.keys(local).length}`);
            }
        } catch (err) {
            console.error('[SyllabusRoute] Supabase load failed:', err);
        }
    }

    async function _syncToSupabase() {
        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) return;

        try {
            const masterData = SafeStorage.getItem(MASTER_KEY, {});
            const rows = [];

            for (const chapName in masterData) {
                const entry = masterData[chapName];
                if (typeof entry !== 'object' || entry === null) continue;

                rows.push({
                    user_id: userId,
                    subject: entry.subject || (entry.isSyllabus ? 'General' : 'Backlog'),
                    book: entry.book || '',
                    chapter: chapName,
                    read: !!entry.read,
                    notes: !!entry.notes,
                    revised: !!entry.revised,
                    pyq: !!entry.pyq,
                    completed: !!(entry.read && entry.notes && entry.revised && entry.pyq),
                    class_level: Number(entry.classLevel || _currentClass) || null,
                    board: entry.board || _academicProfile?.board || 'CBSE',
                    academic_year: entry.academicYear || _academicProfile?.academicYear || '2026-27',
                    preset_key: entry.presetKey || '',
                    source_type: entry.sourceType || '',
                    verification_status: entry.verificationStatus || '',
                    updated_at: new Date().toISOString()
                });
            }

            if (rows.length === 0) return;

            console.log('[SyllabusRoute] Sync rows:', rows.length);

            // Batch upsert
            const { error } = await window.supabaseClient
                .from('syllabus_progress')
                .upsert(rows, { onConflict: 'user_id,subject,chapter' });

            if (error) {
                console.error('[SyllabusRoute] Supabase sync failed:', error);
                // Warn if unique constraint may be missing
                if (error.code === '42709' || error.code === '42P10' || (error.message && error.message.includes('unique'))) {
                    console.error('[SyllabusRoute] Missing unique constraint? Run: CREATE UNIQUE INDEX IF NOT EXISTS syllabus_progress_user_subject_chapter_key ON syllabus_progress(user_id, subject, chapter);');
                }
            } else {
                console.log('[SyllabusRoute] Supabase sync success:', rows.length);
            }
        } catch (err) {
            console.error('[SyllabusRoute] Supabase sync error:', err);
        }
    }

    // ════════════════════════════════════════════════════════
    //  HTML RENDERING
    // ════════════════════════════════════════════════════════

    function renderFullUI() {
        return `
        <div class="syllabus-wrapper">
            <!-- PAGE HEADER -->
            <div class="syllabus-page-header">
                <h1 class="syllabus-page-title">Syllabus</h1>
                <p class="syllabus-page-subtitle">Strategic chapter mastery tracker</p>
                <div id="syllabusPresetStatus" class="syllabus-preset-status"></div>
            </div>

            <!-- CLASS SELECTOR -->
            <div id="classSelector" class="class-selection-overlay">
                <h2>Select Your Mission Level</h2>
                <p class="class-selection-subtitle">Choose your battlefield to begin mission tracking</p>
                <p id="classSelectorMessage" class="class-selection-subtitle" style="display:none; color:#f59e0b;"></p>
                <div class="class-cards">
                    <div class="class-card" data-action="select-class" data-class="7" data-supported="true">
                        <span class="class-number">07</span>
                        <p class="class-label">Class 7th</p>
                        <p class="class-desc">NCERT/Draft preset</p>
                    </div>
                    <div class="class-card" data-action="select-class" data-class="8" data-supported="true">
                        <span class="class-number">08</span>
                        <p class="class-label">Class 8th</p>
                        <p class="class-desc">NCERT/Draft preset</p>
                    </div>
                    <div class="class-card" data-action="select-class" data-class="9" data-supported="true">
                        <span class="class-number">09</span>
                        <p class="class-label">Class 9th</p>
                        <p class="class-desc">Foundation year — build core concepts</p>
                    </div>
                    <div class="class-card" data-action="select-class" data-class="10" data-supported="true">
                        <span class="class-number">10</span>
                        <p class="class-label">Class 10th</p>
                        <p class="class-desc">Board year — conquer every chapter</p>
                    </div>
                </div>
            </div>

            <!-- SUBJECT SECTION -->
            <div id="subjectSection" style="display:none;">
                <div class="section-header">
                    <button class="back-btn sp-btn" data-action="go-back-to-class">← Back</button>
                    <h2 id="classHeading">Class 10th Missions</h2>
                </div>

                <!-- GAP ANALYZER -->
                <div id="gapAnalyzerSection" class="gap-analyzer-section"></div>

                <div class="subject-grid" id="subjectGrid"></div>
            </div>

            <!-- CHECKLIST SECTION -->
            <div id="checklistSection" style="display:none;">
                <div class="section-header">
                    <button class="back-btn sp-btn" data-action="go-back-to-subjects">← Back to Subjects</button>
                    <h2 id="checklistTitle">Science - Mission List</h2>
                </div>
                <div id="bookTabs" class="book-tabs" style="display:none;"></div>
                <div class="chapter-list-container" id="chapterList"></div>
            </div>
        </div>
        <!-- Toast -->
        <div class="syl-toast" id="sylToast"></div>`;
    }

    // ════════════════════════════════════════════════════════
    //  CLASS SELECTION
    // ════════════════════════════════════════════════════════

    function _renderPresetStatusLine(classLevel) {
        const el = _container?.querySelector('#syllabusPresetStatus');
        if (!el) return;

        const preset = _getActivePreset(classLevel);
        if (!preset) {
            el.innerHTML = '<span>No preset loaded.</span><br><small>Manual Setup Coming Soon</small>';
            return;
        }

        // P9S-4: Show verification status from official CBSE PDF data
        const isVerified = preset.verificationStatus === 'verified';
        const isPartial = preset.verificationStatus === 'partial';
        const verifiedBadge = isVerified
            ? '<span style="color:#00d4ff;font-weight:700;"> &#10003; Verified</span>'
            : isPartial
                ? '<span style="color:#f59e0b;font-weight:700;"> Partially verified</span>'
                : '';

        const baseLine = `${preset.board} Class ${preset.classLevel} · ${preset.academicYear}${verifiedBadge ? ' · ' : ''}${verifiedBadge}`;
        const warning = preset.verificationNote || (preset.sourceType === 'Draft Preset'
            ? 'Draft syllabus preset. Verify with school before exams.'
            : '');

        el.innerHTML = `<span>${baseLine}</span>${warning ? `<br><small>${warning}</small>` : ''}`;
    }

    function _showUnsupportedPresetMessage(message) {
        const classSelector = _container?.querySelector('#classSelector');
        const subjectSection = _container?.querySelector('#subjectSection');
        const checklistSection = _container?.querySelector('#checklistSection');
        const msgEl = _container?.querySelector('#classSelectorMessage');

        if (classSelector) classSelector.style.display = 'block';
        if (subjectSection) subjectSection.style.display = 'none';
        if (checklistSection) checklistSection.style.display = 'none';
        if (msgEl) {
            msgEl.innerHTML = `${message || 'Preset not available yet.'}<br><strong>[Manual Setup Coming Soon]</strong>`;
            msgEl.style.display = 'block';
        }
    }

    function _findChapterPresetMeta(chapterName, classLevel) {
        const subjects = _getActivePreset(classLevel || _currentClass)?.subjects;
        if (!subjects) return { subject: '', book: '' };

        for (const subject in subjects) {
            for (const book in subjects[subject]) {
                if (subjects[subject][book].includes(chapterName)) {
                    return { subject, book };
                }
            }
        }

        return { subject: '', book: '' };
    }

    function _selectClass(classNum, skipSave) {
        classNum = _normalizeClassLevel(classNum);
        _currentClass = classNum;
        _renderPresetStatusLine(classNum);

        const activePreset = _getActivePreset(classNum);
        if (!activePreset) {
            const meta = _getPresetMetaSafe(classNum);
            _showUnsupportedPresetMessage(`Preset not available yet for Class ${classNum} · ${meta.board} · ${meta.academicYear}.`);
            _dispatchSyllabusUpdated();
            return;
        }

        const msgEl = _container?.querySelector('#classSelectorMessage');
        if (msgEl) msgEl.style.display = 'none';

        // Show subjects, hide class selector
        const classSelector = _container?.querySelector('#classSelector');
        const subjectSection = _container?.querySelector('#subjectSection');
        const classHeading = _container?.querySelector('#classHeading');
        const checklistSection = _container?.querySelector('#checklistSection');

        // Mark selected class card visually
        _container?.querySelectorAll('.class-card').forEach(c => c.classList.remove('selected'));
        const selectedCard = _container?.querySelector(`.class-card[data-class="${classNum}"]`);
        if (selectedCard) selectedCard.classList.add('selected');

        if (classSelector) classSelector.style.display = 'none';
        if (subjectSection) subjectSection.style.display = 'block';
        if (checklistSection) checklistSection.style.display = 'none';
        if (classHeading) classHeading.innerText = `Class ${classNum}th Missions`;

        // Save preference
        if (!skipSave) {
            SafeStorage.setItem(CLASS_KEY, classNum);
        }

        // Register all chapters in smartPadhaiData
        let masterData = SafeStorage.getItem(MASTER_KEY, {});
        const subjects = activePreset.subjects;
        if (!subjects) return;

        for (const subj in subjects) {
            for (const book in subjects[subj]) {
                subjects[subj][book].forEach(chap => {
                    const existing = masterData[chap] || {};
                    masterData[chap] = {
                        read: false,
                        notes: false,
                        pyq: false,
                        revised: false,
                        ...existing,
                        subject: existing.subject || subj,
                        book: existing.book || book,
                        classLevel: existing.classLevel || classNum,
                        board: existing.board || activePreset.board,
                        academicYear: existing.academicYear || activePreset.academicYear,
                        presetKey: existing.presetKey || _getPresetKey(activePreset),
                        sourceType: existing.sourceType || activePreset.sourceType,
                        sourceFile: existing.sourceFile || (activePreset.subjectVerification?.[subj]?.sourceFile || ''),
                        verificationStatus: existing.verificationStatus || activePreset.verificationStatus || '',
                        isSyllabus: true
                    };
                });
            }
        }
        SafeStorage.setItem(MASTER_KEY, masterData);

        // Sync progress tracker
        _syncProgressTracker(classNum);

        // Mirror to Supabase
        _syncToSupabase().catch(err => console.warn('[SyllabusRoute] Sync failed:', err));

        // Render subject cards
        _renderSubjectGrid();

        // Render Gap Analyzer
        _renderGapAnalyzer();

        _dispatchSyllabusUpdated();
    }

    function _renderSubjectGrid() {
        const grid = _container?.querySelector('#subjectGrid');
        if (!grid) return;

        const activePreset = _getActivePreset();
        const subjects = activePreset?.subjects;
        if (!subjects) { grid.innerHTML = '<p>Preset not available yet. Manual chapter support coming soon.</p>'; return; }

        const subjectMeta = {
            "Science": { label: "Science", icon: "🧪", desc: "Physics, Chemistry, Biology", color: "#00d4ff" },
            "Maths": { label: "Maths", icon: "📐", desc: "Calculations & Logic", color: "#ffcc00" },
            "SocialScience": { label: "Social Science", icon: "🌍", desc: "History, Geography, Civics, Economics", color: "#ff5e62" },
            "English": { label: "English", icon: "📖", desc: "Literature & Grammar", color: "#a8ff78" },
            "Hindi": { label: "Hindi", icon: "✍️", desc: "Vyakaran & Sahitya", color: "#feb47b" },
            "ComputerApplications": { label: "Computer Applications", icon: "💻", desc: "Digital Skills", color: "#8e44ad" }
        };

        let html = '';
        for (const subj in subjects) {
            const meta = subjectMeta[subj] || { label: subj, icon: "📝", desc: "Subject", color: "#888" };
            html += `
            <div class="subject-card-box" data-action="show-chapters" data-subject="${subj}">
                <div class="sub-icon" style="color: ${meta.color};">${meta.icon}</div>
                <h3>${meta.label || subj}</h3>
                <p>${meta.desc}</p>
            </div>`;
        }

        grid.innerHTML = html;
    }

    // ════════════════════════════════════════════════════════
    //  SAFE HELPERS (special-character-safe DOM IDs)
    // ════════════════════════════════════════════════════════

    function _makeSafeChapterId(chapterName, index = '') {
        const base = String(chapterName || '')
            .toLowerCase()
            .trim()
            .replace(/[^\w]+/g, '-')
            .replace(/^-+|-+$/g, '');

        return `${base || 'chapter'}${index !== '' ? '-' + index : ''}`;
    }

    function _escapeHtml(value) {
        return String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    // ════════════════════════════════════════════════════════
    //  CHAPTERS
    // ════════════════════════════════════════════════════════

    function _showChapters(subjectName) {
        const subjectSection = _container?.querySelector('#subjectSection');
        const checklistSection = _container?.querySelector('#checklistSection');
        const checklistTitle = _container?.querySelector('#checklistTitle');

        if (subjectSection) subjectSection.style.display = 'none';
        if (checklistSection) checklistSection.style.display = 'block';
        if (checklistTitle) checklistTitle.innerText = `${subjectName} - Mission List`;

        const chapterList = _container?.querySelector('#chapterList');
        const bookTabsEl = _container?.querySelector('#bookTabs');
        if (!chapterList) return;

        const books = _getActivePreset()?.subjects?.[subjectName];
        const masterData = SafeStorage.getItem(MASTER_KEY, {});

        if (!books) {
            chapterList.innerHTML = `<div class="syl-empty-state sp-empty-state">
                <span class="syl-empty-icon sp-empty-state-icon">\uD83D\uDCCB</span>
                <h3 class="sp-empty-state-title">No Syllabus Data</h3>
                <p class="sp-empty-state-text">Add chapters to activate tracking for ${subjectName}.</p>
            </div>`;
            return;
        }

        // If multiple books, show tabs
        const bookNames = Object.keys(books);
        if (bookNames.length > 1 && bookTabsEl) {
            bookTabsEl.style.display = 'flex';
            bookTabsEl.innerHTML = bookNames.map((book, i) =>
                `<button class="back-btn sp-btn ${i === 0 ? 'active' : ''}" data-action="filter-book" data-book="${book}">${book}</button>`
            ).join('');
        } else if (bookTabsEl) {
            bookTabsEl.style.display = 'none';
        }

        let html = '';
        for (const book in books) {
            html += `<h3 class="book-title">${book}</h3>`;

            books[book].forEach((chapter, chapterIndex) => {
                const chapId = _makeSafeChapterId(chapter, `${book}-${chapterIndex}`);
                const chapterAttr = _escapeHtml(chapter);
                const chapterText = _escapeHtml(chapter);
                const saved = masterData[chapter] || { read: false, notes: false, pyq: false, revised: false };
                const isDone = saved.read && saved.notes && saved.pyq && saved.revised;

                html += `
                <div class="chapter-card ${isDone ? 'mastered' : ''}" id="chap-${chapId}" data-chapter="${chapterAttr}">
                    <div class="chapter-main">
                        <div class="chapter-header">
                            <span class="diff-tag medium sp-badge">MEDIUM</span>
                            <h3 class="chapter-name ${isDone ? 'completed-task' : ''}">${chapterText}</h3>
                        </div>
                        <div class="chapter-progress-container">
                            <div class="progress-track">
                                <div class="progress-fill" id="fill-${chapId}"
                                     style="width:${isDone ? '100%' : '0%'}; background:${isDone ? 'linear-gradient(90deg, #28a745, #20c997)' : ''}">
                                </div>
                            </div>
                            <span class="percentage" id="perc-${chapId}">${isDone ? '100%' : '0%'}</span>
                        </div>
                    </div>
                    <div class="chapter-actions">
                        <div class="check-group">
                            <label class="custom-check">
                                <input type="checkbox" data-action="update-progress" data-chapter="${chapterAttr}" data-field="read" ${saved.read ? 'checked' : ''}>
                                <span class="check-label">Read</span>
                            </label>
                            <label class="custom-check">
                                <input type="checkbox" data-action="update-progress" data-chapter="${chapterAttr}" data-field="notes" ${saved.notes ? 'checked' : ''}>
                                <span class="check-label">Notes</span>
                            </label>
                            <label class="custom-check">
                                <input type="checkbox" data-action="update-progress" data-chapter="${chapterAttr}" data-field="revised" ${saved.revised ? 'checked' : ''}>
                                <span class="check-label">Revised</span>
                            </label>
                            <label class="custom-check">
                                <input type="checkbox" data-action="update-progress" data-chapter="${chapterAttr}" data-field="pyq" ${saved.pyq ? 'checked' : ''}>
                                <span class="check-label">PYQ</span>
                            </label>
                        </div>
                    </div>
                    <div class="mastery-badge" id="badge-${chapId}" style="display:${isDone ? 'block' : 'none'};">\uD83C\uDFC6 MASTERED</div>
                </div>`;
            });
        }

        chapterList.innerHTML = html;
    }

    // ════════════════════════════════════════════════════════
    //  PROGRESS UPDATE
    // ════════════════════════════════════════════════════════

    function _updateProgress(chapter, field, isChecked, target) {
        const card =
            target?.closest('.chapter-card') ||
            Array.from(_container?.querySelectorAll('.chapter-card') || [])
                .find(el => el.dataset.chapter === chapter);

        if (!card) {
            console.warn('[SyllabusRoute] Chapter card not found for:', chapter);
            return;
        }

        // Read current state from all 4 checkboxes
        const readCb = card.querySelector('[data-field="read"]');
        const notesCb = card.querySelector('[data-field="notes"]');
        const revisedCb = card.querySelector('[data-field="revised"]');
        const pyqCb = card.querySelector('[data-field="pyq"]');

        const readVal = readCb ? readCb.checked : false;
        const notesVal = notesCb ? notesCb.checked : false;
        const revisedVal = revisedCb ? revisedCb.checked : false;
        const pyqVal = pyqCb ? pyqCb.checked : false;

        const checkedCount = [readVal, notesVal, revisedVal, pyqVal].filter(Boolean).length;
        const isMastered = checkedCount === 4;
        const wasMastered = card.classList.contains('mastered');

        // Update progress bar — find elements from card, not global IDs
        const fill = card.querySelector('.progress-fill');
        const perc = card.querySelector('.percentage');
        const badge = card.querySelector('.mastery-badge');
        const chapterName = card.querySelector('.chapter-name');

        const progress = Math.round((checkedCount / 4) * 100);

        if (fill) {
            fill.style.width = progress + '%';
            fill.style.background = isMastered ?
                'linear-gradient(90deg, #28a745, #20c997)' :
                'linear-gradient(90deg, #00d4ff, #0072ff)';
        }
        if (perc) perc.innerText = progress + '%';

        // Mastery logic
        if (isMastered && !wasMastered) {
            card.classList.add('mastered');
            if (badge) badge.style.display = 'block';
            if (chapterName) chapterName.classList.add('completed-task');

            // PP reward — ONLY on transition from non-mastered to mastered
            const safeRewardId = _makeSafeChapterId(chapter);
            const rewardId = `mastered_${safeRewardId}_${new Date().toDateString().replace(/\s+/g, '_')}`;
            PulseEngine.addPoints(20, 'mission', { rewardId });
            _showToast(`CHAPTER MASTERED: +20 PP \uD83C\uDFC6`);
        } else if (!isMastered) {
            card.classList.remove('mastered');
            if (badge) badge.style.display = 'none';
            if (chapterName) chapterName.classList.remove('completed-task');
        }

        // Save to smartPadhaiData — PRESERVE ALL existing chapters
        let masterData = SafeStorage.getItem(MASTER_KEY, {});

        // Defensive: masterData must be a plain object
        if (typeof masterData !== 'object' || masterData === null || Array.isArray(masterData)) {
            console.warn('[SyllabusRoute] masterData corrupted, resetting to {}');
            masterData = {};
        }

        const existing = masterData[chapter] || {};
        const presetInfo = _findChapterPresetMeta(chapter, _currentClass);
        const presetMeta = _getPresetMetaSafe(_currentClass);

        // Preserve ALL existing fields (_scheduledFor, isSyllabus, etc.)
        masterData[chapter] = {
            ...existing,
            read: readVal,
            notes: notesVal,
            revised: revisedVal,
            pyq: pyqVal,
            subject: existing.subject || presetInfo.subject,
            book: existing.book || presetInfo.book,
            classLevel: existing.classLevel || _currentClass,
            board: existing.board || presetMeta.board,
            academicYear: existing.academicYear || presetMeta.academicYear,
            presetKey: existing.presetKey || presetMeta.presetKey,
            sourceType: existing.sourceType || presetMeta.sourceType,
            isSyllabus: true,
            lastUpdated: new Date().toISOString()
        };

        SafeStorage.setItem(MASTER_KEY, masterData);
        _syncToSupabase().catch(err => console.warn('[SyllabusRoute] Sync failed:', err));
        _dispatchSyllabusUpdated();

        // Re-render Gap Analyzer with fresh data
        _renderGapAnalyzer();
    }

    // ════════════════════════════════════════════════════════
    //  PROGRESS TRACKER
    // ════════════════════════════════════════════════════════

    function _syncProgressTracker(classNum) {
        let progressTracker = SafeStorage.getItem(TRACKER_KEY, {});
        const activePreset = _getActivePreset(classNum);
        const subjects = activePreset?.subjects;
        if (!subjects) return;

        for (const subj in subjects) {
            for (const book in subjects[subj]) {
                subjects[subj][book].forEach(chap => {
                    const existing = progressTracker[chap] || {};
                    progressTracker[chap] = {
                        ...existing,
                        isRegistered: true,
                        subject: existing.subject || subj,
                        book: existing.book || book,
                        classLevel: existing.classLevel || classNum,
                        board: existing.board || activePreset.board,
                        academicYear: existing.academicYear || activePreset.academicYear,
                        presetKey: existing.presetKey || _getPresetKey(activePreset),
                        sourceType: existing.sourceType || activePreset.sourceType
                    };
                });
            }
        }
        SafeStorage.setItem(TRACKER_KEY, progressTracker);
    }

    // ════════════════════════════════════════════════════════
    //  KNOWLEDGE DECAY / MEMORY RETENTION SYSTEM
    // ════════════════════════════════════════════════════════

    const MEMORY_DECAY_STRENGTH = {
        BASE: 3,
        NOTES_BONUS: 2,
        REVISION_BONUS: 3,
        PYQ_BONUS: 4,
        REVIEW_BONUS: 2,
        MAX: 30
    };

    function getTodayDateKey() {
        const d = new Date();
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    }

    function getDaysSince(date) {
        if (!date) return null;
        const d = typeof date === 'string' ? new Date(date) : date;
        if (isNaN(d.getTime())) return null;
        const now = new Date();
        const diffMs = now.getTime() - d.getTime();
        return Math.floor(diffMs / (1000 * 60 * 60 * 24));
    }

    function getChapterMemoryKey(chapter) {
        const name = chapter.name || chapter;
        const subject = chapter.subject || '';
        return `${subject}__${name}`;
    }

    function getMemoryMeta(chapter) {
        const key = getChapterMemoryKey(chapter);
        const allMeta = SafeStorage.getItem(MEMORY_DECAY_KEY, {});
        if (typeof allMeta !== 'object' || allMeta === null || Array.isArray(allMeta)) return {};
        return allMeta[key] || {};
    }

    function saveMemoryMeta(chapter, meta) {
        const key = getChapterMemoryKey(chapter);
        let allMeta = SafeStorage.getItem(MEMORY_DECAY_KEY, {});
        if (typeof allMeta !== 'object' || allMeta === null || Array.isArray(allMeta)) allMeta = {};
        allMeta[key] = {
            ...allMeta[key],
            ...meta
        };
        SafeStorage.setItem(MEMORY_DECAY_KEY, allMeta);
    }

    function calculateMemoryStrength(chapter, meta) {
        let strength = MEMORY_DECAY_STRENGTH.BASE;
        if (chapter.notes) strength += MEMORY_DECAY_STRENGTH.NOTES_BONUS;
        if (chapter.revised) strength += MEMORY_DECAY_STRENGTH.REVISION_BONUS;
        if (chapter.pyq) strength += MEMORY_DECAY_STRENGTH.PYQ_BONUS;
        const reviewCount = meta.reviewCount || 0;
        strength += reviewCount * MEMORY_DECAY_STRENGTH.REVIEW_BONUS;
        return Math.min(strength, MEMORY_DECAY_STRENGTH.MAX);
    }

    function _getLastMeaningfulReviewDate(chapter, entry, meta) {
        // Priority: lastReviewedAt (from meta) > revisedAt/pyqDoneAt/notesDoneAt (from entry) > lastUpdated > null
        if (meta.lastReviewedAt) return meta.lastReviewedAt;

        // Check entry fields (defensive — various possible field names)
        if (entry && typeof entry === 'object') {
            if (entry.lastReviewedAt) return entry.lastReviewedAt;
            if (entry.revisedAt) return entry.revisedAt;
            if (entry.pyqDoneAt || entry.practiceDoneAt) return entry.pyqDoneAt || entry.practiceDoneAt;
            if (entry.notesDoneAt) return entry.notesDoneAt;
            if (entry.lastUpdated) {
                // Try to parse lastUpdated — it might be locale string or ISO
                const parsed = new Date(entry.lastUpdated);
                if (!isNaN(parsed.getTime())) return entry.lastUpdated;
            }
        }

        // If chapter has any completion status but no date, use a rough estimate
        const hasAnyProgress = chapter.read || chapter.notes || chapter.revised || chapter.pyq;
        if (hasAnyProgress && entry && entry.lastUpdated) {
            return entry.lastUpdated;
        }

        return null;
    }

    function calculateRetention(chapter, entry) {
        const meta = getMemoryMeta(chapter);
        const lastReviewDate = _getLastMeaningfulReviewDate(chapter, entry, meta);

        if (!lastReviewDate) {
            // No review date — check if chapter has any progress
            const hasAnyProgress = chapter.read || chapter.notes || chapter.revised || chapter.pyq;
            if (!hasAnyProgress) return null; // Unknown / Not started
            // Has progress but no date — can't calculate, return null
            return null;
        }

        const daysSince = getDaysSince(lastReviewDate);
        if (daysSince === null) return null;

        const strength = calculateMemoryStrength(chapter, meta);
        const retention = Math.round(100 * Math.exp(-daysSince / strength));
        return Math.max(0, Math.min(100, retention));
    }

    function getMemoryStatus(retention) {
        if (retention === null || retention === undefined) {
            return { status: 'Unknown', color: '#6b7280', cssClass: 'memory-unknown', message: 'No memory record yet.' };
        }
        if (retention >= 80) {
            return { status: 'Strong', color: '#00ff9d', cssClass: 'memory-strong', message: 'Memory stable.' };
        }
        if (retention >= 60) {
            return { status: 'Good', color: '#00bcd4', cssClass: 'memory-good', message: 'Light revision soon.' };
        }
        if (retention >= 40) {
            return { status: 'Fading', color: '#ff9f1a', cssClass: 'memory-fading', message: 'Review recommended.' };
        }
        if (retention >= 1) {
            return { status: 'Memory Critical', color: '#ff4c4c', cssClass: 'memory-critical', message: 'Revise immediately.' };
        }
        return { status: 'Not Started', color: '#6b7280', cssClass: 'memory-unknown', message: 'No memory record yet.' };
    }

    function getNextReviewDue(retention) {
        if (retention === null || retention === undefined) return 'Start chapter first';
        if (retention >= 80) return 'In 5-7 days';
        if (retention >= 60) return 'In 2-3 days';
        if (retention >= 40) return 'Tomorrow';
        return 'Today';
    }

    function getMemorySuggestion(retention) {
        if (retention === null || retention === undefined) return 'Start or mark first review to activate memory tracking.';
        if (retention < 40) return 'Revise this today. Memory has decayed below safe level.';
        if (retention < 60) return 'Do a quick revision and 10 questions.';
        if (retention < 80) return 'Light review soon to protect memory.';
        return 'Keep in spaced revision cycle.';
    }

    function getMemorySummary(chaptersWithRetention) {
        const summary = { memoryCritical: 0, fading: 0, strong: 0, good: 0, unknown: 0, reviewDueToday: 0 };
        chaptersWithRetention.forEach(ch => {
            const memInfo = ch.memoryInfo || {};
            const status = memInfo.status || 'Unknown';
            if (status === 'Memory Critical') summary.memoryCritical++;
            else if (status === 'Fading') summary.fading++;
            else if (status === 'Strong') summary.strong++;
            else if (status === 'Good') summary.good++;
            else summary.unknown++;

            // Review due today = retention < 40 OR nextReviewDue === 'Today'
            if (memInfo.nextReviewDue === 'Today') summary.reviewDueToday++;
        });
        return summary;
    }

    function filterByMemoryStatus(chaptersWithRetention, filter) {
        if (!filter || filter === 'all') return chaptersWithRetention;
        return chaptersWithRetention.filter(ch => {
            const memInfo = ch.memoryInfo || {};
            const status = memInfo.status || 'Unknown';
            switch (filter) {
                case 'memory-critical': return status === 'Memory Critical';
                case 'fading': return status === 'Fading';
                case 'review-due': return memInfo.nextReviewDue === 'Today';
                case 'strong': return status === 'Strong';
                case 'unknown': return status === 'Unknown' || status === 'Not Started';
                default: return true;
            }
        });
    }

    function _markChapterReviewed(chapterName) {
        const chapters = getSyllabusData();
        const chapter = chapters.find(ch => ch.name === chapterName);
        if (!chapter) return;

        const meta = getMemoryMeta(chapter);
        const now = new Date().toISOString();
        meta.lastReviewedAt = now;
        meta.reviewCount = (meta.reviewCount || 0) + 1;
        meta.strength = calculateMemoryStrength(chapter, meta);
        saveMemoryMeta(chapter, meta);

        // Dispatch events
        try {
            window.dispatchEvent(new CustomEvent('smartPadhai:syllabusUpdated'));
            window.dispatchEvent(new CustomEvent('smartPadhai:memoryUpdated'));
        } catch (e) { /* safe */ }

        _showToast(`${chapterName} marked reviewed. Memory strength increased.`);

        // Re-render Gap Analyzer
        _renderGapAnalyzer();
    }


    // ════════════════════════════════════════════════════════
    //  GAP ANALYZER — Data Helpers
    // ════════════════════════════════════════════════════════

    /**
     * Get all syllabus chapters for current class, normalized.
     * Returns array of normalized chapter objects.
     */
    function getSyllabusData() {
        const activePreset = _getActivePreset();
        const subjects = activePreset?.subjects;
        if (!subjects) return [];

        const masterData = SafeStorage.getItem(MASTER_KEY, {});
        const chapters = [];

        for (const subj in subjects) {
            for (const book in subjects[subj]) {
                subjects[subj][book].forEach(chapName => {
                    const entry = masterData[chapName] || {};
                    chapters.push(_normalizeChapter(chapName, subj, book, entry));
                });
            }
        }

        return chapters;
    }

    /**
     * Normalize a raw chapter entry into a consistent structure.
     * Defensive: handles missing or differently-named fields.
     */
    function _normalizeChapter(chapterName, subject, book, entry) {
        if (!entry || typeof entry !== 'object') entry = {};

        return {
            name: chapterName,
            subject: subject || 'Unknown',
            book: book || 'General',
            read: !!(entry.read || entry.lecture || entry.lectureDone || entry.lectureWatched),
            notes: !!(entry.notes || entry.notesDone),
            revised: !!(entry.revised || entry.revision || entry.isRevised),
            pyq: !!(entry.pyq || entry.testPractice || entry.testPracticeDone || entry.practice),
            confidence: entry.confidence || null,
            priority: entry.priority || null,
            isSyllabus: entry.isSyllabus !== false,
            lastUpdated: entry.lastUpdated || null,
            _scheduledFor: entry._scheduledFor || null,
            _rawEntry: entry
        };
    }

    /**
     * Analyze a single chapter and compute gap score, risk level, gap type.
     */
    function analyzeChapterGap(chapter) {
        let gapScore = 0;
        const missingItems = [];

        if (!chapter.read) { gapScore += 30; missingItems.push('Lecture'); }
        if (!chapter.notes) { gapScore += 25; missingItems.push('Notes'); }
        if (!chapter.revised) { gapScore += 25; missingItems.push('Revision'); }
        if (!chapter.pyq) { gapScore += 20; missingItems.push('Test Practice'); }

        // Bonus penalties
        if (chapter.confidence === 'low') { gapScore += 15; }
        if (chapter.priority === 'high' || chapter.priority === 'critical') { gapScore += 10; }

        // Memory Decay penalty — add risk for low retention
        const retention = calculateRetention(chapter, chapter._rawEntry);
        if (retention !== null && retention !== undefined) {
            if (retention < 40) { gapScore += 30; }
            else if (retention < 60) { gapScore += 20; }
            else if (retention < 80) { gapScore += 10; }
            // retention >= 80: no penalty
        }

        // Bonus reduction: all core tasks done
        const allCoreDone = chapter.read && chapter.notes && chapter.revised && chapter.pyq;
        if (allCoreDone) { gapScore -= 20; }
        if (gapScore < 0) gapScore = 0;

        const riskLevel = getRiskLevel(gapScore);
        const gapType = getGapType(chapter, missingItems, retention);
        const suggestedAction = getSuggestedAction({ riskLevel, gapType, chapter, missingItems, retention });

        // Calculate memory info
        const memStatus = getMemoryStatus(retention);
        const nextReview = getNextReviewDue(retention);
        const memSuggestion = getMemorySuggestion(retention);
        const meta = getMemoryMeta(chapter);
        const lastReviewDate = _getLastMeaningfulReviewDate(chapter, chapter._rawEntry, meta);
        const daysSinceReview = getDaysSince(lastReviewDate);

        return {
            ...chapter,
            gapScore,
            riskLevel,
            gapType,
            missingItems,
            suggestedAction,
            allCoreDone,
            retention,
            memoryInfo: {
                retention: retention,
                status: memStatus.status,
                color: memStatus.color,
                cssClass: memStatus.cssClass,
                message: memStatus.message,
                nextReviewDue: nextReview,
                suggestion: memSuggestion,
                lastReviewedAt: meta.lastReviewedAt || null,
                daysSinceReview: daysSinceReview,
                reviewCount: meta.reviewCount || 0,
                strength: meta.strength || calculateMemoryStrength(chapter, meta)
            }
        };
    }

    /**
     * Get risk level from gap score.
     */
    function getRiskLevel(score) {
        if (score <= 20) return 'safe';
        if (score <= 45) return 'watch';
        if (score <= 70) return 'high';
        return 'critical';
    }

    /**
     * Determine gap type from which tasks are missing.
     */
    function getGapType(chapter, missingItems, retention) {
        if (!chapter.read) return 'Foundation Missing';
        if (missingItems.length > 1) {
            // If retention is also critical, include that in gap type
            if (retention !== null && retention !== undefined && retention < 40) return 'Multi-Gap + Memory Critical';
            return 'Multi-Gap';
        }

        if (!chapter.notes) return 'Notes Pending';
        if (!chapter.revised) return 'Revision Pending';
        if (!chapter.pyq) return 'Test Practice Missing';

        // All core done but memory is decaying
        if (retention !== null && retention !== undefined && retention < 40) return 'Memory Critical';
        if (retention !== null && retention !== undefined && retention < 60) return 'Memory Fading';

        return 'Complete';
    }

    /**
     * Generate rule-based suggested action (no AI, no API).
     */
    function getSuggestedAction(analysis) {
        const { riskLevel, gapType, chapter, missingItems, retention } = analysis;

        // Memory-based suggestion takes priority if retention is very low
        if (retention !== null && retention !== undefined && retention < 40) {
            return 'Retention is below 40%. Revise this before adding new chapters.';
        }

        if (riskLevel === 'safe') {
            return 'Keep this in light revision cycle.';
        }

        if (riskLevel === 'critical') {
            return 'Schedule this chapter in today\u2019s backlog or timetable. Urgent.';
        }

        // Gap-type specific
        if (gapType === 'Foundation Missing') {
            return 'Complete the lecture first. Foundation is missing.';
        }
        if (gapType === 'Notes Pending') {
            return 'Complete notes first. Without notes, revision will collapse.';
        }
        if (gapType === 'Revision Pending') {
            return 'Revise this chapter today and mark formulas/key points.';
        }
        if (gapType === 'Test Practice Missing') {
            return 'Solve practice questions to check actual command.';
        }
        if (gapType === 'Multi-Gap' || gapType === 'Multi-Gap + Memory Critical') {
            // Prioritize: lecture > notes > revision > practice
            if (!chapter.read) return 'Start with the lecture, then build notes and revision.';
            if (!chapter.notes) return 'Complete notes first, then revise and practice.';
            if (!chapter.revised) return 'Revise first, then solve practice questions.';
            return 'Solve practice questions to complete this chapter.';
        }
        if (gapType === 'Memory Critical') {
            return 'Retention is below 40%. Revise this before adding new chapters.';
        }
        if (gapType === 'Memory Fading') {
            return 'Memory is fading. Do a quick revision and 10 questions.';
        }

        return 'Keep working on this chapter.';
    }

    /**
     * Get summary counts from analyzed chapters.
     */
    function getGapSummary(analyzedChapters) {
        const summary = { critical: 0, high: 0, watch: 0, safe: 0, revisionPending: 0, notesPending: 0, practiceMissing: 0, foundationMissing: 0, multiGap: 0, memoryCritical: 0, memoryFading: 0, total: analyzedChapters.length };

        analyzedChapters.forEach(ch => {
            if (ch.riskLevel === 'critical') summary.critical++;
            if (ch.riskLevel === 'high') summary.high++;
            if (ch.riskLevel === 'watch') summary.watch++;
            if (ch.riskLevel === 'safe') summary.safe++;
            if (ch.gapType === 'Revision Pending') summary.revisionPending++;
            if (ch.gapType === 'Notes Pending') summary.notesPending++;
            if (ch.gapType === 'Test Practice Missing') summary.practiceMissing++;
            if (ch.gapType === 'Foundation Missing') summary.foundationMissing++;
            if (ch.gapType === 'Multi-Gap' || ch.gapType === 'Multi-Gap + Memory Critical') summary.multiGap++;
            // Memory decay counts
            if (ch.memoryInfo && ch.memoryInfo.status === 'Memory Critical') summary.memoryCritical++;
            if (ch.memoryInfo && ch.memoryInfo.status === 'Fading') summary.memoryFading++;
        });

        return summary;
    }

    // ════════════════════════════════════════════════════════
    //  GAP ANALYZER — Rendering
    // ════════════════════════════════════════════════════════

    function _renderGapAnalyzer() {
        const container = _container?.querySelector('#gapAnalyzerSection');
        if (!container) return;

        const chapters = getSyllabusData();
        const analyzed = chapters.map(ch => analyzeChapterGap(ch));
        _gapChaptersCache = analyzed;

        const summary = getGapSummary(analyzed);

        // Collect unique subjects for filter
        const uniqueSubjects = [...new Set(analyzed.map(ch => ch.subject))].sort();

        // Build inner analyzer HTML
        const innerHTML = _buildGapAnalyzerHTML(analyzed, summary, uniqueSubjects);

        // Wrap in collapsible shell
        const collapseClass = _isGapAnalyzerExpanded ? 'expanded' : 'collapsed';

        container.innerHTML = `
        <div class="gap-analyzer-shell ${collapseClass}">
            <button class="gap-analyzer-toggle" data-action="toggle-gap-analyzer">
                <div class="gap-toggle-left">
                    <span class="gap-toggle-icon">\uD83D\uDCE1</span>
                    <div>
                        <h3>Gap Analyzer</h3>
                        <p>Academic scanner</p>
                    </div>
                </div>
                <div class="gap-toggle-summary">
                    <span class="gap-summary-pill gap-pill-critical">Critical: ${summary.critical}</span>
                    <span class="gap-summary-pill gap-pill-high">High: ${summary.high}</span>
                    <span class="gap-summary-pill gap-pill-revision">Revision: ${summary.revisionPending}</span>
                    <span class="gap-summary-pill gap-pill-safe">Safe: ${summary.safe}</span>
                </div>
                <span class="gap-toggle-chevron">\u2304</span>
            </button>
            <div class="gap-analyzer-fold-body">
                ${innerHTML}
            </div>
        </div>`;

        // Re-apply active filter button state
        _applyGapFilterState();
    }

    function _toggleGapAnalyzer() {
        _isGapAnalyzerExpanded = !_isGapAnalyzerExpanded;
        SafeStorage.setItem(GAP_ANALYZER_COLLAPSE_KEY, _isGapAnalyzerExpanded);
        _renderGapAnalyzer();
    }

    function _buildGapAnalyzerHTML(analyzed, summary, subjects) {
        if (analyzed.length === 0) {
            return `
            <div class="gap-analyzer-panel">
                <div class="gap-analyzer-header">
                    <h2 class="gap-analyzer-title">SYLLABUS GAP ANALYZER</h2>
                    <p class="gap-analyzer-subtitle">Find the weak links before the exam finds them.</p>
                </div>
                <div class="gap-empty-state sp-empty-state">
                    <span class="gap-empty-icon sp-empty-state-icon">\uD83D\uDD0D</span>
                    <h3 class="sp-empty-state-title">No Syllabus Data</h3>
                    <p class="sp-empty-state-text">Add chapters to activate Gap Analyzer and track weak links.</p>
                </div>
            </div>`;
        }

        // Filter chapters based on current filter state
        const filtered = _filterGapChapters(analyzed);

        // Risk color map
        const riskColors = {
            critical: '#ff4c4c',
            high: '#ff9f1a',
            watch: '#00bcd4',
            safe: '#00ff9d'
        };

        const riskLabels = {
            critical: 'Critical',
            high: 'High Risk',
            watch: 'Watch',
            safe: 'Safe'
        };

        // Build subject filter buttons
        const subjectButtons = ['All Subjects', ...subjects].map(s => {
            const isActive = (_gapSubject === 'all' && s === 'All Subjects') || _gapSubject === s;
            return `<button class="gap-filter-btn gap-subject-btn ${isActive ? 'active' : ''}"
                        data-action="gap-subject-filter" data-subject="${s === 'All Subjects' ? 'all' : s}">${s}</button>`;
        }).join('');

        // Build risk filter buttons
        const riskFilterDefs = [
            { key: 'all', label: 'All' },
            { key: 'critical', label: 'Critical' },
            { key: 'high', label: 'High Risk' },
            { key: 'revision', label: 'Revision Pending' },
            { key: 'notes', label: 'Notes Pending' },
            { key: 'practice', label: 'Test Practice Missing' },
            { key: 'memory-critical', label: 'Memory Critical' },
            { key: 'fading', label: 'Fading' },
            { key: 'review-due', label: 'Review Due' },
            { key: 'strong', label: 'Strong Memory' },
            { key: 'safe', label: 'Safe' }
        ];
        const riskButtons = riskFilterDefs.map(f => {
            return `<button class="gap-filter-btn ${_gapFilter === f.key ? 'active' : ''}"
                        data-action="gap-filter" data-filter="${f.key}">${f.label}</button>`;
        }).join('');

        // Build gap cards
        let gapCardsHTML = '';
        if (filtered.length === 0) {
            gapCardsHTML = `<div class="gap-no-results">
                <span class="gap-no-results-icon">\u2714\uFE0F</span>
                <p>No chapters match this filter. Try a different one.</p>
            </div>`;
        } else {
            gapCardsHTML = filtered.map(ch => _buildGapCardHTML(ch, riskColors, riskLabels)).join('');
        }

        return `
        <div class="gap-analyzer-panel">
            <div class="gap-analyzer-header">
                <div class="gap-analyzer-title-row">
                    <h2 class="gap-analyzer-title">SYLLABUS GAP ANALYZER</h2>
                    <span class="gap-scan-indicator"></span>
                </div>
                <p class="gap-analyzer-subtitle">Find the weak links before the exam finds them.</p>
            </div>

            <!-- Summary Cards -->
            <div class="gap-summary-grid">
                <div class="gap-summary-card gap-summary-critical">
                    <span class="gap-summary-count">${summary.critical}</span>
                    <span class="gap-summary-label">Critical Gaps</span>
                </div>
                <div class="gap-summary-card gap-summary-high">
                    <span class="gap-summary-count">${summary.high}</span>
                    <span class="gap-summary-label">High Risk</span>
                </div>
                <div class="gap-summary-card gap-summary-revision">
                    <span class="gap-summary-count">${summary.revisionPending}</span>
                    <span class="gap-summary-label">Revision Pending</span>
                </div>
                <div class="gap-summary-card gap-summary-safe">
                    <span class="gap-summary-count">${summary.safe}</span>
                    <span class="gap-summary-label">Safe</span>
                </div>
            </div>

            <!-- Memory Decay Summary Cards -->
            <div class="memory-summary-grid">
                <div class="gap-summary-card memory-summary-critical">
                    <span class="gap-summary-count">${summary.memoryCritical}</span>
                    <span class="gap-summary-label">Memory Critical</span>
                </div>
                <div class="gap-summary-card memory-summary-fading">
                    <span class="gap-summary-count">${summary.memoryFading}</span>
                    <span class="gap-summary-label">Fading</span>
                </div>
                <div class="gap-summary-card memory-summary-strong">
                    <span class="gap-summary-count">${(() => { const ms = getMemorySummary(analyzed); return ms.strong; })()}</span>
                    <span class="gap-summary-label">Strong</span>
                </div>
                <div class="gap-summary-card memory-summary-review-due">
                    <span class="gap-summary-count">${(() => { const ms = getMemorySummary(analyzed); return ms.reviewDueToday; })()}</span>
                    <span class="gap-summary-label">Review Due</span>
                </div>
            </div>

            <!-- Filters -->
            <div class="gap-filters">
                <div class="gap-filter-row">${riskButtons}</div>
                <div class="gap-filter-row gap-subject-row">${subjectButtons}</div>
            </div>

            <!-- Gap List -->
            <div class="gap-list">
                ${gapCardsHTML}
            </div>
        </div>`;
    }

    function _buildGapCardHTML(ch, riskColors, riskLabels) {
        const color = riskColors[ch.riskLevel] || '#888';
        const label = riskLabels[ch.riskLevel] || 'Unknown';
        const checkMark = (done) => done
            ? '<span class="gap-check gap-check-done">\u2713</span>'
            : '<span class="gap-check gap-check-missing">\u2717</span>';
        const checkLabel = (done, text) => done
            ? `<span class="gap-check-label gap-check-label-done">${text} Done</span>`
            : `<span class="gap-check-label gap-check-label-missing">${text} Pending</span>`;

        // Memory info
        const memInfo = ch.memoryInfo || {};
        const memColor = memInfo.color || '#6b7280';
        const memStatus = memInfo.status || 'Unknown';
        const memCssClass = memInfo.cssClass || 'memory-unknown';
        const retention = memInfo.retention;
        const nextReview = memInfo.nextReviewDue || 'Start chapter first';
        const memSuggestion = memInfo.suggestion || '';
        const daysSince = memInfo.daysSinceReview;
        const reviewCount = memInfo.reviewCount || 0;

        // Build retention bar HTML
        let retentionBarHTML = '';
        if (retention !== null && retention !== undefined) {
            retentionBarHTML = `
            <div class="memory-retention-strip ${memCssClass}">
                <div class="memory-retention-bar" style="width: ${retention}%; background: ${memColor};"></div>
                <span class="memory-retention-label">${retention}% Retention</span>
            </div>`;
        } else {
            retentionBarHTML = `
            <div class="memory-retention-strip memory-unknown">
                <div class="memory-retention-bar" style="width: 0%; background: #6b7280;"></div>
                <span class="memory-retention-label">No retention data yet</span>
            </div>`;
        }

        // Memory status line
        let memoryLineHTML = '';
        const lastReviewedText = daysSince !== null && daysSince !== undefined
            ? (daysSince === 0 ? 'Today' : daysSince === 1 ? '1 day ago' : `${daysSince} days ago`)
            : 'Never';
        memoryLineHTML = `
        <div class="memory-status-line">
            <span class="memory-status-badge ${memCssClass}" style="background: ${memColor}20; color: ${memColor}; border: 1px solid ${memColor}50;">${memStatus.toUpperCase()}</span>
            <span class="memory-meta-item">Last: ${lastReviewedText}</span>
            <span class="memory-meta-item">Next: ${nextReview}</span>
            ${reviewCount > 0 ? `<span class="memory-meta-item">Reviews: ${reviewCount}</span>` : ''}
        </div>`;

        // Determine which action buttons to show
        let actionButtonsHTML = '';

        if (!ch.notes && ch.read) {
            actionButtonsHTML += `<button class="gap-action-btn gap-action-notes" data-action="gap-mark-field" data-chapter="${ch.name}" data-field="notes">Mark Notes Done</button>`;
        }
        if (!ch.revised && ch.read && ch.notes) {
            actionButtonsHTML += `<button class="gap-action-btn gap-action-revised" data-action="gap-mark-field" data-chapter="${ch.name}" data-field="revised">Mark Revised</button>`;
        }
        if (!ch.pyq && ch.read && ch.notes && ch.revised) {
            actionButtonsHTML += `<button class="gap-action-btn gap-action-pyq" data-action="gap-mark-field" data-chapter="${ch.name}" data-field="pyq">Mark PYQ Done</button>`;
        }

        // Mark Reviewed button — always show if chapter has any progress
        const hasAnyProgress = ch.read || ch.notes || ch.revised || ch.pyq;
        if (hasAnyProgress) {
            actionButtonsHTML += `<button class="gap-action-btn gap-action-review" data-action="memory-mark-reviewed" data-chapter="${ch.name}">Mark Reviewed</button>`;
        }

        // Backlog button — check if SafeStorage and BACKLOG_TIMELINE_KEY are accessible
        const backlogBtn = ch.riskLevel === 'safe'
            ? ''
            : `<button class="gap-action-btn gap-action-backlog" data-action="gap-add-backlog" data-chapter="${ch.name}" data-subject="${ch.subject}">Add to Backlog</button>`;

        // Memory suggestion line (separate from gap suggestion)
        let memSuggestionHTML = '';
        if (memSuggestion) {
            memSuggestionHTML = `
            <div class="memory-suggestion-line">
                <span class="gap-action-icon">\uD83E\uDDE0</span>
                <span>${memSuggestion}</span>
            </div>`;
        }

        return `
        <div class="gap-card gap-risk-${ch.riskLevel}" style="border-left-color: ${color};">
            <div class="gap-card-header">
                <span class="gap-card-subject">${ch.subject} / ${ch.book}</span>
                <span class="gap-risk-badge" style="background: ${color}20; color: ${color}; border: 1px solid ${color}50;">${label}</span>
            </div>
            <h3 class="gap-card-chapter">${ch.name}</h3>
            ${retentionBarHTML}
            ${memoryLineHTML}
            <div class="gap-card-meta">
                <span class="gap-gap-type" style="color: ${color};">${ch.gapType}</span>
                <span class="gap-score">Score: ${ch.gapScore}</span>
            </div>
            <div class="gap-checklist">
                <div class="gap-check-item">${checkMark(ch.read)} ${checkLabel(ch.read, 'Read')}</div>
                <div class="gap-check-item">${checkMark(ch.notes)} ${checkLabel(ch.notes, 'Notes')}</div>
                <div class="gap-check-item">${checkMark(ch.revised)} ${checkLabel(ch.revised, 'Revision')}</div>
                <div class="gap-check-item">${checkMark(ch.pyq)} ${checkLabel(ch.pyq, 'PYQ')}</div>
            </div>
            <div class="gap-suggested-action">
                <span class="gap-action-icon">\uD83D\uDCA1</span>
                <span>${ch.suggestedAction}</span>
            </div>
            ${memSuggestionHTML}
            ${actionButtonsHTML || backlogBtn ? `<div class="gap-card-actions">${actionButtonsHTML}${backlogBtn}</div>` : ''}
        </div>`;
    }

    // ════════════════════════════════════════════════════════
    //  GAP ANALYZER — Filtering
    // ════════════════════════════════════════════════════════

    function _filterGapChapters(analyzed) {
        let result = analyzed;

        // Risk/filter filter
        if (_gapFilter === 'critical') {
            result = result.filter(ch => ch.riskLevel === 'critical');
        } else if (_gapFilter === 'high') {
            result = result.filter(ch => ch.riskLevel === 'high');
        } else if (_gapFilter === 'revision') {
            result = result.filter(ch => ch.gapType === 'Revision Pending' || (ch.missingItems && ch.missingItems.includes('Revision')));
        } else if (_gapFilter === 'notes') {
            result = result.filter(ch => ch.gapType === 'Notes Pending' || (ch.missingItems && ch.missingItems.includes('Notes')));
        } else if (_gapFilter === 'practice') {
            result = result.filter(ch => ch.gapType === 'Test Practice Missing' || (ch.missingItems && ch.missingItems.includes('Test Practice')));
        } else if (_gapFilter === 'memory-critical') {
            result = result.filter(ch => ch.memoryInfo && ch.memoryInfo.status === 'Memory Critical');
        } else if (_gapFilter === 'fading') {
            result = result.filter(ch => ch.memoryInfo && ch.memoryInfo.status === 'Fading');
        } else if (_gapFilter === 'review-due') {
            result = result.filter(ch => ch.memoryInfo && ch.memoryInfo.nextReviewDue === 'Today');
        } else if (_gapFilter === 'strong') {
            result = result.filter(ch => ch.memoryInfo && ch.memoryInfo.status === 'Strong');
        } else if (_gapFilter === 'safe') {
            result = result.filter(ch => ch.riskLevel === 'safe');
        }
        // 'all' — no filter

        // Subject filter
        if (_gapSubject !== 'all') {
            result = result.filter(ch => ch.subject === _gapSubject);
        }

        // Sort: highest risk first, then lowest retention first within same risk
        const riskOrder = { critical: 0, high: 1, watch: 2, safe: 3 };
        result.sort((a, b) => {
            const ro = (riskOrder[a.riskLevel] ?? 9) - (riskOrder[b.riskLevel] ?? 9);
            if (ro !== 0) return ro;
            // Secondary sort: lowest retention first
            const retA = a.memoryInfo && a.memoryInfo.retention !== null && a.memoryInfo.retention !== undefined ? a.memoryInfo.retention : 999;
            const retB = b.memoryInfo && b.memoryInfo.retention !== null && b.memoryInfo.retention !== undefined ? b.memoryInfo.retention : 999;
            if (retA !== retB) return retA - retB;
            return b.gapScore - a.gapScore;
        });

        return result;
    }

    function filterGapAnalyzer(filterType, subject) {
        if (filterType !== undefined) _gapFilter = filterType;
        if (subject !== undefined) _gapSubject = subject;
        _renderGapAnalyzer();
    }

    function _applyGapFilterState() {
        // No-op: filter state is baked into the HTML during render
        // This function exists for future extensibility
    }

    // ════════════════════════════════════════════════════════
    //  GAP ANALYZER — Actions
    // ════════════════════════════════════════════════════════

    /**
     * Mark a specific field as done for a chapter from the Gap Analyzer.
     * Safely writes to smartPadhaiData and re-renders.
     */
    function _gapMarkField(chapterName, field) {
        let masterData = SafeStorage.getItem(MASTER_KEY, {});
        if (typeof masterData !== 'object' || masterData === null || Array.isArray(masterData)) {
            masterData = {};
        }

        const existing = masterData[chapterName];
        if (!existing || typeof existing !== 'object') {
            // Chapter not in master data — skip safely
            console.warn(`[GapAnalyzer] Chapter "${chapterName}" not found in master data`);
            return;
        }

        // Map gap field names to data field names
        const fieldMap = {
            'read': 'read',
            'notes': 'notes',
            'revised': 'revised',
            'pyq': 'pyq'
        };

        const dataField = fieldMap[field];
        if (!dataField) return;

        // Only mark if not already done
        if (existing[dataField]) return;

        masterData[chapterName] = {
            ...existing,
            [dataField]: true,
            lastUpdated: new Date().toLocaleDateString()
        };

        SafeStorage.setItem(MASTER_KEY, masterData);
        _syncToSupabase().catch(err => console.warn('[SyllabusRoute] Sync failed:', err));

        // Check if this triggers mastery
        const updated = masterData[chapterName];
        const allDone = updated.read && updated.notes && updated.revised && updated.pyq;
        if (allDone) {
            const safeRewardId = _makeSafeChapterId(chapterName);
            const rewardId = `mastered_${safeRewardId}_${new Date().toDateString().replace(/\s+/g, '_')}`;
            PulseEngine.addPoints(20, 'mission', { rewardId });
            _showToast(`CHAPTER MASTERED: +20 PP \uD83C\uDFC6`);
        } else {
            const fieldLabel = { read: 'Lecture', notes: 'Notes', revised: 'Revision', pyq: 'Test Practice' };
            _showToast(`${fieldLabel[dataField] || dataField} marked done for ${chapterName}`);
        }

        // Re-render Gap Analyzer
        _renderGapAnalyzer();
    }

    /**
     * Add a chapter to the Backlog (safe integration via shared localStorage).
     * Uses the same BACKLOG_TIMELINE_KEY and _scheduledFor field that BacklogRoute reads.
     */
    function _gapAddToBacklog(chapterName, subject) {
        try {
            // 1. Add to backlog timeline for tomorrow
            const tomorrow = new Date(Date.now() + 86400000);
            const tomorrowStr = tomorrow.toDateString();

            let timeline = {};
            try {
                timeline = SafeStorage.getItem(BACKLOG_TIMELINE_KEY, {});
            } catch (e) {
                timeline = {};
            }
            if (typeof timeline !== 'object' || timeline === null || Array.isArray(timeline)) {
                timeline = {};
            }
            if (!timeline[tomorrowStr]) timeline[tomorrowStr] = [];
            if (!timeline[tomorrowStr].includes(chapterName)) {
                timeline[tomorrowStr].push(chapterName);
            }
            SafeStorage.setItem(BACKLOG_TIMELINE_KEY, timeline);

            // 2. Set _scheduledFor on the chapter entry in smartPadhaiData
            let masterData = SafeStorage.getItem(MASTER_KEY, {});
            if (typeof masterData !== 'object' || masterData === null || Array.isArray(masterData)) {
                masterData = {};
            }

            if (masterData[chapterName] && typeof masterData[chapterName] === 'object') {
                masterData[chapterName] = {
                    ...masterData[chapterName],
                    _scheduledFor: tomorrowStr
                };
                SafeStorage.setItem(MASTER_KEY, masterData);
            }

            _showToast(`${chapterName} added to backlog for tomorrow`);
        } catch (err) {
            console.warn('[GapAnalyzer] Failed to add to backlog:', err);
            _showToast('Could not add to backlog. Try again.');
        }
    }

    // ════════════════════════════════════════════════════════
    //  NAVIGATION
    // ════════════════════════════════════════════════════════

    function _goBackToClass() {
        const classSelector = _container?.querySelector('#classSelector');
        const subjectSection = _container?.querySelector('#subjectSection');
        const checklistSection = _container?.querySelector('#checklistSection');

        if (classSelector) classSelector.style.display = 'flex';
        if (subjectSection) subjectSection.style.display = 'none';
        if (checklistSection) checklistSection.style.display = 'none';

        // Reset gap state
        _gapFilter = 'all';
        _gapSubject = 'all';
    }

    function _goBackToSubjects() {
        const subjectSection = _container?.querySelector('#subjectSection');
        const checklistSection = _container?.querySelector('#checklistSection');

        if (subjectSection) subjectSection.style.display = 'block';
        if (checklistSection) checklistSection.style.display = 'none';

        // Re-render Gap Analyzer in case data changed
        _renderGapAnalyzer();
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING — Delegation + AbortController
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {
        // ── CLICK DELEGATION ──
        container.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;

            switch (action) {
                case 'select-class': {
                    const classNum = parseInt(target.dataset.class, 10);
                    if (!isNaN(classNum)) _selectClass(classNum);
                    break;
                }

                case 'show-chapters': {
                    const subject = target.dataset.subject;
                    if (subject) _showChapters(subject);
                    break;
                }

                case 'go-back-to-class':
                    _goBackToClass();
                    break;

                case 'go-back-to-subjects':
                    _goBackToSubjects();
                    break;

                case 'filter-book': {
                    // Toggle active tab and scroll to book section
                    const book = target.dataset.book;
                    if (book) {
                        // Toggle active class on book tabs
                        container.querySelectorAll('.book-tabs .back-btn').forEach(b => b.classList.remove('active'));
                        target.classList.add('active');
                        // Scroll to book title
                        const headings = container.querySelectorAll('.book-title');
                        headings.forEach(h => {
                            if (h.textContent === book) {
                                h.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            }
                        });
                    }
                    break;
                }

                // ── Gap Analyzer Filters ──
                case 'toggle-gap-analyzer':
                    _toggleGapAnalyzer();
                    break;

                case 'gap-filter': {
                    const filter = target.dataset.filter;
                    if (filter) filterGapAnalyzer(filter, undefined);
                    break;
                }

                case 'gap-subject-filter': {
                    const subject = target.dataset.subject;
                    if (subject !== undefined) filterGapAnalyzer(undefined, subject);
                    break;
                }

                // ── Gap Analyzer Actions ──
                case 'gap-mark-field': {
                    const chapter = target.dataset.chapter;
                    const field = target.dataset.field;
                    if (chapter && field) _gapMarkField(chapter, field);
                    break;
                }

                case 'gap-add-backlog': {
                    const chapter = target.dataset.chapter;
                    const subject = target.dataset.subject;
                    if (chapter) _gapAddToBacklog(chapter, subject);
                    break;
                }

                // ── Memory Decay Actions ──
                case 'memory-mark-reviewed': {
                    const chapter = target.dataset.chapter;
                    if (chapter) _markChapterReviewed(chapter);
                    break;
                }
            }
        }, { signal });

        // ── CHANGE DELEGATION (checkboxes) ──
        container.addEventListener('change', (e) => {
            const target = e.target;
            const action = target.dataset.action;

            if (action === 'update-progress') {
                const chapter = target.dataset.chapter;
                const field = target.dataset.field;
                if (chapter && field) {
                    _updateProgress(chapter, field, target.checked, target);
                }
            }
        }, { signal });
    }

    // ════════════════════════════════════════════════════════
    //  TOAST
    // ════════════════════════════════════════════════════════

    function _showToast(message) {
        const toast = _container?.querySelector('#sylToast');
        if (!toast) return;

        toast.textContent = message;
        toast.classList.add('visible');

        if (_toastTimeout) clearTimeout(_toastTimeout);
        _toastTimeout = setTimeout(() => {
            toast.classList.remove('visible');
        }, 3000);
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();

window.SyllabusRoute = SyllabusRoute;
