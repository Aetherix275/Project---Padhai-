/**
 * ═══════════════════════════════════════════════════════
 *  SMART PADHAI — PLACEHOLDER ROUTES (Phase 6B)
 *  Shows a card with route info + button to open legacy page
 * ═══════════════════════════════════════════════════════
 *
 *  Each placeholder shows:
 *    - Route name + icon
 *    - Brief description
 *    - "Open Legacy Page" button (opens .html in same tab)
 *    - SPA badge indicating this is a placeholder
 */

function PlaceholderRoute(id, icon, title, description, legacyPage) {
    return {
        init(container) {
            container.innerHTML = `
                <div class="placeholder-route">
                    <div class="placeholder-badge">SPA ROUTE — PLACEHOLDER</div>
                    <div class="placeholder-card">
                        <div class="placeholder-icon">${icon}</div>
                        <h1 class="placeholder-title">${title}</h1>
                        <p class="placeholder-desc">${description}</p>
                        <div class="placeholder-status">
                            <span class="status-dot status-pending"></span>
                            <span>Not yet converted to SPA route</span>
                        </div>
                        <div class="placeholder-actions">
                            <a href="./${legacyPage}" class="legacy-btn">
                                Open Legacy Page →
                            </a>
                            <button class="spa-info-btn" onclick="this.parentElement.querySelector('.spa-info-panel').classList.toggle('open')">
                                Why am I seeing this?
                            </button>
                        </div>
                        <div class="spa-info-panel">
                            <p>This page is part of the legacy multi-page architecture. It will be converted to an SPA route in a future phase. For now, clicking "Open Legacy Page" will take you to the original standalone page.</p>
                            <p><strong>Route ID:</strong> ${id} | <strong>Legacy file:</strong> ${legacyPage}</p>
                        </div>
                    </div>
                </div>
            `;
        },

        cleanup() {
            // Nothing to clean up for static placeholder
        }
    };
}

// Make globally accessible
window.PlaceholderRoute = PlaceholderRoute;
