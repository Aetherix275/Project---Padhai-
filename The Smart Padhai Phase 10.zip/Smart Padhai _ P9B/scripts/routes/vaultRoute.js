/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — VAULT ROUTE MODULE (Phase 9A Sprint 4F)
 *  Full SPA conversion of Study Vault: Methods + Operator Journal
 *  + Achievement Badges 2.0 Gallery
 *  + Streak / Activity Intelligence Heatmap
 *  Sprint 4F: Daily Performance Intelligence Engine — multi-source scoring
 *  Sprint 4E: Historical Data Source — cloud time_blocks + local fallback
 *  Sprint 4D: Honest Scoring — completion ratio primary, minutes supporting
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear state
 *
 *  Dependencies (must be loaded BEFORE this module):
 *    - methodDetails.js  (METHOD_DETAILS, MethodUsageTracker, MethodMission)
 *    - journalEngine.js  (JournalEngine)
 *    - userSession.js    (getCurrentUserOrRedirect, SafeStorage, fetchUserRows)
 *
 *  CSS: Loaded dynamically from styles/modules/vault.css
 *       Removed on cleanup() to prevent style leakage.
 *
 *  Events: All via event delegation + AbortController. Zero inline onclick.
 * ═══════════════════════════════════════════════════════════════════
 */

const VaultRoute = (() => {

    // ── Private state (scoped to this IIFE, reset on cleanup) ──
    let _container = null;
    let _abortController = null;
    let _currentMood = 'Normal';
    let _toastTimeout = null;
    let _cssLinkEl = null;       // reference to dynamically loaded <link>
    let _badgeUnlockTimeout = null; // timeout for badge unlock toast
    let _heatmapTooltipEl = null;  // reference to heatmap tooltip element
    let _heatmapDayData = null;    // cached dayMap from _buildHeatmapData
    let _selectedHeatmapDate = null; // currently selected day in detail panel
    let _cloudTimeBlocks = null;    // cached cloud rows from time_blocks (read-only)
    let _cloudLoadAttempted = false; // whether cloud load was attempted this session

    const CSS_PATH = './styles/modules/vault.css';

    // ════════════════════════════════════════════════════════
    //  ACHIEVEMENT BADGES 2.0 — Badge Catalog
    // ════════════════════════════════════════════════════════
    //
    //  Each badge has:
    //    id          — unique string key
    //    name        — display name
    //    emoji       — icon
    //    category    — one of: Consistency, Time Table, Syllabus,
    //                  Backlog, Notebook, PP / Rank
    //    description — short explanation
    //    calculate   — function() => { unlocked, current, target, reason }
    //                  Purely derived from existing SafeStorage data.
    //                  No Supabase reads or writes.

    const BADGE_CATALOG = [
        // ── Consistency ──
        {
            id: 'early_bird',
            name: 'Early Bird',
            emoji: '🌅',
            category: 'Consistency',
            description: 'Complete a time block before 7 AM',
            calculate() {
                try {
                    const tbData = SafeStorage.getItem('time_blocks_v1', null);
                    const blocks = (tbData && Array.isArray(tbData.blocks)) ? tbData.blocks : [];
                    // Check today + recent days for any completed block with endTime before 7 AM
                    let found = false;
                    for (const b of blocks) {
                        if (b.status === 'completed' && b.endTime) {
                            const endH = parseInt(String(b.endTime).split(':')[0], 10);
                            if (!isNaN(endH) && endH < 7) { found = true; break; }
                        }
                        // Also check startTime — if block started before 7 AM and is completed
                        if (b.status === 'completed' && b.startTime) {
                            const startH = parseInt(String(b.startTime).split(':')[0], 10);
                            if (!isNaN(startH) && startH < 7) { found = true; break; }
                        }
                    }
                    return {
                        unlocked: found,
                        current: found ? 1 : 0,
                        target: 1,
                        reason: found ? 'Completed a block before 7 AM' : 'Complete any block before 7 AM'
                    };
                } catch { return { unlocked: false, current: 0, target: 1, reason: 'Complete any block before 7 AM' }; }
            }
        },
        {
            id: 'night_owl',
            name: 'Night Owl',
            emoji: '🦉',
            category: 'Consistency',
            description: 'Complete a time block after 10 PM',
            calculate() {
                try {
                    const tbData = SafeStorage.getItem('time_blocks_v1', null);
                    const blocks = (tbData && Array.isArray(tbData.blocks)) ? tbData.blocks : [];
                    let found = false;
                    for (const b of blocks) {
                        if (b.status === 'completed' && b.endTime) {
                            const endH = parseInt(String(b.endTime).split(':')[0], 10);
                            if (!isNaN(endH) && endH >= 22) { found = true; break; }
                        }
                        if (b.status === 'completed' && b.startTime) {
                            const startH = parseInt(String(b.startTime).split(':')[0], 10);
                            if (!isNaN(startH) && startH >= 22) { found = true; break; }
                        }
                    }
                    return {
                        unlocked: found,
                        current: found ? 1 : 0,
                        target: 1,
                        reason: found ? 'Completed a block after 10 PM' : 'Complete any block after 10 PM'
                    };
                } catch { return { unlocked: false, current: 0, target: 1, reason: 'Complete any block after 10 PM' }; }
            }
        },
        {
            id: 'streak_keeper',
            name: 'Streak Keeper',
            emoji: '🔥',
            category: 'Consistency',
            description: 'Maintain a 7-day streak',
            calculate() {
                try {
                    const pulseData = SafeStorage.getItem('pulse_engine_data', {}) || {};
                    const streak = Number(pulseData.streak || 0);
                    return {
                        unlocked: streak >= 7,
                        current: Math.min(streak, 7),
                        target: 7,
                        reason: streak >= 7 ? `${streak}-day streak achieved` : `${streak}/7 day streak`
                    };
                } catch { return { unlocked: false, current: 0, target: 7, reason: '0/7 day streak' }; }
            }
        },

        // ── Time Table ──
        {
            id: 'perfect_planner',
            name: 'Perfect Planner',
            emoji: '📋',
            category: 'Time Table',
            description: 'Complete all planned blocks in a day',
            calculate() {
                try {
                    const tbData = SafeStorage.getItem('time_blocks_v1', null);
                    const blocks = (tbData && Array.isArray(tbData.blocks)) ? tbData.blocks : [];
                    if (blocks.length === 0) {
                        return { unlocked: false, current: 0, target: 1, reason: 'Add blocks to your timetable first' };
                    }
                    const total = blocks.length;
                    const completed = blocks.filter(b => b.status === 'completed').length;
                    // Unlocked if there are blocks and ALL are completed
                    const unlocked = total > 0 && completed === total;
                    return {
                        unlocked,
                        current: completed,
                        target: total,
                        reason: unlocked ? `All ${total} blocks completed` : `${completed}/${total} blocks completed today`
                    };
                } catch { return { unlocked: false, current: 0, target: 1, reason: 'Add blocks to your timetable' }; }
            }
        },
        {
            id: 'gold_mission_finisher',
            name: 'Gold Mission Finisher',
            emoji: '🥇',
            category: 'Time Table',
            description: 'Complete 3 gold/high-priority blocks',
            calculate() {
                try {
                    const tbData = SafeStorage.getItem('time_blocks_v1', null);
                    const blocks = (tbData && Array.isArray(tbData.blocks)) ? tbData.blocks : [];
                    const highCompleted = blocks.filter(b =>
                        b.status === 'completed' && (b.priority === 'high' || b.priority === 'gold')
                    ).length;
                    return {
                        unlocked: highCompleted >= 3,
                        current: Math.min(highCompleted, 3),
                        target: 3,
                        reason: highCompleted >= 3 ? `${highCompleted} high-priority blocks done` : `${highCompleted}/3 high-priority blocks`
                    };
                } catch { return { unlocked: false, current: 0, target: 3, reason: '0/3 high-priority blocks' }; }
            }
        },

        // ── Syllabus ──
        {
            id: 'subject_master',
            name: 'Subject Master',
            emoji: '🏆',
            category: 'Syllabus',
            description: 'Complete all tracked chapters in one subject',
            calculate() {
                try {
                    const masterData = SafeStorage.getItem('smartPadhaiData', {}) || {};
                    // Group by subject, check if any subject has all chapters completed
                    const subjects = {};
                    for (const [chKey, chData] of Object.entries(masterData)) {
                        if (!chData || typeof chData !== 'object') continue;
                        const subj = chData.subject || 'Unknown';
                        if (!subjects[subj]) subjects[subj] = { total: 0, completed: 0 };
                        subjects[subj].total++;
                        // completed = read && notes && pyq
                        const read   = !!(chData.read || chData.read === true || chData.read === 'true');
                        const notes  = !!(chData.notes || chData.notes === true || chData.notes === 'true');
                        const pyq    = !!(chData.pyq || chData.pyq === true || chData.pyq === 'true');
                        if (read && notes && pyq) subjects[subj].completed++;
                    }
                    // Find best subject
                    let bestSubj = null;
                    let bestRatio = 0;
                    for (const [subj, info] of Object.entries(subjects)) {
                        if (info.total > 0) {
                            const ratio = info.completed / info.total;
                            if (ratio > bestRatio) { bestRatio = ratio; bestSubj = subj; }
                        }
                    }
                    const unlocked = bestSubj !== null && subjects[bestSubj].completed === subjects[bestSubj].total && subjects[bestSubj].total > 0;
                    const current = bestSubj ? subjects[bestSubj].completed : 0;
                    const target  = bestSubj ? subjects[bestSubj].total : 1;
                    return {
                        unlocked,
                        current,
                        target,
                        reason: unlocked ? `All chapters in ${bestSubj} completed` : (bestSubj ? `${current}/${target} chapters in ${bestSubj}` : 'Track chapters in Syllabus')
                    };
                } catch { return { unlocked: false, current: 0, target: 1, reason: 'Track chapters in Syllabus' }; }
            }
        },

        // ── Backlog ──
        {
            id: 'quick_win_hunter',
            name: 'Quick Win Hunter',
            emoji: '⚡',
            category: 'Backlog',
            description: 'Neutralize 3 quick-win backlogs (2/3 tasks done)',
            calculate() {
                try {
                    const masterData = SafeStorage.getItem('smartPadhaiData', {}) || {};
                    let quickWins = 0;
                    for (const [chKey, chData] of Object.entries(masterData)) {
                        if (!chData || typeof chData !== 'object') continue;
                        const read   = !!(chData.read || chData.read === true || chData.read === 'true');
                        const notes  = !!(chData.notes || chData.notes === true || chData.notes === 'true');
                        const pyq    = !!(chData.pyq || chData.pyq === true || chData.pyq === 'true');
                        const tasksDone = (read ? 1 : 0) + (notes ? 1 : 0) + (pyq ? 1 : 0);
                        const started = tasksDone > 0;
                        const completed = read && notes && pyq;
                        // Quick win: started, not fully completed, but 2/3 done
                        if (started && !completed && tasksDone >= 2) quickWins++;
                    }
                    return {
                        unlocked: quickWins >= 3,
                        current: Math.min(quickWins, 3),
                        target: 3,
                        reason: quickWins >= 3 ? `${quickWins} quick wins neutralized` : `${quickWins}/3 quick wins found`
                    };
                } catch { return { unlocked: false, current: 0, target: 3, reason: '0/3 quick wins found' }; }
            }
        },
        {
            id: 'backlog_slayer',
            name: 'Backlog Slayer',
            emoji: '🗡️',
            category: 'Backlog',
            description: 'Complete 5 backlog missions (chapters fully done)',
            calculate() {
                try {
                    const masterData = SafeStorage.getItem('smartPadhaiData', {}) || {};
                    let completed = 0;
                    let started = 0;
                    for (const [chKey, chData] of Object.entries(masterData)) {
                        if (!chData || typeof chData !== 'object') continue;
                        const read   = !!(chData.read || chData.read === true || chData.read === 'true');
                        const notes  = !!(chData.notes || chData.notes === true || chData.notes === 'true');
                        const pyq    = !!(chData.pyq || chData.pyq === true || chData.pyq === 'true');
                        if (read || notes || pyq) started++;
                        if (read && notes && pyq) completed++;
                    }
                    return {
                        unlocked: completed >= 5,
                        current: Math.min(completed, 5),
                        target: 5,
                        reason: completed >= 5 ? `${completed} backlogs cleared` : `${completed}/5 backlogs cleared`
                    };
                } catch { return { unlocked: false, current: 0, target: 5, reason: '0/5 backlogs cleared' }; }
            }
        },

        // ── Notebook ──
        {
            id: 'notebook_guardian',
            name: 'Notebook Guardian',
            emoji: '📓',
            category: 'Notebook',
            description: 'Mark 5 notebook subjects as complete',
            calculate() {
                try {
                    const nbData = SafeStorage.getItem('notebook_matrix_data', []) || [];
                    const subjects = Array.isArray(nbData) ? nbData : [];
                    // notebook_matrix_data is an array of subject objects
                    // Each may have a status/completed field
                    let completed = 0;
                    for (const subj of subjects) {
                        if (subj && (subj.completed || subj.status === 'complete' || subj.status === 'completed')) {
                            completed++;
                        }
                    }
                    return {
                        unlocked: completed >= 5,
                        current: Math.min(completed, 5),
                        target: 5,
                        reason: completed >= 5 ? `${completed} notebook subjects complete` : `${completed}/5 notebook subjects`
                    };
                } catch { return { unlocked: false, current: 0, target: 5, reason: '0/5 notebook subjects' }; }
            }
        },

        // ── PP / Rank ──
        {
            id: 'pp_grinder',
            name: 'PP Grinder',
            emoji: '💎',
            category: 'PP / Rank',
            description: 'Earn 100 PP total',
            calculate() {
                try {
                    const pulseData = SafeStorage.getItem('pulse_engine_data', {}) || {};
                    const totalPP = Number(pulseData.totalPP || 0);
                    return {
                        unlocked: totalPP >= 100,
                        current: Math.min(totalPP, 100),
                        target: 100,
                        reason: totalPP >= 100 ? `${totalPP} PP earned` : `${totalPP}/100 PP`
                    };
                } catch { return { unlocked: false, current: 0, target: 100, reason: '0/100 PP' }; }
            }
        }
    ];

    // ════════════════════════════════════════════════════════
    //  ACHIEVEMENT BADGES 2.0 — Calculation Engine
    // ════════════════════════════════════════════════════════

    /**
     * Computes all badge states from existing SafeStorage data.
     * Returns Map<badgeId, { unlocked, current, target, reason }>
     * Also detects newly unlocked badges vs. previously known.
     */
    function _calculateAllBadges() {
        const results = {};
        for (const badge of BADGE_CATALOG) {
            try {
                results[badge.id] = badge.calculate();
            } catch (err) {
                console.warn(`[VaultRoute] Badge calc error for ${badge.id}:`, err);
                results[badge.id] = { unlocked: false, current: 0, target: 1, reason: 'Data unavailable' };
            }
        }
        return results;
    }

    /**
     * Returns the set of badge IDs that were unlocked in a previous session.
     * Uses badge_progress_v2 local key. Does NOT write to Supabase.
     */
    function _getPreviouslyUnlocked() {
        try {
            const saved = SafeStorage.getItem('badge_progress_v2', null);
            if (saved && typeof saved === 'object' && Array.isArray(saved.unlocked)) {
                return new Set(saved.unlocked);
            }
        } catch { /* defensive */ }
        return new Set();
    }

    /**
     * Persists the set of unlocked badge IDs locally.
     * No Supabase write. Local-only key: badge_progress_v2
     */
    function _saveUnlockedBadgeIds(unlockedIds) {
        try {
            SafeStorage.setItem('badge_progress_v2', {
                unlocked: Array.from(unlockedIds),
                updatedAt: new Date().toISOString()
            });
        } catch (err) {
            console.warn('[VaultRoute] Failed to save badge_progress_v2:', err);
        }
    }

    /**
     * Detects newly unlocked badges and shows toast for each.
     * Called once during init after calculation.
     */
    function _checkForNewUnlocks(badgeResults) {
        const previouslyUnlocked = _getPreviouslyUnlocked();
        const currentlyUnlocked = new Set();

        for (const [id, result] of Object.entries(badgeResults)) {
            if (result.unlocked) currentlyUnlocked.add(id);
        }

        // Find newly unlocked (in current but not in previous)
        const newlyUnlocked = [];
        for (const id of currentlyUnlocked) {
            if (!previouslyUnlocked.has(id)) newlyUnlocked.push(id);
        }

        // Save updated set
        _saveUnlockedBadgeIds(currentlyUnlocked);

        // Show unlock toast for each new badge (staggered)
        newlyUnlocked.forEach((id, idx) => {
            const badge = BADGE_CATALOG.find(b => b.id === id);
            if (badge) {
                setTimeout(() => {
                    _showBadgeUnlockToast(badge);
                }, 400 * (idx + 1));
            }
        });
    }

    // ════════════════════════════════════════════════════════
    //  ACHIEVEMENT BADGES 2.0 — Badge Gallery Rendering
    // ════════════════════════════════════════════════════════

    function _renderBadgeGallery() {
        const gallery = _container?.querySelector('#badgeGalleryGrid');
        if (!gallery) return;

        const badgeResults = _calculateAllBadges();

        // Check for newly unlocked badges (toast notification)
        _checkForNewUnlocks(badgeResults);

        // Group badges by category
        const categories = ['Consistency', 'Time Table', 'Syllabus', 'Backlog', 'Notebook', 'PP / Rank'];
        const categoryEmojis = {
            'Consistency': '🔄',
            'Time Table': '⏰',
            'Syllabus': '📚',
            'Backlog': '🗡️',
            'Notebook': '📓',
            'PP / Rank': '💎'
        };

        let html = '';

        // Summary stats
        const totalBadges = BADGE_CATALOG.length;
        const unlockedCount = Object.values(badgeResults).filter(r => r.unlocked).length;
        const inProgressCount = Object.values(badgeResults).filter(r => !r.unlocked && r.current > 0).length;

        html += `
        <div class="badge-summary">
            <div class="badge-summary-stat">
                <div class="badge-summary-value">${unlockedCount}/${totalBadges}</div>
                <div class="badge-summary-label">Unlocked</div>
            </div>
            <div class="badge-summary-stat">
                <div class="badge-summary-value">${inProgressCount}</div>
                <div class="badge-summary-label">In Progress</div>
            </div>
            <div class="badge-summary-stat">
                <div class="badge-summary-value">${totalBadges - unlockedCount - inProgressCount}</div>
                <div class="badge-summary-label">Locked</div>
            </div>
        </div>`;

        for (const category of categories) {
            const catBadges = BADGE_CATALOG.filter(b => b.category === category);
            if (catBadges.length === 0) continue;

            html += `
            <div class="badge-category">
                <div class="badge-category-header">
                    <span class="badge-category-emoji">${categoryEmojis[category] || '🏅'}</span>
                    <span class="badge-category-title">${category}</span>
                </div>
                <div class="badge-category-grid">`;

            for (const badge of catBadges) {
                const result = badgeResults[badge.id] || { unlocked: false, current: 0, target: 1, reason: '' };
                const stateClass = result.unlocked ? 'badge-card-unlocked' : (result.current > 0 ? 'badge-card-progress' : 'badge-card-locked');
                const progressPct = result.target > 0 ? Math.min(Math.round((result.current / result.target) * 100), 100) : 0;

                html += `
                <div class="badge-card ${stateClass}" data-action="badge-detail" data-badge-id="${badge.id}">
                    <div class="badge-card-icon">${badge.emoji}</div>
                    <div class="badge-card-info">
                        <div class="badge-card-name">${badge.name}</div>
                        <div class="badge-card-reason">${result.reason}</div>
                    </div>
                    ${result.unlocked ? '<div class="badge-card-check">✓</div>' : ''}
                    ${!result.unlocked && result.current > 0 ? `
                    <div class="badge-card-progress-ring">
                        <svg viewBox="0 0 36 36" class="badge-progress-svg">
                            <path class="badge-progress-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
                            <path class="badge-progress-fill" stroke-dasharray="${progressPct}, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
                        </svg>
                        <span class="badge-progress-text">${progressPct}%</span>
                    </div>` : ''}
                    ${!result.unlocked && result.current === 0 ? '<div class="badge-card-lock">🔒</div>' : ''}
                </div>`;
            }

            html += `
                </div>
            </div>`;
        }

        gallery.innerHTML = html;
    }

    /**
     * Shows a special unlock toast when a badge is newly unlocked.
     */
    function _showBadgeUnlockToast(badge) {
        // Create a dedicated unlock toast element
        const toast = document.createElement('div');
        toast.className = 'badge-unlock-toast';
        toast.innerHTML = `
            <div class="badge-unlock-icon">${badge.emoji}</div>
            <div class="badge-unlock-text">
                <div class="badge-unlock-title">BADGE UNLOCKED!</div>
                <div class="badge-unlock-name">${badge.name}</div>
            </div>`;
        document.body.appendChild(toast);

        // Trigger animation
        requestAnimationFrame(() => {
            toast.classList.add('badge-unlock-toast-visible');
        });

        if (_badgeUnlockTimeout) clearTimeout(_badgeUnlockTimeout);
        _badgeUnlockTimeout = setTimeout(() => {
            toast.classList.remove('badge-unlock-toast-visible');
            setTimeout(() => toast.remove(), 400);
        }, 3200);
    }

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE: INIT
    // ════════════════════════════════════════════════════════

    async function init(container) {
        // Abort any previous instance's listeners
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();

        _container = container;
        _currentMood = 'Normal';

        // 1. Load vault CSS dynamically
        _loadCSS();

        // 2. Render full UI
        container.innerHTML = renderFullUI();

        // 3. Bind all events via delegation
        _bindEvents(container, _abortController.signal);

        // 4. Load data from Supabase (non-blocking merges)
        await _loadRemoteData();

        // 5. Render method cards into #methodGrid
        _renderMethodCards();

        // 6. Initialize journal UI
        _initJournalUI();

        // 7. Render Badge Gallery (Phase 9A Sprint 2)
        _renderBadgeGallery();

        // 8. Render Activity Intelligence Map (Phase 9A Sprint 4E — async for cloud data)
        await _renderActivityHeatmapAsync();

        console.log('[VaultRoute] Initialized (with Badge Gallery + Activity Intelligence Map — Sprint 4F Daily Performance)');
    }

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE: CLEANUP
    // ════════════════════════════════════════════════════════

    function cleanup() {
        // Abort all event listeners
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }

        // Clear toast timeout
        if (_toastTimeout) {
            clearTimeout(_toastTimeout);
            _toastTimeout = null;
        }

        // Clear badge unlock timeout
        if (_badgeUnlockTimeout) {
            clearTimeout(_badgeUnlockTimeout);
            _badgeUnlockTimeout = null;
        }

        // Remove any confirm overlays
        document.querySelectorAll('.journal-confirm-overlay').forEach(el => el.remove());

        // Remove any badge unlock toasts
        document.querySelectorAll('.badge-unlock-toast').forEach(el => el.remove());

        // Remove heatmap tooltip
        _removeHeatmapTooltip();

        // Clear heatmap intelligence state
        _heatmapDayData = null;
        _selectedHeatmapDate = null;
        _cloudTimeBlocks = null;
        _cloudLoadAttempted = false;

        // Remove dynamically loaded CSS
        _unloadCSS();

        // Reset state
        _container = null;
        _currentMood = 'Normal';

        console.log('[VaultRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        // Prevent duplicate
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;

        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.vaultCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-vault-css]');
        if (el) {
            el.remove();
            _cssLinkEl = null;
        }
    }

    // ════════════════════════════════════════════════════════
    //  HTML RENDERING
    // ════════════════════════════════════════════════════════

    function renderFullUI() {
        return `
        <div class="vault-container">
            <div class="vault-header">
                <h1>STUDY VAULT</h1>
                <p>TACTICAL STUDY TECHNIQUES FOR ELITE PERFORMANCE</p>
            </div>

            <!-- Tab Navigation -->
            <div class="vault-tabs">
                <div class="vault-tab active" data-action="switch-tab" data-tab="methods">🧠 Study Methods</div>
                <div class="vault-tab" data-action="switch-tab" data-tab="journal">📔 Operator Journal</div>
                <div class="vault-tab" data-action="switch-tab" data-tab="badges">🏅 Badges</div>
                <div class="vault-tab" data-action="switch-tab" data-tab="activity">🔥 Activity</div>
            </div>

            <!-- ═══ TAB 1: STUDY METHODS ═══ -->
            <div class="vault-tab-content active" id="tab-methods">
                <div class="tech-grid" id="methodGrid"></div>

                <div class="pro-feature-box">
                    <h2>☣️ THE DISTRACTION CALCULATOR</h2>
                    <p>Dekho tumhara phone tumhara kitna career kha raha hai.</p>

                    <div style="margin: 30px 0;">
                        Roz kitne ghante Screen Time (Distraction)?
                        <input type="number" id="screenHours" class="calc-input" placeholder="0"> Hrs
                    </div>

                    <button class="calc-btn" data-action="calc-waste">CALCULATE DAMAGE</button>

                    <div id="calcResult"></div>
                </div>
            </div>

            <!-- ═══ TAB 2: OPERATOR JOURNAL ═══ -->
            <div class="vault-tab-content" id="tab-journal">

                <!-- Today's Journal Entry -->
                <div class="journal-today-card" id="journalTodayCard">
                    <div class="journal-today-header">
                        <div class="journal-today-date" id="journalTodayDate"></div>
                        <div class="journal-today-label" id="journalTodayLabel">NEW ENTRY</div>
                    </div>

                    <div class="journal-form" id="journalForm">
                        <!-- Mood -->
                        <div class="journal-field full-width">
                            <label>Mood</label>
                            <div class="mood-selector" id="moodSelector">
                                <button class="mood-btn" data-mood="Focused" data-action="select-mood" type="button">🎯 Focused</button>
                                <button class="mood-btn" data-mood="Confident" data-action="select-mood" type="button">💪 Confident</button>
                                <button class="mood-btn" data-mood="Normal" data-action="select-mood" type="button">😐 Normal</button>
                                <button class="mood-btn" data-mood="Tired" data-action="select-mood" type="button">😴 Tired</button>
                                <button class="mood-btn" data-mood="Stressed" data-action="select-mood" type="button">😰 Stressed</button>
                            </div>
                        </div>

                        <!-- Focus Rating -->
                        <div class="journal-field full-width">
                            <label>Focus Rating</label>
                            <div class="journal-rating-row">
                                <input type="range" min="1" max="10" value="5" class="journal-rating-slider" id="focusRatingSlider">
                                <div class="journal-rating-value" id="focusRatingValue">5</div>
                            </div>
                        </div>

                        <!-- What I Studied -->
                        <div class="journal-field">
                            <label>What I Studied</label>
                            <textarea id="journalWhatStudied" placeholder="Maths Ch 5, Physics derivations..." rows="2"></textarea>
                        </div>

                        <!-- Biggest Distraction -->
                        <div class="journal-field">
                            <label>Biggest Distraction</label>
                            <input type="text" id="journalDistraction" placeholder="Instagram, YouTube, noise...">
                        </div>

                        <!-- Today's Win -->
                        <div class="journal-field">
                            <label>Today's Win</label>
                            <textarea id="journalWin" placeholder="Finished 3 chapters! Cleared 2 backlogs..." rows="2"></textarea>
                        </div>

                        <!-- Tomorrow's Target -->
                        <div class="journal-field">
                            <label>Tomorrow's Target</label>
                            <textarea id="journalTarget" placeholder="Revise Ch 6, complete homework..." rows="2"></textarea>
                        </div>

                        <!-- Notes -->
                        <div class="journal-field full-width">
                            <label>Notes</label>
                            <textarea id="journalNotes" placeholder="Anything on your mind..." rows="3"></textarea>
                        </div>
                    </div>

                    <div class="journal-actions">
                        <button class="journal-btn journal-btn-delete" id="journalDeleteBtn" data-action="delete-today-journal" style="display:none;">🗑️ Delete</button>
                        <button class="journal-btn journal-btn-save" data-action="save-today-journal">💾 SAVE ENTRY</button>
                    </div>
                </div>

                <!-- Past Entries -->
                <div class="journal-section">
                    <div class="journal-past-header">
                        <div class="journal-past-title">PAST ENTRIES</div>
                        <div class="journal-past-count" id="journalEntryCount"></div>
                    </div>
                    <div id="journalPastEntries"></div>
                </div>

                <!-- AESTRA Locked Card -->
                <div class="aestra-locked-card">
                    <div class="aestra-locked-icon">🔒</div>
                    <div class="aestra-locked-title">AESTRA Journal Analysis</div>
                    <div class="aestra-locked-desc">AI-powered journal insights — mood patterns, focus trends, distraction analysis, and personalized study recommendations from your journal data.</div>
                    <div class="aestra-locked-badge">COMING SOON — PREMIUM FEATURE</div>
                </div>

            </div>

            <!-- ═══ TAB 3: ACHIEVEMENT BADGES 2.0 ═══ -->
            <div class="vault-tab-content" id="tab-badges">
                <div class="badge-gallery">
                    <div class="badge-gallery-header">
                        <h2>ACHIEVEMENT BADGES</h2>
                        <p>Unlock badges by completing study milestones</p>
                    </div>
                    <div id="badgeGalleryGrid"></div>
                </div>
            </div>

            <!-- ═══ TAB 4: ACTIVITY INTELLIGENCE MAP ═══ -->
            <div class="vault-tab-content" id="tab-activity">
                <div class="heatmap-section">
                    <div class="heatmap-header">
                        <h2>ACTIVITY INTELLIGENCE MAP</h2>
                        <p>Your study performance decoded — day by day</p>
                    </div>
                    <div id="heatmapStats"></div>
                    <div class="heatmap-grid-wrapper">
                        <div class="heatmap-month-labels" id="heatmapMonthLabels"></div>
                        <div class="heatmap-grid-container">
                            <div class="heatmap-day-labels">
                                <span>Mon</span><span>Wed</span><span>Fri</span>
                            </div>
                            <div class="heatmap-grid" id="heatmapGrid"></div>
                        </div>
                    </div>
                    <div class="heatmap-legend">
                        <span class="heatmap-legend-label">Slipped</span>
                        <span class="heatmap-cell heatmap-level-1"></span>
                        <span class="heatmap-legend-sep"></span>
                        <span class="heatmap-cell heatmap-level-2"></span>
                        <span class="heatmap-legend-label">Low</span>
                        <span class="heatmap-legend-sep"></span>
                        <span class="heatmap-cell heatmap-level-3"></span>
                        <span class="heatmap-legend-label">Stable</span>
                        <span class="heatmap-legend-sep"></span>
                        <span class="heatmap-cell heatmap-level-4"></span>
                        <span class="heatmap-legend-label">Focused</span>
                        <span class="heatmap-legend-sep"></span>
                        <span class="heatmap-cell heatmap-level-5"></span>
                        <span class="heatmap-legend-label">Peak</span>
                    </div>
                    <!-- Day Detail Panel (populated on cell click) -->
                    <div id="heatmapDayDetail" class="heatmap-day-detail"></div>
                    <!-- Week Insight Summary -->
                    <div id="heatmapInsights" class="heatmap-insights"></div>
                </div>
            </div>
        </div>

        <!-- Toast notification element -->
        <div class="vault-toast" id="vaultToast"></div>`;
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING — Delegation + AbortController
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {

        // ── Main click delegation ──
        container.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;

            switch (action) {
                // Tab switching
                case 'switch-tab':
                    _switchVaultTab(target.dataset.tab);
                    break;

                // Mood selection
                case 'select-mood':
                    _selectMood(target.dataset.mood);
                    break;

                // Journal actions
                case 'save-today-journal':
                    _saveTodayJournal();
                    break;
                case 'delete-today-journal':
                    _deleteTodayJournal();
                    break;

                // Method card expand/collapse
                case 'toggle-method':
                    _toggleMethodCard(target.dataset.methodId);
                    break;

                // Activate badge
                case 'activate-badge':
                    e.stopPropagation();
                    _activateMethodBadge(target.dataset.methodId);
                    break;

                // Add to mission
                case 'add-mission':
                    e.stopPropagation();
                    _addMethodToMission(target.dataset.methodId);
                    break;

                // Distraction calculator
                case 'calc-waste':
                    _calculateWaste();
                    break;

                // Past entry — view
                case 'view-entry':
                    e.stopPropagation();
                    _loadPastEntryIntoForm(target.dataset.date);
                    break;

                // Past entry — delete
                case 'delete-entry':
                    e.stopPropagation();
                    _deletePastEntry(target.dataset.date);
                    break;

                // Badge detail (Phase 9A Sprint 2)
                case 'badge-detail':
                    _showBadgeDetail(target.dataset.badgeId);
                    break;

                // Heatmap cell click (Phase 9A Sprint 4C — Intelligence Map)
                case 'heatmap-cell':
                    _selectHeatmapDay(target.dataset.heatmapDate);
                    break;
            }
        }, { signal });

        // ── Focus rating slider (input event, not click) ──
        const slider = container.querySelector('#focusRatingSlider');
        if (slider) {
            slider.addEventListener('input', () => {
                _updateRatingDisplay();
            }, { signal });
        }
    }

    // ════════════════════════════════════════════════════════
    //  REMOTE DATA LOADING
    // ════════════════════════════════════════════════════════

    async function _loadRemoteData() {
        // Load method usage from Supabase (best-effort)
        if (typeof MethodUsageTracker !== 'undefined') {
            try { await MethodUsageTracker.loadFromSupabase(); }
            catch (err) { console.warn('[VaultRoute] MethodUsageTracker load failed:', err); }
        }

        // Load journal entries from Supabase (best-effort)
        if (typeof JournalEngine !== 'undefined') {
            try { await JournalEngine.loadFromSupabase(); }
            catch (err) { console.warn('[VaultRoute] JournalEngine load failed:', err); }
        }
    }

    // ════════════════════════════════════════════════════════
    //  TAB SYSTEM
    // ════════════════════════════════════════════════════════

    function _switchVaultTab(tabName) {
        if (!_container) return;

        // Update tab buttons
        _container.querySelectorAll('.vault-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === tabName);
        });

        // Update tab content
        _container.querySelectorAll('.vault-tab-content').forEach(content => {
            content.classList.remove('active');
        });

        const targetContent = _container.querySelector(`#tab-${tabName}`);
        if (targetContent) {
            targetContent.classList.add('active');
        }

        // Re-render journal if switching to it
        if (tabName === 'journal') {
            _renderPastEntries();
        }

        // Re-calculate badges if switching to badges tab (data may have changed)
        if (tabName === 'badges') {
            _renderBadgeGallery();
        }

        // Re-render heatmap if switching to activity tab (data may have changed)
        // Sprint 4E: Use async wrapper to ensure cloud data is loaded
        if (tabName === 'activity') {
            _renderActivityHeatmapAsync();
        }
    }

    // ════════════════════════════════════════════════════════
    //  JOURNAL UI
    // ════════════════════════════════════════════════════════

    function _initJournalUI() {
        if (typeof JournalEngine === 'undefined') {
            console.error('[VaultRoute] JournalEngine not loaded');
            return;
        }

        const todayStr = JournalEngine.getTodayStr();

        // Format date for display
        const dateObj = new Date(todayStr + 'T00:00:00');
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const dateDisplay = dateObj.toLocaleDateString('en-IN', options);

        const dateEl = _container.querySelector('#journalTodayDate');
        if (dateEl) dateEl.textContent = dateDisplay;

        // Load existing entry for today if it exists
        const existing = JournalEngine.getEntryByDate(todayStr);
        if (existing) {
            _loadEntryIntoForm(existing);
            const labelEl = _container.querySelector('#journalTodayLabel');
            if (labelEl) labelEl.textContent = 'EDITING';
            const delBtn = _container.querySelector('#journalDeleteBtn');
            if (delBtn) delBtn.style.display = 'inline-flex';
        } else {
            _resetJournalForm();
            const labelEl = _container.querySelector('#journalTodayLabel');
            if (labelEl) labelEl.textContent = 'NEW ENTRY';
            const delBtn = _container.querySelector('#journalDeleteBtn');
            if (delBtn) delBtn.style.display = 'none';
        }

        // Render past entries
        _renderPastEntries();
    }

    function _selectMood(mood) {
        _currentMood = mood;
        if (!_container) return;
        _container.querySelectorAll('.mood-btn').forEach(btn => {
            btn.classList.toggle('selected', btn.dataset.mood === mood);
        });
    }

    function _updateRatingDisplay() {
        if (!_container) return;
        const slider = _container.querySelector('#focusRatingSlider');
        const valueEl = _container.querySelector('#focusRatingValue');
        if (slider && valueEl) {
            valueEl.textContent = slider.value;
        }
    }

    function _loadEntryIntoForm(entry) {
        _currentMood = entry.mood || 'Normal';
        _selectMood(_currentMood);

        const slider = _container.querySelector('#focusRatingSlider');
        if (slider) slider.value = entry.focus_rating || 5;
        _updateRatingDisplay();

        const fields = {
            'journalWhatStudied': entry.what_i_studied || '',
            'journalDistraction': entry.biggest_distraction || '',
            'journalWin': entry.today_win || '',
            'journalTarget': entry.tomorrow_target || '',
            'journalNotes': entry.notes || ''
        };

        for (const [id, val] of Object.entries(fields)) {
            const el = _container.querySelector(`#${id}`);
            if (el) el.value = val;
        }
    }

    function _resetJournalForm() {
        _currentMood = 'Normal';
        _selectMood('Normal');

        const slider = _container.querySelector('#focusRatingSlider');
        if (slider) slider.value = 5;
        _updateRatingDisplay();

        ['journalWhatStudied', 'journalDistraction', 'journalWin', 'journalTarget', 'journalNotes'].forEach(id => {
            const el = _container.querySelector(`#${id}`);
            if (el) el.value = '';
        });
    }

    async function _saveTodayJournal() {
        if (typeof JournalEngine === 'undefined') return;

        const slider = _container.querySelector('#focusRatingSlider');

        const entryData = {
            mood: _currentMood,
            focus_rating: slider ? parseInt(slider.value) || 5 : 5,
            what_i_studied: (_container.querySelector('#journalWhatStudied')?.value || '').trim(),
            biggest_distraction: (_container.querySelector('#journalDistraction')?.value || '').trim(),
            today_win: (_container.querySelector('#journalWin')?.value || '').trim(),
            tomorrow_target: (_container.querySelector('#journalTarget')?.value || '').trim(),
            notes: (_container.querySelector('#journalNotes')?.value || '').trim()
        };

        await JournalEngine.saveEntry(entryData);

        const labelEl = _container.querySelector('#journalTodayLabel');
        if (labelEl) labelEl.textContent = 'EDITING';

        const delBtn = _container.querySelector('#journalDeleteBtn');
        if (delBtn) delBtn.style.display = 'inline-flex';

        _showToast('Journal entry saved! 📔');
        _renderPastEntries();
    }

    function _deleteTodayJournal() {
        _showConfirmDialog(
            'Delete today\'s journal entry? This cannot be undone.',
            async () => {
                const todayStr = JournalEngine.getTodayStr();
                await JournalEngine.deleteEntry(todayStr);
                _resetJournalForm();

                const labelEl = _container.querySelector('#journalTodayLabel');
                if (labelEl) labelEl.textContent = 'NEW ENTRY';

                const delBtn = _container.querySelector('#journalDeleteBtn');
                if (delBtn) delBtn.style.display = 'none';

                _showToast('Journal entry deleted.');
                _renderPastEntries();
            }
        );
    }

    function _deletePastEntry(dateStr) {
        _showConfirmDialog(
            `Delete journal entry for ${dateStr}? This cannot be undone.`,
            async () => {
                await JournalEngine.deleteEntry(dateStr);
                _showToast('Entry deleted.');
                _initJournalUI();
            }
        );
    }

    function _loadPastEntryIntoForm(dateStr) {
        const entry = JournalEngine.getEntryByDate(dateStr);
        if (!entry) return;

        // Switch to journal tab
        _switchVaultTab('journal');

        // If it's today's entry, load it into the form
        if (dateStr === JournalEngine.getTodayStr()) {
            _loadEntryIntoForm(entry);
            const labelEl = _container.querySelector('#journalTodayLabel');
            if (labelEl) labelEl.textContent = 'EDITING';
            const delBtn = _container.querySelector('#journalDeleteBtn');
            if (delBtn) delBtn.style.display = 'inline-flex';
        } else {
            _showToast('Viewing entry for ' + dateStr);
        }
    }

    function _renderPastEntries() {
        const container = _container?.querySelector('#journalPastEntries');
        const countEl = _container?.querySelector('#journalEntryCount');
        if (!container) return;

        const all = JournalEngine.getAllEntries();
        const todayStr = JournalEngine.getTodayStr();

        // Filter out today's entry (shown in the form above)
        const pastEntries = all.filter(e => e.entry_date !== todayStr);

        if (countEl) {
            countEl.textContent = `${all.length} total entr${all.length === 1 ? 'y' : 'ies'}`;
        }

        if (pastEntries.length === 0) {
            container.innerHTML = `
                <div class="journal-empty sp-empty-state">
                    <div class="journal-empty-icon sp-empty-state-icon">📔</div>
                    <h3 class="sp-empty-state-title">No Journal Entries</h3>
                    <div class="journal-empty-text sp-empty-state-text">Write your first journal entry today to start tracking your study journey.</div>
                </div>`;
            return;
        }

        container.innerHTML = pastEntries.map(entry => {
            const dateObj = new Date(entry.entry_date + 'T00:00:00');
            const dayName = dateObj.toLocaleDateString('en-IN', { weekday: 'short' });
            const dateDisplay = dateObj.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

            const preview = entry.what_i_studied || entry.today_win || entry.notes || 'No content';
            const truncated = preview.length > 80 ? preview.substring(0, 80) + '...' : preview;

            return `
            <div class="journal-entry-card" data-action="view-entry" data-date="${entry.entry_date}">
                <div class="journal-entry-top">
                    <div class="journal-entry-date">${dayName}, ${dateDisplay}</div>
                    <div class="journal-entry-mood mood-${entry.mood || 'Normal'}">${entry.mood || 'Normal'}</div>
                </div>
                <div class="journal-entry-stats">
                    <div class="journal-entry-stat">Focus: <span>${entry.focus_rating || 5}/10</span></div>
                    ${entry.biggest_distraction ? `<div class="journal-entry-stat">Distraction: <span>${entry.biggest_distraction}</span></div>` : ''}
                </div>
                <div class="journal-entry-preview">${truncated}</div>
                <div class="journal-entry-actions">
                    <button class="journal-entry-btn" data-action="view-entry" data-date="${entry.entry_date}">View</button>
                    <button class="journal-entry-btn delete-btn" data-action="delete-entry" data-date="${entry.entry_date}">Delete</button>
                </div>
            </div>`;
        }).join('');
    }

    // ── Confirm dialog (replaces confirm() for better UX) ──
    function _showConfirmDialog(message, onConfirm) {
        const overlay = document.createElement('div');
        overlay.className = 'journal-confirm-overlay';
        overlay.innerHTML = `
            <div class="journal-confirm-box">
                <div class="journal-confirm-text">${message}</div>
                <div class="journal-confirm-btns">
                    <button class="journal-confirm-no" data-action="confirm-cancel">Cancel</button>
                    <button class="journal-confirm-yes" data-action="confirm-yes">Delete</button>
                </div>
            </div>`;

        document.body.appendChild(overlay);

        // Bind confirm buttons
        overlay.querySelector('[data-action="confirm-yes"]').addEventListener('click', () => {
            overlay.remove();
            onConfirm();
        });

        overlay.querySelector('[data-action="confirm-cancel"]').addEventListener('click', () => {
            overlay.remove();
        });

        // Close on backdrop click
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) overlay.remove();
        });
    }

    // ════════════════════════════════════════════════════════
    //  STUDY METHODS
    // ════════════════════════════════════════════════════════

    function _renderMethodCards() {
        const grid = _container?.querySelector('#methodGrid');
        if (!grid) return;

        if (typeof METHOD_DETAILS === 'undefined') {
            console.error('[VaultRoute] METHOD_DETAILS not loaded');
            grid.innerHTML = '<p style="color:#ff4c4c;">Error: Method data could not be loaded.</p>';
            return;
        }

        const activeBadges = SafeStorage.getItem('activeBadges', []);

        grid.innerHTML = METHOD_DETAILS.map(method => {
            const isActivated = activeBadges.some(b => b.name === method.badge);
            const usage = (typeof MethodUsageTracker !== 'undefined')
                ? MethodUsageTracker.getUsage(method.id)
                : { timesActivated: 0, totalMinutes: 0, effectivenessRating: 0 };

            return `
            <div class="method-card" id="method-${method.id}">
                <div class="method-card-header" data-action="toggle-method" data-method-id="${method.id}">
                    <div class="method-card-title">
                        <span class="method-card-emoji">${method.emoji}</span>
                        <div>
                            <div class="method-card-name">${method.name}</div>
                            <div class="method-card-badge">${method.badge}</div>
                        </div>
                    </div>
                    <span class="method-expand-arrow">▼</span>
                </div>
                <div class="method-card-short">${method.shortDesc}</div>
                <div class="method-card-details">
                    <!-- What It Is -->
                    <div class="method-section">
                        <div class="method-section-title">What It Is</div>
                        <p>${method.whatItIs}</p>
                    </div>

                    <!-- When To Use -->
                    <div class="method-section">
                        <div class="method-section-title">When To Use</div>
                        <ul class="method-list">
                            ${method.whenToUse.map(item => `<li>${item}</li>`).join('')}
                        </ul>
                    </div>

                    <!-- Best Subjects -->
                    <div class="method-section">
                        <div class="method-section-title">Best Subjects</div>
                        <div class="method-subject-tags">
                            ${method.bestSubjects.map(s => `<span class="method-subject-tag">${s}</span>`).join('')}
                        </div>
                    </div>

                    <!-- Step-by-Step -->
                    <div class="method-section">
                        <div class="method-section-title">Step-by-Step Implementation</div>
                        <ol class="method-steps-list">
                            ${method.steps.map(step => `<li>${step}</li>`).join('')}
                        </ol>
                    </div>

                    <!-- Common Mistakes -->
                    <div class="method-section">
                        <div class="method-section-title">Common Mistakes</div>
                        <ul class="method-list mistake-list">
                            ${method.commonMistakes.map(m => `<li>${m}</li>`).join('')}
                        </ul>
                    </div>

                    <!-- Usage Stats -->
                    <div class="method-usage-stats">
                        <div class="method-stat">
                            <div class="method-stat-value">${usage.timesActivated || 0}</div>
                            <div class="method-stat-label">Activated</div>
                        </div>
                        <div class="method-stat">
                            <div class="method-stat-value">${usage.totalMinutes || 0}</div>
                            <div class="method-stat-label">Minutes</div>
                        </div>
                        <div class="method-stat">
                            <div class="method-stat-value">${usage.effectivenessRating || 0}/10</div>
                            <div class="method-stat-label">Rating</div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="method-actions">
                        <button class="method-btn method-btn-activate ${isActivated ? 'activated' : ''}"
                            id="activate-btn-${method.id}"
                            data-action="activate-badge"
                            data-method-id="${method.id}">
                            ${isActivated ? '✓ ACTIVATED' : '🛡️ Activate Badge'}
                        </button>
                        <button class="method-btn method-btn-mission"
                            id="mission-btn-${method.id}"
                            data-action="add-mission"
                            data-method-id="${method.id}">
                            ⚡ Add to Mission
                        </button>
                    </div>
                </div>
            </div>`;
        }).join('');
    }

    function _toggleMethodCard(methodId) {
        if (!_container) return;
        const card = _container.querySelector(`#method-${methodId}`);
        if (!card) return;

        // Collapse other expanded cards
        _container.querySelectorAll('.method-card.expanded').forEach(c => {
            if (c.id !== `method-${methodId}`) {
                c.classList.remove('expanded');
            }
        });

        card.classList.toggle('expanded');
    }

    function _activateMethodBadge(methodId) {
        const methodDetail = METHOD_DETAILS.find(m => m.id === methodId);
        if (!methodDetail) return;

        let activeBadges = SafeStorage.getItem('activeBadges', []);

        if (activeBadges.some(b => b.name === methodDetail.badge)) {
            _showToast(`${methodDetail.badge} already active!`);
            return;
        }

        activeBadges.push({ name: methodDetail.badge, emoji: methodDetail.emoji });
        SafeStorage.setItem('activeBadges', activeBadges);

        // Record activation in MethodUsageTracker
        if (typeof MethodUsageTracker !== 'undefined') {
            MethodUsageTracker.recordActivation(methodId);
        }

        // Update button UI
        const btn = _container?.querySelector(`#activate-btn-${methodId}`);
        if (btn) {
            btn.innerHTML = '✓ ACTIVATED';
            btn.classList.add('activated');
        }

        _showToast(`${methodDetail.badge} Badge Activated! Check Dashboard. 🛡️`);
    }

    function _addMethodToMission(methodId) {
        if (typeof MethodMission === 'undefined') {
            console.error('[VaultRoute] MethodMission not loaded');
            _showToast('Error: Could not add mission.');
            return;
        }

        const slot = MethodMission.addMethodToMission(methodId);
        if (slot) {
            const methodDetail = METHOD_DETAILS.find(m => m.id === methodId);
            const slotLabel = slot.charAt(0).toUpperCase() + slot.slice(1);
            _showToast(`${methodDetail.emoji} ${methodDetail.name} added to ${slotLabel} Mission!`);

            const btn = _container?.querySelector(`#mission-btn-${methodId}`);
            if (btn) {
                const originalHTML = btn.innerHTML;
                btn.innerHTML = '✓ ADDED!';
                btn.classList.add('added');
                setTimeout(() => {
                    if (btn && _container) {
                        btn.innerHTML = originalHTML;
                        btn.classList.remove('added');
                    }
                }, 1500);
            }
        } else {
            _showToast('Failed to add mission. Check console.');
        }
    }

    // ════════════════════════════════════════════════════════
    //  BADGE DETAIL POPUP (Phase 9A Sprint 2)
    // ════════════════════════════════════════════════════════

    function _showBadgeDetail(badgeId) {
        const badge = BADGE_CATALOG.find(b => b.id === badgeId);
        if (!badge) return;

        const result = badge.calculate();
        const progressPct = result.target > 0 ? Math.min(Math.round((result.current / result.target) * 100), 100) : 0;
        const stateLabel = result.unlocked ? 'UNLOCKED' : (result.current > 0 ? 'IN PROGRESS' : 'LOCKED');

        // Create overlay
        const overlay = document.createElement('div');
        overlay.className = 'journal-confirm-overlay badge-detail-overlay';
        overlay.innerHTML = `
            <div class="badge-detail-card ${result.unlocked ? 'badge-detail-unlocked' : ''}">
                <div class="badge-detail-icon">${badge.emoji}</div>
                <div class="badge-detail-name">${badge.name}</div>
                <div class="badge-detail-category">${badge.category}</div>
                <div class="badge-detail-desc">${badge.description}</div>
                <div class="badge-detail-status ${result.unlocked ? 'status-unlocked' : (result.current > 0 ? 'status-progress' : 'status-locked')}">${stateLabel}</div>
                ${!result.unlocked ? `
                <div class="badge-detail-progress">
                    <div class="badge-detail-progress-bar">
                        <div class="badge-detail-progress-fill" style="width: ${progressPct}%"></div>
                    </div>
                    <div class="badge-detail-progress-text">${result.current}/${result.target}</div>
                </div>` : ''}
                <div class="badge-detail-reason">${result.reason}</div>
                <button class="badge-detail-close" data-action="badge-detail-close">Close</button>
            </div>`;

        document.body.appendChild(overlay);

        // Bind close
        overlay.querySelector('[data-action="badge-detail-close"]').addEventListener('click', () => {
            overlay.remove();
        });

        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) overlay.remove();
        });
    }

    // ════════════════════════════════════════════════════════
    //  ACTIVITY INTELLIGENCE MAP (Phase 9A Sprint 4D)
    // ════════════════════════════════════════════════════════

    /**
     * Day status labels — student-friendly performance indicators.
     * Uses score AND completion context for honest labeling.
     * Sprint 4D: Status now depends on score + ratio + missed blocks.
     *
     * Rules:
     *   PEAK DAY:   score >= 9, ratio >= 0.9, missed === 0, planned > 0
     *   LOCKED IN:  score >= 8, ratio >= 0.8, missed <= 1
     *   FOCUSED:    score >= 7, ratio >= 0.5 (or high effort with moderate ratio)
     *   STABLE:     ratio >= 0.5 and score >= 5
     *   LOW ENERGY: ratio < 0.5 and missed is low
     *   SLIPPED:    ratio < 0.5 and missed is high
     */
    function _getDayStatus(score, completionRatio, missedBlocks, plannedBlocks) {
        // Defensive defaults
        const ratio = (typeof completionRatio === 'number' && isFinite(completionRatio)) ? completionRatio : 0;
        const missed = (typeof missedBlocks === 'number') ? missedBlocks : 0;
        const planned = (typeof plannedBlocks === 'number') ? plannedBlocks : 0;

        if (score <= 0) return 'NO DATA';

        // ── Sprint 4F: Simplified honest status mapping ──
        // PEAK DAY: score 10, perfect execution
        if (score >= 9) {
            if (planned > 0 && ratio >= 0.9 && missed === 0) return 'PEAK DAY';
            if (ratio >= 0.8 && missed <= 1) return 'FOCUSED';
            return 'FOCUSED';
        }

        // FOCUSED: score 8-9, strong day
        if (score >= 8) return 'FOCUSED';

        // FOCUSED: score 7, good execution
        if (score >= 7) return 'FOCUSED';

        // STABLE: score 6, decent
        if (score >= 6) return 'STABLE';

        // LOW ENERGY: score 4-5
        if (score >= 4) return 'LOW ENERGY';

        // SLIPPED: score 1-3
        if (score >= 1) return 'SLIPPED';

        return 'NO DATA';
    }

    /**
     * Returns an emoji for the day status.
     */
    function _getDayStatusEmoji(status) {
        const map = {
            'NO DATA': '⚫',
            'SLIPPED': '🔻',
            'LOW ENERGY': '⚠️',
            'STABLE': '🟡',
            'FOCUSED': '🎯',
            'LOCKED IN': '🔥',
            'PEAK DAY': '👑'
        };
        return map[status] || '⚫';
    }

    /**
     * Returns a short insight line for the day based on status + full performance data.
     * Sprint 4F: Multi-source insights — acknowledges backlog, notebooks, syllabus too.
     */
    function _getDayInsight(status, score, entry) {
        const blocks = entry.blocks || 0;
        const minutes = entry.studyMinutes || entry.minutes || 0;
        const plannedBlocks = entry.plannedBlocks || 0;
        const missedBlocks = entry.missedBlocks || 0;
        const completionRatio = plannedBlocks > 0 ? blocks / plannedBlocks : 0;
        const highMinutes = minutes >= 240;
        const highMissed = missedBlocks >= 3;
        const backlogCleared = entry.backlogCleared || 0;
        const notebookCompleted = entry.notebookCompleted || 0;
        const syllabusProgress = entry.syllabusProgress || 0;
        const hasOtherProgress = backlogCleared > 0 || notebookCompleted > 0 || syllabusProgress > 0;

        switch (status) {
            case 'NO DATA':
                return 'No activity recorded. Start with one light mission today.';
            case 'SLIPPED':
                if (highMinutes && highMissed) return 'Strong study time, but execution slipped because many planned blocks were missed.';
                if (missedBlocks > 0) return `You missed ${missedBlocks} planned block${missedBlocks > 1 ? 's' : ''}. Tomorrow is a fresh start.`;
                return 'You slipped today. Even one block tomorrow rebuilds momentum.';
            case 'LOW ENERGY':
                if (hasOtherProgress) return `Low study time, but you made progress elsewhere: ${backlogCleared} backlog${backlogCleared !== 1 ? 's' : ''} cleared.`;
                if (blocks > 0) return `${blocks} block${blocks > 1 ? 's' : ''} done — low output but you showed up. That matters.`;
                return 'Low activity day. Restart with a light mission tomorrow.';
            case 'STABLE':
                if (highMissed) return `Decent progress, but ${missedBlocks} planned block${missedBlocks > 1 ? 's' : ''} were missed. Tighten execution.`;
                if (hasOtherProgress) return `Steady day with ${backlogCleared} backlog cleared and consistent study time.`;
                return `Steady day at ${score}/10. Consistency beats intensity over time.`;
            case 'FOCUSED':
                if (highMinutes && highMissed) return `Strong study time (${minutes} min), but ${missedBlocks} planned blocks were missed. Improve execution tomorrow.`;
                if (hasOtherProgress && missedBlocks === 0) return `High focus day: strong completion with low misses. Plus ${backlogCleared} backlog cleared.`;
                if (highMinutes) return `${minutes} minutes of deep focus. You are building real discipline.`;
                if (missedBlocks > 0) return `Good focus at ${score}/10, but ${missedBlocks} block${missedBlocks > 1 ? 's' : ''} slipped. Aim for full completion.`;
                return `Focused session at ${score}/10. You are in the zone.`;
            case 'LOCKED IN':
                if (missedBlocks === 1) return `Almost perfect at ${score}/10 — just 1 block slipped. Finish strong next time.`;
                return `Locked in at ${score}/10. Almost perfect — one more push for peak.`;
            case 'PEAK DAY':
                if (plannedBlocks > 0 && completionRatio >= 0.9 && missedBlocks === 0) return 'Excellent execution. You completed your plan.';
                return `Peak performance at ${score}/10. Elite discipline. Keep this energy.`;
            default:
                return '';
        }
    }

    /**
     * Calculates an honest day score from multi-source performance data.
     * Sprint 4F: Multi-source scoring — completion ratio, minutes, PP, backlog, notebook, syllabus.
     *
     * Formula:
     *   completionScore = completionRatio * 4        (max 4.0)
     *   minutesScore    = min(studyMinutes/180, 1)*2 (max 2.0)
     *   ppScore         = min(dailyPp/80, 1) * 1     (max 1.0, only if daily PP exists)
     *   backlogScore    = min(backlogCleared/3, 1)*1.5 (max 1.5)
     *   notebookScore   = min(notebookCompleted/2, 1)*0.8 (max 0.8)
     *   syllabusScore   = min(syllabusProgress/3, 1)*0.7 (max 0.7)
     *   missPenalty     = min(blocksMissed * 0.8, 3) (max 3.0)
     *
     *   rawScore = positives - missPenalty
     *   finalScore = clamp(0, 10, Math.round(rawScore * 10) / 10)
     *
     * Hard caps:
     *   missed >= planned * 0.3 → cap at 7
     *   missed >= 3             → cap at 7
     *   PEAK DAY requires completionRatio >= 0.9 AND missed === 0
     *
     * Returns float 0-10 rounded to 1 decimal. Returns 0 if no data.
     */
    function _calculateDayScore(entry) {
        const completedBlocks = entry.blocks || 0;
        const plannedBlocks   = entry.plannedBlocks || 0;
        const missedBlocks    = entry.missedBlocks || 0;
        const studyMinutes    = entry.studyMinutes || entry.minutes || 0;
        const dailyPp         = entry.ppEarned || 0;
        const backlogCleared  = entry.backlogCleared || 0;
        const notebookCompleted = entry.notebookCompleted || 0;
        const syllabusProgress  = entry.syllabusProgress || 0;

        // No activity at all → 0
        const hasAnyActivity = completedBlocks > 0 || studyMinutes > 0 || plannedBlocks > 0 ||
                               dailyPp > 0 || backlogCleared > 0 || notebookCompleted > 0 || syllabusProgress > 0;
        if (!hasAnyActivity) return 0;

        // ── Completion ratio (PRIMARY factor) ──
        const completionRatio = plannedBlocks > 0 ? completedBlocks / plannedBlocks : 0;

        // ── Score components ──
        const completionScore = completionRatio * 4;                          // max 4.0
        const minutesScore    = Math.min(studyMinutes / 180, 1) * 2;         // max 2.0
        const ppScore         = dailyPp > 0 ? Math.min(dailyPp / 80, 1) * 1 : 0;  // max 1.0
        const backlogScore    = Math.min(backlogCleared / 3, 1) * 1.5;       // max 1.5
        const notebookScore   = Math.min(notebookCompleted / 2, 1) * 0.8;    // max 0.8
        const syllabusScore   = Math.min(syllabusProgress / 3, 1) * 0.7;     // max 0.7

        // ── Miss penalty ──
        const missPenalty = Math.min(missedBlocks * 0.8, 3);                  // max 3.0

        // ── Raw score ──
        let score = completionScore + minutesScore + ppScore + backlogScore + notebookScore + syllabusScore - missPenalty;

        // ── Hard caps for missed blocks ──
        if (missedBlocks >= 3) {
            score = Math.min(score, 7);
        }
        if (plannedBlocks > 0 && missedBlocks >= plannedBlocks * 0.3) {
            score = Math.min(score, 7);
        }

        // ── Case: no planned blocks but has other activity ──
        // Use a simpler score to avoid inflated results without a plan
        if (plannedBlocks === 0 && completedBlocks === 0) {
            // Only backlog/notebook/syllabus/minutes/PP — capped at 5
            score = Math.min(5, ppScore + backlogScore + notebookScore + syllabusScore + minutesScore * 0.5 - missPenalty);
        }

        // Clamp and round to 1 decimal
        score = Math.min(10, Math.max(0, Math.round(score * 10) / 10));

        return score;
    }

    // ════════════════════════════════════════════════════════
    //  CLOUD DATA SOURCE — Sprint 4E
    // ════════════════════════════════════════════════════════

    /**
     * Resolves window.SPSyncManager (actual app sync manager).
     * Avoids collision with browser native SyncManager.
     */
    function _getSyncManager() {
        return window.SPSyncManager || window.SyncManager || null;
    }

    /**
     * Returns the current user ID from SPSyncManager or SafeStorage.
     * Returns null if no authenticated user.
     */
    function _getUserId() {
        const sync = _getSyncManager();
        if (sync && typeof sync.getUserId === 'function') {
            const uid = sync.getUserId();
            if (uid) return uid;
        }
        // Fallback: try SafeStorage for session user
        try {
            const session = SafeStorage.getItem('sp_session', null);
            if (session && session.userId) return session.userId;
        } catch { /* defensive */ }
        try {
            const session = SafeStorage.getItem('user_session', null);
            if (session && session.userId) return session.userId;
        } catch { /* defensive */ }
        return null;
    }

    /**
     * Loads historical time_blocks rows from Supabase (READ-ONLY).
     * Uses SPSyncManager.loadFromCloud() if available,
     * otherwise falls back to direct window.supabaseClient select.
     * No data is written to Supabase.
     *
     * Returns: Array of cloud rows, or [] if unavailable.
     */
    async function _loadCloudTimeBlocks() {
        const rows = [];

        // ── Try SPSyncManager first ──
        const sync = _getSyncManager();
        if (sync && typeof sync.loadFromCloud === 'function') {
            try {
                const cloudRows = await sync.loadFromCloud('time_blocks', {
                    columns: '*',
                    statusKey: 'time_blocks'
                });
                if (Array.isArray(cloudRows) && cloudRows.length > 0) {
                    console.log(`[VaultRoute] Loaded ${cloudRows.length} cloud time_blocks via SPSyncManager`);
                    return cloudRows;
                }
            } catch (err) {
                console.warn('[VaultRoute] SPSyncManager loadFromCloud(time_blocks) failed:', err?.message || err);
            }
        }

        // ── Direct Supabase fallback ──
        if (!window.supabaseClient) return rows;
        const userId = _getUserId();
        if (!userId) return rows;

        try {
            const { data, error } = await window.supabaseClient
                .from('time_blocks')
                .select('*')
                .eq('user_id', userId);

            if (error) {
                console.warn('[VaultRoute] Direct Supabase time_blocks load failed:', error.message || error);
                return rows;
            }
            if (Array.isArray(data) && data.length > 0) {
                console.log(`[VaultRoute] Loaded ${data.length} cloud time_blocks via direct Supabase`);
                return data;
            }
        } catch (err) {
            console.warn('[VaultRoute] Direct Supabase time_blocks error:', err?.message || err);
        }

        return rows;
    }

    /**
     * Builds a daily performance map for the last 90 days.
     * Sprint 4F: Multi-source merge — time blocks, productivity snapshots,
     * focus sessions, backlog, notebooks, syllabus — all contribute to daily score.
     *
     * Data sources (defensive reads):
     *   - time_blocks_v1 (local) + time_blocks (cloud) → blocks, minutes, completion, missed
     *   - productivity_snapshots_log → per-day PP, focus minutes, backlogs, sessions
     *   - focus_sessions_log → per-day PP from focus sessions
     *   - pulse_engine_data → today-only dailyEarned (NOT lifetime totalPP)
     *   - smartPadhaiData → backlog cleared (today snapshot only)
     *   - notebook_matrix_data → notebook completion (today snapshot only)
     *
     * PP BUG FIX: Lifetime totalPP is NEVER used as daily PP.
     * Only dailyEarned (today) or per-session/snapshot PP (historical) is used.
     *
     * Deduplication: time_blocks use (source_key, block_id) or (id).
     * Local blocks take priority — cloud rows only added if not already present.
     *
     * Returns { dayMap: Map<YYYY-MM-DD, {score, blocks, studyMinutes, plannedBlocks,
     *           missedBlocks, ppEarned, backlogCleared, backlogPending,
     *           notebookCompleted, syllabusProgress, completionRatio, status, insight, _dateStr}>,
     *           stats: { currentStreak, bestStreak, activeDays, strongestDay, strongestDayScore } }
     */
    function _buildDailyPerformanceMap() {
        const dayMap = {};
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayStr = _formatDate(today);

        // Initialize last 90 days with zero activity
        for (let i = 0; i < 90; i++) {
            const d = new Date(today);
            d.setDate(d.getDate() - i);
            const key = _formatDate(d);
            dayMap[key] = {
                score: 0, blocks: 0, studyMinutes: 0, minutes: 0,
                plannedBlocks: 0, missedBlocks: 0, ppEarned: 0,
                backlogCleared: 0, backlogPending: 0,
                notebookCompleted: 0, syllabusProgress: 0,
                completionRatio: 0, status: 'NO DATA', insight: '',
                _dateStr: key
            };
        }

        // ── Deduplication set: tracks block identifiers already counted ──
        const seenBlockKeys = new Set();

        function _blockDedupKey(block, source) {
            if (source === 'cloud') {
                const sk = block.source_key || '';
                const bid = block.block_id || '';
                if (sk && bid) return `cloud:${sk}:${bid}`;
                if (bid) return `cloud:${bid}`;
                if (block.raw_data && block.raw_data.id) return `cloud:raw:${block.raw_data.id}`;
                return null;
            }
            if (block.id) return `local:${block.id}`;
            return null;
        }

        // ═══════════════════════════════════════════════
        // Source 1: time_blocks_v1 (local SafeStorage)
        // ═══════════════════════════════════════════════
        try {
            const tbData = SafeStorage.getItem('time_blocks_v1', null);
            const blocks = (tbData && Array.isArray(tbData.blocks)) ? tbData.blocks : [];

            for (const b of blocks) {
                if (!b) continue;

                const dedupKey = _blockDedupKey(b, 'local');
                if (dedupKey) seenBlockKeys.add(dedupKey);

                let blockDate = null;
                if (b.date) {
                    blockDate = b.date;
                } else if (b.completedAt) {
                    try { const dt = new Date(b.completedAt); if (!isNaN(dt.getTime())) blockDate = _formatDate(dt); } catch { /* skip */ }
                } else if (b.createdAt) {
                    try { const dt = new Date(b.createdAt); if (!isNaN(dt.getTime())) blockDate = _formatDate(dt); } catch { /* skip */ }
                }
                if (!blockDate) blockDate = todayStr;

                if (dayMap[blockDate]) {
                    dayMap[blockDate].plannedBlocks += 1;

                    if (b.status === 'completed') {
                        dayMap[blockDate].blocks += 1;
                        let durationMin = 0;
                        if (b.startTime && b.endTime) {
                            try {
                                const [sh, sm] = String(b.startTime).split(':').map(Number);
                                const [eh, em] = String(b.endTime).split(':').map(Number);
                                if (!isNaN(sh) && !isNaN(sm) && !isNaN(eh) && !isNaN(em)) {
                                    durationMin = Math.max(0, (eh * 60 + em) - (sh * 60 + sm));
                                }
                            } catch { /* skip */ }
                        }
                        if (durationMin === 0 && b.duration) durationMin = Number(b.duration) || 0;
                        if (durationMin === 0) durationMin = 30;
                        dayMap[blockDate].studyMinutes += durationMin;
                        dayMap[blockDate].minutes += durationMin;
                    } else {
                        dayMap[blockDate].missedBlocks += 1;
                    }
                }
            }
        } catch (err) {
            console.warn('[VaultRoute] Daily Performance: time_blocks_v1 read error:', err);
        }

        // ═══════════════════════════════════════════════
        // Source 1B: cloud time_blocks (Sprint 4E — historical)
        // ═══════════════════════════════════════════════
        if (_cloudTimeBlocks && Array.isArray(_cloudTimeBlocks) && _cloudTimeBlocks.length > 0) {
            let cloudAdded = 0;
            let cloudSkipped = 0;

            for (const row of _cloudTimeBlocks) {
                if (!row) continue;

                const dedupKey = _blockDedupKey(row, 'cloud');
                if (dedupKey && seenBlockKeys.has(dedupKey)) { cloudSkipped++; continue; }
                if (row.block_id && seenBlockKeys.has(`local:${row.block_id}`)) { cloudSkipped++; continue; }
                if (row.raw_data && row.raw_data.id && seenBlockKeys.has(`local:${row.raw_data.id}`)) { cloudSkipped++; continue; }

                let blockDate = null;
                if (row.mission_date) {
                    blockDate = row.mission_date;
                    if (typeof blockDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(blockDate)) {
                        // Valid
                    } else {
                        try { const dt = new Date(blockDate); if (!isNaN(dt.getTime())) blockDate = _formatDate(dt); else blockDate = null; } catch { blockDate = null; }
                    }
                }
                if (!blockDate && row.updated_at) {
                    try { const dt = new Date(row.updated_at); if (!isNaN(dt.getTime())) blockDate = _formatDate(dt); } catch { /* skip */ }
                }

                if (!blockDate || !dayMap[blockDate]) continue;

                dayMap[blockDate].plannedBlocks += 1;
                const rowStatus = (row.status || '').toLowerCase();

                if (rowStatus === 'completed') {
                    dayMap[blockDate].blocks += 1;
                    let durationMin = Number(row.duration) || 0;
                    if (durationMin === 0 && row.start_hour != null && row.end_hour != null) {
                        const startMin = (Number(row.start_hour) || 0) * 60 + (Number(row.start_minute) || 0);
                        const endMin = (Number(row.end_hour) || 0) * 60 + (Number(row.end_minute) || 0);
                        durationMin = Math.max(0, endMin - startMin);
                    }
                    if (durationMin === 0) durationMin = 30;
                    dayMap[blockDate].studyMinutes += durationMin;
                    dayMap[blockDate].minutes += durationMin;
                } else if (rowStatus === 'missed') {
                    dayMap[blockDate].missedBlocks += 1;
                }

                if (dedupKey) seenBlockKeys.add(dedupKey);
                cloudAdded++;
            }

            if (cloudAdded > 0 || cloudSkipped > 0) {
                console.log(`[VaultRoute] Cloud time_blocks merge: ${cloudAdded} added, ${cloudSkipped} duplicates skipped`);
            }
        }

        // ═══════════════════════════════════════════════
        // Source 2: productivity_snapshots_log (per-day PP, focus, backlogs)
        // This is the PRIMARY source for historical per-day PP and backlog data.
        // ═══════════════════════════════════════════════
        try {
            const snapshots = SafeStorage.getItem('productivity_snapshots_log', []);
            if (Array.isArray(snapshots)) {
                for (const snap of snapshots) {
                    if (!snap || !snap.snapshot_date) continue;
                    const dateKey = snap.snapshot_date;
                    if (!dayMap[dateKey]) continue;

                    // PP earned (from snapshot — per-day, NOT lifetime total)
                    const snapPp = Number(snap.pp_earned || 0);
                    if (snapPp > 0) {
                        dayMap[dateKey].ppEarned = Math.max(dayMap[dateKey].ppEarned || 0, snapPp);
                    }

                    // Focus minutes from sessions
                    const snapFocus = Number(snap.focus_minutes || 0);
                    if (snapFocus > 0 && dayMap[dateKey].studyMinutes === 0) {
                        // Only add if no time_blocks data already provided minutes
                        dayMap[dateKey].studyMinutes += snapFocus;
                        dayMap[dateKey].minutes += snapFocus;
                    }

                    // Backlogs cleared
                    const snapBacklogs = Number(snap.backlogs_cleared || 0);
                    if (snapBacklogs > 0) {
                        dayMap[dateKey].backlogCleared = Math.max(dayMap[dateKey].backlogCleared || 0, snapBacklogs);
                    }
                }
            }
        } catch (err) {
            console.warn('[VaultRoute] Daily Performance: productivity_snapshots_log read error:', err);
        }

        // ═══════════════════════════════════════════════
        // Source 3: focus_sessions_log (per-day PP from focus sessions)
        // Supplements snapshots for per-day PP — useful for days without snapshots.
        // ═══════════════════════════════════════════════
        try {
            const sessions = SafeStorage.getItem('focus_sessions_log', []);
            if (Array.isArray(sessions)) {
                for (const sess of sessions) {
                    if (!sess || !sess.session_date || !sess.completed) continue;
                    const dateKey = sess.session_date;
                    if (!dayMap[dateKey]) continue;

                    // Add PP earned from this session
                    const sessPp = Number(sess.pp_earned || 0);
                    if (sessPp > 0) {
                        // Add to ppEarned (don't override snapshot which may be higher)
                        dayMap[dateKey].ppEarned = (dayMap[dateKey].ppEarned || 0) + sessPp;
                    }

                    // Add focus minutes if no time_blocks data
                    const sessMin = Number(sess.duration_minutes || 0);
                    if (sessMin > 0 && dayMap[dateKey].studyMinutes === 0) {
                        dayMap[dateKey].studyMinutes += sessMin;
                        dayMap[dateKey].minutes += sessMin;
                    }
                }
            }
        } catch (err) {
            console.warn('[VaultRoute] Daily Performance: focus_sessions_log read error:', err);
        }

        // ═══════════════════════════════════════════════
        // Source 4: pulse_engine_data (TODAY ONLY)
        // FIX: Only use dailyEarned for today. NEVER use totalPP as daily PP.
        // ═══════════════════════════════════════════════
        try {
            const pulseData = SafeStorage.getItem('pulse_engine_data', {}) || {};
            const dailyDate = pulseData.dailyDate || '';
            const todayDateStr = today.toDateString();

            // Only apply dailyEarned if it's actually for today
            if (dailyDate === todayDateStr && dayMap[todayStr]) {
                const dailyEarned = Number(pulseData.dailyEarned || pulseData.dailyEarnedPP || 0);
                if (dailyEarned > 0) {
                    // Use the higher of: snapshot PP, sessions PP, or dailyEarned
                    dayMap[todayStr].ppEarned = Math.max(dayMap[todayStr].ppEarned || 0, dailyEarned);
                }
            }
            // NOTE: totalPP is intentionally NOT used here.
            // It is a lifetime total and must never be shown as daily PP.
        } catch { /* defensive */ }

        // ═══════════════════════════════════════════════
        // Source 5: smartPadhaiData — backlog + syllabus (today snapshot only)
        // Only counts for today since there's no per-day history.
        // ═══════════════════════════════════════════════
        try {
            const masterData = SafeStorage.getItem('smartPadhaiData', {}) || {};
            let todayCleared = 0;
            let todayPending = 0;
            let todaySyllabusProgress = 0;

            for (const [chKey, chData] of Object.entries(masterData)) {
                if (!chData || typeof chData !== 'object') continue;
                if (chData._scheduledFor) continue; // Skip scheduled backlogs

                const read   = !!(chData.read || chData.read === true || chData.read === 'true');
                const notes  = !!(chData.notes || chData.notes === true || chData.notes === 'true');
                const pyq    = !!(chData.pyq || chData.pyq === true || chData.pyq === 'true');
                const completed = read && notes && pyq;
                const started   = read || notes || pyq;

                if (completed) {
                    todayCleared++;
                } else if (started) {
                    todayPending++;
                }

                // Syllabus progress: count chapters with any task done today
                if (chData.isSyllabus && started) {
                    const tasksDone = (read ? 1 : 0) + (notes ? 1 : 0) + (pyq ? 1 : 0);
                    todaySyllabusProgress += tasksDone;
                }
            }

            if (dayMap[todayStr]) {
                // Only update if we don't already have snapshot data (snapshots are more accurate for past)
                if (dayMap[todayStr].backlogCleared === 0) {
                    dayMap[todayStr].backlogCleared = todayCleared;
                }
                dayMap[todayStr].backlogPending = todayPending;
                if (dayMap[todayStr].syllabusProgress === 0) {
                    dayMap[todayStr].syllabusProgress = todaySyllabusProgress;
                }
            }
        } catch (err) {
            console.warn('[VaultRoute] Daily Performance: smartPadhaiData read error:', err);
        }

        // ═══════════════════════════════════════════════
        // Source 6: notebook_matrix_data (today snapshot only)
        // No date fields — can only count current completion for today.
        // ═══════════════════════════════════════════════
        try {
            const nbData = SafeStorage.getItem('notebook_matrix_data', []) || [];
            const nbRows = Array.isArray(nbData) ? nbData : [];
            let completedCount = 0;
            for (const subj of nbRows) {
                if (subj && (subj.done || subj.status === 'complete' || subj.status === 'completed')) {
                    completedCount++;
                }
            }
            if (dayMap[todayStr] && completedCount > 0 && dayMap[todayStr].notebookCompleted === 0) {
                dayMap[todayStr].notebookCompleted = completedCount;
            }
        } catch { /* defensive */ }

        // ═══════════════════════════════════════════════
        // Calculate scores, status, and insights for each day
        // ═══════════════════════════════════════════════
        for (const key of Object.keys(dayMap)) {
            const entry = dayMap[key];
            entry._dateStr = key;

            // Calculate completion ratio
            entry.completionRatio = entry.plannedBlocks > 0
                ? entry.blocks / entry.plannedBlocks
                : 0;

            // Calculate score using multi-source formula
            entry.score = _calculateDayScore(entry);

            // Determine status from score + completion ratio + missed
            entry.status = _getDayStatus(entry.score, entry.completionRatio, entry.missedBlocks, entry.plannedBlocks);

            // Generate insight line
            entry.insight = _getDayInsight(entry.status, entry.score, entry);
        }

        // ═══════════════════════════════════════════════
        // Calculate stats
        // ═══════════════════════════════════════════════
        let currentStreak = 0;
        let bestStreak = 0;
        let tempStreak = 0;
        let activeDays = 0;
        let strongestDay = null;
        let strongestDayScore = 0;

        const sortedDays = Object.keys(dayMap).sort();
        for (const key of sortedDays) {
            const entry = dayMap[key];
            if (entry.score > 0) {
                activeDays++;
                tempStreak++;
                if (tempStreak > bestStreak) bestStreak = tempStreak;
                if (entry.score > strongestDayScore) {
                    strongestDayScore = entry.score;
                    strongestDay = key;
                }
            } else {
                tempStreak = 0;
            }
        }

        // Current streak: count backwards from today
        currentStreak = 0;
        for (let i = 0; i < 90; i++) {
            const d = new Date(today);
            d.setDate(d.getDate() - i);
            const key = _formatDate(d);
            if (dayMap[key] && dayMap[key].score > 0) {
                currentStreak++;
            } else {
                break;
            }
        }

        return {
            dayMap,
            stats: {
                currentStreak,
                bestStreak,
                activeDays,
                strongestDay,
                strongestDayScore
            }
        };
    }

    /**
     * Legacy alias: _buildHeatmapData now delegates to _buildDailyPerformanceMap.
     * Preserved for backward compatibility with any internal references.
     */
    function _buildHeatmapData() {
        return _buildDailyPerformanceMap();
    }

    /**
     * Formats a Date object to YYYY-MM-DD string.
     */
    function _formatDate(date) {
        const y = date.getFullYear();
        const m = String(date.getMonth() + 1).padStart(2, '0');
        const d = String(date.getDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
    }

    /**
     * Maps a score (0-10) to an intensity level (0-5).
     * 0=none, 1=slipped/red, 2=low energy/orange, 3=stable/yellow,
     * 4=focused/cyan, 5=peak/purple
     */
    function _scoreToLevel(score) {
        if (score <= 0) return 0;   // None — dark gray
        if (score <= 3) return 1;   // Slipped — red
        if (score <= 5) return 2;   // Low Energy — orange
        if (score <= 7) return 3;   // Stable — yellow
        if (score <= 9) return 4;   // Focused — cyan/blue
        return 5;                   // Peak — purple glow
    }

    /**
     * Async wrapper: loads cloud time_blocks data, then renders the heatmap.
     * Sprint 4E: Cloud data is loaded once per session and cached in _cloudTimeBlocks.
     * If cloud is unavailable, heatmap still works with local data.
     */
    async function _renderActivityHeatmapAsync() {
        // Load cloud data if not already attempted this session
        if (!_cloudLoadAttempted) {
            _cloudLoadAttempted = true;
            try {
                _cloudTimeBlocks = await _loadCloudTimeBlocks();
            } catch (err) {
                console.warn('[VaultRoute] Cloud time_blocks load failed, using local only:', err?.message || err);
                _cloudTimeBlocks = [];
            }
        }

        // Render the heatmap (synchronous — uses cached _cloudTimeBlocks)
        _renderActivityHeatmap();
    }

    /**
     * Renders the Activity Intelligence Map grid + stats + insights.
     * Sprint 4E: Now uses merged local + cloud data from _buildHeatmapData().
     */
    function _renderActivityHeatmap() {
        const gridEl = _container?.querySelector('#heatmapGrid');
        const statsEl = _container?.querySelector('#heatmapStats');
        const monthLabelsEl = _container?.querySelector('#heatmapMonthLabels');
        if (!gridEl) return;

        const { dayMap, stats } = _buildHeatmapData();

        // Cache dayMap for detail panel use
        _heatmapDayData = dayMap;

        // ── Check for empty state ──
        const hasAnyActivity = Object.values(dayMap).some(d => d.score > 0);

        if (!hasAnyActivity) {
            gridEl.innerHTML = '';
            if (statsEl) {
                statsEl.innerHTML = `
                <div class="heatmap-empty sp-empty-state">
                    <div class="heatmap-empty-icon sp-empty-state-icon">🔥</div>
                    <h3 class="sp-empty-state-title">No Activity Data</h3>
                    <div class="heatmap-empty-text sp-empty-state-text">Complete time blocks to build your activity intelligence map.</div>
                </div>`;
            }
            if (monthLabelsEl) monthLabelsEl.innerHTML = '';
            _renderInsightSummary(dayMap, false);
            _renderDayDetailPanel(null); // clear detail panel
            return;
        }

        // ── Render Stats ──
        if (statsEl) {
            const strongestDayDisplay = stats.strongestDay
                ? _formatDisplayDate(stats.strongestDay)
                : '—';

            statsEl.innerHTML = `
            <div class="heatmap-stats-row">
                <div class="heatmap-stat-card">
                    <div class="heatmap-stat-value">${stats.currentStreak}</div>
                    <div class="heatmap-stat-label">Current Streak</div>
                </div>
                <div class="heatmap-stat-card">
                    <div class="heatmap-stat-value">${stats.bestStreak}</div>
                    <div class="heatmap-stat-label">Best Streak</div>
                </div>
                <div class="heatmap-stat-card">
                    <div class="heatmap-stat-value">${stats.activeDays}/90</div>
                    <div class="heatmap-stat-label">Active Days</div>
                </div>
                <div class="heatmap-stat-card">
                    <div class="heatmap-stat-value">${strongestDayDisplay}</div>
                    <div class="heatmap-stat-label">Strongest Day</div>
                </div>
            </div>
            ${_cloudTimeBlocks && _cloudTimeBlocks.length > 0 ? '<div class="heatmap-data-source">☁️ Cloud + Local data</div>' : '<div class="heatmap-data-source">📦 Local data only</div>'}`;
        }

        // ── Build the grid (GitHub-style: columns = weeks, rows = days of week) ──
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const endDay = new Date(today);
        const dayOfWeek = endDay.getDay();
        endDay.setDate(endDay.getDate() + (7 - dayOfWeek) % 7);

        const startDay = new Date(endDay);
        startDay.setDate(startDay.getDate() - 12 * 7 + 1);
        const startDow = startDay.getDay();
        if (startDow !== 1) {
            startDay.setDate(startDay.getDate() - ((startDow + 6) % 7));
        }

        let gridHtml = '';
        let current = new Date(startDay);
        const weeks = [];
        let weekCols = [];

        while (current <= endDay) {
            const key = _formatDate(current);
            const entry = dayMap[key] || { score: 0, blocks: 0, minutes: 0 };
            const level = _scoreToLevel(entry.score);
            const dow = current.getDay();

            weekCols.push({
                date: key,
                level,
                blocks: entry.blocks,
                minutes: entry.minutes,
                score: entry.score,
                dow
            });

            if (dow === 0) {
                weeks.push(weekCols);
                weekCols = [];
            }

            current.setDate(current.getDate() + 1);
        }
        if (weekCols.length > 0) {
            weeks.push(weekCols);
        }

        gridHtml = '<div class="heatmap-weeks">';

        const monthPositions = {};
        let weekIndex = 0;

        for (const week of weeks) {
            const ordered = new Array(7).fill(null);
            for (const day of week) {
                let rowIdx;
                if (day.dow === 0) rowIdx = 6;
                else rowIdx = day.dow - 1;
                ordered[rowIdx] = day;
            }

            for (const day of week) {
                const d = new Date(day.date + 'T00:00:00');
                const dayOfMonth = d.getDate();
                if (dayOfMonth <= 7) {
                    const monthName = d.toLocaleDateString('en-IN', { month: 'short' });
                    if (!monthPositions[monthName]) {
                        monthPositions[monthName] = weekIndex;
                    }
                }
            }

            gridHtml += '<div class="heatmap-week">';
            for (let row = 0; row < 7; row++) {
                const day = ordered[row];
                if (!day) {
                    gridHtml += '<div class="heatmap-cell heatmap-level-empty"></div>';
                } else {
                    const isToday = day.date === _formatDate(today);
                    const todayClass = isToday ? ' heatmap-today' : '';
                    const isSelected = day.date === _selectedHeatmapDate;
                    const selectedClass = isSelected ? ' heatmap-selected' : '';
                    const isFuture = new Date(day.date + 'T00:00:00') > today;
                    if (isFuture) {
                        gridHtml += '<div class="heatmap-cell heatmap-level-empty heatmap-future"></div>';
                    } else {
                        gridHtml += `<div class="heatmap-cell heatmap-level-${day.level}${todayClass}${selectedClass}" data-action="heatmap-cell" data-heatmap-date="${day.date}"></div>`;
                    }
                }
            }
            gridHtml += '</div>';
            weekIndex++;
        }

        gridHtml += '</div>';
        gridEl.innerHTML = gridHtml;

        // ── Render month labels ──
        if (monthLabelsEl) {
            let monthHtml = '<div class="heatmap-month-spacer"></div>';
            const totalWeeks = weeks.length;
            for (const [monthName, pos] of Object.entries(monthPositions)) {
                const leftPct = (pos / totalWeeks) * 100;
                monthHtml += `<span class="heatmap-month-label" style="left:${leftPct}%">${monthName}</span>`;
            }
            monthLabelsEl.innerHTML = monthHtml;
        }

        // ── Render insight summary ──
        _renderInsightSummary(dayMap, true);

        // ── If there was a previously selected day, re-render its detail panel ──
        if (_selectedHeatmapDate && dayMap[_selectedHeatmapDate]) {
            _renderDayDetailPanel(_selectedHeatmapDate);
        }
    }

    /**
     * Selects a heatmap day and renders the detail panel.
     */
    function _selectHeatmapDay(dateStr) {
        if (!_container || !_heatmapDayData) return;

        // Remove previous selected highlight
        _container.querySelectorAll('.heatmap-cell.heatmap-selected').forEach(el => {
            el.classList.remove('heatmap-selected');
        });

        // Highlight new selection
        const cell = _container.querySelector(`[data-heatmap-date="${dateStr}"]`);
        if (cell) {
            cell.classList.add('heatmap-selected');
        }

        _selectedHeatmapDate = dateStr;
        _renderDayDetailPanel(dateStr);
    }

    /**
     * Renders the day detail panel below the heatmap.
     * Shows: date, status label, score, blocks, minutes, PP, missed blocks, insight.
     */
    function _renderDayDetailPanel(dateStr) {
        const detailEl = _container?.querySelector('#heatmapDayDetail');
        if (!detailEl) return;

        if (!dateStr || !_heatmapDayData || !_heatmapDayData[dateStr]) {
            detailEl.innerHTML = '';
            detailEl.classList.remove('active');
            return;
        }

        const entry = _heatmapDayData[dateStr];
        const score = entry.score;
        const completionRatio = entry.completionRatio || (entry.plannedBlocks > 0 ? entry.blocks / entry.plannedBlocks : 0);
        const status = entry.status || _getDayStatus(score, completionRatio, entry.missedBlocks, entry.plannedBlocks);
        const emoji = _getDayStatusEmoji(status);
        const level = _scoreToLevel(score);

        const displayDate = _formatDisplayDate(dateStr);
        const dayName = new Date(dateStr + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'long' });

        const levelColor = level === 0 ? '#555' :
                           level === 1 ? '#ff4757' :
                           level === 2 ? '#ff8c00' :
                           level === 3 ? '#ffd700' :
                           level === 4 ? '#00d2ff' :
                           '#a855f7';

        const insight = entry.insight || _getDayInsight(status, score, entry);
        const studyMinutes = entry.studyMinutes || entry.minutes || 0;

        // Score display: show 1 decimal if not integer
        const scoreDisplay = Number.isInteger(score) ? score : score.toFixed(1);

        let detailHtml = `
            <div class="day-detail-header">
                <div class="day-detail-date">${dayName}, ${displayDate}</div>
                <div class="day-detail-status" style="color:${levelColor}">${emoji} ${status}</div>
            </div>
            <div class="day-detail-score-bar">
                <div class="day-detail-score-fill" style="width:${score * 10}%;background:${levelColor}"></div>
                <div class="day-detail-score-text">${scoreDisplay}/10</div>
            </div>
            <div class="day-detail-metrics">
                ${entry.blocks > 0 ? `<div class="day-detail-metric"><span class="day-detail-metric-value">${entry.blocks}</span><span class="day-detail-metric-label">Blocks Done</span></div>` : ''}
                ${entry.plannedBlocks > 0 ? `<div class="day-detail-metric"><span class="day-detail-metric-value">${entry.plannedBlocks}</span><span class="day-detail-metric-label">Planned</span></div>` : ''}
                ${studyMinutes > 0 ? `<div class="day-detail-metric"><span class="day-detail-metric-value">${studyMinutes}</span><span class="day-detail-metric-label">Minutes</span></div>` : ''}
                ${entry.missedBlocks > 0 ? `<div class="day-detail-metric day-detail-metric-warn"><span class="day-detail-metric-value">${entry.missedBlocks}</span><span class="day-detail-metric-label">Missed</span></div>` : ''}
                ${entry.ppEarned > 0 ? `<div class="day-detail-metric"><span class="day-detail-metric-value">${entry.ppEarned}</span><span class="day-detail-metric-label">PP Earned</span></div>` : ''}
            </div>
            ${(entry.backlogCleared > 0 || entry.backlogPending > 0) ? `
            <div class="day-detail-secondary">
                <div class="day-detail-secondary-title">Backlog</div>
                ${entry.backlogCleared > 0 ? `<span class="day-detail-tag day-detail-tag-good">${entry.backlogCleared} cleared</span>` : ''}
                ${entry.backlogPending > 0 ? `<span class="day-detail-tag day-detail-tag-warn">${entry.backlogPending} pending</span>` : ''}
            </div>` : ''}
            ${entry.notebookCompleted > 0 ? `
            <div class="day-detail-secondary">
                <div class="day-detail-secondary-title">Notebooks</div>
                <span class="day-detail-tag day-detail-tag-good">${entry.notebookCompleted} completed</span>
            </div>` : ''}
            ${entry.syllabusProgress > 0 ? `
            <div class="day-detail-secondary">
                <div class="day-detail-secondary-title">Syllabus</div>
                <span class="day-detail-tag day-detail-tag-info">${entry.syllabusProgress} tasks done</span>
            </div>` : ''}
            <div class="day-detail-insight">${insight}</div>
        `;

        detailEl.innerHTML = detailHtml;
        detailEl.classList.add('active');
    }

    /**
     * Renders the insight summary above/below the heatmap.
     * Only shows insights if data exists.
     */
    function _renderInsightSummary(dayMap, hasActivity) {
        const insightsEl = _container?.querySelector('#heatmapInsights');
        if (!insightsEl) return;

        if (!hasActivity) {
            insightsEl.innerHTML = `
            <div class="heatmap-insight-empty">
                Complete more study blocks to generate insights.
            </div>`;
            insightsEl.classList.remove('active');
            return;
        }

        const insights = [];

        // Find best day
        let bestDay = null;
        let bestScore = 0;
        for (const [dateStr, entry] of Object.entries(dayMap)) {
            if (entry.score > bestScore) {
                bestScore = entry.score;
                bestDay = dateStr;
            }
        }
        if (bestDay && bestScore > 0) {
            const bestDate = _formatDisplayDate(bestDay);
            const bestEntry = dayMap[bestDay];
            const bestRatio = bestEntry ? (bestEntry.completionRatio || 0) : 0;
            const bestMissed = bestEntry ? bestEntry.missedBlocks : 0;
            const bestPlanned = bestEntry ? bestEntry.plannedBlocks : 0;
            const bestStatus = _getDayStatus(bestScore, bestRatio, bestMissed, bestPlanned);
            insights.push({ icon: '🏆', text: `Best day: ${bestDate} — ${bestStatus}` });
        }

        // Count slip days (score 1-3) in last 30 days
        const today = new Date();
        let slipDays = 0;
        for (let i = 0; i < 30; i++) {
            const d = new Date(today);
            d.setDate(d.getDate() - i);
            const key = _formatDate(d);
            if (dayMap[key] && dayMap[key].score > 0 && dayMap[key].score <= 3) {
                slipDays++;
            }
        }
        if (slipDays > 0) {
            insights.push({ icon: '🔻', text: `Weak zone: ${slipDays} slip day${slipDays > 1 ? 's' : ''} this month` });
        }

        // Detect evening vs morning pattern (Sprint 4E: also checks cloud data)
        let morningBlocks = 0;
        let eveningBlocks = 0;
        try {
            const tbData = SafeStorage.getItem('time_blocks_v1', null);
            const blocks = (tbData && Array.isArray(tbData.blocks)) ? tbData.blocks : [];
            for (const b of blocks) {
                if (b && b.status === 'completed' && b.startTime) {
                    const h = parseInt(String(b.startTime).split(':')[0], 10);
                    if (!isNaN(h)) {
                        if (h < 12) morningBlocks++;
                        else if (h >= 17) eveningBlocks++;
                    }
                }
            }
            // Also check cloud time_blocks for pattern detection
            if (_cloudTimeBlocks && Array.isArray(_cloudTimeBlocks)) {
                for (const row of _cloudTimeBlocks) {
                    if (row && (row.status || '').toLowerCase() === 'completed' && row.start_hour != null) {
                        const h = Number(row.start_hour);
                        if (!isNaN(h)) {
                            if (h < 12) morningBlocks++;
                            else if (h >= 17) eveningBlocks++;
                        }
                    }
                }
            }
        } catch { /* skip */ }
        if (morningBlocks > 0 || eveningBlocks > 0) {
            if (eveningBlocks > morningBlocks * 1.5) {
                insights.push({ icon: '🌙', text: 'Current pattern: You perform better on evenings' });
            } else if (morningBlocks > eveningBlocks * 1.5) {
                insights.push({ icon: '🌅', text: 'Current pattern: You perform better on mornings' });
            }
        }

        // Streak insight
        try {
            const pulseData = SafeStorage.getItem('pulse_engine_data', {}) || {};
            const streak = Number(pulseData.streak || 0);
            if (streak >= 3) {
                insights.push({ icon: '🔥', text: `${streak}-day streak active — don't break it!` });
            }
        } catch { /* skip */ }

        if (insights.length === 0) {
            insightsEl.innerHTML = `
            <div class="heatmap-insight-empty">
                Complete more study blocks to generate insights.
            </div>`;
            insightsEl.classList.remove('active');
            return;
        }

        let html = '<div class="heatmap-insight-title">INSIGHTS</div>';
        for (const ins of insights) {
            html += `<div class="heatmap-insight-item"><span class="heatmap-insight-icon">${ins.icon}</span><span class="heatmap-insight-text">${ins.text}</span></div>`;
        }
        insightsEl.innerHTML = html;
        insightsEl.classList.add('active');
    }

    /**
     * Formats YYYY-MM-DD to a readable display date.
     */
    function _formatDisplayDate(dateStr) {
        try {
            const d = new Date(dateStr + 'T00:00:00');
            return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
        } catch {
            return dateStr;
        }
    }

    /**
     * Shows a tooltip for a heatmap cell on click/tap (legacy — kept for reference).
     * Now replaced by _selectHeatmapDay + _renderDayDetailPanel.
     */
    function _showHeatmapTooltip(dateStr, blocks, minutes, score) {
        // Removed in Sprint 4D — detail panel is now used instead
        _selectHeatmapDay(dateStr);
    }

    /**
     * Removes the heatmap tooltip from DOM.
     */
    function _removeHeatmapTooltip() {
        if (_heatmapTooltipEl) {
            _heatmapTooltipEl.remove();
            _heatmapTooltipEl = null;
        }
    }

    // ════════════════════════════════════════════════════════
    //  DISTRACTION CALCULATOR
    // ════════════════════════════════════════════════════════

    function _calculateWaste() {
        const input = _container?.querySelector('#screenHours');
        if (!input) return;

        const hours = input.value;
        if (!hours || hours <= 0) {
            _showToast('Bhai, kuch toh time waste karte hoge?');
            return;
        }

        const yearlyWaste = hours * 365;
        const booksCouldRead = Math.floor(yearlyWaste / 15);

        const resultEl = _container.querySelector('#calcResult');
        if (resultEl) {
            resultEl.innerHTML = `
                ⚠️ SYSTEM ALERT: <br>
                Tum saal mein <strong>${yearlyWaste} ghante</strong> waste kar rahe ho! <br>
                Itne time mein tum <strong>${booksCouldRead} badi books</strong> khatam kar sakte the!
            `;
        }
    }

    // ════════════════════════════════════════════════════════
    //  TOAST NOTIFICATION
    // ════════════════════════════════════════════════════════

    function _showToast(message) {
        const toast = _container?.querySelector('#vaultToast');
        if (!toast) return;

        toast.textContent = message;
        toast.classList.add('visible');

        if (_toastTimeout) clearTimeout(_toastTimeout);
        _toastTimeout = setTimeout(() => {
            toast.classList.remove('visible');
        }, 2800);
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();

window.VaultRoute = VaultRoute;
