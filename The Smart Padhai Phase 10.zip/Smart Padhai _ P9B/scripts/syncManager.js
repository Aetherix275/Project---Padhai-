/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — CENTRALIZED SYNC MANAGER (Phase 8D)
 *  Debounced per-row Supabase sync with retry & offline detection
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Exposed as: window.SPSyncManager  (avoids native SyncManager conflict)
 *
 *  APIs:
 *    enqueue(tableName, rowData, options)
 *      → options: { conflictKey, statusKey, operation, deleteFilter, deleteValue }
 *      → operation: 'upsert' (default) | 'delete'
 *      → For upsert: auto-injects user_id, batches rows per table, uses conflictKey
 *      → For delete: uses deleteFilter + deleteValue with user_id
 *
 *    loadFromCloud(tableName, options)
 *      → options: { columns, statusKey }
 *      → Direct Supabase query with user_id filter, returns rows
 *
 *    getUserId()  → returns current user ID
 *    isOnline()   → checks online status
 *    onStatusChange(callback) → listen for status events
 *
 *  Features:
 *    - 300ms debounce per table (rows are batched)
 *    - Retry with exponential backoff (max 5 attempts)
 *    - Online/offline detection
 *    - Fallback-safe: all calls no-op gracefully if Supabase unavailable
 *    - Multi-source Supabase client + user ID resolution
 * ═══════════════════════════════════════════════════════════════════
 */

(function () {
    'use strict';

    // ── Internal state ──
    const _queues = {};          // tableName → array of row operations
    const _timers = {};          // tableName → debounce timer id
    const _statusCallbacks = []; // online/offline listeners
    const DEBOUNCE_MS = 300;
    const MAX_RETRIES = 5;
    const BASE_RETRY_MS = 500;

    let _isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;

    // ── Online / offline detection ──
    if (typeof window !== 'undefined') {
        window.addEventListener('online', () => {
            _isOnline = true;
            _emitStatus('online');
            // Flush all pending queues when coming back online
            _flushAll();
        });

        window.addEventListener('offline', () => {
            _isOnline = false;
            _emitStatus('offline');
        });
    }

    function _emitStatus(status) {
        _statusCallbacks.forEach(cb => {
            try { cb(status); } catch (e) { console.warn('[SPSyncManager] Status callback error:', e); }
        });
    }

    // ════════════════════════════════════════════════════════
    //  MULTI-SOURCE SUPABASE CLIENT RESOLVER
    // ════════════════════════════════════════════════════════

    /**
     * Resolve Supabase client from multiple possible window locations.
     * Returns the client object or null.
     */
    function _getClientSafe() {
        const sources = [
            () => window.supabaseClient,
            () => window.supabase,
            () => window.SUPABASE_CLIENT,
            () => window.sb,
            () => window.AppSupabase?.client,
            () => window.SPSyncManager?.supabase,
            () => window.SyncManager?.supabase
        ];
        for (const source of sources) {
            try {
                const client = typeof source === 'function' ? source() : null;
                if (client && typeof client.from === 'function') {
                    return client;
                }
            } catch (e) { /* skip */ }
        }
        return null;
    }

    // ════════════════════════════════════════════════════════
    //  MULTI-SOURCE USER ID RESOLVER
    // ════════════════════════════════════════════════════════

    /**
     * Get current user ID from multiple sources (sync only).
     * For async auth.getUser() fallback, call _getUserIdAsync instead.
     */
    function _getUserId() {
        const syncSources = [
            () => window.AppState?.currentUser?.id,
            () => {
                try { return SafeStorage?.getItem?.('_current_user_id') || null; } catch(e) { return null; }
            },
            () => localStorage.getItem('_current_user_id'),
        ];
        for (const source of syncSources) {
            try {
                const id = typeof source === 'function' ? source() : null;
                if (id) return id;
            } catch (e) { /* skip */ }
        }
        return null;
    }

    /**
     * Async user ID resolver — tries sync sources first, then auth.getUser().
     * Used by _loadFromCloud and other async operations.
     */
    async function _getUserIdAsync() {
        // Try sync sources first
        const syncId = _getUserId();
        if (syncId) return syncId;

        // Try auth.getUser() as async fallback
        const client = _getClientSafe();
        if (client?.auth?.getUser) {
            try {
                const { data } = await client.auth.getUser();
                const id = data?.user?.id;
                if (id) {
                    console.log('[SPSyncManager] userId resolved via auth.getUser():', id);
                    return id;
                }
            } catch (e) {
                console.warn('[SPSyncManager] auth.getUser() failed:', e.message || e);
            }
        }

        return null;
    }

    // ── Enqueue a row operation ──
    function _enqueue(tableName, rowData, options) {
        if (!tableName) return;

        const operation = (options && options.operation) || 'upsert';

        // For delete operations, rowData can be empty
        if (operation !== 'delete' && !rowData) return;

        const userId = _getUserId();
        if (!userId) {
            console.warn('[SPSyncManager] No user ID — skipping enqueue for', tableName);
            return;
        }

        if (!_queues[tableName]) _queues[tableName] = [];

        if (operation === 'delete') {
            _queues[tableName].push({
                operation: 'delete',
                tableName,
                deleteFilter: options?.deleteFilter || '',
                deleteValue: options?.deleteValue || '',
                userId
            });
        } else {
            // Upsert: auto-inject user_id
            const row = { ...rowData, user_id: userId };
            _queues[tableName].push({
                operation: 'upsert',
                tableName,
                row,
                conflictKey: options?.conflictKey || '',
                statusKey: options?.statusKey || ''
            });
        }

        // Debounce flush per table
        if (_timers[tableName]) clearTimeout(_timers[tableName]);
        _timers[tableName] = setTimeout(() => {
            _flushTable(tableName);
        }, DEBOUNCE_MS);
    }

    // ── Flush a single table's queue ──
    async function _flushTable(tableName) {
        if (_timers[tableName]) {
            clearTimeout(_timers[tableName]);
            delete _timers[tableName];
        }

        const ops = _queues[tableName];
        if (!ops || ops.length === 0) return;
        _queues[tableName] = [];

        // Separate upserts and deletes
        const upserts = ops.filter(o => o.operation === 'upsert');
        const deletes = ops.filter(o => o.operation === 'delete');

        // Process upserts as a batch
        if (upserts.length > 0) {
            const rows = upserts.map(o => o.row);
            const conflictKey = upserts[0].conflictKey;
            await _retryUpsert(tableName, rows, conflictKey);
        }

        // Process deletes individually (different filter/value per op)
        for (const del of deletes) {
            await _retryDelete(tableName, del.deleteFilter, del.deleteValue, del.userId);
        }
    }

    // ── Flush all pending queues ──
    function _flushAll() {
        const tables = Object.keys(_queues);
        tables.forEach(t => _flushTable(t));
    }

    // ── Retry upsert with exponential backoff ──
    async function _retryUpsert(tableName, rows, conflictKey, attempt) {
        attempt = attempt || 0;
        const client = _getClientSafe();
        if (!client) {
            console.warn('[SPSyncManager] No Supabase client — upsert skipped for', tableName);
            return;
        }

        try {
            const opts = conflictKey ? { onConflict: conflictKey } : undefined;
            const { error } = await client
                .from(tableName)
                .upsert(rows, opts);

            if (error) throw error;
            console.log(`[SPSyncManager] Upserted ${rows.length} row(s) to ${tableName}`);
        } catch (err) {
            if (attempt < MAX_RETRIES) {
                const delay = BASE_RETRY_MS * Math.pow(2, attempt);
                console.warn(`[SPSyncManager] Upsert retry ${attempt + 1}/${MAX_RETRIES} for ${tableName} in ${delay}ms:`, err.message || err);
                await _sleep(delay);
                return _retryUpsert(tableName, rows, conflictKey, attempt + 1);
            }
            console.error(`[SPSyncManager] Upsert failed after ${MAX_RETRIES} retries for ${tableName}:`, err);
        }
    }

    // ── Retry delete with exponential backoff ──
    async function _retryDelete(tableName, filterKey, filterValue, userId, attempt) {
        attempt = attempt || 0;
        const client = _getClientSafe();
        if (!client) {
            console.warn('[SPSyncManager] No Supabase client — delete skipped for', tableName);
            return;
        }

        try {
            let query = client
                .from(tableName)
                .delete()
                .eq('user_id', userId);

            if (filterKey && filterValue !== undefined && filterValue !== '') {
                query = query.eq(filterKey, filterValue);
            }

            const { error } = await query;
            if (error) throw error;
            console.log(`[SPSyncManager] Deleted from ${tableName} where ${filterKey}=${filterValue}`);
        } catch (err) {
            if (attempt < MAX_RETRIES) {
                const delay = BASE_RETRY_MS * Math.pow(2, attempt);
                console.warn(`[SPSyncManager] Delete retry ${attempt + 1}/${MAX_RETRIES} for ${tableName} in ${delay}ms:`, err.message || err);
                await _sleep(delay);
                return _retryDelete(tableName, filterKey, filterValue, userId, attempt + 1);
            }
            console.error(`[SPSyncManager] Delete failed after ${MAX_RETRIES} retries for ${tableName}:`, err);
        }
    }

    // ── Load from cloud ──
    async function _loadFromCloud(tableName, options) {
        options = options || {};
        const client = _getClientSafe();
        if (!client) {
            console.warn('[SPSyncManager] No Supabase client — load skipped for', tableName);
            return [];
        }
        const userId = await _getUserIdAsync();
        if (!userId) {
            console.warn('[SPSyncManager] No userId — load skipped for', tableName);
            return [];
        }

        try {
            const columns = options.columns || '*';
            let query = client
                .from(tableName)
                .select(columns)
                .eq('user_id', userId);

            const { data, error } = await query;
            if (error) {
                console.warn(`[SPSyncManager] Load from ${tableName} failed:`, error);
                return [];
            }
            return data || [];
        } catch (err) {
            console.warn(`[SPSyncManager] Load from ${tableName} error:`, err);
            return [];
        }
    }

    // ── Sleep helper ──
    function _sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    window.SPSyncManager = {
        enqueue: _enqueue,
        loadFromCloud: _loadFromCloud,
        getUserId: _getUserId,
        isOnline: function () { return _isOnline; },
        onStatusChange: function (callback) {
            if (typeof callback === 'function') {
                _statusCallbacks.push(callback);
            }
        }
    };

    console.log('[SPSyncManager] Initialized');

})();
