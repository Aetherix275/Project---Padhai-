/**
 * ═══════════════════════════════════════════════════════════════
 *  Smart Padhai — TimerEngine v1.0
 *  Custom Focus Timer with Supabase Sync
 * ═══════════════════════════════════════════════════════════════
 *
 *  Features:
 *    - Preset durations: 5, 15, 25, 45, 60 minutes
 *    - Custom duration input
 *    - Session label selector: Maths, Physics, Chemistry, Revision, Backlog, Other
 *    - Start / Pause / Resume / Reset
 *    - Completion toast + PP reward via PulseEngine
 *    - SafeStorage first, Supabase mirror second
 *    - rewardId dedup so page refresh never double-awards PP
 *
 *  SafeStorage key: focus_sessions_log
 *  Supabase table:  focus_sessions
 * ═══════════════════════════════════════════════════════════════
 */

const TimerEngine = (() => {
    // ── Constants ──
    const STORAGE_KEY   = 'focus_sessions_log';
    const STATE_KEY     = 'timer_state';       // for persist/resume across refresh
    const PRESETS       = [5, 15, 25, 45, 60];
    const LABELS        = ['Maths', 'Physics', 'Chemistry', 'Revision', 'Backlog', 'Other'];
    const PP_PER_SESSION = 10;                 // flat +10 PP per completed session

    const SUPABASE_URL     = 'https://jgkohrwpyjlfywvqsozj.supabase.co';
    const SUPABASE_ANON_KEY = 'sb_publishable_OkDNIEJg0BDU9dx3aqcm8A_uFqb5jd6';

    // ── Internal State ──
    let totalSeconds   = 25 * 60;   // selected duration in seconds
    let timeLeft       = 25 * 60;   // remaining seconds
    let isRunning      = false;
    let isPaused       = false;
    let intervalId     = null;
    let selectedLabel  = 'Other';
    let sessionStartTs = null;      // ISO timestamp when session started
    let completedSessionId = null;  // prevents double-award on rapid clicks
    let _startDebounce = false;     // double-click guard for start/toggle

    // ── Helpers ──
    function todayISO() {
        const d = new Date();
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
    }

    function generateSessionId() {
        // Unique per session: focus-{date}-{label}-{timestamp}
        return `focus-${todayISO()}-${selectedLabel}-${Date.now()}`;
    }

    // ── SafeStorage ──
    function getSessions() {
        return SafeStorage.getItem(STORAGE_KEY, []);
    }

    function saveSessions(sessions) {
        // Keep last 200 sessions locally to avoid unbounded growth
        if (sessions.length > 200) sessions = sessions.slice(-200);
        SafeStorage.setItem(STORAGE_KEY, sessions);
    }

    function addSessionToLocal(sessionObj) {
        const sessions = getSessions();
        sessions.push(sessionObj);
        saveSessions(sessions);
    }

    function saveDashboardTimerSessionLog(sessionObj) {
        try {
            if (!sessionObj || sessionObj.completed !== true) return null;

            const sessionMinutes = Number(sessionObj.duration_minutes || sessionObj.minutes || 0);
            if (!Number.isFinite(sessionMinutes) || sessionMinutes <= 0) return null;

            const sessionLog = {
                id: sessionObj.id || `session_${Date.now()}`,
                date: todayISO(),
                createdAt: sessionObj.started_at || new Date().toISOString(),
                completedAt: sessionObj.completed_at || new Date().toISOString(),
                minutes: sessionMinutes,
                focusMinutes: sessionMinutes,
                category: sessionObj.label || 'Focus',
                completed: true,
                source: 'focus_timer'
            };

            const stored = SafeStorage.getItem('smart_padhai_timer_sessions', []);
            const sessions = Array.isArray(stored) ? stored : [];
            const alreadySaved = sessions.some(existing => {
                if (!existing) return false;
                if (existing.id === sessionLog.id || existing.completedAt === sessionLog.completedAt) return true;
                if (!existing.completedAt) return false;
                return Math.abs(new Date(existing.completedAt).getTime() - new Date(sessionLog.completedAt).getTime()) < 2000;
            });

            if (!alreadySaved) {
                sessions.push(sessionLog);
                SafeStorage.setItem('smart_padhai_timer_sessions', sessions);
            }

            return sessionLog;
        } catch (err) {
            console.warn('[TimerEngine] Dashboard timer session log save failed:', err);
            return null;
        }
    }

    function dispatchDashboardTimerSessionEvents(sessionLog) {
        if (!sessionLog) return;
        try {
            window.dispatchEvent(new CustomEvent('smartPadhai:timerSessionSaved', { detail: sessionLog }));
            window.dispatchEvent(new CustomEvent('smartPadhai:dashboardDataUpdated', { detail: { source: 'timer_session', log: sessionLog } }));
        } catch (err) {
            console.warn('[TimerEngine] Dashboard timer session event dispatch failed:', err);
        }
    }

    // ── Persist / Restore Timer State (survives refresh) ──
    function persistTimerState() {
        SafeStorage.setItem(STATE_KEY, {
            totalSeconds,
            timeLeft,
            selectedLabel,
            sessionStartTs,
            isRunning,
            isPaused,
            savedAt: Date.now()
        });
    }

    function clearTimerState() {
        SafeStorage.removeItem(STATE_KEY);
    }

    function restoreTimerState() {
        const saved = SafeStorage.getItem(STATE_KEY, null);
        if (!saved) return;

        // If less than 2 seconds elapsed since save, restore fully
        const elapsed = Math.floor((Date.now() - (saved.savedAt || 0)) / 1000);
        totalSeconds   = saved.totalSeconds || 25 * 60;
        selectedLabel  = saved.selectedLabel || 'Other';
        sessionStartTs = saved.sessionStartTs || null;

        if (saved.isRunning && !saved.isPaused && elapsed > 0) {
            // Timer was running when page closed — deduct elapsed time
            timeLeft = Math.max(0, (saved.timeLeft || 0) - elapsed);
            if (timeLeft <= 0) {
                // Time ran out while page was closed — count as NOT completed
                clearTimerState();
                timeLeft = totalSeconds;
                isRunning = false;
                isPaused = false;
                updateUI();
                return;
            }
            // Resume countdown
            isRunning = true;
            isPaused = false;
            startCountdown();
        } else if (saved.isPaused) {
            timeLeft = saved.timeLeft || totalSeconds;
            isRunning = true;
            isPaused = true;
        } else {
            timeLeft = saved.timeLeft || totalSeconds;
            isRunning = false;
            isPaused = false;
        }
        updateUI();
    }

    // ── Supabase Sync ──
   async function syncSessionToSupabase(sessionObj) {
    try {
        if (!window.supabaseClient) {
            console.error("[TimerEngine] No Supabase client found.");
            return null;
        }

        const { data: userData, error: userError } =
            await window.supabaseClient.auth.getUser();

        if (userError || !userData?.user?.id) {
            console.error("[TimerEngine] No active user. Session sync blocked.", userError);
            return null;
        }

        const userId = userData.user.id;

        const row = {
            user_id: userId,
            session_date: sessionObj.session_date,
            duration_minutes: Number(sessionObj.duration_minutes || 0),
            label: sessionObj.label || "Other",
            completed: sessionObj.completed === true,
            pp_earned: Number(sessionObj.pp_earned || 0),
            started_at: sessionObj.started_at,
            completed_at: sessionObj.completed_at
        };

        const { data, error } = await window.supabaseClient
            .from("focus_sessions")
            .insert(row)
            .select();

        if (error) {
            console.error("[TimerEngine] Supabase session sync error:", error);
            return null;
        }

        console.info("[TimerEngine] Session synced to Supabase:", data);
        return data;
    } catch (err) {
        console.error("[TimerEngine] Supabase sync exception:", err);
        return null;
    }
}
    // ── Core Timer Logic ──
    function selectDuration(minutes) {
        if (isRunning) return;  // can't change duration while running
        totalSeconds = minutes * 60;
        timeLeft = totalSeconds;
        completedSessionId = null;
        updateUI();
    }

    function selectLabel(label) {
        if (isRunning) return;  // can't change label while running
        selectedLabel = label;
        updateLabelChips();
    }

    function start() {
        if (isRunning && !isPaused) return; // already running

        // Double-activation guard: prevent rapid re-entry
        if (_startDebounce) return;
        _startDebounce = true;
        setTimeout(() => { _startDebounce = false; }, 300);

        if (isPaused) {
            // Resume
            isPaused = false;
            startCountdown();
            updateStartButton();
            persistTimerState();
            return;
        }

        // Fresh start
        if (timeLeft <= 0) {
            timeLeft = totalSeconds;
        }
        sessionStartTs = new Date().toISOString();
        completedSessionId = null;
        isRunning = true;
        isPaused = false;
        startCountdown();
        updateStartButton();
        persistTimerState();
    }

    function startCountdown() {
        // Strict guard: never create a second interval if one is already running
        if (intervalId) {
            clearInterval(intervalId);
        }
        intervalId = setInterval(() => {
            if (timeLeft > 0) {
                timeLeft--;
                updateTimerDisplay();
                // Persist every 5 seconds for crash recovery
                if (timeLeft % 5 === 0) persistTimerState();
            } else {
                // Timer completed!
                clearInterval(intervalId);
                intervalId = null;
                onSessionComplete();
            }
        }, 1000);
    }

    function pause() {
        if (!isRunning || isPaused) return;
        if (intervalId) {
            clearInterval(intervalId);
            intervalId = null;
        }
        isPaused = true;
        updateStartButton();
        persistTimerState();
    }

    function reset() {
        if (intervalId) {
            clearInterval(intervalId);
            intervalId = null;
        }
        timeLeft = totalSeconds;
        isRunning = false;
        isPaused = false;
        sessionStartTs = null;
        completedSessionId = null;
        _startDebounce = false;
        updateUI();
        clearTimerState();
    }

    function onSessionComplete() {
        const sessionId = generateSessionId();

        // Prevent double-award
        if (completedSessionId === sessionId) return;
        completedSessionId = sessionId;

        // Award PP via PulseEngine — use rewardId for dedup
        let ppEarned = 0;
        if (typeof PulseEngine !== 'undefined') {
            ppEarned = PulseEngine.addPoints(PP_PER_SESSION, 'timer', {
                rewardId: sessionId,
                source_key: 'focus_timer'
            });
        }

        // Build session record
        const sessionObj = {
            id:               sessionId,
            session_date:     todayISO(),
            duration_minutes: Math.round(totalSeconds / 60),
            label:            selectedLabel,
            completed:        true,
            pp_earned:        ppEarned,
            started_at:       sessionStartTs,
            completed_at:     new Date().toISOString()
        };

        // Save locally
        addSessionToLocal(sessionObj);
        const dashboardSessionLog = saveDashboardTimerSessionLog(sessionObj);
        dispatchDashboardTimerSessionEvents(dashboardSessionLog);

        // Mirror to Supabase (fire-and-forget)
        syncSessionToSupabase(sessionObj);

        // Notify WeeklyInsightEngine if available
        if (window.WeeklyInsightEngine) {
            WeeklyInsightEngine.addFocusMinutes(sessionObj.duration_minutes);
        }

        // Notify GraphEngine to update today's snapshot
        if (window.GraphEngine) {
            GraphEngine.recordTodaySnapshot().then(() => {
                GraphEngine.renderDashboard();
            });
        }

        // Reset timer state
        isRunning = false;
        isPaused = false;
        _startDebounce = false;
        clearTimerState();

        // Show completion feedback
        showCompletionToast(sessionObj);

        // Update UI
        updateUI();
    }

    // ── Completion Toast ──
    function showCompletionToast(session) {
        // Use Alfred if available, otherwise fallback
        if (typeof Alfred !== 'undefined') {
            Alfred.show(
                `Focus session complete! +${session.pp_earned} PP earned for ${session.label} (${session.duration_minutes} min)`,
                'reward',
                0
            );
        }

        // Also show a custom timer completion animation
        const timerCard = document.querySelector('.focus-timer-card');
        if (timerCard) {
            timerCard.classList.add('timer-complete-flash');
            setTimeout(() => timerCard.classList.remove('timer-complete-flash'), 2000);
        }

        // Visual beep on timer display
        const display = document.querySelector('.timer-display');
        if (display) {
            display.style.color = '#28A745';
            display.style.textShadow = '0 0 20px rgba(40, 167, 69, 0.6)';
            setTimeout(() => {
                display.style.color = '';
                display.style.textShadow = '';
            }, 3000);
        }
    }

    // ── Session Stats ──
    function getTodayStats() {
        const sessions = getSessions();
        const today = todayISO();
        const todaySessions = sessions.filter(s => s.session_date === today && s.completed);
        return {
            sessionsCompleted: todaySessions.length,
            totalFocusMinutes: todaySessions.reduce((sum, s) => sum + (s.duration_minutes || 0), 0),
            totalPPEarned: todaySessions.reduce((sum, s) => sum + (s.pp_earned || 0), 0)
        };
    }

    // ── UI Update Functions ──
    function updateTimerDisplay() {
        const mins = Math.floor(timeLeft / 60);
        const secs = timeLeft % 60;
        const minsEl = document.getElementById('focusMinutes');
        const secsEl = document.getElementById('focusSeconds');
        if (minsEl) minsEl.textContent = mins.toString().padStart(2, '0');
        if (secsEl) secsEl.textContent = secs.toString().padStart(2, '0');

        // Update progress bar
        const progressEl = document.getElementById('timerProgressBar');
        if (progressEl && totalSeconds > 0) {
            const pct = ((totalSeconds - timeLeft) / totalSeconds) * 100;
            progressEl.style.width = pct + '%';
        }

        // Update page title with timer
        if (isRunning && !isPaused) {
            document.title = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')} — Smart Padhai`;
        } else {
            document.title = 'The Smart Padhai | Action OS';
        }
    }

    function updateStartButton() {
        const btn = document.getElementById('focusStartBtn');
        if (!btn) return;

        if (!isRunning) {
            btn.textContent = 'Start Focus';
            btn.classList.remove('active', 'paused');
        } else if (isPaused) {
            btn.textContent = 'Resume';
            btn.classList.remove('active');
            btn.classList.add('paused');
        } else {
            btn.textContent = 'Pause';
            btn.classList.add('active');
            btn.classList.remove('paused');
        }
    }

    function updateLabelChips() {
        const chips = document.querySelectorAll('.label-chip');
        chips.forEach(chip => {
            chip.classList.toggle('selected', chip.dataset.label === selectedLabel);
        });
    }

    function updatePresetButtons() {
        const btns = document.querySelectorAll('.preset-btn');
        btns.forEach(btn => {
            const mins = parseInt(btn.dataset.minutes, 10);
            btn.classList.toggle('selected', mins * 60 === totalSeconds && !isRunning);
        });
    }

    function updateTodayStats() {
        const stats = getTodayStats();
        const el1 = document.getElementById('todaySessionsCount');
        const el2 = document.getElementById('todayFocusMinutes');
        if (el1) el1.textContent = stats.sessionsCompleted;
        if (el2) el2.textContent = stats.totalFocusMinutes;
    }

    function updateUI() {
        updateTimerDisplay();
        updateStartButton();
        updateLabelChips();
        updatePresetButtons();
        updateTodayStats();
    }

    // ── Public API ──
    return {
        PRESETS,
        LABELS,
        selectDuration,
        selectLabel,
        start,
        pause,
        reset,
        getTodayStats,
        getSessions,
        updateUI,
        restoreTimerState,

        // Convenience: start/pause toggle (for the Start button)
        toggle() {
            if (!isRunning) {
                start();
            } else if (isPaused) {
                start(); // resume
            } else {
                pause();
            }
        },

        // Expose state for debugging
        getState() {
            return { totalSeconds, timeLeft, isRunning, isPaused, selectedLabel, sessionStartTs };
        }
    };
})();
window.TimerEngine = TimerEngine;

// ── Auto-init on DOM ready ──
// __SPA_MODE GUARD: In SPA mode, the dashboardRoute handles button wiring
// and UI refresh via data-action delegation. The DOMContentLoaded auto-init
// is disabled to prevent duplicate listeners and race conditions.
if (!window.__SPA_MODE) {
document.addEventListener('DOMContentLoaded', () => {
    // Wire preset buttons
    document.querySelectorAll('.preset-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const mins = parseInt(btn.dataset.minutes, 10);
            if (!isNaN(mins)) TimerEngine.selectDuration(mins);
        });
    });

    // Wire custom duration input
    const customInput = document.getElementById('customDuration');
    const customBtn = document.getElementById('customDurationBtn');
    if (customBtn && customInput) {
        customBtn.addEventListener('click', () => {
            const val = parseInt(customInput.value, 10);
            if (val >= 1 && val <= 180) {
                TimerEngine.selectDuration(val);
                customInput.value = '';
            }
        });
        customInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') customBtn.click();
        });
    }

    // Wire label chips
    document.querySelectorAll('.label-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            TimerEngine.selectLabel(chip.dataset.label);
        });
    });

    // Wire start/pause button
    const startBtn = document.getElementById('focusStartBtn');
    if (startBtn) {
        startBtn.addEventListener('click', () => TimerEngine.toggle());
    }

    // Wire reset button
    const resetBtn = document.getElementById('focusResetBtn');
    if (resetBtn) {
        resetBtn.addEventListener('click', () => TimerEngine.reset());
    }

    // Restore any running timer from before page refresh
    TimerEngine.restoreTimerState();

    // Initial UI render
    TimerEngine.updateUI();
});
} // end __SPA_MODE guard
