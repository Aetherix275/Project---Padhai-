// =====================================================
// SMART PADHAI — USER SESSION MANAGER
// Load order: Supabase CDN → userSession.js → everything else
// =====================================================

(function () {
    const SUPABASE_URL = "https://jgkohrwpyjlfywvqsozj.supabase.co";
    const SUPABASE_ANON_KEY = "sb_publishable_OkDNIEJg0BDU9dx3aqcm8A_uFqb5jd6";

    let _supabaseClient = null;

    if (typeof supabase !== "undefined" && supabase.createClient) {
        _supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        window.supabaseClient = _supabaseClient;
        window._supabase = _supabaseClient;
    } else {
        console.error("[UserSession] Supabase CDN not loaded before userSession.js");
    }

    const PROTECTED_KEYS = [
        "_current_user_id",
        "_current_user_email"
    ];

    function isProtected(key) {
        if (PROTECTED_KEYS.includes(key)) return true;
        if (typeof key === "string" && (key.startsWith("sb-") || key.startsWith("supabase"))) return true;
        return false;
    }

    function getCurrentUserIdSync() {
        return localStorage.getItem("_current_user_id");
    }

    window.userKey = function (baseKey) {
        const uid = getCurrentUserIdSync();

        if (!uid) {
            console.warn(`[SafeStorage] No active user for key: ${baseKey}`);
            return `guest_${baseKey}`;
        }

        return `${baseKey}_${uid}`;
    };

    window.SafeStorage = {
        getItem: function (key, fallback = null) {
            try {
                if (isProtected(key)) {
                    const protectedValue = localStorage.getItem(key);
                    return protectedValue ?? fallback;
                }

                const raw = localStorage.getItem(window.userKey(key));

                if (raw === null || raw === undefined) return fallback;

                try {
                    return JSON.parse(raw);
                } catch {
                    return raw;
                }
            } catch (err) {
                console.error(`[SafeStorage] getItem failed for ${key}:`, err);
                return fallback;
            }
        },

        setItem: function (key, value) {
            try {
                if (isProtected(key)) {
                    localStorage.setItem(key, String(value));
                    return;
                }

                const safeKey = window.userKey(key);
                const finalValue =
                    typeof value === "string" ? value : JSON.stringify(value);

                localStorage.setItem(safeKey, finalValue);
            } catch (err) {
                console.error(`[SafeStorage] setItem failed for ${key}:`, err);
            }
        },

        removeItem: function (key) {
            try {
                if (isProtected(key)) {
                    localStorage.removeItem(key);
                    return;
                }

                localStorage.removeItem(window.userKey(key));
            } catch (err) {
                console.error(`[SafeStorage] removeItem failed for ${key}:`, err);
            }
        },

        clearCurrentUser: function () {
            const uid = getCurrentUserIdSync();
            if (!uid) return;

            const keysToRemove = [];

            for (let i = 0; i < localStorage.length; i++) {
                const k = localStorage.key(i);
                if (k && k.endsWith("_" + uid)) {
                    keysToRemove.push(k);
                }
            }

            keysToRemove.forEach(k => localStorage.removeItem(k));
        }
    };

    function applySession(session) {
        if (session && session.user) {
            localStorage.setItem("_current_user_id", session.user.id);
            localStorage.setItem("_current_user_email", session.user.email || "");
            console.log("[UserSession] User active:", session.user.email, session.user.id);
        } else {
            localStorage.removeItem("_current_user_id");
            localStorage.removeItem("_current_user_email");
            console.log("[UserSession] No active session.");
        }
    }

    window.getCurrentUserOrRedirect = async function () {
        if (!_supabaseClient) {
            window.location.href = "login.html";
            return null;
        }

        // P2 Fix 3: Auth timeout — if Supabase getUser hangs, redirect safely
        const AUTH_TIMEOUT_MS = 10000; // 10 seconds
        let timedOut = false;

        const timeoutPromise = new Promise((resolve) => {
            setTimeout(() => {
                timedOut = true;
                resolve({ data: { user: null }, error: { message: "Auth check timed out" } });
            }, AUTH_TIMEOUT_MS);
        });

        const { data, error } = await Promise.race([
            _supabaseClient.auth.getUser(),
            timeoutPromise
        ]);

        if (timedOut) {
            console.warn("[UserSession] Auth check timed out after", AUTH_TIMEOUT_MS, "ms. Redirecting to login.");
            window.location.href = "login.html";
            return null;
        }

        if (error || !data.user) {
            window.location.href = "login.html";
            return null;
        }

        // P2 Fix 4: Detect account switch — if user ID changed, reset PulseEngine load flag
        const prevUserId = localStorage.getItem("_current_user_id");
        if (prevUserId && prevUserId !== data.user.id) {
            console.log("[UserSession] Account switch detected:", prevUserId, "→", data.user.id);
            if (typeof PulseEngine !== 'undefined') {
                PulseEngine.hasLoadedFromSupabase = false;
            }
        }

        localStorage.setItem("_current_user_id", data.user.id);
        localStorage.setItem("_current_user_email", data.user.email || "");

        return data.user;
    };

    window.getCurrentSession = async function () {
        if (!_supabaseClient) return null;

        const { data, error } = await _supabaseClient.auth.getSession();
        if (error) return null;

        return data.session;
    };

    window.fetchUserRows = async function (tableName, columns = "*") {
        const user = await window.getCurrentUserOrRedirect();
        if (!user) return [];

        const { data, error } = await _supabaseClient
            .from(tableName)
            .select(columns)
            .eq("user_id", user.id);

        if (error) {
            console.error(`[${tableName}] fetch failed:`, error);
            return [];
        }

        return data || [];
    };

    window.upsertUserRow = async function (tableName, row, conflictKey) {
        const user = await window.getCurrentUserOrRedirect();
        if (!user) return null;

        const finalRow = {
            ...row,
            user_id: user.id
        };

        const query = _supabaseClient
            .from(tableName)
            .upsert(finalRow, conflictKey ? { onConflict: conflictKey } : undefined)
            .select();

        const { data, error } = await query;

        if (error) {
            console.error(`[${tableName}] upsert failed:`, error);
            return null;
        }

        return data;
    };

    window.insertUserRow = async function (tableName, row) {
        const user = await window.getCurrentUserOrRedirect();
        if (!user) return null;

        const finalRow = {
            ...row,
            user_id: user.id
        };

        const { data, error } = await _supabaseClient
            .from(tableName)
            .insert(finalRow)
            .select();

        if (error) {
            console.error(`[${tableName}] insert failed:`, error);
            return null;
        }

        return data;
    };

    async function initUserSession() {
        if (!_supabaseClient) return;

        try {
            const { data, error } = await _supabaseClient.auth.getSession();

            if (error) {
                console.warn("[UserSession] getSession error:", error.message);
                return;
            }

            applySession(data?.session);
        } catch (err) {
            console.warn("[UserSession] init failed:", err);
        }

        _supabaseClient.auth.onAuthStateChange((event, session) => {
            console.log("[UserSession] Auth event:", event);
            applySession(session);

            if (event === "SIGNED_OUT") {
                window.location.href = "login.html";
            }
        });
    }

    window.smartPadhaiLogout = async function () {
        // P2 Fix 5: Optional — sync pulse before logout, but ONLY if already loaded
        // This ensures the latest PP/rank is saved to Supabase before switching accounts
        if (typeof PulseEngine !== 'undefined' && PulseEngine.hasLoadedFromSupabase && typeof syncPulseEngineToSupabase === 'function') {
            try {
                await syncPulseEngineToSupabase();
                console.log("[Logout] Pulse synced before logout.");
            } catch (err) {
                console.warn("[Logout] Pulse sync before logout failed:", err);
            }
        }

        // Reset PulseEngine load flag so next login must reload from Supabase
        if (typeof PulseEngine !== 'undefined') {
            PulseEngine.hasLoadedFromSupabase = false;
        }

        if (_supabaseClient) {
            await _supabaseClient.auth.signOut();
        }

        // Only remove session identity keys — do NOT remove user-prefixed SafeStorage data
        // (other accounts' data must be preserved for account switching)
        localStorage.removeItem("_current_user_id");
        localStorage.removeItem("_current_user_email");

        window.location.href = "login.html";
    };

    initUserSession();
})();