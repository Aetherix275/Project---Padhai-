/**
 * ═══════════════════════════════════════════════════════════════
 *  Smart Padhai — GraphEngine v1.0
 *  Productivity Snapshot Engine with Supabase Sync
 * ═══════════════════════════════════════════════════════════════
 *
 *  Features:
 *    - Reads focus_sessions_log / focus_sessions from SafeStorage
 *    - Reads pulse_engine_data from SafeStorage
 *    - Reads smartPadhaiData (backlog completion) from SafeStorage
 *    - Computes daily productivity snapshot
 *    - Saves to SafeStorage first (productivity_snapshots_log)
 *    - Mirrors to Supabase (productivity_snapshots table)
 *    - Upsert by user_id + snapshot_date to prevent duplicates
 *    - Computes consistency score (0-100) from multiple metrics
 *    - Provides data for dashboard graph UI rendering
 *
 *  SafeStorage key: productivity_snapshots_log
 *  Supabase table:  productivity_snapshots
 * ═══════════════════════════════════════════════════════════════
 */

const GraphEngine = (() => {
    // ── Constants ──
    const STORAGE_KEY    = 'productivity_snapshots_log';
    const PRESETS        = [5, 15, 25, 45, 60];
    const DAY_LABELS     = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const WEEK_START_MODE = 'monday';

    const SUPABASE_URL      = 'https://jgkohrwpyjlfywvqsozj.supabase.co';
    const SUPABASE_ANON_KEY = 'sb_publishable_OkDNIEJg0BDU9dx3aqcm8A_uFqb5jd6';

    // ── Helpers ──
    function todayISO() {
        const d = new Date();
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
    }

    function yesterdayISO() {
        const d = new Date();
        d.setDate(d.getDate() - 1);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
    }

    function dateToISO(dateObj) {
        const d = new Date(dateObj);
        d.setHours(0, 0, 0, 0);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
    }

    function getWeekStart(date = new Date(), mode = WEEK_START_MODE) {
        const d = new Date(date);
        d.setHours(0, 0, 0, 0);
        const weekDay = d.getDay();
        const delta = mode === 'monday' ? (weekDay === 0 ? -6 : 1 - weekDay) : -weekDay;
        d.setDate(d.getDate() + delta);
        return d;
    }

    function getWeekDates() {
        const weekStart = getWeekStart(new Date(), WEEK_START_MODE);
        const dates = [];
        for (let i = 0; i < 7; i++) {
            const d = new Date(weekStart);
            d.setDate(weekStart.getDate() + i);
            dates.push(dateToISO(d));
        }
        return dates;
    }

    function getLastWeekDates() {
        const weekStart = getWeekStart(new Date(), WEEK_START_MODE);
        const lastWeekStart = new Date(weekStart);
        lastWeekStart.setDate(weekStart.getDate() - 7);
        const dates = [];
        for (let i = 0; i < 7; i++) {
            const d = new Date(lastWeekStart);
            d.setDate(lastWeekStart.getDate() + i);
            dates.push(dateToISO(d));
        }
        return dates;
    }

    // ── SafeStorage ──
    function getSnapshots() {
        return SafeStorage.getItem(STORAGE_KEY, []);
    }

    function saveSnapshots(snapshots) {
        // Keep last 90 days of snapshots locally (about 3 months)
        if (snapshots.length > 90) snapshots = snapshots.slice(-90);
        SafeStorage.setItem(STORAGE_KEY, snapshots);
    }

    function getSnapshotByDate(dateISO) {
        const snapshots = getSnapshots();
        return snapshots.find(s => s.snapshot_date === dateISO) || null;
    }

    function upsertLocalSnapshot(snapshotObj) {
        const snapshots = getSnapshots();
        const idx = snapshots.findIndex(s => s.snapshot_date === snapshotObj.snapshot_date);
        if (idx >= 0) {
            // Update existing — merge, prefer newer values
            snapshots[idx] = { ...snapshots[idx], ...snapshotObj, updated_at: new Date().toISOString() };
        } else {
            snapshots.push({ ...snapshotObj, created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
        }
        saveSnapshots(snapshots);
    }

    // ── Backlog Helper ──
    function toBool(value) {
        return value === true || value === 'true';
    }

    function isRealBacklog(status) {
        if (!status || typeof status !== 'object') return false;
        if (status._scheduledFor) return false;
        const read  = toBool(status.read);
        const notes = toBool(status.notes);
        const pyq   = toBool(status.pyq);
        const started   = read || notes || pyq;
        const completed = read && notes && pyq;
        return started && !completed;
    }

    function isCompletedBacklog(status) {
        if (!status || typeof status !== 'object') return false;
        if (status._scheduledFor) return false;
        return toBool(status.read) && toBool(status.notes) && toBool(status.pyq);
    }

    // ── Data Collection ──
    function getFocusSessionsForDate(dateISO) {
        const sessions = (typeof TimerEngine !== 'undefined')
            ? TimerEngine.getSessions()
            : (SafeStorage.getItem('focus_sessions_log', []));
        return sessions.filter(s => s.session_date === dateISO && s.completed);
    }

    function getPPEarnedForDate(dateISO) {
        // PulseEngine stores dailyEarned for today only
        // For historical dates, we check the snapshot or use focus session pp_earned sum
        const today = todayISO();
        if (dateISO === today && typeof PulseEngine !== 'undefined') {
            return PulseEngine.data.dailyEarned || 0;
        }
        // For past dates, sum focus session PP earned
        const sessions = getFocusSessionsForDate(dateISO);
        let ppFromSessions = sessions.reduce((sum, s) => sum + (s.pp_earned || 0), 0);
        // Also check saved snapshot for tasks/mission PP
        const snap = getSnapshotByDate(dateISO);
        if (snap && snap.pp_earned > ppFromSessions) {
            return snap.pp_earned;
        }
        return ppFromSessions;
    }

    function getBacklogsClearedForDate(dateISO) {
        // We count completed backlog chapters from smartPadhaiData
        // For today, count freshly completed; for past, rely on snapshots
        const today = todayISO();
        if (dateISO !== today) {
            const snap = getSnapshotByDate(dateISO);
            return snap ? (snap.backlogs_cleared || 0) : 0;
        }
        // For today: count chapters with all 3 tasks done
        const backlogs = SafeStorage.getItem('smartPadhaiData', {});
        let cleared = 0;
        for (const chap in backlogs) {
            if (isCompletedBacklog(backlogs[chap])) cleared++;
        }
        return cleared;
    }

    // ── Consistency Score Algorithm ──
    // Score out of 100, based on 4 weighted pillars:
    //   - PP Earned (30 pts max): dailyEarned / 50 * 30, capped at 30
    //   - Focus Minutes (25 pts max): focusMinutes / 60 * 25, capped at 25
    //   - Sessions Completed (25 pts max): sessions / 4 * 25, capped at 25
    //   - Backlog Progress (20 pts max): cleared / 3 * 20, capped at 20
    function computeConsistencyScore(ppEarned, focusMinutes, sessionsCompleted, backlogsCleared) {
        const ppScore         = Math.min(30, Math.round((ppEarned / 50) * 30));
        const focusScore      = Math.min(25, Math.round((focusMinutes / 60) * 25));
        const sessionScore    = Math.min(25, Math.round((sessionsCompleted / 4) * 25));
        const backlogScore    = Math.min(20, Math.round((backlogsCleared / 3) * 20));

        const total = ppScore + focusScore + sessionScore + backlogScore;
        return Math.min(100, Math.max(0, total));
    }

    // ── Core: Compute Daily Snapshot ──
    function computeSnapshot(dateISO) {
        const sessions = getFocusSessionsForDate(dateISO);
        const sessionsCompleted = sessions.length;
        const focusMinutes = sessions.reduce((sum, s) => sum + (s.duration_minutes || 0), 0);
        const ppEarned = getPPEarnedForDate(dateISO);
        const backlogsCleared = getBacklogsClearedForDate(dateISO);
        const consistencyScore = computeConsistencyScore(ppEarned, focusMinutes, sessionsCompleted, backlogsCleared);

        return {
            snapshot_date:     dateISO,
            pp_earned:         ppEarned,
            backlogs_cleared:  backlogsCleared,
            sessions_completed: sessionsCompleted,
            focus_minutes:     focusMinutes,
            consistency_score: consistencyScore
        };
    }

    // ── Supabase Sync ──
async function syncSnapshotToSupabase(snapshotObj) {
    try {
        if (!window.supabaseClient) {
            console.warn("[GraphEngine] No Supabase client — skipping sync");
            return null;
        }

        const { data: userData, error: userError } =
            await window.supabaseClient.auth.getUser();

        if (userError || !userData?.user?.id) {
            console.warn("[GraphEngine] No active user — skipping sync", userError);
            return null;
        }

        const userId = userData.user.id;

        const row = {
            user_id: userId,
            snapshot_date: snapshotObj.snapshot_date,
            pp_earned: Number(snapshotObj.pp_earned || 0),
            backlogs_cleared: Number(snapshotObj.backlogs_cleared || 0),
            sessions_completed: Number(snapshotObj.sessions_completed || 0),
            focus_minutes: Number(snapshotObj.focus_minutes || 0),
            consistency_score: Number(snapshotObj.consistency_score || 0),
            updated_at: new Date().toISOString()
        };

        const { data, error } = await window.supabaseClient
            .from("productivity_snapshots")
            .upsert(row, {
                onConflict: "user_id,snapshot_date"
            })
            .select();

        if (error) {
            console.error("[GraphEngine] Supabase snapshot sync error:", error);
            return null;
        }

        console.info("[GraphEngine] Snapshot synced to Supabase:", data);
        return data;
    } catch (err) {
        console.error("[GraphEngine] Supabase sync exception:", err);
        return null;
    }
}

    // ── Load Supabase snapshots into local cache ──
    async function loadSnapshotsFromSupabase() {
        try {
            if (!window.supabaseClient) return;

            const { data: userData } = await window.supabaseClient.auth.getUser();
            const userId = userData?.user?.id;
            if (!userId) return;

            // Fetch last 14 days of snapshots
            const twoWeeksAgo = new Date();
            twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);
            const since = dateToISO(twoWeeksAgo);

            const { data, error } = await window.supabaseClient
                .from('productivity_snapshots')
                .select('*')
                .eq('user_id', userId)
                .gte('snapshot_date', since)
                .order('snapshot_date', { ascending: true });

            if (error) {
                console.warn('[GraphEngine] Supabase load error:', error.message);
                return;
            }

            if (data && data.length > 0) {
                const localSnapshots = getSnapshots();
                data.forEach(row => {
                    const snapObj = {
                        snapshot_date:      row.snapshot_date,
                        pp_earned:          row.pp_earned || 0,
                        backlogs_cleared:   row.backlogs_cleared || 0,
                        sessions_completed: row.sessions_completed || 0,
                        focus_minutes:      row.focus_minutes || 0,
                        consistency_score:  row.consistency_score || 0,
                        created_at:         row.created_at,
                        updated_at:         row.updated_at
                    };
                    const idx = localSnapshots.findIndex(s => s.snapshot_date === row.snapshot_date);
                    if (idx >= 0) {
                        // Merge: take the one with higher pp_earned (more complete data)
                        if (row.pp_earned > localSnapshots[idx].pp_earned) {
                            localSnapshots[idx] = snapObj;
                        }
                    } else {
                        localSnapshots.push(snapObj);
                    }
                });
                saveSnapshots(localSnapshots);
                console.info('[GraphEngine] Loaded', data.length, 'snapshots from Supabase');
            }
        } catch (err) {
            console.warn('[GraphEngine] Supabase load error:', err.message);
        }
    }

    // ── Public: Record Today's Snapshot ──
    async function recordTodaySnapshot() {
        const today = todayISO();
        const snapshot = computeSnapshot(today);
        upsertLocalSnapshot(snapshot);
        // Fire-and-forget sync to Supabase
        syncSnapshotToSupabase(snapshot);
        return snapshot;
    }

    // ── Public: Get Comparison Data ──
    function getTodayVsYesterday() {
        const todaySnap  = computeSnapshot(todayISO());
        const yesterdaySnap = getSnapshotByDate(yesterdayISO()) || computeSnapshot(yesterdayISO());

        return {
            today:     todaySnap,
            yesterday: yesterdaySnap,
            deltas: {
                pp_earned:         todaySnap.pp_earned - yesterdaySnap.pp_earned,
                focus_minutes:     todaySnap.focus_minutes - yesterdaySnap.focus_minutes,
                sessions_completed: todaySnap.sessions_completed - yesterdaySnap.sessions_completed,
                backlogs_cleared:  todaySnap.backlogs_cleared - yesterdaySnap.backlogs_cleared,
                consistency_score: todaySnap.consistency_score - yesterdaySnap.consistency_score
            }
        };
    }

    function getThisWeekVsLastWeek() {
        const thisWeekDates  = getWeekDates();
        const lastWeekDates  = getLastWeekDates();
        const snapshots      = getSnapshots();

        function sumWeek(dates) {
            let pp = 0, focus = 0, sessions = 0, backlogs = 0, score = 0, count = 0;
            dates.forEach(dateISO => {
                // Try live compute for today, otherwise use cached snapshot
                let snap;
                if (dateISO === todayISO()) {
                    snap = computeSnapshot(dateISO);
                } else {
                    snap = snapshots.find(s => s.snapshot_date === dateISO);
                }
                if (snap) {
                    pp       += snap.pp_earned || 0;
                    focus    += snap.focus_minutes || 0;
                    sessions += snap.sessions_completed || 0;
                    backlogs += snap.backlogs_cleared || 0;
                    score    += snap.consistency_score || 0;
                    count++;
                }
            });
            return {
                pp_earned:         pp,
                focus_minutes:     focus,
                sessions_completed: sessions,
                backlogs_cleared:  backlogs,
                avg_consistency:   count > 0 ? Math.round(score / count) : 0,
                days_with_data:    count
            };
        }

        const thisWeek = sumWeek(thisWeekDates);
        const lastWeek = sumWeek(lastWeekDates);

        return {
            thisWeek,
            lastWeek,
            deltas: {
                pp_earned:         thisWeek.pp_earned - lastWeek.pp_earned,
                focus_minutes:     thisWeek.focus_minutes - lastWeek.focus_minutes,
                sessions_completed: thisWeek.sessions_completed - lastWeek.sessions_completed,
                backlogs_cleared:  thisWeek.backlogs_cleared - lastWeek.backlogs_cleared
            }
        };
    }

    function getWeekBarData(metric = 'focus_minutes') {
        const weekDates  = getWeekDates();
        const snapshots  = getSnapshots();
        const maxVal     = { focus_minutes: 120, pp_earned: 100, sessions_completed: 6, consistency_score: 100 };
        const cap        = maxVal[metric] || 100;

        return weekDates.map((dateISO, i) => {
            let snap;
            if (dateISO === todayISO()) {
                snap = computeSnapshot(dateISO);
            } else {
                snap = snapshots.find(s => s.snapshot_date === dateISO);
            }
            const value = snap ? (snap[metric] || 0) : 0;
            const isToday = dateISO === todayISO();
            return {
                label:     DAY_LABELS[i],
                dateISO:   dateISO,
                value:     value,
                pct:       Math.min(100, Math.round((value / cap) * 100)),
                isToday:   isToday
            };
        });
    }

    // ── Public: Backfill historical snapshots ──
    async function backfillThisWeek() {
        const weekDates = getWeekDates();
        let filled = 0;
        weekDates.forEach(dateISO => {
            if (dateISO <= todayISO()) {
                const snapshot = computeSnapshot(dateISO);
                upsertLocalSnapshot(snapshot);
                syncSnapshotToSupabase(snapshot);
                filled++;
            }
        });
        console.info('[GraphEngine] Backfilled', filled, 'days');
        return filled;
    }

    // ── Public: Render Dashboard UI ──
    function renderDashboard() {
        renderTodayVsYesterday();
        renderWeekComparison();
        renderWeekBars();
        renderConsistencyScore();
        renderPPSparkline();
    }

    function renderTodayVsYesterday() {
        const data = getTodayVsYesterday();
        const t = data.today;
        const d = data.deltas;

        // Update Today Stats cards
        setText('ge-today-pp', t.pp_earned);
        setText('ge-today-focus', t.focus_minutes + ' min');
        setText('ge-today-sessions', t.sessions_completed);
        setText('ge-today-backlogs', t.backlogs_cleared);

        // Update deltas with trend arrows
        setDelta('ge-delta-pp', d.pp_earned);
        setDelta('ge-delta-focus', d.focus_minutes);
        setDelta('ge-delta-sessions', d.sessions_completed);
        setDelta('ge-delta-backlogs', d.backlogs_cleared);
    }

    function renderWeekComparison() {
        const data = getThisWeekVsLastWeek();
        const tw = data.thisWeek;
        const lw = data.lastWeek;
        const d  = data.deltas;

        setText('ge-week-pp', tw.pp_earned);
        setText('ge-week-focus', tw.focus_minutes + ' min');
        setText('ge-week-sessions', tw.sessions_completed);
        setText('ge-week-backlogs', tw.backlogs_cleared);
        setText('ge-week-consistency', tw.avg_consistency + '/100');

        setDelta('ge-week-delta-pp', d.pp_earned);
        setDelta('ge-week-delta-focus', d.focus_minutes);
        setDelta('ge-week-delta-sessions', d.sessions_completed);
        setDelta('ge-week-delta-backlogs', d.backlogs_cleared);
    }

    function renderWeekBars() {
        // Determine active metric from toggle buttons
        const activeBtn = document.querySelector('.ge-metric-btn.active');
        const metric = activeBtn ? activeBtn.dataset.metric : 'focus_minutes';

        const barData = getWeekBarData(metric);
        const container = document.getElementById('ge-week-bars');
        if (!container) return;

        const bars = container.querySelectorAll('.ge-day-bar');
        barData.forEach((d, i) => {
            if (bars[i]) {
                const fill = bars[i].querySelector('.ge-bar-fill');
                const label = bars[i].querySelector('.ge-bar-label');
                const valueLabel = bars[i].querySelector('.ge-bar-value');
                if (fill) fill.style.height = d.pct + '%';
                if (fill) {
                    fill.classList.toggle('ge-bar-current', d.isToday);
                }
                if (label) label.textContent = d.label;
                if (valueLabel) valueLabel.textContent = d.value;
            }
        });

        // Update summary stats below bars
        const totalFocus = barData.reduce((s, d) => s + d.value, 0);
        const metricLabels = {
            focus_minutes: 'Focus',
            pp_earned: 'PP',
            sessions_completed: 'Sessions',
            consistency_score: 'Score'
        };
        setText('ge-bar-metric-label', metricLabels[metric] || 'Focus');
        setText('ge-bar-total', totalFocus);

        // Also update sessions and avg score in summary
        const sessionData = getWeekBarData('sessions_completed');
        const totalSessions = sessionData.reduce((s, d) => s + d.value, 0);
        setText('ge-bar-sessions', totalSessions);

        const scoreData = getWeekBarData('consistency_score');
        const scoreDays = scoreData.filter(d => d.value > 0);
        const avgScore = scoreDays.length > 0 ? Math.round(scoreDays.reduce((s, d) => s + d.value, 0) / scoreDays.length) : 0;
        setText('ge-bar-avg-score', avgScore);
    }

    function renderPPSparkline() {
        const weekDates = getWeekDates();
        const snapshots = getSnapshots();

        const sparkContainer = document.getElementById('ge-pp-sparkline');
        if (!sparkContainer) return;

        const ppValues = weekDates.map(dateISO => {
            if (dateISO === todayISO()) {
                const snap = computeSnapshot(dateISO);
                return snap.pp_earned || 0;
            }
            const snap = snapshots.find(s => s.snapshot_date === dateISO);
            return snap ? (snap.pp_earned || 0) : 0;
        });

        const maxPP = Math.max(1, ...ppValues);
        const sparkBars = sparkContainer.querySelectorAll('.ge-spark-bar');

        ppValues.forEach((val, i) => {
            if (sparkBars[i]) {
                const pct = Math.max(5, Math.round((val / maxPP) * 100));
                sparkBars[i].style.height = pct + '%';
            }
        });
    }

    function renderConsistencyScore() {
        const todaySnap = computeSnapshot(todayISO());
        const score = todaySnap.consistency_score;

        // Update the score ring
        setText('ge-consistency-value', score);

        // Update the SVG ring (circumference = 2 * PI * 42 = ~263.9)
        const circle = document.getElementById('ge-consistency-ring');
        if (circle) {
            const circumference = 2 * Math.PI * 42;
            circle.style.strokeDasharray = circumference;
            const offset = circumference - (score / 100) * circumference;
            circle.style.strokeDashoffset = offset;
        }

        // Update score breakdown
        const ppScore      = Math.min(30, Math.round((todaySnap.pp_earned / 50) * 30));
        const focusScore   = Math.min(25, Math.round((todaySnap.focus_minutes / 60) * 25));
        const sessionScore = Math.min(25, Math.round((todaySnap.sessions_completed / 4) * 25));
        const backlogScore = Math.min(20, Math.round((todaySnap.backlogs_cleared / 3) * 20));

        setText('ge-score-pp', ppScore + '/30');
        setText('ge-score-focus', focusScore + '/25');
        setText('ge-score-sessions', sessionScore + '/25');
        setText('ge-score-backlogs', backlogScore + '/20');
    }

    // ── UI Helpers ──
    function setText(id, value) {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    }

    function setDelta(id, deltaValue) {
        const el = document.getElementById(id);
        if (!el) return;
        if (deltaValue > 0) {
            el.textContent = '+' + deltaValue;
            el.className = 'ge-delta ge-delta-up';
        } else if (deltaValue < 0) {
            el.textContent = String(deltaValue);
            el.className = 'ge-delta ge-delta-down';
        } else {
            el.textContent = '0';
            el.className = 'ge-delta ge-delta-neutral';
        }
    }

    // ── Initialize ──
    async function init() {
        // Load any existing Supabase data
        await loadSnapshotsFromSupabase();

        // Record today's snapshot
        await recordTodaySnapshot();

        // Render dashboard
        renderDashboard();

        console.info('[GraphEngine] Initialized');
    }

    // ── Public API ──
    return {
        init,
        recordTodaySnapshot,
        renderDashboard,
        renderWeekBars,
        renderTodayVsYesterday,
        renderWeekComparison,
        renderConsistencyScore,
        backfillThisWeek,
        computeSnapshot,
        computeConsistencyScore,
        getTodayVsYesterday,
        getThisWeekVsLastWeek,
        getWeekBarData,
        getSnapshots,
        getSnapshotByDate,
        DAY_LABELS
    };
})();
window.GraphEngine = GraphEngine;

// ── Auto-init on DOM ready (after other modules) ──
// __SPA_MODE GUARD: In SPA mode, the dashboardRoute handles initialization.
// The DOMContentLoaded auto-init is disabled to prevent duplicate listeners
// and rendering before the dashboard DOM exists.
if (!window.__SPA_MODE) {
document.addEventListener('DOMContentLoaded', () => {
    // Wire metric toggle buttons
    document.querySelectorAll('.ge-metric-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.ge-metric-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            GraphEngine.renderWeekBars();
        });
    });

    // Wire backfill button
    const backfillBtn = document.getElementById('ge-backfill-btn');
    if (backfillBtn) {
        backfillBtn.addEventListener('click', () => {
            GraphEngine.backfillThisWeek().then(() => {
                GraphEngine.renderDashboard();
            });
        });
    }

    // Delay init slightly so other modules (PulseEngine, TimerEngine) load first
    setTimeout(() => GraphEngine.init(), 800);
});
} // end __SPA_MODE guard
