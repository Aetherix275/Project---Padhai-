/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — CALENDAR ROUTE MODULE (Phase 7E-3)
 *  Full SPA conversion of Strategic Planning Area / Calendar
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear state
 *
 *  Key improvements over legacy:
 *    - NO prompt() — uses inline modal for event description input
 *    - NO confirm() — uses inline confirm dialog for delete
 *    - NO alert()   — uses toast notification for "select mode first"
 *    - Updates shared next-exam sidebar after calendar changes
 *
 *  Data: SafeStorage-first, Supabase mirror second
 *  Events: All via event delegation + AbortController. Zero inline onclick.
 *
 *  Phase 7E-3: Calendar Reskin — visual strength only.
 *  No logic changes. All IDs, data-actions, storage keys preserved.
 * ═══════════════════════════════════════════════════════════════════
 */

const CalendarRoute = (() => {

    // ── Private state ──
    let _container = null;
    let _abortController = null;
    let _viewDate = null;
    let _strategyData = {};
    let _currentMode = null;
    let _cssLinkEl = null;

    const CSS_PATH = './styles/modules/calendar.css';

    const MONTHS = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE",
                    "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════

    async function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;

        // Load CSS
        _loadCSS();

        // Init state
        const now = new Date();
        _viewDate = new Date(2026, now.getMonth(), 1);
        _strategyData = SafeStorage.getItem('calendarStrategy', {});
        _currentMode = null;

        // Try loading from cloud (best-effort merge, Phase 8D)
        await _loadFromCloud();

        // Render
        container.innerHTML = renderFullUI();
        _renderCalendar();

        // Bind events
        _bindEvents(container, _abortController.signal);

        console.log('[CalendarRoute] Initialized');
    }

    function cleanup() {
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }
        // Remove any open modals
        document.querySelectorAll('.cal-modal-overlay').forEach(el => el.remove());
        _unloadCSS();
        _container = null;
        _strategyData = {};
        _currentMode = null;
        console.log('[CalendarRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.calendarCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-calendar-css]');
        if (el) { el.remove(); _cssLinkEl = null; }
    }

    // ════════════════════════════════════════════════════════
    //  SUPABASE SYNC (Phase 8D — via SPSyncManager)
    // ════════════════════════════════════════════════════════

    async function _loadFromCloud() {
        // Use SPSyncManager if available, else fall back to direct Supabase
        if (window.SPSyncManager) {
            try {
                const rows = await SPSyncManager.loadFromCloud('calendar_events', {
                    columns: 'source_key,mode,text,updated_at',
                    statusKey: 'source_key'
                });
                if (!rows || rows.length === 0) return;
                _mergeCloudRows(rows);
            } catch (err) {
                console.warn('[CalendarRoute] SPSyncManager load failed:', err);
                await _loadFromSupabaseDirect();
            }
        } else {
            await _loadFromSupabaseDirect();
        }
    }

    function _mergeCloudRows(rows) {
        const local = SafeStorage.getItem('calendarStrategy', {});
        let merged = false;

        rows.forEach(row => {
            if (!row.source_key) return;
            if (!local[row.source_key]) {
                local[row.source_key] = {
                    mode: row.mode || 'exam',
                    text: row.text || ''
                };
                merged = true;
            }
        });

        if (merged) {
            SafeStorage.setItem('calendarStrategy', local);
            _strategyData = local;
        }
    }

    async function _loadFromSupabaseDirect() {
        // Direct Supabase fallback (when SPSyncManager is unavailable)
        if (!window.supabaseClient) return;
        try {
            const rows = await fetchUserRows('calendar_events');
            if (!rows || rows.length === 0) return;
            _mergeCloudRows(rows);
        } catch (err) {
            console.warn('[CalendarRoute] Direct Supabase load failed:', err);
        }
    }

    function _enqueueEventUpsert(dateKey) {
        const entry = _strategyData[dateKey];
        if (!entry) return;

        if (window.SPSyncManager) {
            SPSyncManager.enqueue('calendar_events', {
                source_key: dateKey,
                mode: entry.mode,
                text: entry.text,
                updated_at: new Date().toISOString()
            }, { conflictKey: 'user_id,source_key' });
        } else {
            // Direct Supabase fallback
            _directUpsertEvent(dateKey);
        }
    }

    function _enqueueEventDelete(dateKey) {
        if (window.SPSyncManager) {
            SPSyncManager.enqueue('calendar_events', {}, {
                operation: 'delete',
                deleteFilter: 'source_key',
                deleteValue: dateKey
            });
        } else {
            // Direct Supabase fallback — no-op for delete (best effort)
            _directUpsertEvent(dateKey);
        }
    }

    async function _directUpsertEvent(dateKey) {
        if (!window.supabaseClient) return;
        try {
            const userId = localStorage.getItem('_current_user_id');
            if (!userId) return;
            const entry = _strategyData[dateKey];
            if (!entry) return;
            await window.supabaseClient
                .from('calendar_events')
                .upsert({
                    user_id: userId,
                    source_key: dateKey,
                    mode: entry.mode,
                    text: entry.text,
                    updated_at: new Date().toISOString()
                }, { onConflict: 'user_id,source_key' });
        } catch (err) {
            console.warn('[CalendarRoute] Direct upsert error:', err);
        }
    }

    // ════════════════════════════════════════════════════════
    //  SIDEBAR UPDATE (shared with app-init.js)
    // ════════════════════════════════════════════════════════

    function _updateNextExamSidebar() {
        const localStrategyData = SafeStorage.getItem('calendarStrategy', {});
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        let nextExamDate = null;
        let minDiff = Infinity;

        for (const key in localStrategyData) {
            if (localStrategyData[key].mode === 'exam') {
                const examDate = _parseDateKey(key);
                if (examDate >= today) {
                    const diffTime = examDate - today;
                    if (diffTime < minDiff) {
                        minDiff = diffTime;
                        nextExamDate = examDate;
                    }
                }
            }
        }

        const el = document.getElementById('nextExamCountdown');
        if (!el) return;

        if (nextExamDate) {
            const daysLeft = Math.ceil(minDiff / (1000 * 60 * 60 * 24));
            el.innerHTML = `<svg class="urgency-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg><span class="urgency-text">NEXT EXAM: ${daysLeft} DAYS</span>`;
            el.style.display = 'flex';
        } else {
            el.innerHTML = `<svg class="urgency-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg><span class="urgency-text">NO UPCOMING EXAMS</span>`;
        }
    }

    // ════════════════════════════════════════════════════════
    //  DATE UTILITIES
    // ════════════════════════════════════════════════════════

    function _makeDateKey(year, monthIndex, day) {
        const month = String(monthIndex + 1).padStart(2, '0');
        const date = String(day).padStart(2, '0');
        return `${year}-${month}-${date}`;
    }

    function _parseDateKey(dateKey) {
        const [year, month, day] = dateKey.split('-').map(Number);
        return new Date(year, month - 1, day); // month - 1 fix
    }

    // ════════════════════════════════════════════════════════
    //  HTML RENDERING
    // ════════════════════════════════════════════════════════

    function renderFullUI() {
        return `
        <div id="strategy-map-page">
            <div class="strategy-header">
                <div class="header-main">
                    <h1 class="zone-title">STRATEGIC MAP</h1>
                    <p class="zone-subtitle">Tactical deployment & milestone tracker</p>
                </div>
                <div class="strategy-controls">
                    <button class="strat-btn exam sp-btn" data-action="set-mode" data-mode="exam">
                        <span class="btn-icon">\uD83D\uDEA9</span> EXAM
                    </button>
                    <button class="strat-btn holiday sp-btn" data-action="set-mode" data-mode="holiday">
                        <span class="btn-icon">\uD83C\uDFD6\uFE0F</span> HOLIDAY
                    </button>
                    <button class="strat-btn special sp-btn" data-action="set-mode" data-mode="special">
                        <span class="btn-icon">\u2B50</span> SPECIAL
                    </button>
                </div>
            </div>

            <div class="calendar-container">
                <div class="calendar-header-nav">
                    <button class="nav-arrow sp-btn" data-action="change-month" data-offset="-1">\u25C0</button>
                    <div class="calendar-month-year" id="currentMonthYear"></div>
                    <button class="nav-arrow sp-btn" data-action="change-month" data-offset="1">\u25B6</button>
                </div>

                <div class="cal-legend">
                    <span class="cal-legend-item"><span class="cal-legend-dot dot-exam"></span> Exam</span>
                    <span class="cal-legend-item"><span class="cal-legend-dot dot-holiday"></span> Holiday</span>
                    <span class="cal-legend-item"><span class="cal-legend-dot dot-special"></span> Special</span>
                    <span class="cal-legend-item"><span class="cal-legend-dot dot-today"></span> Today</span>
                    <span class="cal-legend-item"><span class="cal-legend-dot dot-productive"></span> Productive</span>
                    <span class="cal-legend-item"><span class="cal-legend-dot dot-wasted"></span> Wasted</span>
                </div>

                <div class="calendar-grid">
                    <div class="day-name">Sun</div><div class="day-name">Mon</div><div class="day-name">Tue</div>
                    <div class="day-name">Wed</div><div class="day-name">Thu</div><div class="day-name">Fri</div>
                    <div class="day-name">Sat</div>
                    <div id="calendarDates" class="dates-wrapper"></div>
                </div>
            </div>
        </div>
        <div class="cal-toast" id="calToast"></div>`;
    }

    function _renderCalendar() {
        const container = _container?.querySelector('#calendarDates');
        const monthYearDisplay = _container?.querySelector('#currentMonthYear');
        if (!container) return;

        container.innerHTML = '';

        const year = _viewDate.getFullYear();
        const month = _viewDate.getMonth();
        const dailyStats = SafeStorage.getItem('dailyStats', {});

        monthYearDisplay.innerText = `${MONTHS[month]} ${year}`;

        const firstDayIndex = new Date(year, month, 1).getDay();
        const lastDay = new Date(year, month + 1, 0).getDate();
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        // Empty slots before first day
        for (let s = 0; s < firstDayIndex; s++) {
            const emptySlot = document.createElement('div');
            container.appendChild(emptySlot);
        }

        // Track if any strategic events exist this month
        let hasEventsThisMonth = false;

        // Date boxes
        for (let i = 1; i <= lastDay; i++) {
            const dateBox = document.createElement('div');
            dateBox.className = 'date-box';

            const dateKey = _makeDateKey(year, month, i);
            const checkDateObj = new Date(year, month, i);
            const checkDateStr = checkDateObj.toDateString();

            const dateNum = document.createElement('span');
            dateNum.className = 'date-number';
            dateNum.innerText = i;
            dateBox.appendChild(dateNum);

            // Past day status
            if (checkDateObj < today) {
                dateBox.classList.add('past-dull');
                const statusTag = document.createElement('div');
                statusTag.className = 'day-status';
                if (dailyStats[checkDateStr] > 0) {
                    statusTag.innerText = 'PRODUCTIVE';
                    statusTag.classList.add('status-productive');
                } else {
                    statusTag.innerText = 'WASTED';
                    statusTag.classList.add('status-wasted');
                }
                dateBox.appendChild(statusTag);
            }

            // Strategy data
            if (_strategyData[dateKey]) {
                dateBox.classList.add('has-data', `${_strategyData[dateKey].mode}-day`);
                const desc = document.createElement('div');
                desc.className = 'date-desc';
                desc.innerText = _strategyData[dateKey].text;
                dateBox.appendChild(desc);
                hasEventsThisMonth = true;
            }

            // Today highlight
            if (checkDateStr === today.toDateString()) dateBox.classList.add('today');

            // Click handler via data attributes
            dateBox.dataset.action = 'date-click';
            dateBox.dataset.day = i;
            dateBox.dataset.month = month;
            dateBox.dataset.year = year;

            container.appendChild(dateBox);
        }

        // Show empty state message if no events this month
        _updateEmptyState(hasEventsThisMonth);
    }

    // ── Empty state for months with no events ──
    function _updateEmptyState(hasEvents) {
        // Remove existing empty state
        const existing = _container?.querySelector('.cal-empty-state');
        if (existing) existing.remove();

        if (!hasEvents) {
            const calContainer = _container?.querySelector('.calendar-container');
            if (!calContainer) return;
            const emptyEl = document.createElement('div');
            emptyEl.className = 'cal-empty-state';
            emptyEl.innerHTML = `<span class="cal-empty-icon">\uD83D\uDCC5</span> No strategic events this month. Select a mode and click a date to add one.`;
            calContainer.appendChild(emptyEl);
        }
    }

    // ════════════════════════════════════════════════════════
    //  CALENDAR ACTIONS
    // ════════════════════════════════════════════════════════

    function _changeMonth(offset) {
        _viewDate.setMonth(_viewDate.getMonth() + offset);
        if (_viewDate.getFullYear() > 2026) _viewDate.setFullYear(2026, 11, 1);
        if (_viewDate.getFullYear() < 2026) _viewDate.setFullYear(2026, 0, 1);
        _renderCalendar();
    }

    function _setMode(mode) {
        _currentMode = mode;
        if (!_container) return;
        _container.querySelectorAll('.strat-btn').forEach(btn => btn.classList.remove('active-mode'));
        const targetBtn = _container.querySelector(`.strat-btn.${mode}`);
        if (targetBtn) targetBtn.classList.add('active-mode');
    }

    function _handleDateClick(day, month, year) {
        if (!_currentMode) {
            _showToast('\u26A0\uFE0F Select a Mode first (Exam/Holiday/Special)!');
            return;
        }

        const dateKey = _makeDateKey(year, month, day);
        const monthName = MONTHS[month];

        // If entry already exists → show delete confirm modal
        if (_strategyData[dateKey]) {
            _showDeleteConfirm(dateKey, day, monthName);
            return;
        }

        // Show input modal for new entry
        _showEntryModal(dateKey, day, monthName);
    }

    // ── Modal: New Entry Input (replaces prompt()) ──
    function _showEntryModal(dateKey, day, monthName) {
        // Remove any existing modal
        document.querySelectorAll('.cal-modal-overlay').forEach(el => el.remove());

        const overlay = document.createElement('div');
        overlay.className = 'cal-modal-overlay';
        overlay.innerHTML = `
            <div class="cal-modal-box">
                <div class="cal-modal-title">Enter ${_currentMode.toUpperCase()} details for ${day} ${monthName}:</div>
                <input type="text" class="cal-modal-input sp-input" id="calEntryInput" placeholder="e.g. Maths Final Exam" autofocus>
                <div class="cal-modal-btns">
                    <button class="cal-modal-cancel sp-btn" data-action="modal-cancel">Cancel</button>
                    <button class="cal-modal-confirm sp-btn" data-action="modal-confirm-add">Add</button>
                </div>
            </div>`;

        document.body.appendChild(overlay);

        // Focus the input
        setTimeout(() => {
            const input = overlay.querySelector('#calEntryInput');
            if (input) input.focus();
        }, 50);

        // Store dateKey for later use
        overlay.dataset.dateKey = dateKey;
    }

    // ── Modal: Delete Confirm (replaces confirm()) ──
    function _showDeleteConfirm(dateKey, day, monthName) {
        document.querySelectorAll('.cal-modal-overlay').forEach(el => el.remove());

        const overlay = document.createElement('div');
        overlay.className = 'cal-modal-overlay';
        overlay.innerHTML = `
            <div class="cal-modal-box">
                <div class="cal-modal-title">Entry exists for ${day} ${monthName}. Delete it?</div>
                <div class="cal-modal-btns">
                    <button class="cal-modal-cancel sp-btn" data-action="modal-cancel">Cancel</button>
                    <button class="cal-modal-delete sp-btn" data-action="modal-confirm-delete">Delete</button>
                </div>
            </div>`;

        document.body.appendChild(overlay);
        overlay.dataset.dateKey = dateKey;
    }

    function _confirmAddEntry() {
        const overlay = document.querySelector('.cal-modal-overlay');
        if (!overlay) return;

        const dateKey = overlay.dataset.dateKey;
        const input = overlay.querySelector('#calEntryInput');
        const description = input ? input.value.trim() : '';

        if (!description) {
            overlay.remove();
            return;
        }

        _strategyData[dateKey] = { mode: _currentMode, text: description };
        SafeStorage.setItem('calendarStrategy', _strategyData);
        _enqueueEventUpsert(dateKey);

        overlay.remove();
        _renderCalendar();
        _updateNextExamSidebar();
        _showToast(`${_currentMode.charAt(0).toUpperCase() + _currentMode.slice(1)} added!`, true);
    }

    function _confirmDeleteEntry() {
        const overlay = document.querySelector('.cal-modal-overlay');
        if (!overlay) return;

        const dateKey = overlay.dataset.dateKey;
        delete _strategyData[dateKey];
        SafeStorage.setItem('calendarStrategy', _strategyData);
        _enqueueEventDelete(dateKey);

        overlay.remove();
        _renderCalendar();
        _updateNextExamSidebar();
        _showToast('Entry deleted.', true);
    }

    function _cancelModal() {
        document.querySelectorAll('.cal-modal-overlay').forEach(el => el.remove());
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {
        // Click delegation on route container
        container.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;

            switch (action) {
                case 'set-mode':
                    _setMode(target.dataset.mode);
                    break;
                case 'change-month':
                    _changeMonth(parseInt(target.dataset.offset));
                    break;
                case 'date-click':
                    const day = parseInt(target.dataset.day);
                    const month = parseInt(target.dataset.month);
                    const year = parseInt(target.dataset.year);
                    _handleDateClick(day, month, year);
                    break;
            }
        }, { signal });

        // Modal events on document (for cal-modal buttons appended to body)
        _bindModalEvents(signal);
    }

    // Also bind modal buttons (they live on document.body, not route container)
    // Uses AbortController so cleanup() removes them properly
    function _bindModalEvents(signal) {
        document.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;
            switch (action) {
                case 'modal-cancel':
                    _cancelModal();
                    break;
                case 'modal-confirm-add':
                    _confirmAddEntry();
                    break;
                case 'modal-confirm-delete':
                    _confirmDeleteEntry();
                    break;
            }
        }, { signal });

        // Handle Enter key in modal input
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && e.target.id === 'calEntryInput') {
                _confirmAddEntry();
            } else if (e.key === 'Escape') {
                _cancelModal();
            }
        }, { signal });
    }

    // ════════════════════════════════════════════════════════
    //  TOAST
    // ════════════════════════════════════════════════════════

    function _showToast(message, success = false) {
        const toast = _container?.querySelector('#calToast');
        if (!toast) return;

        toast.textContent = message;
        toast.className = `cal-toast ${success ? 'success' : ''} visible`;
        setTimeout(() => {
            toast.classList.remove('visible');
        }, 2800);
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();

window.CalendarRoute = CalendarRoute;
