/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — BACKLOG ROUTE MODULE (Phase 8D-3)
 *  Full SPA conversion of Backlog Battle
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear timers
 *
 *  Backlog Calculation Rule (MANDATORY):
 *    started    = read || notes || pyq
 *    completed  = read && notes && pyq
 *    realBacklog = started && !completed
 *    Untouched chapters (all false) are NOT backlog.
 *
 *  Data: SafeStorage-first, SyncManager-debounced Supabase mirror second
 *  Events: All via event delegation + AbortController. Zero inline onclick.
 *  CSS: Loaded dynamically from styles/modules/backlog.css
 *
 *  Phase 8D-3: SyncManager Migration — replaced full-table fire-and-forget
 *  _syncToSupabase with per-chapter SyncManager.enqueue. Debounced 300ms
 *  per table. Conservative cloud merge. SafeStorage remains primary.
 *  smartPadhaiData format unchanged. PP and Syllabus untouched.
 *  Actual backlogs table columns: id, chapter, subject, read, notes, pyq,
 *  last_updated, user_key, user_id. Unique constraint: user_id, chapter.
 * ═══════════════════════════════════════════════════════════════════
 */

const BacklogRoute = (() => {

    // ── Private state ──
    let _container = null;
    let _abortController = null;
    let _missionTimer = null;
    let _isMissionRunning = false;
    let _toastTimeout = null;
    let _cssLinkEl = null;

    const CSS_PATH = './styles/modules/backlog.css';
    const TIMELINE_KEY = 'backlog_timeline';
    const VICTORY_KEY = 'victoryList';
    const DAILY_STATS_KEY = 'dailyStats';
    const MASTER_KEY = 'smartPadhaiData';

    // ── Subject detection for Supabase mirror ──
    const _CHEMISTRY_CHAPTERS = [
        "Metals & Non-metals", "Carbon & its Compounds",
        "Acids, Bases & Salts", "Chemical Reactions",
        "Electricity", "Magnetic Effects"
    ];
    const _MATHS_CHAPTERS = [
        "Polynomials", "Real Numbers", "Real Number",
        "Quadratic Equations", "Trigonometry"
    ];

    function _detectSubject(chapter) {
        if (_CHEMISTRY_CHAPTERS.includes(chapter)) return "Chemistry";
        if (_MATHS_CHAPTERS.includes(chapter)) return "Maths";
        return "Unknown";
    }

    // ── Phase 8D-5A: SyncManager Naming Compatibility Helper ──
    // Resolves window.SPSyncManager (actual app sync manager)
    // Falls back to window.SyncManager (legacy), then null.
    // NEVER touches Aestra Ai/syncManager.js
    function _getSyncManager() {
        return window.SPSyncManager || window.SyncManager || null;
    }

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════

    async function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;
        _isMissionRunning = false;
        _missionTimer = null;

        // 1. Load CSS
        _loadCSS();

        // 2. Try loading from cloud via SyncManager (best-effort merge)
        await _loadFromCloud();

        // 3. Render full UI
        container.innerHTML = renderFullUI();

        // 4. Auto-load today's schedule
        _autoLoadTodaySchedule();

        // 5. Render all sections
        _renderInventory();
        _syncCurrentBacklogInventory(); // Phase 8D-5C: mirror syllabus-created backlogs to Supabase
        _renderVictories();
        _buildTimelineTabs();
        _updateDynamicCleanup();

        // 6. Bind events
        _bindEvents(container, _abortController.signal);

        console.log('[BacklogRoute] Initialized');
    }

    function cleanup() {
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }
        if (_missionTimer) {
            clearInterval(_missionTimer);
            _missionTimer = null;
        }
        if (_toastTimeout) {
            clearTimeout(_toastTimeout);
            _toastTimeout = null;
        }
        _isMissionRunning = false;
        // Remove confirm overlays
        document.querySelectorAll('.bl-confirm-overlay').forEach(el => el.remove());
        // Remove toast elements
        document.querySelectorAll('.bl-toast').forEach(el => el.remove());
        _unloadCSS();
        _container = null;
        console.log('[BacklogRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.backlogCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-backlog-css]');
        if (el) { el.remove(); _cssLinkEl = null; }
    }

    // ════════════════════════════════════════════════════════
    //  SYNC MANAGER SYNC (Phase 8D-3)
    //  Actual backlogs schema:
    //    id, chapter, subject, read, notes, pyq, last_updated,
    //    user_key, user_id
    //  Unique constraint for upsert: user_id, chapter
    //  SyncManager injects user_id automatically on enqueue.
    // ════════════════════════════════════════════════════════

    // ── Canonical User ID Helper ── (Phase 8D-5A: uses _getSyncManager)
    // Priority: SyncManager → AppState → localStorage fallback
    // Returns null if no userId found (caller must guard)
    function _getUserId() {
        const sync = _getSyncManager();
        return sync?.getUserId?.()
            || window.AppState?.currentUser?.id
            || localStorage.getItem('_current_user_id')
            || null;
    }

    /**
     * Merge cloud rows into local smartPadhaiData.
     * Conservative: cloud-only chapters added, existing local progress
     * NEVER overwritten unless local has zero progress and cloud has some.
     * Preserves _scheduledFor, isSyllabus, and subject from local.
     * @param {array} rows - Rows from backlogs table
     */
    function _mergeCloudRows(rows) {
        const local = SafeStorage.getItem(MASTER_KEY, {});

        // Defensive: local must be a plain object
        if (typeof local !== 'object' || local === null || Array.isArray(local)) {
            console.warn('[BacklogRoute] Local masterData corrupted in cloud merge, resetting');
            return;
        }

        let merged = false;

        rows.forEach(row => {
            const chapter = row.chapter;
            if (!chapter) return;

            const localEntry = local[chapter];
            const cloudRead = !!row.read;
            const cloudNotes = !!row.notes;
            const cloudPyq = !!row.pyq;

            if (!localEntry || typeof localEntry !== 'object') {
                // Cloud-only chapter — add to local
                local[chapter] = {
                    read: cloudRead,
                    notes: cloudNotes,
                    pyq: cloudPyq,
                    subject: row.subject || 'Unknown',
                    lastUpdated: row.last_updated || new Date().toLocaleDateString(),
                    isSyllabus: true
                };
                merged = true;
            } else {
                // Both exist — SAFE MERGE: only accept cloud when local has ZERO progress
                // This prevents stale Supabase data from overwriting user's recent edits
                const localDone = [localEntry.read, localEntry.notes, localEntry.pyq].filter(Boolean).length;
                const cloudDone = [cloudRead, cloudNotes, cloudPyq].filter(Boolean).length;

                if (localDone === 0 && cloudDone > 0) {
                    local[chapter] = {
                        ...localEntry,  // preserve _scheduledFor, isSyllabus
                        read: cloudRead,
                        notes: cloudNotes,
                        pyq: cloudPyq,
                        subject: row.subject || localEntry.subject || 'Unknown',
                        isSyllabus: localEntry.isSyllabus !== false,
                        lastUpdated: row.last_updated || localEntry.lastUpdated
                    };
                    merged = true;
                }
            }
        });

        if (merged) {
            SafeStorage.setItem(MASTER_KEY, local);
            console.log(`[BacklogRoute] Merged ${rows.length} cloud rows. Local chapters: ${Object.keys(local).length}`);
        }
    }

    /**
     * Load backlog data from cloud via SyncManager.
     * Falls back to direct Supabase query if SyncManager unavailable.
     * Conservative merge: cloud-only rows added, local rows NEVER overwritten.
     */
    async function _loadFromCloud() {
        // ── Try SyncManager first (Phase 8D-5A: via _getSyncManager) ──
        const sync = _getSyncManager();
        if (sync && typeof sync.loadFromCloud === 'function') {
            try {
                const rows = await sync.loadFromCloud('backlogs', {
                    columns: '*',
                    statusKey: 'backlogs'
                });
                if (rows && rows.length > 0) {
                    _mergeCloudRows(rows);
                    return;
                }
                return; // No rows or empty — nothing to merge
            } catch (err) {
                console.warn('[BacklogRoute] SyncManager load failed, trying fallback:', err);
            }
        }

        // ── Fallback: direct Supabase query (legacy path) ──
        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) {
            console.warn('[BacklogRoute] Supabase load skipped — no userId available');
            return;
        }

        try {
            const { data, error } = await window.supabaseClient
                .from('backlogs')
                .select('*')
                .eq('user_id', userId);

            if (error || !data || data.length === 0) return;

            _mergeCloudRows(data);
        } catch (err) {
            console.warn('[BacklogRoute] Fallback Supabase load failed:', err);
        }
    }

    /**
     * Build a schema-safe row for the backlogs table from a local chapter entry.
     * Uses ONLY actual backlogs columns:
     *   chapter, subject, read, notes, pyq, last_updated, user_key
     * SyncManager injects user_id automatically.
     * Does NOT send: source_key, completed, progress, raw_data, updated_at
     * @param {string} chapterName - Chapter name (key in smartPadhaiData)
     * @returns {object|null} Row object or null if entry missing
     */
    function _buildBacklogRow(chapterName) {
        const masterData = SafeStorage.getItem(MASTER_KEY, {});
        const entry = masterData[chapterName];

        if (!entry || typeof entry !== 'object') return null;

        const userId = _getUserId();

        return {
            chapter: chapterName,
            subject: entry.subject || _detectSubject(chapterName),
            read: !!entry.read,
            notes: !!entry.notes,
            pyq: !!entry.pyq,
            last_updated: entry.lastUpdated || new Date().toISOString(),
            user_key: userId || ''   // legacy column, kept for backward compat
        };
    }

    /**
     * Enqueue a single chapter upsert via SyncManager.
     * conflictKey: 'user_id,chapter' — matches actual DB unique constraint.
     * Falls back to direct Supabase single-row upsert if SyncManager unavailable/rejected.
     * @param {string} chapterName - Chapter name (key in smartPadhaiData)
     */
    function _enqueueChapterUpsert(chapterName) {
        const row = _buildBacklogRow(chapterName);
        if (!row) return;

        const options = {
            conflictKey: 'user_id,chapter',
            statusKey: 'backlogs'
        };

        // Phase 8D-5A/5B: SPSyncManager.enqueue does not return a boolean.
        // If the function exists, call it and treat the operation as queued.
        const sync = _getSyncManager();
        if (sync && typeof sync.enqueue === 'function') {
            sync.enqueue('backlogs', row, options);
            console.log('[BacklogRoute] Enqueued backlog row via SyncManager:', chapterName);
            return;
        }

        // Fallback: direct single-row upsert using the same schema-safe row
        if (!window.supabaseClient) {
            console.warn('[BacklogRoute] No SyncManager and no Supabase client — sync skipped');
            return;
        }

        const userId = _getUserId();
        if (!userId) {
            console.warn('[BacklogRoute] Upsert skipped — no userId');
            return;
        }

        window.supabaseClient
            .from('backlogs')
            .upsert({ ...row, user_id: userId }, { onConflict: 'user_id,chapter' })
            .then(function (result) {
                if (result.error) {
                    console.warn('[BacklogRoute] Direct upsert failed:', result.error.message);
                } else {
                    console.log('[BacklogRoute] Direct upsert success for', chapterName);
                }
            })
            .catch(function (err) {
                console.warn('[BacklogRoute] Direct upsert error:', err);
            });
    }

    /**
     * Enqueue a single chapter delete via SyncManager.
     * SyncManager's _processBatchDelete already does:
     *   .eq('user_id', userId).eq(deleteFilter, deleteValue)
     * So deleteFilter='chapter' + deleteValue=chapterName produces:
     *   .eq('user_id', userId).eq('chapter', chapterName)
     * Falls back to direct Supabase delete if SyncManager unavailable/rejected.
     * @param {string} chapterName - Chapter name to delete from backlogs table
     */
    function _enqueueChapterDelete(chapterName) {
        const options = {
            operation: 'delete',
            deleteFilter: 'chapter',
            deleteValue: chapterName,
            statusKey: 'backlogs'
        };

        // Phase 8D-5A/5B: SPSyncManager.enqueue does not return a boolean.
        // If the function exists, call it and treat the delete as queued.
        const sync = _getSyncManager();
        if (sync && typeof sync.enqueue === 'function') {
            sync.enqueue('backlogs', {}, options);
            console.log('[BacklogRoute] Enqueued backlog delete via SyncManager:', chapterName);
            return;
        }

        // Fallback: direct Supabase delete
        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) {
            console.warn('[BacklogRoute] Delete skipped — no userId');
            return;
        }

        window.supabaseClient
            .from('backlogs')
            .delete()
            .eq('user_id', userId)
            .eq('chapter', chapterName)
            .then(function (result) {
                if (result.error) {
                    console.warn('[BacklogRoute] Delete failed:', result.error.message);
                } else {
                    console.log('[BacklogRoute] Deleted from Supabase:', chapterName);
                }
            })
            .catch(function (err) {
                console.warn('[BacklogRoute] Delete error:', err);
            });
    }

    // ════════════════════════════════════════════════════════
    //  BACKLOG CALCULATION (CRITICAL RULE)
    // ════════════════════════════════════════════════════════

    function _isStarted(entry) {
        if (!entry || typeof entry !== 'object') return false;
        return entry.read === true || entry.notes === true || entry.pyq === true;
    }

    function _isCompleted(entry) {
        if (!entry || typeof entry !== 'object') return false;
        return entry.read === true && entry.notes === true && entry.pyq === true;
    }

    function _isRealBacklog(entry) {
        return _isStarted(entry) && !_isCompleted(entry);
    }

    function _countDone(entry) {
        if (!entry || typeof entry !== 'object') return 0;
        let count = 0;
        if (entry.read === true) count++;
        if (entry.notes === true) count++;
        if (entry.pyq === true) count++;
        return count;
    }

    function _isScheduled(entry) {
        return entry && !!entry._scheduledFor;
    }

    // ════════════════════════════════════════════════════════
    //  HTML RENDERING
    // ════════════════════════════════════════════════════════

    function renderFullUI() {
        return `
        <div class="backlog-wrapper">
            <div class="backlog-stats-container">
                <div class="backlog-master-container sp-card">
                    <!-- TOP: Neutralization Stats -->
                    <div class="backlog-top-bar">
                        <div class="daily-target-card sp-card">
                            <div class="target-header">
                                <span class="label">BACKLOG NEUTRALIZATION</span>
                                <span id="completion-stats" class="status">0/0 CLEANED</span>
                            </div>
                            <div class="kill-counter-container" id="dynamic-slots"></div>
                        </div>
                    </div>

                    <!-- FOCUS MISSION ZONE (shows empty state by default, filled on Target) -->
                    <div class="focus-mission-zone" id="focusMissionZone">
                        <h2 class="zone-title">Current Objective</h2>
                        <div id="focusEmptyState" class="focus-empty-state">
                            <span class="focus-empty-icon">\u{1F3AF}</span>
                            <h3 class="focus-empty-title">No Active Target Selected</h3>
                            <p class="focus-empty-subtitle">Choose a backlog mission below to begin neutralization.</p>
                        </div>
                        <div id="focusActiveCard" class="main-focus-card sp-card-elevated" style="display:none;">
                            <div class="focus-info">
                                <div id="missionPriorityTag" class="priority-badge critical sp-badge">CRITICAL</div>
                                <h1 id="activeMissionName">---</h1>
                                <div class="mission-tasks" id="currentMissionTasks"></div>
                            </div>
                            <div class="action-zone">
                                <div class="timer-display" id="missionTimer">25:00</div>
                                <button class="launch-btn sp-btn" data-action="toggle-mission">START MISSION</button>
                            </div>
                        </div>
                    </div>

                    <!-- RECOVERY TIMELINE -->
                    <div class="timeline-section">
                        <h3>Recovery Timeline</h3>
                        <div class="timeline-scroll" id="timeline-tabs"></div>
                        <div id="timeline-content" class="timeline-day-view"></div>
                    </div>

                    <!-- INVENTORY -->
                    <div class="all-tasks-section">
                        <h3>Inventory (Pending)</h3>
                        <div id="backlogInventory" class="tasks-grid"></div>
                    </div>

                    <!-- FOOTER -->
                    <div class="footer-sections">
                        <div class="suggestions-box sp-card">
                            <h4>Alfred's Advice</h4>
                            <p id="alfredAdvice">"Select a target mission to begin neutralization."</p>
                        </div>
                        <div class="victory-zone sp-card" id="victoryZone">
                            <h4>Recent Victories</h4>
                            <div id="toast-container"></div>
                            <div class="victory-scroll" id="clearedList"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Toast -->
        <div class="bl-toast sp-toast" id="blToast"></div>`;
    }

    // ════════════════════════════════════════════════════════
    //  INVENTORY RENDERING
    // ════════════════════════════════════════════════════════

    /**
     * Phase 8D-5C: Mirror current real backlog inventory to Supabase.
     *
     * Why this exists:
     * SyllabusRoute creates backlog items by updating the shared
     * smartPadhaiData store. BacklogRoute renders those items from
     * local storage, but no BacklogRoute action has happened yet, so
     * nothing has been enqueued to the `backlogs` table.
     *
     * On Backlog page load, mirror every real backlog chapter once.
     * SyncManager debounces these into a single batch upsert.
     */
    function _syncCurrentBacklogInventory() {
        const masterData = SafeStorage.getItem(MASTER_KEY, {});

        if (typeof masterData !== 'object' || masterData === null || Array.isArray(masterData)) {
            console.warn('[BacklogRoute] masterData corrupted in _syncCurrentBacklogInventory, skipping sync');
            return;
        }

        const chaptersToSync = Object.entries(masterData)
            .filter(([chapter, entry]) => {
                if (typeof entry !== 'object' || entry === null) return false;
                return _isRealBacklog(entry);
            })
            .map(([chapter]) => chapter);

        chaptersToSync.forEach(chapter => _enqueueChapterUpsert(chapter));

        console.log(`[BacklogRoute] Inventory mirror queued: ${chaptersToSync.length} backlog row(s)`);
    }

    function _renderInventory() {
        const inventory = _container?.querySelector('#backlogInventory');
        if (!inventory) return;

        const masterData = SafeStorage.getItem(MASTER_KEY, {});

        // Defensive: masterData must be a plain object
        if (typeof masterData !== 'object' || masterData === null || Array.isArray(masterData)) {
            console.warn('[BacklogRoute] masterData corrupted in _renderInventory, skipping render');
            inventory.innerHTML = `<div class="bl-empty-state sp-empty-state">
                <div class="bl-empty-icon sp-empty-state-icon">\u26A0\uFE0F</div>
                <p class="sp-empty-state-text">Data error. Try refreshing.</p>
            </div>`;
            return;
        }

        // ── CRITICAL: Render ALL realBacklog chapters, not just the first one ──
        // Use Object.entries + filter + map to guarantee every matching chapter is rendered
        // No slice(0,1). No single selected item. No overwriting inside loop.
        const backlogItems = Object.entries(masterData)
            .filter(([name, entry]) => {
                if (typeof entry !== 'object' || entry === null) return false;
                if (_isScheduled(entry)) return false;
                if (!_isRealBacklog(entry)) return false;
                return true;
            })
            .map(([chap, status]) => {
                const doneCount = _countDone(status);
                let pTag = '', pClass = '';

                if (doneCount === 1) {
                    pTag = 'CRITICAL';
                    pClass = 'critical';
                } else if (doneCount === 2) {
                    pTag = 'QUICK WIN';
                    pClass = 'low';
                } else {
                    pTag = 'PENDING';
                    pClass = 'medium';
                }

                const chapId = chap.replace(/\s+/g, '_');
                const leftCount = 3 - doneCount;

                return `
                <div class="backlog-item-card ${pClass} sp-card"
                     draggable="true"
                     data-action="drag-start"
                     data-chapter="${chap}"
                     id="card-${chapId}">
                    <div class="info-side">
                        <span class="priority-badge ${pClass} sp-badge">${pTag}</span>
                        <h4>${chap}</h4>
                        <p>${leftCount} left</p>
                    </div>
                    <div class="action-side">
                        <button class="mini-kill-btn sp-btn" data-action="set-focus" data-chapter="${chap}">Target</button>
                        <button class="delete-mission-btn sp-btn sp-btn-danger" data-action="delete-mission" data-chapter="${chap}" title="Remove Mission">\uD83D\uDDD1\uFE0F</button>
                    </div>
                </div>`;
            });

        if (backlogItems.length === 0) {
            inventory.innerHTML = `<div class="bl-empty-state sp-empty-state">
                <div class="bl-empty-icon sp-empty-state-icon">\uD83C\uDFC6</div>
                <p class="sp-empty-state-text">No backlogs found! You're all caught up.</p>
            </div>`;
        } else {
            inventory.innerHTML = backlogItems.join('');
        }

        console.log(`[BacklogRoute] Inventory rendered: ${backlogItems.length} backlog items`);

        // Update Alfred's advice
        _updateAdvice();
    }

    function _updateAdvice() {
        const data = SafeStorage.getItem(MASTER_KEY, {});
        const adviceEl = _container?.querySelector('#alfredAdvice');
        if (!adviceEl) return;

        // Find a quick win (2 of 3 done)
        let quickWin = null;
        for (const chap in data) {
            const status = data[chap];
            if (typeof status !== 'object' || status === null) continue;
            if (_isScheduled(status) || !_isRealBacklog(status)) continue;
            if (_countDone(status) === 2) {
                quickWin = chap;
                break;
            }
        }

        if (quickWin) {
            adviceEl.textContent = `"Finish '${quickWin}' first — it's a Quick Win (1 task left)."`;
        } else {
            adviceEl.textContent = `"Select a target mission to begin neutralization."`;
        }
    }

    // ════════════════════════════════════════════════════════
    //  FOCUS MISSION
    // ════════════════════════════════════════════════════════

    function _setFocusMission(name) {
        const focusZone = _container?.querySelector('#focusMissionZone');
        const emptyState = _container?.querySelector('#focusEmptyState');
        const activeCard = _container?.querySelector('#focusActiveCard');
        if (!focusZone) return;

        // Show active card, hide empty state
        if (emptyState) emptyState.style.display = 'none';
        if (activeCard) activeCard.style.display = 'flex';
        _updateFocusCard(name);
        _container.querySelector('.backlog-wrapper')?.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function _updateFocusCard(name) {
        const data = SafeStorage.getItem(MASTER_KEY, {});
        const missionData = data[name];
        const taskContainer = _container?.querySelector('#currentMissionTasks');
        const focusTitle = _container?.querySelector('#activeMissionName');
        const priorityBadge = _container?.querySelector('#missionPriorityTag');

        if (!missionData || !taskContainer || !focusTitle) return;

        focusTitle.innerText = name;

        // Notebook variant
        if (missionData.isNotebook || name.includes('\u0394')) {
            taskContainer.innerHTML = `
                <div class="notebook-task-item">
                    Complete ${missionData.pagesToComplete || ''} Pending Pages \u2705
                </div>
                <p class="notebook-hint">Target: Physical Notebook Completion</p>
            `;
        } else {
            // Normal chapter
            taskContainer.innerHTML = `
                <div class="task-item ${missionData.read ? 'done' : ''}">Read Theory ${missionData.read ? '\u2705' : '\u274C'}</div>
                <div class="task-item ${missionData.notes ? 'done' : ''}">Short Notes ${missionData.notes ? '\u2705' : '\u274C'}</div>
                <div class="task-item ${missionData.pyq ? 'done' : ''}">PYQ Practice ${missionData.pyq ? '\u2705' : '\u274C'}</div>
            `;
        }

        if (priorityBadge) {
            const doneCount = _countDone(missionData);
            priorityBadge.innerText = doneCount === 2 ? 'QUICK WIN \u26A1' : 'CRITICAL \uD83D\uDEA9';
            priorityBadge.className = 'priority-badge sp-badge ' + (doneCount === 2 ? 'low' : 'critical');
        }
    }

    // ════════════════════════════════════════════════════════
    //  MISSION TIMER
    // ════════════════════════════════════════════════════════

    function _toggleMission() {
        const btn = _container?.querySelector('[data-action="toggle-mission"]');
        const focusCard = _container?.querySelector('#focusActiveCard');
        if (!btn) return;

        if (!_isMissionRunning) {
            _isMissionRunning = true;
            btn.textContent = 'ABORT MISSION';
            btn.style.background = '#444';
            if (focusCard) focusCard.classList.add('mission-running');
            _startCountdown(15 * 60); // 15 minutes
        } else {
            _stopMission('Mission Aborted!');
        }
    }

    function _startCountdown(durationSeconds) {
        let timer = durationSeconds;
        const display = _container?.querySelector('#missionTimer');

        _missionTimer = setInterval(() => {
            if (!_container) { clearInterval(_missionTimer); return; }

            const mins = Math.floor(timer / 60);
            const secs = timer % 60;
            if (display) {
                display.textContent = `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
            }

            if (--timer < 0) {
                _completeMission();
            }
        }, 1000);
    }

    function _completeMission() {
        clearInterval(_missionTimer);
        _missionTimer = null;
        _isMissionRunning = false;

        const nameEl = _container?.querySelector('#activeMissionName');
        if (!nameEl) return;

        const name = nameEl.innerText;
        if (!name) return;

        const timestamp = new Date().getTime();
        const today = new Date().toDateString();

        // 1. Mark all tasks complete — preserve existing fields
        let masterData = SafeStorage.getItem(MASTER_KEY, {});
        if (masterData[name]) {
            masterData[name] = {
                ...masterData[name],  // preserve isSyllabus, _scheduledFor
                read: true,
                notes: true,
                pyq: true,
                lastUpdated: today
            };
        }
        SafeStorage.setItem(MASTER_KEY, masterData);
        _enqueueChapterUpsert(name); // per-chapter debounced sync

        // 2. Record victory
        let victories = SafeStorage.getItem(VICTORY_KEY, []);
        victories.unshift({ name: name, time: timestamp, date: today });
        SafeStorage.setItem(VICTORY_KEY, victories);

        // 3. Daily stats
        let dailyStats = SafeStorage.getItem(DAILY_STATS_KEY, {});
        if (!dailyStats[today]) dailyStats[today] = 0;
        dailyStats[today] += 1;
        SafeStorage.setItem(DAILY_STATS_KEY, dailyStats);

        // 4. Notebook matrix connection
        if (name.includes('\u0394')) {
            let notebookData = SafeStorage.getItem('notebook_matrix_data', []);
            const subjectName = name.split(' (')[0];
            notebookData = notebookData.map(row => {
                if (row.subject === subjectName) {
                    return { ...row, done: true, incident: false, delta: 0 };
                }
                return row;
            });
            SafeStorage.setItem('notebook_matrix_data', notebookData);
        }

        // 5. PP Reward — unique rewardId prevents duplicates
        const victoryRewardId = `victory_${name.replace(/\s+/g, '_')}_${today.replace(/\s+/g, '_')}`;
        PulseEngine.addPoints(10, 'mission', { rewardId: victoryRewardId });

        // 6. Show empty state in focus zone (hide active card)
        const emptyState = _container?.querySelector('#focusEmptyState');
        const activeCard = _container?.querySelector('#focusActiveCard');
        if (emptyState) emptyState.style.display = '';
        if (activeCard) activeCard.style.display = 'none';

        // Reset timer display
        const timerEl = _container?.querySelector('#missionTimer');
        const btnEl = _container?.querySelector('[data-action="toggle-mission"]');
        const focusCard = _container?.querySelector('#focusActiveCard');
        if (timerEl) timerEl.textContent = '25:00';
        if (btnEl) { btnEl.textContent = 'START MISSION'; btnEl.style.background = ''; }
        if (focusCard) focusCard.classList.remove('mission-running');

        // 7. Refresh UI
        _renderInventory();
        _renderVictories();
        _updateDynamicCleanup();

        // 8. Toast instead of alert
        _showToast(`Mission Accomplished: ${name} Neutralized! \uD83C\uDFC6`);
    }

    function _stopMission(msg) {
        clearInterval(_missionTimer);
        _missionTimer = null;
        _isMissionRunning = false;

        const timerEl = _container?.querySelector('#missionTimer');
        const btnEl = _container?.querySelector('[data-action="toggle-mission"]');
        const focusCard = _container?.querySelector('#focusActiveCard');

        if (timerEl) timerEl.textContent = '25:00';
        if (btnEl) { btnEl.textContent = 'START MISSION'; btnEl.style.background = ''; }
        if (focusCard) focusCard.classList.remove('mission-running');

        _showToast(msg);
    }

    // ════════════════════════════════════════════════════════
    //  DELETE MISSION
    // ════════════════════════════════════════════════════════

    function _deleteMission(name) {
        _showConfirmDialog(
            `Remove "${name}" from inventory? This cannot be undone.`,
            () => {
                let data = SafeStorage.getItem(MASTER_KEY, {});
                delete data[name];
                SafeStorage.setItem(MASTER_KEY, data);
                _enqueueChapterDelete(name);

                // Show empty state if this was the active mission
                const activeName = _container?.querySelector('#activeMissionName')?.innerText;
                if (activeName === name) {
                    const emptyState = _container?.querySelector('#focusEmptyState');
                    const activeCard = _container?.querySelector('#focusActiveCard');
                    if (emptyState) emptyState.style.display = '';
                    if (activeCard) activeCard.style.display = 'none';
                }

                _renderInventory();
                _updateDynamicCleanup();
                _showToast(`"${name}" removed from inventory.`);
            }
        );
    }

    // ════════════════════════════════════════════════════════
    //  VICTORIES
    // ════════════════════════════════════════════════════════

    function _renderVictories() {
        const container = _container?.querySelector('#clearedList');
        if (!container) return;

        let victories = SafeStorage.getItem(VICTORY_KEY, []);
        const currentTime = new Date().getTime();
        const threeHoursMs = 3 * 60 * 60 * 1000;

        // Filter: only show last 3 hours
        const fresh = victories.filter(v => (currentTime - v.time) < threeHoursMs);

        // Clean old ones from storage
        SafeStorage.setItem(VICTORY_KEY, fresh);

        if (fresh.length === 0) {
            container.innerHTML = `<div class="bl-empty-state sp-empty-state" style="grid-column:1/-1;">
                <p class="sp-empty-state-text">No recent victories. Go kill some backlogs! \u2694\uFE0F</p>
            </div>`;
            return;
        }

        container.innerHTML = fresh.map(v => `
            <div class="victory-item slide-in sp-card">
                <div class="v-icon" style="font-size:1.3rem;">\uD83C\uDFC6</div>
                <div class="v-details">
                    <h5>${v.name || 'Mission'}</h5>
                    <span>ACCOMPLISHED</span>
                </div>
            </div>`).join('');
    }

    // ════════════════════════════════════════════════════════
    //  STATS BAR
    // ════════════════════════════════════════════════════════

    function _updateDynamicCleanup() {
        const data = SafeStorage.getItem(MASTER_KEY, {});
        const dailyStats = SafeStorage.getItem(DAILY_STATS_KEY, {});
        const today = new Date().toDateString();

        const todayKills = dailyStats[today] || 0;

        let pendingCount = 0;
        for (const chap in data) {
            const status = data[chap];
            if (typeof status !== 'object' || status === null) continue;
            if (_isRealBacklog(status) && !_isScheduled(status)) pendingCount++;
        }

        const totalSlots = todayKills + pendingCount;
        const container = _container?.querySelector('#dynamic-slots');
        const statsText = _container?.querySelector('#completion-stats');

        if (!container) return;
        container.innerHTML = '';

        for (let i = 0; i < totalSlots; i++) {
            const slot = document.createElement('div');
            slot.className = 'kill-slot' + (i < todayKills ? ' active' : '');
            container.appendChild(slot);
        }

        if (statsText) {
            statsText.innerText = `${todayKills}/${totalSlots} MISSIONS NEUTRALIZED`;
        }

        // Penalty check: >5 untouched syllabus chapters
        const ignoredCount = Object.values(data).filter(s => {
            if (typeof s !== 'object' || s === null) return false;
            return s.isSyllabus && !_isStarted(s);
        }).length;

        if (ignoredCount > 5) {
            const penaltyId = `backlog_penalty_${today.replace(/\s+/g, '_')}`;
            if (!PulseEngine.data.rewardLedger[penaltyId]) {
                PulseEngine.deductPoints(10);
                PulseEngine.data.rewardLedger[penaltyId] = true;
                PulseEngine.save();
                _showToast(`${ignoredCount} SYLLABUS CHAPTERS IGNORED: -10 PP`);
            }
        }
    }

    // ════════════════════════════════════════════════════════
    //  TIMELINE
    // ════════════════════════════════════════════════════════

    function _getTimeline() {
        try { return SafeStorage.getItem(TIMELINE_KEY, {}); }
        catch (e) { return {}; }
    }

    function _saveTimeline(data) {
        SafeStorage.setItem(TIMELINE_KEY, data);
    }

    function _buildTimelineTabs() {
        const container = _container?.querySelector('#timeline-tabs');
        if (!container) return;

        const today = new Date();
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

        container.innerHTML = '';

        for (let i = 0; i < 5; i++) {
            const date = new Date(today);
            date.setDate(today.getDate() + i);
            const label = i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : dayNames[date.getDay()];
            const dateStr = date.toDateString();

            const tab = document.createElement('div');
            tab.className = 'time-node' + (i === 0 ? ' active' : '');
            tab.textContent = label;
            tab.dataset.action = 'timeline-tab';
            tab.dataset.date = dateStr;
            tab.id = `tlnode-${dateStr.replace(/\s+/g, '_')}`;

            container.appendChild(tab);
        }

        // Render today's content
        _renderTimelineDay(today.toDateString());
    }

    function _assignToTimeline(chap, dateStr) {
        const today = new Date().toDateString();
        if (dateStr === today) return; // Can't schedule for today

        const timeline = _getTimeline();
        if (!timeline[dateStr]) timeline[dateStr] = [];

        if (!timeline[dateStr].includes(chap)) {
            timeline[dateStr].push(chap);
        }
        _saveTimeline(timeline);

        // Mark as scheduled in smartPadhaiData
        const data = SafeStorage.getItem(MASTER_KEY, {});
        if (data[chap]) {
            data[chap] = {
                ...data[chap],
                _scheduledFor: dateStr
            };
            SafeStorage.setItem(MASTER_KEY, data);
            _enqueueChapterUpsert(chap);
        }

        _renderInventory();
        _buildTimelineTabs();
        _updateDynamicCleanup();
        _showToast(`${chap} \u2192 Scheduled!`);
    }

    function _renderTimelineDay(dateStr) {
        const container = _container?.querySelector('#timeline-content');
        if (!container) return;

        const timeline = _getTimeline();
        const items = timeline[dateStr] || [];
        const data = SafeStorage.getItem(MASTER_KEY, {});

        if (items.length === 0) {
            container.innerHTML = `<div class="bl-empty-state sp-empty-state">
                <p class="sp-empty-state-text">No missions scheduled. Drag a backlog here!</p>
            </div>`;
            return;
        }

        container.innerHTML = items.map(chap => {
            const status = data[chap];
            const isDone = status && _isCompleted(status);
            return `
            <div class="timeline-item ${isDone ? 'tl-done' : ''} sp-card">
                <span>${chap}</span>
                ${isDone ?
                    '<span class="tl-done-label">\u2713 Done</span>' :
                    `<button class="mini-kill-btn sp-btn" data-action="set-focus" data-chapter="${chap}">Target</button>`
                }
            </div>`;
        }).join('');
    }

    function _autoLoadTodaySchedule() {
        const today = new Date().toDateString();
        const timeline = _getTimeline();
        const todayItems = timeline[today] || [];
        if (todayItems.length === 0) return;

        const data = SafeStorage.getItem(MASTER_KEY, {});
        let changed = false;

        const changedChapters = [];
        todayItems.forEach(chap => {
            if (data[chap] && data[chap]._scheduledFor) {
                delete data[chap]._scheduledFor;
                changedChapters.push(chap);
                changed = true;
            }
        });

        if (changed) {
            SafeStorage.setItem(MASTER_KEY, data);
            // Enqueue each changed chapter individually (SyncManager debounces into one batch)
            changedChapters.forEach(chap => _enqueueChapterUpsert(chap));
        }
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING — Delegation + AbortController
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {
        // ── CLICK DELEGATION ──
        container.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;
            const chapter = target.dataset.chapter;

            switch (action) {
                case 'toggle-mission':
                    _toggleMission();
                    break;

                case 'set-focus':
                    if (chapter) _setFocusMission(chapter);
                    break;

                case 'delete-mission':
                    if (chapter) _deleteMission(chapter);
                    break;

                case 'timeline-tab': {
                    const dateStr = target.dataset.date;
                    if (dateStr) {
                        container.querySelectorAll('.time-node').forEach(t => t.classList.remove('active'));
                        target.classList.add('active');
                        _renderTimelineDay(dateStr);
                    }
                    break;
                }

                case 'drag-start':
                    // Handled by dragstart event, not click
                    break;
            }
        }, { signal });

        // ── DRAG START ──
        container.addEventListener('dragstart', (e) => {
            const card = e.target.closest('.backlog-item-card');
            if (!card) return;
            const chapter = card.dataset.chapter;
            if (chapter) {
                e.dataTransfer.setData('chapterName', chapter);
                e.dataTransfer.effectAllowed = 'move';
                card.classList.add('dragging');
            }
        }, { signal });

        container.addEventListener('dragend', (e) => {
            const card = e.target.closest('.backlog-item-card');
            if (card) card.classList.remove('dragging');
        }, { signal });

        // ── DRAG OVER / DROP on timeline tabs ──
        container.addEventListener('dragover', (e) => {
            const tab = e.target.closest('.time-node');
            if (tab) {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
                tab.classList.add('drag-over');
            }
        }, { signal });

        container.addEventListener('dragleave', (e) => {
            const tab = e.target.closest('.time-node');
            if (tab) tab.classList.remove('drag-over');
        }, { signal });

        container.addEventListener('drop', (e) => {
            e.preventDefault();
            const tab = e.target.closest('.time-node');
            if (!tab) return;
            tab.classList.remove('drag-over');

            const chap = e.dataTransfer.getData('chapterName');
            const dateStr = tab.dataset.date;
            if (!chap || !dateStr) return;
            _assignToTimeline(chap, dateStr);
        }, { signal });
    }

    // ════════════════════════════════════════════════════════
    //  TOAST + CONFIRM DIALOG
    // ════════════════════════════════════════════════════════

    function _showToast(message) {
        const toast = _container?.querySelector('#blToast');
        if (!toast) return;

        toast.textContent = message;
        toast.classList.add('visible');

        if (_toastTimeout) clearTimeout(_toastTimeout);
        _toastTimeout = setTimeout(() => {
            toast.classList.remove('visible');
        }, 3000);
    }

    function _showConfirmDialog(message, onConfirm) {
        const overlay = document.createElement('div');
        overlay.className = 'bl-confirm-overlay sp-modal-overlay';
        overlay.innerHTML = `
            <div class="bl-confirm-box sp-modal-card">
                <div class="bl-confirm-text">${message}</div>
                <div class="bl-confirm-btns">
                    <button class="bl-confirm-no sp-btn sp-btn-secondary" data-action="confirm-cancel">Cancel</button>
                    <button class="bl-confirm-yes sp-btn sp-btn-danger" data-action="confirm-yes">Remove</button>
                </div>
            </div>`;

        document.body.appendChild(overlay);

        const yesBtn = overlay.querySelector('[data-action="confirm-yes"]');
        const noBtn = overlay.querySelector('[data-action="confirm-cancel"]');

        const cleanup = () => overlay.remove();

        yesBtn.addEventListener('click', () => { cleanup(); onConfirm(); });
        noBtn.addEventListener('click', cleanup);
        overlay.addEventListener('click', (e) => { if (e.target === overlay) cleanup(); });
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();

window.BacklogRoute = BacklogRoute;
