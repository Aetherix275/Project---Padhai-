/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — VAULT ROUTE MODULE (Phase 6D)
 *  Full SPA conversion of Study Vault: Methods + Operator Journal
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear state
 *
 *  Dependencies (must be loaded BEFORE this module):
 *    - methodDetails.js  (METHOD_DETAILS, MethodUsageTracker, MethodMission)
 *    - journalEngine.js  (JournalEngine)
 *    - userSession.js    (getCurrentUserOrRedirect, SafeStorage, fetchUserRows)
 *
 *  CSS: Loaded dynamically from styles/modules/vault.css
 *       Removed on cleanup() to prevent style leakage.
 *
 *  Events: All via event delegation + AbortController. Zero inline onclick.
 * ═══════════════════════════════════════════════════════════════════
 */

const VaultRoute = (() => {

    // ── Private state (scoped to this IIFE, reset on cleanup) ──
    let _container = null;
    let _abortController = null;
    let _currentMood = 'Normal';
    let _toastTimeout = null;
    let _cssLinkEl = null;       // reference to dynamically loaded <link>

    const CSS_PATH = './styles/modules/vault.css';

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE: INIT
    // ════════════════════════════════════════════════════════

    async function init(container) {
        // Abort any previous instance's listeners
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();

        _container = container;
        _currentMood = 'Normal';

        // 1. Load vault CSS dynamically
        _loadCSS();

        // 2. Render full UI
        container.innerHTML = renderFullUI();

        // 3. Bind all events via delegation
        _bindEvents(container, _abortController.signal);

        // 4. Load data from Supabase (non-blocking merges)
        await _loadRemoteData();

        // 5. Render method cards into #methodGrid
        _renderMethodCards();

        // 6. Initialize journal UI
        _initJournalUI();

        console.log('[VaultRoute] Initialized');
    }

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE: CLEANUP
    // ════════════════════════════════════════════════════════

    function cleanup() {
        // Abort all event listeners
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }

        // Clear toast timeout
        if (_toastTimeout) {
            clearTimeout(_toastTimeout);
            _toastTimeout = null;
        }

        // Remove any confirm overlays
        document.querySelectorAll('.journal-confirm-overlay').forEach(el => el.remove());

        // Remove dynamically loaded CSS
        _unloadCSS();

        // Reset state
        _container = null;
        _currentMood = 'Normal';

        console.log('[VaultRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        // Prevent duplicate
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;

        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.vaultCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-vault-css]');
        if (el) {
            el.remove();
            _cssLinkEl = null;
        }
    }

    // ════════════════════════════════════════════════════════
    //  HTML RENDERING
    // ════════════════════════════════════════════════════════

    function renderFullUI() {
        return `
        <div class="vault-container">
            <div class="vault-header">
                <h1>STUDY VAULT</h1>
                <p>TACTICAL STUDY TECHNIQUES FOR ELITE PERFORMANCE</p>
            </div>

            <!-- Tab Navigation -->
            <div class="vault-tabs">
                <div class="vault-tab active" data-action="switch-tab" data-tab="methods">🧠 Study Methods</div>
                <div class="vault-tab" data-action="switch-tab" data-tab="journal">📔 Operator Journal</div>
            </div>

            <!-- ═══ TAB 1: STUDY METHODS ═══ -->
            <div class="vault-tab-content active" id="tab-methods">
                <div class="tech-grid" id="methodGrid"></div>

                <div class="pro-feature-box">
                    <h2>☣️ THE DISTRACTION CALCULATOR</h2>
                    <p>Dekho tumhara phone tumhara kitna career kha raha hai.</p>

                    <div style="margin: 30px 0;">
                        Roz kitne ghante Screen Time (Distraction)?
                        <input type="number" id="screenHours" class="calc-input" placeholder="0"> Hrs
                    </div>

                    <button class="calc-btn" data-action="calc-waste">CALCULATE DAMAGE</button>

                    <div id="calcResult"></div>
                </div>
            </div>

            <!-- ═══ TAB 2: OPERATOR JOURNAL ═══ -->
            <div class="vault-tab-content" id="tab-journal">

                <!-- Today's Journal Entry -->
                <div class="journal-today-card" id="journalTodayCard">
                    <div class="journal-today-header">
                        <div class="journal-today-date" id="journalTodayDate"></div>
                        <div class="journal-today-label" id="journalTodayLabel">NEW ENTRY</div>
                    </div>

                    <div class="journal-form" id="journalForm">
                        <!-- Mood -->
                        <div class="journal-field full-width">
                            <label>Mood</label>
                            <div class="mood-selector" id="moodSelector">
                                <button class="mood-btn" data-mood="Focused" data-action="select-mood" type="button">🎯 Focused</button>
                                <button class="mood-btn" data-mood="Confident" data-action="select-mood" type="button">💪 Confident</button>
                                <button class="mood-btn" data-mood="Normal" data-action="select-mood" type="button">😐 Normal</button>
                                <button class="mood-btn" data-mood="Tired" data-action="select-mood" type="button">😴 Tired</button>
                                <button class="mood-btn" data-mood="Stressed" data-action="select-mood" type="button">😰 Stressed</button>
                            </div>
                        </div>

                        <!-- Focus Rating -->
                        <div class="journal-field full-width">
                            <label>Focus Rating</label>
                            <div class="journal-rating-row">
                                <input type="range" min="1" max="10" value="5" class="journal-rating-slider" id="focusRatingSlider">
                                <div class="journal-rating-value" id="focusRatingValue">5</div>
                            </div>
                        </div>

                        <!-- What I Studied -->
                        <div class="journal-field">
                            <label>What I Studied</label>
                            <textarea id="journalWhatStudied" placeholder="Maths Ch 5, Physics derivations..." rows="2"></textarea>
                        </div>

                        <!-- Biggest Distraction -->
                        <div class="journal-field">
                            <label>Biggest Distraction</label>
                            <input type="text" id="journalDistraction" placeholder="Instagram, YouTube, noise...">
                        </div>

                        <!-- Today's Win -->
                        <div class="journal-field">
                            <label>Today's Win</label>
                            <textarea id="journalWin" placeholder="Finished 3 chapters! Cleared 2 backlogs..." rows="2"></textarea>
                        </div>

                        <!-- Tomorrow's Target -->
                        <div class="journal-field">
                            <label>Tomorrow's Target</label>
                            <textarea id="journalTarget" placeholder="Revise Ch 6, complete homework..." rows="2"></textarea>
                        </div>

                        <!-- Notes -->
                        <div class="journal-field full-width">
                            <label>Notes</label>
                            <textarea id="journalNotes" placeholder="Anything on your mind..." rows="3"></textarea>
                        </div>
                    </div>

                    <div class="journal-actions">
                        <button class="journal-btn journal-btn-delete" id="journalDeleteBtn" data-action="delete-today-journal" style="display:none;">🗑️ Delete</button>
                        <button class="journal-btn journal-btn-save" data-action="save-today-journal">💾 SAVE ENTRY</button>
                    </div>
                </div>

                <!-- Past Entries -->
                <div class="journal-section">
                    <div class="journal-past-header">
                        <div class="journal-past-title">PAST ENTRIES</div>
                        <div class="journal-past-count" id="journalEntryCount"></div>
                    </div>
                    <div id="journalPastEntries"></div>
                </div>

                <!-- AESTRA Locked Card -->
                <div class="aestra-locked-card">
                    <div class="aestra-locked-icon">🔒</div>
                    <div class="aestra-locked-title">AESTRA Journal Analysis</div>
                    <div class="aestra-locked-desc">AI-powered journal insights — mood patterns, focus trends, distraction analysis, and personalized study recommendations from your journal data.</div>
                    <div class="aestra-locked-badge">COMING SOON — PREMIUM FEATURE</div>
                </div>

            </div>
        </div>

        <!-- Toast notification element -->
        <div class="vault-toast" id="vaultToast"></div>`;
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING — Delegation + AbortController
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {

        // ── Main click delegation ──
        container.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;

            switch (action) {
                // Tab switching
                case 'switch-tab':
                    _switchVaultTab(target.dataset.tab);
                    break;

                // Mood selection
                case 'select-mood':
                    _selectMood(target.dataset.mood);
                    break;

                // Journal actions
                case 'save-today-journal':
                    _saveTodayJournal();
                    break;
                case 'delete-today-journal':
                    _deleteTodayJournal();
                    break;

                // Method card expand/collapse
                case 'toggle-method':
                    _toggleMethodCard(target.dataset.methodId);
                    break;

                // Activate badge
                case 'activate-badge':
                    e.stopPropagation();
                    _activateMethodBadge(target.dataset.methodId);
                    break;

                // Add to mission
                case 'add-mission':
                    e.stopPropagation();
                    _addMethodToMission(target.dataset.methodId);
                    break;

                // Distraction calculator
                case 'calc-waste':
                    _calculateWaste();
                    break;

                // Past entry — view
                case 'view-entry':
                    e.stopPropagation();
                    _loadPastEntryIntoForm(target.dataset.date);
                    break;

                // Past entry — delete
                case 'delete-entry':
                    e.stopPropagation();
                    _deletePastEntry(target.dataset.date);
                    break;
            }
        }, { signal });

        // ── Focus rating slider (input event, not click) ──
        const slider = container.querySelector('#focusRatingSlider');
        if (slider) {
            slider.addEventListener('input', () => {
                _updateRatingDisplay();
            }, { signal });
        }
    }

    // ════════════════════════════════════════════════════════
    //  REMOTE DATA LOADING
    // ════════════════════════════════════════════════════════

    async function _loadRemoteData() {
        // Load method usage from Supabase (best-effort)
        if (typeof MethodUsageTracker !== 'undefined') {
            try { await MethodUsageTracker.loadFromSupabase(); }
            catch (err) { console.warn('[VaultRoute] MethodUsageTracker load failed:', err); }
        }

        // Load journal entries from Supabase (best-effort)
        if (typeof JournalEngine !== 'undefined') {
            try { await JournalEngine.loadFromSupabase(); }
            catch (err) { console.warn('[VaultRoute] JournalEngine load failed:', err); }
        }
    }

    // ════════════════════════════════════════════════════════
    //  TAB SYSTEM
    // ════════════════════════════════════════════════════════

    function _switchVaultTab(tabName) {
        if (!_container) return;

        // Update tab buttons
        _container.querySelectorAll('.vault-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === tabName);
        });

        // Update tab content
        _container.querySelectorAll('.vault-tab-content').forEach(content => {
            content.classList.remove('active');
        });

        const targetContent = _container.querySelector(`#tab-${tabName}`);
        if (targetContent) {
            targetContent.classList.add('active');
        }

        // Re-render journal if switching to it
        if (tabName === 'journal') {
            _renderPastEntries();
        }
    }

    // ════════════════════════════════════════════════════════
    //  JOURNAL UI
    // ════════════════════════════════════════════════════════

    function _initJournalUI() {
        if (typeof JournalEngine === 'undefined') {
            console.error('[VaultRoute] JournalEngine not loaded');
            return;
        }

        const todayStr = JournalEngine.getTodayStr();

        // Format date for display
        const dateObj = new Date(todayStr + 'T00:00:00');
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const dateDisplay = dateObj.toLocaleDateString('en-IN', options);

        const dateEl = _container.querySelector('#journalTodayDate');
        if (dateEl) dateEl.textContent = dateDisplay;

        // Load existing entry for today if it exists
        const existing = JournalEngine.getEntryByDate(todayStr);
        if (existing) {
            _loadEntryIntoForm(existing);
            const labelEl = _container.querySelector('#journalTodayLabel');
            if (labelEl) labelEl.textContent = 'EDITING';
            const delBtn = _container.querySelector('#journalDeleteBtn');
            if (delBtn) delBtn.style.display = 'inline-flex';
        } else {
            _resetJournalForm();
            const labelEl = _container.querySelector('#journalTodayLabel');
            if (labelEl) labelEl.textContent = 'NEW ENTRY';
            const delBtn = _container.querySelector('#journalDeleteBtn');
            if (delBtn) delBtn.style.display = 'none';
        }

        // Render past entries
        _renderPastEntries();
    }

    function _selectMood(mood) {
        _currentMood = mood;
        if (!_container) return;
        _container.querySelectorAll('.mood-btn').forEach(btn => {
            btn.classList.toggle('selected', btn.dataset.mood === mood);
        });
    }

    function _updateRatingDisplay() {
        if (!_container) return;
        const slider = _container.querySelector('#focusRatingSlider');
        const valueEl = _container.querySelector('#focusRatingValue');
        if (slider && valueEl) {
            valueEl.textContent = slider.value;
        }
    }

    function _loadEntryIntoForm(entry) {
        _currentMood = entry.mood || 'Normal';
        _selectMood(_currentMood);

        const slider = _container.querySelector('#focusRatingSlider');
        if (slider) slider.value = entry.focus_rating || 5;
        _updateRatingDisplay();

        const fields = {
            'journalWhatStudied': entry.what_i_studied || '',
            'journalDistraction': entry.biggest_distraction || '',
            'journalWin': entry.today_win || '',
            'journalTarget': entry.tomorrow_target || '',
            'journalNotes': entry.notes || ''
        };

        for (const [id, val] of Object.entries(fields)) {
            const el = _container.querySelector(`#${id}`);
            if (el) el.value = val;
        }
    }

    function _resetJournalForm() {
        _currentMood = 'Normal';
        _selectMood('Normal');

        const slider = _container.querySelector('#focusRatingSlider');
        if (slider) slider.value = 5;
        _updateRatingDisplay();

        ['journalWhatStudied', 'journalDistraction', 'journalWin', 'journalTarget', 'journalNotes'].forEach(id => {
            const el = _container.querySelector(`#${id}`);
            if (el) el.value = '';
        });
    }

    async function _saveTodayJournal() {
        if (typeof JournalEngine === 'undefined') return;

        const slider = _container.querySelector('#focusRatingSlider');

        const entryData = {
            mood: _currentMood,
            focus_rating: slider ? parseInt(slider.value) || 5 : 5,
            what_i_studied: (_container.querySelector('#journalWhatStudied')?.value || '').trim(),
            biggest_distraction: (_container.querySelector('#journalDistraction')?.value || '').trim(),
            today_win: (_container.querySelector('#journalWin')?.value || '').trim(),
            tomorrow_target: (_container.querySelector('#journalTarget')?.value || '').trim(),
            notes: (_container.querySelector('#journalNotes')?.value || '').trim()
        };

        await JournalEngine.saveEntry(entryData);

        const labelEl = _container.querySelector('#journalTodayLabel');
        if (labelEl) labelEl.textContent = 'EDITING';

        const delBtn = _container.querySelector('#journalDeleteBtn');
        if (delBtn) delBtn.style.display = 'inline-flex';

        _showToast('Journal entry saved! 📔');
        _renderPastEntries();
    }

    function _deleteTodayJournal() {
        _showConfirmDialog(
            'Delete today\'s journal entry? This cannot be undone.',
            async () => {
                const todayStr = JournalEngine.getTodayStr();
                await JournalEngine.deleteEntry(todayStr);
                _resetJournalForm();

                const labelEl = _container.querySelector('#journalTodayLabel');
                if (labelEl) labelEl.textContent = 'NEW ENTRY';

                const delBtn = _container.querySelector('#journalDeleteBtn');
                if (delBtn) delBtn.style.display = 'none';

                _showToast('Journal entry deleted.');
                _renderPastEntries();
            }
        );
    }

    function _deletePastEntry(dateStr) {
        _showConfirmDialog(
            `Delete journal entry for ${dateStr}? This cannot be undone.`,
            async () => {
                await JournalEngine.deleteEntry(dateStr);
                _showToast('Entry deleted.');
                _initJournalUI();
            }
        );
    }

    function _loadPastEntryIntoForm(dateStr) {
        const entry = JournalEngine.getEntryByDate(dateStr);
        if (!entry) return;

        // Switch to journal tab
        _switchVaultTab('journal');

        // If it's today's entry, load it into the form
        if (dateStr === JournalEngine.getTodayStr()) {
            _loadEntryIntoForm(entry);
            const labelEl = _container.querySelector('#journalTodayLabel');
            if (labelEl) labelEl.textContent = 'EDITING';
            const delBtn = _container.querySelector('#journalDeleteBtn');
            if (delBtn) delBtn.style.display = 'inline-flex';
        } else {
            _showToast('Viewing entry for ' + dateStr);
        }
    }

    function _renderPastEntries() {
        const container = _container?.querySelector('#journalPastEntries');
        const countEl = _container?.querySelector('#journalEntryCount');
        if (!container) return;

        const all = JournalEngine.getAllEntries();
        const todayStr = JournalEngine.getTodayStr();

        // Filter out today's entry (shown in the form above)
        const pastEntries = all.filter(e => e.entry_date !== todayStr);

        if (countEl) {
            countEl.textContent = `${all.length} total entr${all.length === 1 ? 'y' : 'ies'}`;
        }

        if (pastEntries.length === 0) {
            container.innerHTML = `
                <div class="journal-empty">
                    <div class="journal-empty-icon">📔</div>
                    <div class="journal-empty-text">No past entries yet. Write your first journal today!</div>
                </div>`;
            return;
        }

        container.innerHTML = pastEntries.map(entry => {
            const dateObj = new Date(entry.entry_date + 'T00:00:00');
            const dayName = dateObj.toLocaleDateString('en-IN', { weekday: 'short' });
            const dateDisplay = dateObj.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

            const preview = entry.what_i_studied || entry.today_win || entry.notes || 'No content';
            const truncated = preview.length > 80 ? preview.substring(0, 80) + '...' : preview;

            return `
            <div class="journal-entry-card" data-action="view-entry" data-date="${entry.entry_date}">
                <div class="journal-entry-top">
                    <div class="journal-entry-date">${dayName}, ${dateDisplay}</div>
                    <div class="journal-entry-mood mood-${entry.mood || 'Normal'}">${entry.mood || 'Normal'}</div>
                </div>
                <div class="journal-entry-stats">
                    <div class="journal-entry-stat">Focus: <span>${entry.focus_rating || 5}/10</span></div>
                    ${entry.biggest_distraction ? `<div class="journal-entry-stat">Distraction: <span>${entry.biggest_distraction}</span></div>` : ''}
                </div>
                <div class="journal-entry-preview">${truncated}</div>
                <div class="journal-entry-actions">
                    <button class="journal-entry-btn" data-action="view-entry" data-date="${entry.entry_date}">View</button>
                    <button class="journal-entry-btn delete-btn" data-action="delete-entry" data-date="${entry.entry_date}">Delete</button>
                </div>
            </div>`;
        }).join('');
    }

    // ── Confirm dialog (replaces confirm() for better UX) ──
    function _showConfirmDialog(message, onConfirm) {
        const overlay = document.createElement('div');
        overlay.className = 'journal-confirm-overlay';
        overlay.innerHTML = `
            <div class="journal-confirm-box">
                <div class="journal-confirm-text">${message}</div>
                <div class="journal-confirm-btns">
                    <button class="journal-confirm-no" data-action="confirm-cancel">Cancel</button>
                    <button class="journal-confirm-yes" data-action="confirm-yes">Delete</button>
                </div>
            </div>`;

        document.body.appendChild(overlay);

        // Bind confirm buttons
        overlay.querySelector('[data-action="confirm-yes"]').addEventListener('click', () => {
            overlay.remove();
            onConfirm();
        });

        overlay.querySelector('[data-action="confirm-cancel"]').addEventListener('click', () => {
            overlay.remove();
        });

        // Close on backdrop click
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) overlay.remove();
        });
    }

    // ════════════════════════════════════════════════════════
    //  STUDY METHODS
    // ════════════════════════════════════════════════════════

    function _renderMethodCards() {
        const grid = _container?.querySelector('#methodGrid');
        if (!grid) return;

        if (typeof METHOD_DETAILS === 'undefined') {
            console.error('[VaultRoute] METHOD_DETAILS not loaded');
            grid.innerHTML = '<p style="color:#ff4c4c;">Error: Method data could not be loaded.</p>';
            return;
        }

        const activeBadges = SafeStorage.getItem('activeBadges', []);

        grid.innerHTML = METHOD_DETAILS.map(method => {
            const isActivated = activeBadges.some(b => b.name === method.badge);
            const usage = (typeof MethodUsageTracker !== 'undefined')
                ? MethodUsageTracker.getUsage(method.id)
                : { timesActivated: 0, totalMinutes: 0, effectivenessRating: 0 };

            return `
            <div class="method-card" id="method-${method.id}">
                <div class="method-card-header" data-action="toggle-method" data-method-id="${method.id}">
                    <div class="method-card-title">
                        <span class="method-card-emoji">${method.emoji}</span>
                        <div>
                            <div class="method-card-name">${method.name}</div>
                            <div class="method-card-badge">${method.badge}</div>
                        </div>
                    </div>
                    <span class="method-expand-arrow">▼</span>
                </div>
                <div class="method-card-short">${method.shortDesc}</div>
                <div class="method-card-details">
                    <!-- What It Is -->
                    <div class="method-section">
                        <div class="method-section-title">What It Is</div>
                        <p>${method.whatItIs}</p>
                    </div>

                    <!-- When To Use -->
                    <div class="method-section">
                        <div class="method-section-title">When To Use</div>
                        <ul class="method-list">
                            ${method.whenToUse.map(item => `<li>${item}</li>`).join('')}
                        </ul>
                    </div>

                    <!-- Best Subjects -->
                    <div class="method-section">
                        <div class="method-section-title">Best Subjects</div>
                        <div class="method-subject-tags">
                            ${method.bestSubjects.map(s => `<span class="method-subject-tag">${s}</span>`).join('')}
                        </div>
                    </div>

                    <!-- Step-by-Step -->
                    <div class="method-section">
                        <div class="method-section-title">Step-by-Step Implementation</div>
                        <ol class="method-steps-list">
                            ${method.steps.map(step => `<li>${step}</li>`).join('')}
                        </ol>
                    </div>

                    <!-- Common Mistakes -->
                    <div class="method-section">
                        <div class="method-section-title">Common Mistakes</div>
                        <ul class="method-list mistake-list">
                            ${method.commonMistakes.map(m => `<li>${m}</li>`).join('')}
                        </ul>
                    </div>

                    <!-- Usage Stats -->
                    <div class="method-usage-stats">
                        <div class="method-stat">
                            <div class="method-stat-value">${usage.timesActivated || 0}</div>
                            <div class="method-stat-label">Activated</div>
                        </div>
                        <div class="method-stat">
                            <div class="method-stat-value">${usage.totalMinutes || 0}</div>
                            <div class="method-stat-label">Minutes</div>
                        </div>
                        <div class="method-stat">
                            <div class="method-stat-value">${usage.effectivenessRating || 0}/10</div>
                            <div class="method-stat-label">Rating</div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="method-actions">
                        <button class="method-btn method-btn-activate ${isActivated ? 'activated' : ''}"
                            id="activate-btn-${method.id}"
                            data-action="activate-badge"
                            data-method-id="${method.id}">
                            ${isActivated ? '✓ ACTIVATED' : '🛡️ Activate Badge'}
                        </button>
                        <button class="method-btn method-btn-mission"
                            id="mission-btn-${method.id}"
                            data-action="add-mission"
                            data-method-id="${method.id}">
                            ⚡ Add to Mission
                        </button>
                    </div>
                </div>
            </div>`;
        }).join('');
    }

    function _toggleMethodCard(methodId) {
        if (!_container) return;
        const card = _container.querySelector(`#method-${methodId}`);
        if (!card) return;

        // Collapse other expanded cards
        _container.querySelectorAll('.method-card.expanded').forEach(c => {
            if (c.id !== `method-${methodId}`) {
                c.classList.remove('expanded');
            }
        });

        card.classList.toggle('expanded');
    }

    function _activateMethodBadge(methodId) {
        const methodDetail = METHOD_DETAILS.find(m => m.id === methodId);
        if (!methodDetail) return;

        let activeBadges = SafeStorage.getItem('activeBadges', []);

        if (activeBadges.some(b => b.name === methodDetail.badge)) {
            _showToast(`${methodDetail.badge} already active!`);
            return;
        }

        activeBadges.push({ name: methodDetail.badge, emoji: methodDetail.emoji });
        SafeStorage.setItem('activeBadges', activeBadges);

        // Record activation in MethodUsageTracker
        if (typeof MethodUsageTracker !== 'undefined') {
            MethodUsageTracker.recordActivation(methodId);
        }

        // Update button UI
        const btn = _container?.querySelector(`#activate-btn-${methodId}`);
        if (btn) {
            btn.innerHTML = '✓ ACTIVATED';
            btn.classList.add('activated');
        }

        _showToast(`${methodDetail.badge} Badge Activated! Check Dashboard. 🛡️`);
    }

    function _addMethodToMission(methodId) {
        if (typeof MethodMission === 'undefined') {
            console.error('[VaultRoute] MethodMission not loaded');
            _showToast('Error: Could not add mission.');
            return;
        }

        const slot = MethodMission.addMethodToMission(methodId);
        if (slot) {
            const methodDetail = METHOD_DETAILS.find(m => m.id === methodId);
            const slotLabel = slot.charAt(0).toUpperCase() + slot.slice(1);
            _showToast(`${methodDetail.emoji} ${methodDetail.name} added to ${slotLabel} Mission!`);

            const btn = _container?.querySelector(`#mission-btn-${methodId}`);
            if (btn) {
                const originalHTML = btn.innerHTML;
                btn.innerHTML = '✓ ADDED!';
                btn.classList.add('added');
                setTimeout(() => {
                    if (btn && _container) {
                        btn.innerHTML = originalHTML;
                        btn.classList.remove('added');
                    }
                }, 1500);
            }
        } else {
            _showToast('Failed to add mission. Check console.');
        }
    }

    // ════════════════════════════════════════════════════════
    //  DISTRACTION CALCULATOR
    // ════════════════════════════════════════════════════════

    function _calculateWaste() {
        const input = _container?.querySelector('#screenHours');
        if (!input) return;

        const hours = input.value;
        if (!hours || hours <= 0) {
            _showToast('Bhai, kuch toh time waste karte hoge?');
            return;
        }

        const yearlyWaste = hours * 365;
        const booksCouldRead = Math.floor(yearlyWaste / 15);

        const resultEl = _container.querySelector('#calcResult');
        if (resultEl) {
            resultEl.innerHTML = `
                ⚠️ SYSTEM ALERT: <br>
                Tum saal mein <strong>${yearlyWaste} ghante</strong> waste kar rahe ho! <br>
                Itne time mein tum <strong>${booksCouldRead} badi books</strong> khatam kar sakte the!
            `;
        }
    }

    // ════════════════════════════════════════════════════════
    //  TOAST NOTIFICATION
    // ════════════════════════════════════════════════════════

    function _showToast(message) {
        const toast = _container?.querySelector('#vaultToast');
        if (!toast) return;

        toast.textContent = message;
        toast.classList.add('visible');

        if (_toastTimeout) clearTimeout(_toastTimeout);
        _toastTimeout = setTimeout(() => {
            toast.classList.remove('visible');
        }, 2800);
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();

window.VaultRoute = VaultRoute;
