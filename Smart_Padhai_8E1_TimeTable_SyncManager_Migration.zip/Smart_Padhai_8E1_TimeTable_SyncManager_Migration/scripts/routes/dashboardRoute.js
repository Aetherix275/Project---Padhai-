/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — DASHBOARD ROUTE MODULE (Phase 7D Hero Restoration Patch)
 *  The heart of the app: PulseEngine card, stat circles, badges,
 *  quote, action hint, panic protocol, GraphEngine, TimerEngine,
 *  ghost mode, cookie jar, rank modal.
 * ═══════════════════════════════════════════════════════════════════
 *
 *  CRITICAL CONSTRAINTS:
 *    1. Do NOT call loadPulseEngineFromSupabase() here
 *    2. Do NOT call initPulseEngineAfterAuth() here
 *    3. Only call PulseEngine.updateUI() — app-init.js inits once
 *    4. If PulseEngine.hasLoadedFromSupabase is false → loading state
 *    5. PP must NEVER reset to 500/490/default
 *    6. Use SafeStorage for all data reads (auto user_{id}_ prefix)
 *    7. Backlog: started = read||notes||pyq, completed = read&&notes&&pyq
 *       realBacklog = started && !completed. Only count read/notes/pyq.
 *    8. All events use data-action + delegation + AbortController
 *    9. No inline onclick handlers
 *   10. CSS loaded dynamically on init, unloaded on cleanup
 *
 *  Phase 7D Hero Layout Polish Patch Changes:
 *    - Moved Quick Win / action hint (hintContent + pulse-dot) OUTSIDE
 *      the hero card into a separate thin action strip (.quickwin-strip)
 *      positioned ABOVE the hero card
 *    - Moved Active Techniques (badgeContainer) from hero-bottom row to
 *      directly below the operator name in hero-left column
 *    - Reorganized hero from 3-column+bottom to 2-column layout:
 *      Left: name, active techniques, rank badge, PP bar
 *      Right: shard image, streak/trophy pills, ghost/cookie buttons
 *    - Removed hero-center and hero-bottom grid areas (now 2-col)
 *    - Enlarged rank pill and brightened PP display via CSS
 *    - Quote strip stays directly below hero (polished)
 *    - dash-widgets-grid contains Timer + Panic Protocol
 *    - No neural SVG lines
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear timers
 * ═══════════════════════════════════════════════════════════════════
 */

const DashboardRoute = (() => {

    // ── Private state ──
    let _container = null;
    let _abortController = null;
    let _cssLinkEl = null;
    let _panicInterval = null;
    let _neuralLinesTimeout = null;  // Kept for cleanup safety; no longer used
    let _graphInitialized = false;

    const CSS_PATH = './styles/modules/dashboard.css';

    // ── Constants ──
    const MASTER_KEY = 'smartPadhaiData';
    const NOTEBOOK_KEY = 'notebook_matrix_data';
    const PULSE_KEY = 'pulse_engine_data';

    function _getTodayDailyEarnedPP() {
        const pulse = window.PulseEngine?.data || {};
        const local = SafeStorage.getItem(PULSE_KEY, {}) || {};

        const candidates = [
            pulse.dailyEarnedPP,
            pulse.dailyEarned,
            pulse.daily_earned_pp,
            local.dailyEarnedPP,
            local.dailyEarned,
            local.daily_earned_pp
        ]
            .map(v => Number(v))
            .filter(v => Number.isFinite(v) && v >= 0);

        return candidates.length ? Math.max(...candidates) : 0;
    }


    // ════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════

    async function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;

        // 1. Load CSS
        _loadCSS();

        // 2. Render HTML
        container.innerHTML = _renderHTML();

        // 3. Wait for PulseEngine then update UI
        await _waitForPulseEngine();

        // 4. Update dashboard circles
        _updateDashboardCircles();

        // 5. Display badges
        _displayBadges();

        // 6. Display quote
        _displayRandomQuote();

        // 7. Update action hint
        _updateActionHint();

        // [Phase 7D] Step 8 (neural lines) REMOVED — no longer called

        // 8. Init GraphEngine (after DOM exists, await for first-visit Supabase load)
        await _initGraphEngine();

        // 9. Init TimerEngine UI (refresh only)
        _initTimerEngine();

        // 10. Start PanicProtocol
        _startPanicProtocol();

        // 11. Bind events
        _bindEvents(container, _abortController.signal);

        console.log('[DashboardRoute] Initialized (Phase 7D Hero Layout Polish Patch)');
    }

    function cleanup() {
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }
        if (_panicInterval) {
            clearInterval(_panicInterval);
            _panicInterval = null;
        }
        if (_neuralLinesTimeout) {
            clearTimeout(_neuralLinesTimeout);
            _neuralLinesTimeout = null;
        }
        // Close any open modals
        const modal = document.getElementById('rank-modal');
        if (modal) modal.style.display = 'none';
        // Remove ghost-active from body
        document.body.classList.remove('ghost-active');
        // Reset page title
        document.title = 'Smart Padhai | Action OS';
        // Unload CSS
        _unloadCSS();
        _container = null;
        console.log('[DashboardRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.dashboardCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-dashboard-css]');
        if (el) { el.remove(); _cssLinkEl = null; }
    }

    // ════════════════════════════════════════════════════════
    //  PULSE ENGINE WAIT + UI UPDATE
    // ════════════════════════════════════════════════════════

    /**
     * Wait for PulseEngine.hasLoadedFromSupabase to be true.
     * Show loading overlay if not ready. Retry every 500ms up to 10s.
     * CRITICAL: Do NOT call loadPulseEngineFromSupabase() or
     * initPulseEngineAfterAuth() here — app-init.js handles that.
     */
    async function _waitForPulseEngine() {
        // Check immediately
        if (window.PulseEngine && PulseEngine.hasLoadedFromSupabase) {
            _updatePulseEngineUI();
            return;
        }

        // Show loading overlay
        _showPulseLoadingOverlay();

        const maxRetries = 20; // 20 * 500ms = 10 seconds
        let attempt = 0;

        return new Promise((resolve) => {
            const interval = setInterval(() => {
                attempt++;

                if (window.PulseEngine && PulseEngine.hasLoadedFromSupabase) {
                    clearInterval(interval);
                    _hidePulseLoadingOverlay();
                    _updatePulseEngineUI();
                    resolve();
                    return;
                }

                if (attempt >= maxRetries) {
                    clearInterval(interval);
                    _hidePulseLoadingOverlay();
                    console.warn('[DashboardRoute] PulseEngine still not loaded after 10s. Rendering with fallback data.');
                    // Attempt UI update anyway — PulseEngine.updateUI() handles missing elements gracefully
                    if (window.PulseEngine) {
                        _updatePulseEngineUI();
                    }
                    resolve();
                }
            }, 500);
        });
    }

    function _showPulseLoadingOverlay() {
        if (!_container) return;
        // Remove existing overlay if any
        const existing = _container.querySelector('.pulse-loading-overlay');
        if (existing) return;

        const overlay = document.createElement('div');
        overlay.className = 'pulse-loading-overlay';
        overlay.style.cssText = `
            position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.7); z-index: 9999;
            display: flex; align-items: center; justify-content: center;
            flex-direction: column; gap: 16px;
        `;
        overlay.innerHTML = `
            <div style="color: #00ccff; font-size: 1.2rem; font-weight: 700; letter-spacing: 2px;">
                Loading PulseEngine...
            </div>
            <div style="width: 40px; height: 40px; border: 3px solid #222; border-top-color: #00ccff;
                        border-radius: 50%; animation: pulse-spin 0.8s linear infinite;"></div>
        `;
        _container.appendChild(overlay);
    }

    function _hidePulseLoadingOverlay() {
        const overlay = _container?.querySelector('.pulse-loading-overlay');
        if (overlay) overlay.remove();
    }

    /**
     * Update PulseEngine-driven UI elements.
     * Called from _waitForPulseEngine and on returning to dashboard.
     * CRITICAL: Only calls PulseEngine.updateUI(). Never resets PP.
     */
    function _updatePulseEngineUI() {
        if (!window.PulseEngine) return;

        // PulseEngine.updateUI() handles:
        //   global-level-display, global-pp-display, xp-needed,
        //   global-pulse-fill, trophy-pp-display, main-shard-badge,
        //   rank-name, syncThemeClasses, updateTimelinePath
        PulseEngine.updateUI();

        // Update streak display separately (not handled by updateUI)
        const streakEl = document.getElementById('streakDisplay');
        if (streakEl && PulseEngine.data) {
            const streak = PulseEngine.data.streak || 0;
            streakEl.textContent = '\uD83D\uDD25 ' + streak;
        }
    }

    // ════════════════════════════════════════════════════════
    //  SVG RING PROGRESS HELPER
    // ════════════════════════════════════════════════════════

    function _setRingProgress(elementId, percent) {
        const circle = document.getElementById(elementId);
        if (!circle) return;
        const radius = circle.r?.baseVal?.value;
        if (!radius || radius <= 0) return;
        const circumference = 2 * Math.PI * radius;
        const clampedPercent = Math.max(0, Math.min(100, percent));
        circle.style.strokeDasharray = circumference;
        circle.style.strokeDashoffset = circumference - (clampedPercent / 100 * circumference);
    }

    // ════════════════════════════════════════════════════════
    //  DASHBOARD CIRCLES UPDATE (CRITICAL BACKLOG RULE)
    // ════════════════════════════════════════════════════════

    function _updateDashboardCircles() {
        // ── Helper: Backlog calculation ──
        // Only count read/notes/pyq fields.
        // Do NOT count isSyllabus, _scheduledFor, lastUpdated.
        function toBool(v) { return v === true || v === 'true'; }

        function isRealBacklog(status) {
            if (!status || typeof status !== 'object') return false;
            if (status._scheduledFor) return false;
            const read = toBool(status.read);
            const notes = toBool(status.notes);
            const pyq = toBool(status.pyq);
            const started = read || notes || pyq;
            const completed = read && notes && pyq;
            return started && !completed;
        }

        function isFullyCompleted(status) {
            if (!status || typeof status !== 'object') return false;
            return toBool(status.read) && toBool(status.notes) && toBool(status.pyq);
        }

        // ── 1. BACKLOG CIRCLE ──
        const masterData = SafeStorage.getItem(MASTER_KEY, {});
        let backlogCount = 0;

        if (masterData && typeof masterData === 'object' && !Array.isArray(masterData)) {
            for (const chap in masterData) {
                const entry = masterData[chap];
                if (isRealBacklog(entry)) backlogCount++;
            }
        }

        const backlogText = document.getElementById('backlog-text');
        if (backlogText) backlogText.textContent = backlogCount;
        _setRingProgress('backlogCircle', Math.min(100, (backlogCount / 10) * 100));

        const backlogHover = document.getElementById('backlog-hover');
        if (backlogHover) {
            backlogHover.textContent = backlogCount === 0
                ? 'All caught up!'
                : `${backlogCount} chapter${backlogCount !== 1 ? 's' : ''} in progress`;
        }

        // ── 2. PROGRESS CIRCLE ──
        // IMPORTANT:
        // syllabus_master_tracker only stores registration info like:
        // { "Chapter Name": { isRegistered: true } }
        // It does NOT store read/notes/pyq completion data.
        // Completion must always be read from smartPadhaiData.
        const trackerData = SafeStorage.getItem('syllabus_master_tracker', {});
        let totalChapters = 0;
        let completedChapters = 0;

        let registeredChapters = [];

        if (trackerData && typeof trackerData === 'object' && !Array.isArray(trackerData) && Object.keys(trackerData).length > 0) {
            registeredChapters = Object.keys(trackerData).filter(chap => {
                const entry = trackerData[chap];
                return entry === true || entry?.isRegistered === true || typeof entry === 'object';
            });
        }

        // Fallback: if tracker is empty/missing, count syllabus chapters from master data.
        if (registeredChapters.length === 0 && masterData && typeof masterData === 'object' && !Array.isArray(masterData)) {
            registeredChapters = Object.keys(masterData).filter(chap => {
                const entry = masterData[chap];
                return entry && typeof entry === 'object' && entry.isSyllabus === true;
            });
        }

        totalChapters = registeredChapters.length;
        completedChapters = registeredChapters.filter(chap => isFullyCompleted(masterData?.[chap])).length;

        console.log('[DashboardRoute] Syllabus progress:', {
            totalChapters,
            completedChapters,
            registeredChapters,
            trackerKeys: trackerData && typeof trackerData === 'object' ? Object.keys(trackerData).length : 0
        });

        const progressPct = totalChapters > 0 ? Math.round((completedChapters / totalChapters) * 100) : 0;
        const progressText = document.getElementById('progress-text');
        if (progressText) progressText.textContent = progressPct + '%';
        _setRingProgress('progressCircle', progressPct);

        const progressHover = document.getElementById('progress-hover');
        if (progressHover) {
            progressHover.textContent = `${completedChapters}/${totalChapters} chapters completed`;
        }

        // ── 3. NOTEBOOKS CIRCLE ──
        const notebookData = SafeStorage.getItem(NOTEBOOK_KEY, []);
        let notebookDone = 0;
        let notebookTotal = 0;

        if (Array.isArray(notebookData)) {
            notebookTotal = notebookData.length;
            notebookDone = notebookData.filter(row => row && row.done === true).length;
        }

        const notebookPct = notebookTotal > 0 ? Math.round((notebookDone / notebookTotal) * 100) : 0;
        const notebookText = document.getElementById('notebook-text');
        if (notebookText) notebookText.textContent = `${notebookDone}/${notebookTotal}`;
        _setRingProgress('notebookCircle', notebookPct);

        const notebookHover = document.getElementById('notebook-hover');
        if (notebookHover) {
            notebookHover.textContent = notebookTotal === 0
                ? 'No notebooks tracked'
                : `${notebookDone} of ${notebookTotal} complete`;
        }

        // ── 4. PULSE SCORE CIRCLE ──
        // P6G Patch: use the strongest current daily-PP value from PulseEngine + current user's SafeStorage.
        // This prevents a stale Supabase 0 from wiping the circle after account switching.
        const dailyEarned = _getTodayDailyEarnedPP();

        const pulseText = document.getElementById('pulse-text');
        if (pulseText) pulseText.textContent = '+' + dailyEarned;
        _setRingProgress('scoreCircle', Math.min(100, (dailyEarned / 200) * 100));

        const pulseHover = document.getElementById('pulse-hover');
        if (pulseHover) {
            pulseHover.textContent = `${dailyEarned} PP earned today`;
        }
    }

    // ════════════════════════════════════════════════════════
    //  BADGES
    // ════════════════════════════════════════════════════════

    function _displayBadges() {
        const container = document.getElementById('badgeContainer');
        if (!container) return;

        const activeBadges = SafeStorage.getItem('activeBadges', []);

        if (!activeBadges || !Array.isArray(activeBadges) || activeBadges.length === 0) {
            container.innerHTML = '<p style="color:#666; font-size:0.7rem;">No Active Techniques</p>';
            return;
        }

        // Badge class mapping based on name
        function getBadgeClass(name) {
            const lower = (name || '').toLowerCase();
            if (lower.includes('legendary') || lower.includes('architect')) return 'legendary';
            if (lower.includes('focus') || lower.includes('deep work')) return 'focus';
            if (lower.includes('recall') || lower.includes('memory')) return 'recall';
            if (lower.includes('strategy') || lower.includes('tactical')) return 'strategy';
            return 'focus';
        }

        // Badge emoji mapping
        function getBadgeEmoji(name) {
            const lower = (name || '').toLowerCase();
            if (lower.includes('legendary') || lower.includes('architect')) return '\uD83D\uDC51';
            if (lower.includes('focus') || lower.includes('deep work')) return '\uD83C\uDFAF';
            if (lower.includes('recall') || lower.includes('memory')) return '\uD83E\uDDE0';
            if (lower.includes('strategy') || lower.includes('tactical')) return '\u2694\uFE0F';
            if (lower.includes('speed')) return '\u26A1';
            if (lower.includes('streak')) return '\uD83D\uDD25';
            return '\uD83C\uDFAF';
        }

        container.innerHTML = activeBadges.map(badge => {
            const name = typeof badge === 'string' ? badge : (badge.name || 'Unknown');
            const cssClass = getBadgeClass(name);
            const emoji = getBadgeEmoji(name);
            return `<div class="badge-item ${cssClass}">
                <span class="badge-emoji">${emoji}</span>
                <span class="badge-name">${name}</span>
            </div>`;
        }).join('');
    }

    // ════════════════════════════════════════════════════════
    //  QUOTE
    // ════════════════════════════════════════════════════════

    function _displayRandomQuote() {
        const famousQuotes = [
            { q: '"I never lose. I either win or learn."', a: 'Nelson Mandela' },
            { q: '"It always seems impossible until it\'s done."', a: 'Nelson Mandela' },
            { q: '"The way to get started is to quit talking and begin doing."', a: 'Walt Disney' },
            { q: '"Success is not final, failure is not fatal: it is the courage to continue that counts."', a: 'Winston Churchill' },
            { q: '"Your time is limited, so don\'t waste it living someone else\'s life."', a: 'Steve Jobs' },
            { q: '"Work hard in silence, let your success be your noise."', a: 'Frank Ocean' },
            { q: '"Don\'t decrease the goal. Increase the effort."', a: 'Grant Cardone' },
            { q: '"Arise, awake, and stop not till the goal is reached."', a: 'Swami Vivekananda' },
            { q: '"Discipline is the way, I make Mistakes but I always Comeback"', a: 'Hayato' }
        ];

        const randomIndex = Math.floor(Math.random() * famousQuotes.length);
        const quote = famousQuotes[randomIndex];

        const quoteText = document.getElementById('quoteText');
        const quoteAuthor = document.getElementById('quoteAuthor');

        if (quoteText) quoteText.textContent = quote.q;
        if (quoteAuthor) quoteAuthor.textContent = '\u2014 ' + quote.a;
    }

    // ════════════════════════════════════════════════════════
    //  ACTION HINT (9-Level Smart Hint)
    // ════════════════════════════════════════════════════════

    function _updateActionHint() {
        const hintContent = document.getElementById('hintContent');
        if (!hintContent) return;

        // Gather data for decision logic
        const calendarData = SafeStorage.getItem('calendarStrategy', {});
        const masterData = SafeStorage.getItem(MASTER_KEY, {});
        // Prefer PulseEngine.data for live accuracy (especially after account switch)
        const pulseData = window.PulseEngine?.data || SafeStorage.getItem(PULSE_KEY, {});

        function toBool(v) { return v === true || v === 'true'; }

        // Check for exam tomorrow
        let examTomorrow = false;
        let examSubject = null;
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        const tomorrowStr = tomorrow.toISOString().split('T')[0];

        if (calendarData && typeof calendarData === 'object') {
            for (const key in calendarData) {
                const event = calendarData[key];
                if (event && (event.mode === 'exam' || event.type === 'exam')) {
                    const eventDateStr = key.includes('-') ? key : (event.date || event.examDate || '');
                    if (eventDateStr === tomorrowStr || eventDateStr === tomorrow.toDateString()) {
                        examTomorrow = true;
                        examSubject = event.subject || event.text || event.title || 'Exam';
                        break;
                    }
                }
            }
        }

        // Count backlogs (realBacklog only)
        let backlogCount = 0;
        let quickWinChapters = [];
        let failedMissions = [];

        if (masterData && typeof masterData === 'object' && !Array.isArray(masterData)) {
            for (const chap in masterData) {
                const entry = masterData[chap];
                if (typeof entry !== 'object' || entry === null) continue;
                if (entry._scheduledFor) continue;

                const read = toBool(entry.read);
                const notes = toBool(entry.notes);
                const pyq = toBool(entry.pyq);
                const started = read || notes || pyq;
                const completed = read && notes && pyq;

                if (started && !completed) {
                    backlogCount++;
                    const doneCount = [read, notes, pyq].filter(Boolean).length;
                    if (doneCount === 2) {
                        quickWinChapters.push(chap);
                    }
                }

                // Failed missions: tasks that were started but not completed and old
                if (started && !completed && entry.lastUpdated) {
                    const lastDate = new Date(entry.lastUpdated);
                    if (!isNaN(lastDate.getTime())) {
                        const daysSinceUpdate = (today - lastDate) / (1000 * 60 * 60 * 24);
                        if (daysSinceUpdate > 3) {
                            failedMissions.push(chap);
                        }
                    }
                }
            }
        }

        // Check pending priority tasks
        const priorityTasks = (pulseData && pulseData.priorityTasks) ? pulseData.priorityTasks : {};
        const pendingPriority = Object.entries(priorityTasks).filter(([k, v]) => v === false);
        const streak = Number(pulseData?.streak ?? 0);
        const dailyEarned = Number(pulseData?.dailyEarnedPP ?? pulseData?.dailyEarned ?? 0);

        // 9-Level Decision Logic
        // Level 1: Exam tomorrow → critical warning
        if (examTomorrow) {
            hintContent.innerHTML = `\uD83D\uDEA8 <strong>CRITICAL:</strong> ${examSubject} exam tomorrow! Activate Panic Protocol NOW.`;
            return;
        }

        // Level 2: Failed missions → recovery needed
        if (failedMissions.length > 0) {
            const target = failedMissions[0];
            hintContent.innerHTML = `\uD83D\uDD34 <strong>RECOVERY:</strong> "${target}" has stalled. Re-engage immediately.`;
            return;
        }

        // Level 3: Quick wins → complete now
        if (quickWinChapters.length > 0) {
            const target = quickWinChapters[0];
            hintContent.innerHTML = `\u26A1 <strong>QUICK WIN:</strong> "${target}" — only 1 task left. Finish it now!`;
            return;
        }

        // Level 4: Exam approaching + backlogs → target specific
        let examApproaching = false;
        let approachingSubject = null;
        const nextWeek = new Date(today);
        nextWeek.setDate(nextWeek.getDate() + 7);
        const nextWeekStr = nextWeek.toISOString().split('T')[0];

        if (calendarData && typeof calendarData === 'object') {
            for (const key in calendarData) {
                const event = calendarData[key];
                if (event && (event.mode === 'exam' || event.type === 'exam')) {
                    const eventDateStr = key.includes('-') ? key : (event.date || event.examDate || '');
                    // Check if exam is within next 7 days
                    if (eventDateStr >= tomorrowStr && eventDateStr <= nextWeekStr) {
                        examApproaching = true;
                        approachingSubject = event.subject || event.text || event.title || 'Exam';
                        break;
                    }
                }
            }
        }

        if (examApproaching && backlogCount > 0) {
            hintContent.innerHTML = `\uD83C\uDFAF <strong>EXAM INCOMING:</strong> ${approachingSubject} is near. Clear your backlogs first!`;
            return;
        }

        // Level 5: Pending priority missions → complete mission
        if (pendingPriority.length > 0) {
            const taskName = pendingPriority[0][0];
            hintContent.innerHTML = `\uD83D\uDCCC <strong>PRIORITY:</strong> Complete your priority task: "${taskName}".`;
            return;
        }

        // Level 6: Heavy backlog (5+) → backlog alert
        if (backlogCount >= 5) {
            hintContent.innerHTML = `\uD83D\uDD35 <strong>BACKLOG ALERT:</strong> ${backlogCount} chapters pending. Start neutralizing!`;
            return;
        }

        // Level 7: Streak 7+ → streak motivation
        if (streak >= 7) {
            hintContent.innerHTML = `\uD83D\uDD25 <strong>ON FIRE!</strong> ${streak}-day streak! Don't break the chain.`;
            return;
        }

        // Level 8: Low daily PP → encourage activity
        if (dailyEarned < 10) {
            hintContent.innerHTML = `\uD83D\uDCAA <strong>GET STARTED:</strong> Earn your first PP today! Start a focus session or complete a task.`;
            return;
        }

        // Level 9: All clear → congratulate
        hintContent.innerHTML = `\u2705 <strong>ALL CLEAR!</strong> You're on track. Keep the momentum going, Architect.`;
    }

    // ════════════════════════════════════════════════════════
    //  GHOST MODE
    // ════════════════════════════════════════════════════════

    function _toggleGhost() {
        const isActive = document.body.classList.toggle('ghost-active');

        // Toggle blur on sidebar (NOT inside route container — it's in app.html)
        const sidebar = document.getElementById('sidebar');
        if (sidebar) sidebar.classList.toggle('ghost-blur', isActive);

        // Toggle blur on internal dashboard elements
        const grid = _container?.querySelector('#grid');
        const header = _container?.querySelector('#header');
        if (grid) grid.classList.toggle('ghost-blur', isActive);
        if (header) header.classList.toggle('ghost-blur', isActive);

        // Update ghost button text/style
        const ghostBtn = _container?.querySelector('#ghostBtn');
        if (ghostBtn) {
            ghostBtn.textContent = isActive ? 'Ghost: ON' : 'Ghost Mode';
            ghostBtn.style.opacity = isActive ? '1' : '';
            ghostBtn.style.boxShadow = isActive ? '0 0 15px rgba(255,255,255,0.3)' : '';
        }

        // Update ghost HUD visibility
        const ghostHud = _container?.querySelector('.ghost-hud');
        if (ghostHud) ghostHud.style.display = isActive ? 'block' : 'none';
    }

    // ════════════════════════════════════════════════════════
    //  NEURAL SVG LINES (DEPRECATED — Phase 7D)
    //  Function definition kept for reference; no longer called.
    // ════════════════════════════════════════════════════════

    function _drawNeuralLines() {
        const svg = _container?.querySelector('#neural-svg');
        if (!svg) return;

        const squares = _container?.querySelectorAll('.stat-square');
        if (!squares || squares.length < 2) return;

        // Clear existing lines
        svg.innerHTML = '';

        // Get positions of stat squares
        const positions = [];
        squares.forEach(sq => {
            const rect = sq.getBoundingClientRect();
            const containerRect = svg.parentElement.getBoundingClientRect();
            positions.push({
                x: rect.left - containerRect.left + rect.width / 2,
                y: rect.top - containerRect.top + rect.height / 2
            });
        });

        // Draw bezier curves between adjacent squares
        for (let i = 0; i < positions.length - 1; i++) {
            const from = positions[i];
            const to = positions[i + 1];
            const midX = (from.x + to.x) / 2;
            const midY = (from.y + to.y) / 2;

            const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            const d = `M ${from.x} ${from.y} Q ${midX} ${from.y} ${midX} ${midY} T ${to.x} ${to.y}`;
            path.setAttribute('d', d);
            path.setAttribute('stroke', 'rgba(0, 204, 255, 0.15)');
            path.setAttribute('stroke-width', '1.5');
            path.setAttribute('fill', 'none');
            path.setAttribute('class', 'neural-path');
            svg.appendChild(path);
        }

        // Also draw a line from first to last for the loop effect
        if (positions.length >= 3) {
            const first = positions[0];
            const last = positions[positions.length - 1];
            const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            const cpx = first.x;
            const cpy = last.y;
            const d = `M ${first.x} ${first.y} Q ${cpx} ${cpy} ${last.x} ${last.y}`;
            path.setAttribute('d', d);
            path.setAttribute('stroke', 'rgba(0, 204, 255, 0.08)');
            path.setAttribute('stroke-width', '1');
            path.setAttribute('fill', 'none');
            path.setAttribute('class', 'neural-path-dim');
            svg.appendChild(path);
        }
    }

    // ════════════════════════════════════════════════════════
    //  RANK MODAL
    // ════════════════════════════════════════════════════════

    function _openRankModal() {
        if (typeof openRankModal === 'function') {
            openRankModal();
        } else {
            // Fallback: manually show modal
            const modal = document.getElementById('rank-modal');
            if (modal) modal.style.display = 'flex';
        }
    }

    function _closeRankModal() {
        if (typeof closeRankModal === 'function') {
            closeRankModal();
        } else {
            const modal = document.getElementById('rank-modal');
            if (modal) modal.style.display = 'none';
        }
    }

    function _showRankDetail(rankName) {
        if (typeof showRankDetail === 'function') {
            showRankDetail(rankName);
        }
    }

    // ════════════════════════════════════════════════════════
    //  COOKIE JAR
    // ════════════════════════════════════════════════════════

    function _openCookieJar() {
        if (typeof openCookieJar === 'function') {
            openCookieJar();
        }
    }

    // ════════════════════════════════════════════════════════
    //  GRAPH ENGINE
    // ════════════════════════════════════════════════════════

    async function _initGraphEngine() {
        if (!window.GraphEngine) {
            console.warn('[DashboardRoute] GraphEngine not available on window yet.');
            return;
        }

        try {
            if (!_graphInitialized) {
                // First visit: full init (loads Supabase snapshots, records today, renders)
                await window.GraphEngine.init();
                _graphInitialized = true;
                console.log('[DashboardRoute] GraphEngine initialized (first visit)');
            } else {
                // Subsequent visits: just re-render dashboard with fresh data
                window.GraphEngine.renderDashboard();
                console.log('[DashboardRoute] GraphEngine re-rendered (return visit)');
            }
        } catch (err) {
            console.warn('[DashboardRoute] GraphEngine init/render failed:', err);
        }
        // Metric toggle and backfill buttons are wired via data-action delegation
    }

    // ════════════════════════════════════════════════════════
    //  TIMER ENGINE
    // ════════════════════════════════════════════════════════

    function _initTimerEngine() {
        if (window.TimerEngine) {
            // CRITICAL: Do NOT re-initialize TimerEngine. Just refresh UI.
            // The timer must survive route switches — only UI refresh, not reset.
            try {
                TimerEngine.updateUI();
                // Restore timer state if a timer was running before navigation
                TimerEngine.restoreTimerState();
            } catch (err) {
                console.warn('[DashboardRoute] TimerEngine UI refresh failed:', err);
            }
        }
    }

    // ════════════════════════════════════════════════════════
    //  PANIC PROTOCOL
    // ════════════════════════════════════════════════════════

    function _startPanicProtocol() {
        if (window.PanicProtocolEngine) {
            try {
                PanicProtocolEngine.run();
            } catch (err) {
                console.warn('[DashboardRoute] PanicProtocolEngine.run() failed:', err);
            }

            // Refresh every hour
            _panicInterval = setInterval(() => {
                if (window.PanicProtocolEngine) {
                    try { PanicProtocolEngine.refresh(); } catch (e) { /* silent */ }
                }
            }, 3600000); // 1 hour
        }
    }

    // ════════════════════════════════════════════════════════
    //  DEV POINTS
    // ════════════════════════════════════════════════════════

    function _triggerDevPoints() {
        if (typeof triggerDevPoints === 'function') {
            triggerDevPoints();
        }
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING — Delegation + AbortController
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {
        // ── CLICK DELEGATION ──
        container.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;

            switch (action) {
                case 'toggle-ghost':
                    _toggleGhost();
                    break;

                case 'open-cookie-jar':
                    _openCookieJar();
                    break;

                case 'open-rank-modal':
                    _openRankModal();
                    break;

                case 'close-rank-modal':
                    _closeRankModal();
                    break;

                case 'trigger-dev-points':
                    _triggerDevPoints();
                    break;

                case 'timer-preset':
                    if (window.TimerEngine) {
                        TimerEngine.selectDuration(parseInt(target.dataset.minutes, 10));
                    }
                    break;

                case 'timer-custom': {
                    const customInput = document.getElementById('customDuration');
                    if (customInput) {
                        const val = parseInt(customInput.value, 10);
                        if (val >= 1 && val <= 180) {
                            if (window.TimerEngine) TimerEngine.selectDuration(val);
                            customInput.value = '';
                        }
                    }
                    break;
                }

                case 'timer-label':
                    if (window.TimerEngine) {
                        TimerEngine.selectLabel(target.dataset.label);
                    }
                    break;

                case 'timer-toggle':
                    if (window.TimerEngine) TimerEngine.toggle();
                    break;

                case 'timer-reset':
                    if (window.TimerEngine) TimerEngine.reset();
                    break;

                case 'ge-metric': {
                    // Toggle active metric button
                    const metricBtns = container.querySelectorAll('.ge-metric-btn');
                    metricBtns.forEach(b => b.classList.remove('active'));
                    target.classList.add('active');
                    if (window.GraphEngine) GraphEngine.renderWeekBars();
                    break;
                }

                case 'ge-backfill':
                    if (window.GraphEngine) {
                        GraphEngine.backfillThisWeek().then(() => {
                            GraphEngine.renderDashboard();
                        });
                    }
                    break;

                case 'show-rank-detail':
                    _showRankDetail(target.dataset.rank);
                    break;

                default:
                    break;
            }
        }, { signal });

        // ── KEYBOARD: Escape to close rank modal ──
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                _closeRankModal();
            }
        }, { signal });
    }

    // ════════════════════════════════════════════════════════
    //  HTML RENDER — Phase 7D Reordered Hierarchy
    //  1. Hero action card (hint with pulse dot)
    //  2. Summary strip (master-header compacted)
    //  3. Key stats grid (4 SVG circle stats)
    //  4. Productivity graph section (GraphEngine)
    //  5. Secondary widgets grid (timer, badges, quote, panic)
    // ════════════════════════════════════════════════════════

    function _renderHTML() {
        return `
<div class="dashboard-wrapper">

    <!-- Ascension overlay (global, but referenced by PulseEngine) -->
    <div id="ascension-overlay" style="display:none;">
        <div class="ascension-content">
            <img src="./assets/The all seeing Eye.png" class="ascension-img" alt="Architect Ascension">
            <h1 class="ascension-quote">The Universe is under your Design, Architect</h1>
        </div>
    </div>

    <!-- Ghost HUD -->
    <div class="ghost-hud" style="display:none;">Distraction Disabled. Focus Active.</div>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- 0. QUICK WIN / NEXT ACTION STRIP                    -->
    <!-- ═══════════════════════════════════════════════════ -->
    <div class="quickwin-strip">
        <span class="pulse-dot"></span>
        <span id="hintContent">Scanning your progress...</span>
    </div>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- 1. HERO COMMAND CARD — Premium identity             -->
    <!-- ═══════════════════════════════════════════════════ -->
    <header id="header">
        <div class="master-header">
            <!-- Left Column: Identity + Techniques + Rank + PP -->
            <div class="hero-left">
                <h2 class="hero-title">Master SJ</h2>
                <div class="hero-techniques" id="badgeContainer">
                    <p style="color:#666; font-size:0.7rem;">No Active Techniques</p>
                </div>
                <div class="hero-rank-pill" data-action="open-rank-modal" style="cursor: pointer;">
                    <span class="hero-rank-icon">\uD83D\uDC51</span>
                    <span id="global-level-display">Initiate</span>
                </div>
                <div class="hero-pp-section">
                    <div class="pulse-bar-container">
                        <div id="global-pulse-fill"></div>
                    </div>
                    <small class="pp-counter"><span id="global-pp-display">0</span> / <span id="xp-needed">0 PP</span></small>
                    <div class="hero-actions-row">
                    <button id="ghostBtn" class="ghost-button-style" data-action="toggle-ghost">Ghost Mode</button>
                    <button id="cookie-jar-trigger" data-action="open-cookie-jar" class="cookie-btn-pro">
                        <div class="btn-glow"></div>
                        <span class="btn-content">
                            <i class="fas fa-cookie-bite cookie-icon">\uD83C\uDF6A</i>
                            <span class="btn-text">The Cookie Jar</span>
                        </span>
                        <div class="btn-border-shine"></div>
                    </button>
                </div>
                </div>
                               
            </div>

            <!-- Right Column: Shard + Pills + Buttons -->
            <div class="hero-right">
                <div class="hero-shard-wrapper">
                    <img id="main-shard-badge" src="./assets/Iniate rank.png" alt="Master Rank Shard">
                </div>
                <div class="hero-pills-row">
                    <div class="hero-pill" id="streakDisplay">\uD83D\uDD25 0</div>
                    <div class="hero-pill">\uD83C\uDFC6 <span id="trophy-pp-display">0</span></div>
                </div>
 
            </div>

            <div id="toast-container"></div>
        </div>
    </header>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- COMMAND QUOTE STRIP                                 -->
    <!-- ═══════════════════════════════════════════════════ -->
    <div class="hero-quote-strip">
        <span class="hero-quote-icon">\uD83D\uDCAC</span>
        <div class="hero-quote-content">
            <span id="quoteText">"I never lose. I either win or learn."</span>
            <span id="quoteAuthor">\u2014 Nelson Mandela</span>
        </div>
    </div>

    <!-- Dev Button -->
    <button data-action="trigger-dev-points" style="background: #ff0055; color: white; border: none; padding: 5px 10px; border-radius: 5px; cursor: pointer; font-family: monospace; font-size: 10px;">
        +1000 PP [DEV]
    </button>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- 3. KEY STATS GRID — 4 SVG circle stats             -->
    <!-- ═══════════════════════════════════════════════════ -->
    <section class="dash-stats-section">
        <div class="stats-grid" id="grid">
            <!-- BACKLOG CIRCLE -->
            <div class="stat-square" id="backlog-square">
                <h4>Backlog</h4>
                <div class="progress-container">
                    <svg class="progress-ring" width="120" height="120">
                        <circle class="progress-ring__circle-bg" stroke="#222" stroke-width="10" fill="transparent" r="50" cx="60" cy="60"/>
                        <circle id="backlogCircle" class="progress-ring__circle" stroke="#FF4C4C" stroke-width="10" stroke-linecap="round" fill="transparent" r="50" cx="60" cy="60"/>
                    </svg>
                    <div class="progress-text" id="backlog-text" style="color: #FF4C4C;">0</div>
                    <div class="circle-hover-msg" id="backlog-hover">Loading...</div>
                </div>
            </div>
            <!-- PROGRESS CIRCLE -->
            <div class="stat-square" id="progress-square">
                <h4>Progress</h4>
                <div class="progress-container">
                    <svg class="progress-ring" width="120" height="120">
                        <circle class="progress-ring__circle-bg" stroke="#222" stroke-width="10" fill="transparent" r="50" cx="60" cy="60"/>
                        <circle id="progressCircle" class="progress-ring__circle" stroke="#007BFF" stroke-width="10" stroke-linecap="round" fill="transparent" r="50" cx="60" cy="60"/>
                    </svg>
                    <div class="progress-text" id="progress-text" style="color: #007BFF;">0%</div>
                    <div class="circle-hover-msg" id="progress-hover">Loading...</div>
                </div>
            </div>
            <!-- NOTEBOOKS CIRCLE -->
            <div class="stat-square" id="notebook-square">
                <h4>Notebooks</h4>
                <div class="progress-container">
                    <svg class="progress-ring" width="120" height="120">
                        <circle class="progress-ring__circle-bg" stroke="#222" stroke-width="10" fill="transparent" r="50" cx="60" cy="60"/>
                        <circle id="notebookCircle" class="progress-ring__circle" stroke="#FFC107" stroke-width="10" stroke-linecap="round" fill="transparent" r="50" cx="60" cy="60"/>
                    </svg>
                    <div class="progress-text" id="notebook-text" style="color: #FFC107;">0/0</div>
                    <div class="circle-hover-msg" id="notebook-hover">Loading...</div>
                </div>
            </div>
            <!-- PULSE SCORE CIRCLE -->
            <div class="stat-square" id="pulse-square">
                <h4>Pulse Score</h4>
                <div class="progress-container">
                    <svg class="progress-ring" width="120" height="120">
                        <circle class="progress-ring__circle-bg" stroke="#222" stroke-width="10" fill="transparent" r="50" cx="60" cy="60"/>
                        <circle id="scoreCircle" class="progress-ring__circle" stroke="#28A745" stroke-width="10" stroke-linecap="round" fill="transparent" r="50" cx="60" cy="60"/>
                    </svg>
                    <div class="progress-text" id="pulse-text" style="color: #28A745;">0</div>
                    <div class="circle-hover-msg" id="pulse-hover">Loading...</div>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- 4. PRODUCTIVITY GRAPH SECTION — GraphEngine         -->
    <!-- ═══════════════════════════════════════════════════ -->
    <section class="dash-graph-section">
        <div class="dash-section-label">Productivity</div>
        <div class="ge-dashboard">
            <!-- Today vs Yesterday -->
            <div class="ge-section-card">
                <div class="ge-section-title"><span class="ge-title-dot"></span> Today vs Yesterday</div>
                <div class="ge-compare-grid">
                    <div class="ge-compare-item"><div class="ge-compare-label">PP Earned</div><div class="ge-compare-value" id="ge-today-pp">0</div><div class="ge-delta ge-delta-neutral" id="ge-delta-pp">0</div></div>
                    <div class="ge-compare-item"><div class="ge-compare-label">Focus Min</div><div class="ge-compare-value" id="ge-today-focus">0 min</div><div class="ge-delta ge-delta-neutral" id="ge-delta-focus">0</div></div>
                    <div class="ge-compare-item"><div class="ge-compare-label">Sessions</div><div class="ge-compare-value" id="ge-today-sessions">0</div><div class="ge-delta ge-delta-neutral" id="ge-delta-sessions">0</div></div>
                    <div class="ge-compare-item"><div class="ge-compare-label">Backlogs</div><div class="ge-compare-value" id="ge-today-backlogs">0</div><div class="ge-delta ge-delta-neutral" id="ge-delta-backlogs">0</div></div>
                </div>
            </div>
            <!-- Consistency Score -->
            <div class="ge-section-card ge-consistency-card">
                <div class="ge-section-title"><span class="ge-title-dot"></span> Consistency Score</div>
                <div class="ge-consistency-ring-wrap">
                    <svg class="ge-consistency-ring" width="100" height="100">
                        <circle stroke="#222" stroke-width="8" fill="transparent" r="42" cx="50" cy="50"/>
                        <circle id="ge-consistency-ring" stroke="var(--accent-blue)" stroke-width="8" stroke-linecap="round" fill="transparent" r="42" cx="50" cy="50" style="stroke-dasharray: 263.9; stroke-dashoffset: 263.9;"/>
                    </svg>
                    <span class="ge-consistency-value" id="ge-consistency-value">0</span>
                </div>
                <div class="ge-score-breakdown">
                    <div class="ge-score-row"><span class="ge-sr-label">PP (30)</span><span class="ge-sr-value" id="ge-score-pp">0/30</span></div>
                    <div class="ge-score-row"><span class="ge-sr-label">Focus (25)</span><span class="ge-sr-value" id="ge-score-focus">0/25</span></div>
                    <div class="ge-score-row"><span class="ge-sr-label">Sessions (25)</span><span class="ge-sr-value" id="ge-score-sessions">0/25</span></div>
                    <div class="ge-score-row"><span class="ge-sr-label">Backlogs (20)</span><span class="ge-sr-value" id="ge-score-backlogs">0/20</span></div>
                </div>
            </div>
            <!-- This Week vs Last Week -->
            <div class="ge-section-card">
                <div class="ge-section-title"><span class="ge-title-dot"></span> This Week vs Last Week</div>
                <div class="ge-compare-grid">
                    <div class="ge-compare-item"><div class="ge-compare-label">PP Earned</div><div class="ge-compare-value" id="ge-week-pp">0</div><div class="ge-delta ge-delta-neutral" id="ge-week-delta-pp">0</div></div>
                    <div class="ge-compare-item"><div class="ge-compare-label">Focus Min</div><div class="ge-compare-value" id="ge-week-focus">0 min</div><div class="ge-delta ge-delta-neutral" id="ge-week-delta-focus">0</div></div>
                    <div class="ge-compare-item"><div class="ge-compare-label">Sessions</div><div class="ge-compare-value" id="ge-week-sessions">0</div><div class="ge-delta ge-delta-neutral" id="ge-week-delta-sessions">0</div></div>
                    <div class="ge-compare-item"><div class="ge-compare-label">Backlogs / Avg Score</div><div class="ge-compare-value" id="ge-week-backlogs">0</div><div class="ge-compare-sub" id="ge-week-consistency">0/100</div></div>
                </div>
            </div>
            <!-- PP Trend Sparkline -->
            <div class="ge-section-card">
                <div class="ge-section-title"><span class="ge-title-dot"></span> PP Earned Trend</div>
                <div class="ge-sparkline" id="ge-pp-sparkline">
                    <div class="ge-spark-bar" style="height: 10%;"></div>
                    <div class="ge-spark-bar" style="height: 10%;"></div>
                    <div class="ge-spark-bar" style="height: 10%;"></div>
                    <div class="ge-spark-bar" style="height: 10%;"></div>
                    <div class="ge-spark-bar" style="height: 10%;"></div>
                    <div class="ge-spark-bar" style="height: 10%;"></div>
                    <div class="ge-spark-bar" style="height: 10%;"></div>
                </div>
                <div style="display:flex; justify-content:space-between; margin-top:4px;">
                    <span style="font-size:0.6rem; color:var(--text-dim);">Mon</span>
                    <span style="font-size:0.6rem; color:var(--text-dim);">Sun</span>
                </div>
            </div>
            <!-- Weekly Bar Chart -->
            <div class="ge-section-card ge-bars-section">
                <div class="ge-bars-header">
                    <div class="ge-section-title" style="margin:0;"><span class="ge-title-dot"></span> Weekly Performance</div>
                    <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                        <div class="ge-metric-toggle">
                            <button class="ge-metric-btn active" data-action="ge-metric" data-metric="focus_minutes">Focus</button>
                            <button class="ge-metric-btn" data-action="ge-metric" data-metric="pp_earned">PP</button>
                            <button class="ge-metric-btn" data-action="ge-metric" data-metric="sessions_completed">Sessions</button>
                            <button class="ge-metric-btn" data-action="ge-metric" data-metric="consistency_score">Score</button>
                        </div>
                        <button id="ge-backfill-btn" data-action="ge-backfill" class="ge-backfill-btn">Backfill This Week</button>
                    </div>
                </div>
                <div class="ge-week-bars" id="ge-week-bars">
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Mon</span></div>
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Tue</span></div>
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Wed</span></div>
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Thu</span></div>
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Fri</span></div>
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Sat</span></div>
                    <div class="ge-day-bar"><div class="ge-bar-value">0</div><div class="ge-bar-fill" style="height: 0%;"></div><span class="ge-bar-label">Sun</span></div>
                </div>
                <div class="ge-bars-summary">
                    <div class="ge-bars-stat"><span class="ge-bs-label" id="ge-bar-metric-label">Focus</span><span class="ge-bs-value" id="ge-bar-total">0</span></div>
                    <div class="ge-bars-stat"><span class="ge-bs-label">Sessions</span><span class="ge-bs-value" id="ge-bar-sessions">0</span></div>
                    <div class="ge-bars-stat"><span class="ge-bs-label">Avg Score</span><span class="ge-bs-value" id="ge-bar-avg-score">0</span></div>
                </div>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════════════════════════════════ -->
    <!-- 5. SECONDARY WIDGETS GRID                          -->
    <!-- Timer, Panic Protocol                              -->
    <!-- ═══════════════════════════════════════════════════ -->
    <section class="dash-widgets-grid">

        <!-- Focus Timer Card -->
        <div class="focus-timer-card">
            <div class="timer-header">
                <span class="timer-label">Focus Timer</span>
                <span class="timer-session-badge" id="todaySessionsCount">0</span>
                <span class="timer-session-sub">today</span>
            </div>
            <div class="timer-display-wrapper">
                <div class="timer-display"><span id="focusMinutes">25</span>:<span id="focusSeconds">00</span></div>
                <div class="timer-progress-track">
                    <div class="timer-progress-bar" id="timerProgressBar"></div>
                </div>
            </div>
            <div class="preset-row">
                <button class="preset-btn" data-action="timer-preset" data-minutes="5">5m</button>
                <button class="preset-btn" data-action="timer-preset" data-minutes="15">15m</button>
                <button class="preset-btn selected" data-action="timer-preset" data-minutes="25">25m</button>
                <button class="preset-btn" data-action="timer-preset" data-minutes="45">45m</button>
                <button class="preset-btn" data-action="timer-preset" data-minutes="60">60m</button>
            </div>
            <div class="custom-duration-row">
                <input type="number" id="customDuration" placeholder="min" min="1" max="180">
                <button id="customDurationBtn" data-action="timer-custom">Set</button>
            </div>
            <div class="label-chips-row">
                <button class="label-chip" data-action="timer-label" data-label="Maths">Maths</button>
                <button class="label-chip" data-action="timer-label" data-label="Physics">Physics</button>
                <button class="label-chip" data-action="timer-label" data-label="Chemistry">Chemistry</button>
                <button class="label-chip" data-action="timer-label" data-label="Revision">Revision</button>
                <button class="label-chip" data-action="timer-label" data-label="Backlog">Backlog</button>
                <button class="label-chip selected" data-action="timer-label" data-label="Other">Other</button>
            </div>
            <div class="timer-controls">
                <button id="focusStartBtn" data-action="timer-toggle">Start Focus</button>
                <button id="focusResetBtn" data-action="timer-reset">Reset</button>
            </div>
            <div class="timer-today-stats">
                <span>Focus: <strong id="todayFocusMinutes">0</strong> min</span>
            </div>
        </div>

        <!-- Panic Protocol -->
        <div class="panic-card" id="panicProtocolCard">
            <div class="panic-header">
                <h3 class="panic-title">PANIC PROTOCOL ENGINE</h3>
                <span id="panicModeIndicator" class="mode-fresh">Fresh Start Mode</span>
            </div>
            <div class="panic-controls">
                <p id="panicActivationToast" style="font-size:0.8rem;"></p>
            </div>
            <ul id="panicTaskList"></ul>
        </div>

    </section>

</div>

<!-- Rank Modal (outside wrapper for z-index) -->
<div id="rank-modal" class="modal-overlay" style="display:none;">
    <div class="rank-modal-window">
        <div class="rank-timeline-container">
            <div class="timeline-track"><div class="timeline-track-fill"></div></div>
            <div class="rank-nodes" id="rank-list-container"></div>
        </div>
        <div id="rank-detail-panel"></div>
        <div style="text-align:center; margin-top:15px;">
            <button data-action="close-rank-modal" style="background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.15); color:#aaa; padding:8px 24px; border-radius:8px; cursor:pointer; font-weight:600;">Close</button>
        </div>
    </div>
</div>

<!-- Alfred Notification (fixed position) -->
<div id="alfred-card">
    <div id="alfred-badge"><span>SYST_AUTH // SUCCESS</span></div>
    <div id="alfred-text">System ready.</div>
</div>`;
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();

window.DashboardRoute = DashboardRoute;
