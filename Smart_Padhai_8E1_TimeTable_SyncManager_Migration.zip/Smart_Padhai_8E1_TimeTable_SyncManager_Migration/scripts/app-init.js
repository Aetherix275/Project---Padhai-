/**
 * ═══════════════════════════════════════════════════════
 *  SMART PADHAI — SPA APP INIT (Phase 7C)
 *  Handles auth check, sidebar setup, route registration,
 *  mobile drawer toggle, responsive shell behavior
 * ═══════════════════════════════════════════════════════
 */

(async function AppInit() {

    // ── 1. AUTH CHECK ──
    let currentUser = null;
    try {
        currentUser = await getCurrentUserOrRedirect();
        if (!currentUser) {
            // getCurrentUserOrRedirect already redirects to login.html
            console.warn('[AppInit] No user session. Redirecting...');
            return;
        }
        console.log('[AppInit] User authenticated:', currentUser.email);
    } catch (err) {
        console.error('[AppInit] Auth check failed:', err);
        window.location.href = 'login.html';
        return;
    }

    // ── 2. CALENDAR SIDEBAR ──
    function updateCalendar() {
        const d = new Date();
        const months = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE",
                        "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];
        const days = ["SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"];

        const monthEl = document.getElementById('curMonth');
        const dateEl  = document.getElementById('curDate');
        const dayEl   = document.getElementById('curDay');

        if (monthEl) monthEl.innerText = months[d.getMonth()];
        if (dateEl)  dateEl.innerText  = d.getDate();
        if (dayEl)   dayEl.innerText   = days[d.getDay()];
    }

    // ── 3. NEXT EXAM BADGE ──
    // SVG icon for urgency tag (replaces emoji)
    const TARGET_SVG = '<svg class="urgency-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>';
    const SHIELD_SVG = '<svg class="urgency-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>';

    function updateNextExamSidebar() {
        const strategyData = SafeStorage.getItem("calendarStrategy", {});
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        let minDiff = Infinity;
        let nextExamDate = null;

        for (const key in strategyData) {
            const event = strategyData[key];
            if (!event || event.mode !== "exam") continue;

            const [year, month, day] = key.split("-").map(Number);
            const examDate = new Date(year, month - 1, day);
            examDate.setHours(0, 0, 0, 0);

            if (examDate >= today) {
                const diff = examDate - today;
                if (diff < minDiff) {
                    minDiff = diff;
                    nextExamDate = examDate;
                }
            }
        }

        const el = document.getElementById("nextExamCountdown");
        if (!el) return;

        if (nextExamDate) {
            const daysLeft = Math.ceil(minDiff / (1000 * 60 * 60 * 24));
            el.innerHTML = `${TARGET_SVG}<span class="urgency-text">NEXT EXAM: ${daysLeft} DAYS</span>`;
            el.style.display = "flex";
        } else {
            el.innerHTML = `${SHIELD_SVG}<span class="urgency-text">NO UPCOMING EXAMS</span>`;
        }
    }

    // ── 4. LOGOUT HANDLER ──
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async () => {
            console.log('[AppInit] Logout clicked');
            if (typeof smartPadhaiLogout === 'function') {
                await smartPadhaiLogout();
            } else {
                window.location.href = 'login.html';
            }
        });
    }

    // ── 5. MOBILE DRAWER (Phase 7C) ──
    const sidebar       = document.getElementById('sidebar');
    const backdrop      = document.querySelector('.sidebar-backdrop');
    const hamburgerBtn  = document.querySelector('[data-action="toggle-sidebar"]');
    const closeBackdrop = document.querySelector('[data-action="close-sidebar"]');

    function openSidebar() {
        if (!sidebar) return;
        sidebar.classList.add('sidebar-open');
        if (backdrop) backdrop.classList.add('visible');
        document.body.style.overflow = 'hidden';
    }

    function closeSidebar() {
        if (!sidebar) return;
        sidebar.classList.remove('sidebar-open');
        if (backdrop) backdrop.classList.remove('visible');
        document.body.style.overflow = '';
    }

    // Hamburger toggle
    if (hamburgerBtn) {
        hamburgerBtn.addEventListener('click', () => {
            if (sidebar.classList.contains('sidebar-open')) {
                closeSidebar();
            } else {
                openSidebar();
            }
        });
    }

    // Backdrop click closes drawer
    if (closeBackdrop) {
        closeBackdrop.addEventListener('click', closeSidebar);
    }

    // Close drawer when a nav route is clicked on mobile
    const navLinks = document.querySelectorAll('.nav-links .nav-item');
    navLinks.forEach(item => {
        item.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                closeSidebar();
            }
        });
    });

    // Close drawer on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && sidebar && sidebar.classList.contains('sidebar-open')) {
            closeSidebar();
        }
    });

    // Close drawer on resize back to desktop
    window.addEventListener('resize', () => {
        if (window.innerWidth > 768 && sidebar) {
            closeSidebar();
        }
    });

    // ── 6. INITIALIZE PULSEENGINE (once after auth) ──
    if (typeof initPulseEngineAfterAuth === 'function') {
        try {
            await initPulseEngineAfterAuth();
            console.log('[AppInit] PulseEngine initialized after auth');
        } catch (err) {
            console.warn('[AppInit] PulseEngine init failed (will retry in dashboard):', err);
        }
    } else if (window.PulseEngine) {
        // Fallback: just run dailyCheck + updateUI
        PulseEngine.dailyCheck();
        PulseEngine.updateUI();
    }

    // ── 7. REGISTER ALL ROUTES ──
    // Dashboard — FULL SPA ROUTE (Phase 6G conversion)
    SpaRouter.register('/dashboard', DashboardRoute);

    // Backlog — FULL SPA ROUTE (Phase 6F conversion)
    SpaRouter.register('/backlog', BacklogRoute);

    // Syllabus — FULL SPA ROUTE (Phase 6F conversion)
    SpaRouter.register('/syllabus', SyllabusRoute);

    // Notebooks — FULL SPA ROUTE (Phase 6E conversion)
    SpaRouter.register('/notebooks', NotebooksRoute);

    // Calendar — FULL SPA ROUTE (Phase 6E conversion)
    SpaRouter.register('/calendar', CalendarRoute);

    // Timetable — FULL SPA ROUTE (Phase 6H conversion)
    SpaRouter.register('/timetable', TimetableRoute);

    // Vault — FULL SPA ROUTE (Phase 6D conversion)
    SpaRouter.register('/vault', VaultRoute);

    // Aestra — FULL SPA ROUTE (Phase 6J conversion)
    SpaRouter.register('/aestra', AestraRoute);

    // Plans — FULL SPA ROUTE (Phase 6B conversion)
    SpaRouter.register('/plans', PlansRoute);

    // ── 8. INITIALIZE ROUTER ──
    updateCalendar();
    updateNextExamSidebar();
    SpaRouter.init();
    SpaRouter.start();

    console.log('[AppInit] SPA initialized successfully. User:', currentUser.email);

})();
