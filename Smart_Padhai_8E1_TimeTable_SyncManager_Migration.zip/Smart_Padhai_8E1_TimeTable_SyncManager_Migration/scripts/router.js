/**
 * ═══════════════════════════════════════════════════════
 *  SMART PADHAI — SPA ROUTER (Phase 6B)
 *  Hash-based, zero-dependency, vanilla JS router
 * ═══════════════════════════════════════════════════════
 *
 *  How it works:
 *    - Listens to `hashchange` events
 *    - Reads window.location.hash → e.g. "#/plans"
 *    - Looks up the route in the registry
 *    - Calls route.init(container) to render content
 *    - Calls route.cleanup() before switching away
 *
 *  Route modules must export:
 *    { init(container: HTMLElement): void, cleanup(): void }
 */

const SpaRouter = (() => {

    // ── Route Registry ──
    const routes = {};

    // ── Currently active route key ──
    let currentRouteKey = null;

    // ── DOM reference to main content area ──
    let contentArea = null;

    // ── Navigation guard (prevents double-navigate from hashchange) ──
    let isNavigating = false;

    // ── Fallback route ──
    const DEFAULT_ROUTE = '/dashboard';

    // ─────────────────────────────
    //  Register a route module
    // ─────────────────────────────
    function register(path, module) {
        if (!path || !module || typeof module.init !== 'function') {
            console.error('[Router] Invalid route registration:', path);
            return;
        }
        routes[path] = module;
        console.log(`[Router] Registered: #${path}`);
    }

    // ─────────────────────────────
    //  Navigate to a route
    // ─────────────────────────────
    async function navigate(path) {
        if (!contentArea) {
            console.error('[Router] Content area not set. Call init() first.');
            return;
        }

        // Guard: prevent double navigation
        if (isNavigating) return;
        isNavigating = true;

        try {
            // Normalize path (remove trailing slash, ensure leading /)
            path = normalizePath(path);

            // Same route? Skip
            if (path === currentRouteKey) return;

            // Cleanup previous route
            if (currentRouteKey && routes[currentRouteKey] && typeof routes[currentRouteKey].cleanup === 'function') {
                try {
                    routes[currentRouteKey].cleanup();
                } catch (err) {
                    console.warn('[Router] Cleanup error for', currentRouteKey, err);
                }
            }

            // Clear content area
            contentArea.innerHTML = '';

            // Find route module
            const module = routes[path];

            if (!module) {
                console.warn('[Router] No route registered for:', path, '→ showing not found');
                renderNotFound(contentArea, path);
                currentRouteKey = null;
                updateActiveNav(path);
                return;
            }

            // Init new route
            await module.init(contentArea);
            currentRouteKey = path;
            updateActiveNav(path);

            // Update URL hash only if it doesn't match (avoid unnecessary replaceState)
            const currentHash = window.location.hash.slice(1);
            if (currentHash !== path) {
                // Use replaceState to update URL without triggering hashchange
                // This prevents the browser from adding a new history entry on every nav
                history.replaceState(null, '', '#' + path);
            }

            console.log('[Router] Navigated to:', path);
        } catch (err) {
            console.error('[Router] Init error for', path, err);
            contentArea.innerHTML = `
                <div class="spa-error">
                    <h2>Route Error</h2>
                    <p>Failed to load: #${path}</p>
                    <p class="error-detail">${err.message}</p>
                    <button onclick="window.location.hash='#/dashboard'" class="retry-btn">Go to Dashboard</button>
                </div>
            `;
            currentRouteKey = null;
        } finally {
            isNavigating = false;
        }
    }

    // ─────────────────────────────
    //  Get current route key
    // ─────────────────────────────
    function getCurrentRoute() {
        return currentRouteKey;
    }

    // ─────────────────────────────
    //  Initialize router
    // ─────────────────────────────
    function init() {
        contentArea = document.getElementById('app-content');
        if (!contentArea) {
            console.error('[Router] #app-content element not found!');
            return;
        }

        // Single hashchange listener — never duplicated
        window.addEventListener('hashchange', handleHashChange);

        console.log('[Router] Initialized. Listening for hash changes.');
    }

    // ── Hash change handler (extracted for clarity) ──
    function handleHashChange() {
        const hash = window.location.hash.slice(1) || DEFAULT_ROUTE;
        navigate(hash);
    }

    // ─────────────────────────────
    //  Start routing (call after all routes registered)
    // ─────────────────────────────
    function start() {
        const hash = window.location.hash.slice(1) || DEFAULT_ROUTE;

        // Ensure URL has a hash on first load so refresh works
        // replaceState avoids triggering hashchange
        if (!window.location.hash || window.location.hash === '#' || window.location.hash === '#/') {
            history.replaceState(null, '', '#' + hash);
        }

        navigate(hash);
    }

    // ─────────────────────────────
    //  Internal helpers
    // ─────────────────────────────
    function normalizePath(path) {
        path = String(path).trim();
        if (!path.startsWith('/')) path = '/' + path;
        if (path.length > 1 && path.endsWith('/')) path = path.slice(0, -1);
        return path;
    }

    function updateActiveNav(path) {
        // Remove active class from all nav items
        const navItems = document.querySelectorAll('.nav-links .nav-item');
        navItems.forEach(item => item.classList.remove('active'));

        // Add active class to matching nav item
        const target = document.querySelector(`.nav-links .nav-item[data-route="${path.replace('/', '')}"]`);
        if (target) target.classList.add('active');
    }

    function renderNotFound(container, path) {
        container.innerHTML = `
            <div class="spa-not-found">
                <div class="not-found-icon">🔍</div>
                <h2>Route Not Found</h2>
                <p>No route registered for: <code>#${path}</code></p>
                <button onclick="window.location.hash='#/dashboard'" class="retry-btn">Go to Dashboard</button>
            </div>
        `;
    }

    // ── Public API ──
    return {
        register,
        navigate,
        getCurrentRoute,
        init,
        start
    };

})();

// Make globally accessible
window.SpaRouter = SpaRouter;
