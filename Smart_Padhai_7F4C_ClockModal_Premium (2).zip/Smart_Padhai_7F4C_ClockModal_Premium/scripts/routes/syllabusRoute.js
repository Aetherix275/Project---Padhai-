/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — SYLLABUS ROUTE MODULE (Phase 7E-2B Visual Strength)
 *  Full SPA conversion of Syllabus Tracker
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear state
 *
 *  Data: SafeStorage-first, Supabase mirror second
 *  Events: All via event delegation + AbortController. Zero inline onclick.
 *  CSS: Loaded dynamically from styles/modules/syllabus.css
 *
 *  PP Safety:
 *    - Mastery (+20 PP) only when transitioning non-mastered → mastered
 *    - Unique rewardId prevents duplicate PP
 *    - Never calls loadPulseEngineFromSupabase() or syncPulseEngineToSupabase()
 * ═══════════════════════════════════════════════════════════════════
 */

const SyllabusRoute = (() => {

    // ── Private state ──
    let _container = null;
    let _abortController = null;
    let _currentClass = 10;
    let _toastTimeout = null;
    let _cssLinkEl = null;

    const CSS_PATH = './styles/modules/syllabus.css';
    const MASTER_KEY = 'smartPadhaiData';
    const TRACKER_KEY = 'syllabus_master_tracker';
    const CLASS_KEY = 'userClass';

    // ── Syllabus Data Map ──
    const _SYLLABUS_DATA = {
        9: {
            "Science": {
                "Physics": ["Motion", "Force & Laws of Motion", "Gravitation"],
                "Chemistry": ["Matter in our Surroundings", "Is Matter Around Us Pure"],
                "Biology": ["Cell - Basic Unit of Life", "Tissues"]
            }
        },
        10: {
            "Science": {
                "Physics": ["Light - Reflection & Refraction", "The Human Eye", "Electricity", "Magnetic Effects"],
                "Chemistry": ["Chemical Reactions", "Acids, Bases & Salts", "Metals & Non-metals", "Carbon & its Compounds"],
                "Biology": ["Life Processes", "Control & Coordination", "Reproduction", "Heredity"]
            },
            "Maths": {
                "Standard": ["Real Numbers", "Polynomials", "Quadratic Equations", "Trigonometry"]
            }
        }
    };

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════

    async function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;

        // 1. Load CSS
        _loadCSS();

        // 2. Try loading from Supabase (best-effort merge)
        await _loadFromSupabase();

        // 3. Render full UI
        container.innerHTML = renderFullUI();

        // 4. Check saved class preference
        const savedClass = SafeStorage.getItem(CLASS_KEY, null);
        if (savedClass && _SYLLABUS_DATA[savedClass]) {
            _currentClass = savedClass;
            _selectClass(savedClass, true); // true = skip saving again
        }

        // 5. Bind events
        _bindEvents(container, _abortController.signal);

        console.log('[SyllabusRoute] Initialized');
    }

    function cleanup() {
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }
        if (_toastTimeout) {
            clearTimeout(_toastTimeout);
            _toastTimeout = null;
        }
        // Remove confirm overlays
        document.querySelectorAll('.syl-confirm-overlay').forEach(el => el.remove());
        // Remove toast
        document.querySelectorAll('.syl-toast').forEach(el => el.remove());
        _unloadCSS();
        _container = null;
        console.log('[SyllabusRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.syllabusCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-syllabus-css]');
        if (el) { el.remove(); _cssLinkEl = null; }
    }

    // ════════════════════════════════════════════════════════
    //  SUPABASE SYNC
    // ════════════════════════════════════════════════════════

    function _getUserId() {
        return window.AppState?.currentUser?.id || localStorage.getItem('_current_user_id');
    }

    async function _loadFromSupabase() {
        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) return;

        try {
            const { data, error } = await window.supabaseClient
                .from('syllabus_progress')
                .select('*')
                .eq('user_id', userId);

            if (error || !data || data.length === 0) return;

            const local = SafeStorage.getItem(MASTER_KEY, {});

            // Defensive: local must be a plain object
            if (typeof local !== 'object' || local === null || Array.isArray(local)) {
                console.warn('[SyllabusRoute] Local masterData corrupted in Supabase merge, resetting');
                return;
            }

            let merged = false;

            // Merge ALL rows chapter-by-chapter — NEVER overwrite local with only one row
            data.forEach(row => {
                const chapter = row.chapter;
                if (!chapter) return;

                const localEntry = local[chapter];
                const cloudRead = !!row.read;
                const cloudNotes = !!row.notes;
                const cloudPyq = !!row.pyq;

                if (!localEntry || typeof localEntry !== 'object') {
                    // Cloud-only chapter — add to local
                    local[chapter] = {
                        read: cloudRead,
                        notes: cloudNotes,
                        pyq: cloudPyq,
                        lastUpdated: row.updated_at || new Date().toLocaleDateString(),
                        isSyllabus: true
                    };
                    merged = true;
                } else {
                    // Both exist — only take cloud if it has STRICTLY more progress
                    // AND local has zero progress (never overwrite user's recent changes)
                    const localDone = [localEntry.read, localEntry.notes, localEntry.pyq].filter(Boolean).length;
                    const cloudDone = [cloudRead, cloudNotes, cloudPyq].filter(Boolean).length;

                    // SAFE MERGE: Only accept cloud data when local has NO progress at all
                    // This prevents stale Supabase data from overwriting user's recent edits
                    if (localDone === 0 && cloudDone > 0) {
                        local[chapter] = {
                            ...localEntry,  // preserve _scheduledFor, isSyllabus
                            read: cloudRead,
                            notes: cloudNotes,
                            pyq: cloudPyq,
                            isSyllabus: true,
                            lastUpdated: row.updated_at || localEntry.lastUpdated
                        };
                        merged = true;
                    }
                }
            });

            if (merged) {
                SafeStorage.setItem(MASTER_KEY, local);
                console.log(`[SyllabusRoute] Merged ${data.length} rows from Supabase. Local chapters: ${Object.keys(local).length}`);
            }
        } catch (err) {
            console.warn('[SyllabusRoute] Supabase load failed:', err);
        }
    }

    async function _syncToSupabase() {
        if (!window.supabaseClient) return;
        const userId = _getUserId();
        if (!userId) return;

        try {
            const masterData = SafeStorage.getItem(MASTER_KEY, {});
            const rows = [];

            for (const chapName in masterData) {
                const entry = masterData[chapName];
                if (typeof entry !== 'object' || entry === null) continue;

                rows.push({
                    user_id: userId,
                    subject: entry.isSyllabus ? 'General' : 'Backlog',
                    chapter: chapName,
                    read: !!entry.read,
                    notes: !!entry.notes,
                    pyq: !!entry.pyq,
                    completed: !!(entry.read && entry.notes && entry.pyq),
                    updated_at: new Date().toISOString()
                });
            }

            if (rows.length === 0) return;

            // Batch upsert
            const { error } = await window.supabaseClient
                .from('syllabus_progress')
                .upsert(rows, { onConflict: 'user_id,subject,chapter' });

            if (error) console.warn('[SyllabusRoute] Mirror sync failed:', error);
            else console.log('[SyllabusRoute] Synced to Supabase');
        } catch (err) {
            console.warn('[SyllabusRoute] Mirror error:', err);
        }
    }

    // ════════════════════════════════════════════════════════
    //  HTML RENDERING
    // ════════════════════════════════════════════════════════

    function renderFullUI() {
        return `
        <div class="syllabus-wrapper">
            <!-- PAGE HEADER -->
            <div class="syllabus-page-header">
                <h1 class="syllabus-page-title">Syllabus</h1>
                <p class="syllabus-page-subtitle">Strategic chapter mastery tracker</p>
            </div>

            <!-- CLASS SELECTOR -->
            <div id="classSelector" class="class-selection-overlay">
                <h2>Select Your Mission Level</h2>
                <p class="class-selection-subtitle">Choose your battlefield to begin mission tracking</p>
                <div class="class-cards">
                    <div class="class-card" data-action="select-class" data-class="9">
                        <span class="class-number">09</span>
                        <p class="class-label">Class 9th</p>
                        <p class="class-desc">Foundation year \u2014 build core concepts</p>
                    </div>
                    <div class="class-card" data-action="select-class" data-class="10">
                        <span class="class-number">10</span>
                        <p class="class-label">Class 10th</p>
                        <p class="class-desc">Board year \u2014 conquer every chapter</p>
                    </div>
                </div>
            </div>

            <!-- SUBJECT SECTION -->
            <div id="subjectSection" style="display:none;">
                <div class="section-header">
                    <button class="back-btn sp-btn" data-action="go-back-to-class">\u2190 Back</button>
                    <h2 id="classHeading">Class 10th Missions</h2>
                </div>
                <div class="subject-grid" id="subjectGrid"></div>
            </div>

            <!-- CHECKLIST SECTION -->
            <div id="checklistSection" style="display:none;">
                <div class="section-header">
                    <button class="back-btn sp-btn" data-action="go-back-to-subjects">\u2190 Back to Subjects</button>
                    <h2 id="checklistTitle">Science - Mission List</h2>
                </div>
                <div id="bookTabs" class="book-tabs" style="display:none;"></div>
                <div class="chapter-list-container" id="chapterList"></div>
            </div>
        </div>
        <!-- Toast -->
        <div class="syl-toast" id="sylToast"></div>`;
    }

    // ════════════════════════════════════════════════════════
    //  CLASS SELECTION
    // ════════════════════════════════════════════════════════

    function _selectClass(classNum, skipSave) {
        _currentClass = classNum;

        // Show subjects, hide class selector
        const classSelector = _container?.querySelector('#classSelector');
        const subjectSection = _container?.querySelector('#subjectSection');
        const classHeading = _container?.querySelector('#classHeading');
        const checklistSection = _container?.querySelector('#checklistSection');

        // Mark selected class card visually
        _container?.querySelectorAll('.class-card').forEach(c => c.classList.remove('selected'));
        const selectedCard = _container?.querySelector(`.class-card[data-class="${classNum}"]`);
        if (selectedCard) selectedCard.classList.add('selected');

        if (classSelector) classSelector.style.display = 'none';
        if (subjectSection) subjectSection.style.display = 'block';
        if (checklistSection) checklistSection.style.display = 'none';
        if (classHeading) classHeading.innerText = `Class ${classNum}th Missions`;

        // Save preference
        if (!skipSave) {
            SafeStorage.setItem(CLASS_KEY, classNum);
        }

        // Register all chapters in smartPadhaiData
        let masterData = SafeStorage.getItem(MASTER_KEY, {});
        const subjects = _SYLLABUS_DATA[classNum];
        if (!subjects) return;

        for (const subj in subjects) {
            for (const book in subjects[subj]) {
                subjects[subj][book].forEach(chap => {
                    if (!masterData[chap]) {
                        masterData[chap] = { read: false, notes: false, pyq: false, isSyllabus: true };
                    } else {
                        // Preserve existing data, just mark as syllabus
                        masterData[chap].isSyllabus = true;
                    }
                });
            }
        }
        SafeStorage.setItem(MASTER_KEY, masterData);

        // Sync progress tracker
        _syncProgressTracker(classNum);

        // Mirror to Supabase
        _syncToSupabase(); // fire-and-forget

        // Render subject cards
        _renderSubjectGrid();
    }

    function _renderSubjectGrid() {
        const grid = _container?.querySelector('#subjectGrid');
        if (!grid) return;

        const subjects = _SYLLABUS_DATA[_currentClass];
        if (!subjects) { grid.innerHTML = '<p>No data found.</p>'; return; }

        const subjectMeta = {
            "Science":  { icon: "\uD83E\uDDEC", desc: "Phy, Chem, Bio", color: "#00d4ff" },
            "Maths":    { icon: "\uD83D\uDCD0", desc: "Calculations & Logic", color: "#ffcc00" },
            "SST":      { icon: "\uD83C\uDF0D", desc: "His, Geo, Civ, Eco", color: "#ff5e62" },
            "English":  { icon: "\uD83D\uDCD6", desc: "Literature & Grammar", color: "#a8ff78" },
            "Hindi":    { icon: "\u270D\uFE0F", desc: "Vyakaran & Sahitya", color: "#feb47b" },
            "IT":       { icon: "\uD83D\uDCBB", desc: "Digital Mastery", color: "#8e44ad" }
        };

        let html = '';
        for (const subj in subjects) {
            const meta = subjectMeta[subj] || { icon: "\uD83D\uDCDD", desc: "Subject", color: "#888" };
            html += `
            <div class="subject-card-box" data-action="show-chapters" data-subject="${subj}">
                <div class="sub-icon" style="color: ${meta.color};">${meta.icon}</div>
                <h3>${subj}</h3>
                <p>${meta.desc}</p>
            </div>`;
        }

        grid.innerHTML = html;
    }

    // ════════════════════════════════════════════════════════
    //  CHAPTERS
    // ════════════════════════════════════════════════════════

    function _showChapters(subjectName) {
        const subjectSection = _container?.querySelector('#subjectSection');
        const checklistSection = _container?.querySelector('#checklistSection');
        const checklistTitle = _container?.querySelector('#checklistTitle');

        if (subjectSection) subjectSection.style.display = 'none';
        if (checklistSection) checklistSection.style.display = 'block';
        if (checklistTitle) checklistTitle.innerText = `${subjectName} - Mission List`;

        const chapterList = _container?.querySelector('#chapterList');
        const bookTabsEl = _container?.querySelector('#bookTabs');
        if (!chapterList) return;

        const books = _SYLLABUS_DATA[_currentClass]?.[subjectName];
        const masterData = SafeStorage.getItem(MASTER_KEY, {});

        if (!books) {
            chapterList.innerHTML = `<div class="syl-empty-state">
                <span class="syl-empty-icon">\uD83D\uDCCB</span>
                <p>No chapters found for ${subjectName}.</p>
            </div>`;
            return;
        }

        // If multiple books, show tabs
        const bookNames = Object.keys(books);
        if (bookNames.length > 1 && bookTabsEl) {
            bookTabsEl.style.display = 'flex';
            bookTabsEl.innerHTML = bookNames.map((book, i) =>
                `<button class="back-btn sp-btn ${i === 0 ? 'active' : ''}" data-action="filter-book" data-book="${book}">${book}</button>`
            ).join('');
        } else if (bookTabsEl) {
            bookTabsEl.style.display = 'none';
        }

        let html = '';
        for (const book in books) {
            html += `<h3 class="book-title">${book}</h3>`;

            books[book].forEach(chapter => {
                const chapId = chapter.replace(/\s+/g, '');
                const saved = masterData[chapter] || { read: false, notes: false, pyq: false };
                const isDone = saved.read && saved.notes && saved.pyq;

                html += `
                <div class="chapter-card ${isDone ? 'mastered' : ''}" id="chap-${chapId}" data-chapter="${chapter}">
                    <div class="chapter-main">
                        <div class="chapter-header">
                            <span class="diff-tag medium sp-badge">MEDIUM</span>
                            <h3 class="chapter-name ${isDone ? 'completed-task' : ''}">${chapter}</h3>
                        </div>
                        <div class="chapter-progress-container">
                            <div class="progress-track">
                                <div class="progress-fill" id="fill-${chapId}"
                                     style="width:${isDone ? '100%' : '0%'}; background:${isDone ? 'linear-gradient(90deg, #28a745, #20c997)' : ''}">
                                </div>
                            </div>
                            <span class="percentage" id="perc-${chapId}">${isDone ? '100%' : '0%'}</span>
                        </div>
                    </div>
                    <div class="chapter-actions">
                        <div class="check-group">
                            <label class="custom-check">
                                <input type="checkbox" data-action="update-progress" data-chapter="${chapter}" data-field="read" ${saved.read ? 'checked' : ''}>
                                <span class="check-label">Read</span>
                            </label>
                            <label class="custom-check">
                                <input type="checkbox" data-action="update-progress" data-chapter="${chapter}" data-field="notes" ${saved.notes ? 'checked' : ''}>
                                <span class="check-label">Notes</span>
                            </label>
                            <label class="custom-check">
                                <input type="checkbox" data-action="update-progress" data-chapter="${chapter}" data-field="pyq" ${saved.pyq ? 'checked' : ''}>
                                <span class="check-label">PYQ</span>
                            </label>
                        </div>
                    </div>
                    <div class="mastery-badge" id="badge-${chapId}" style="display:${isDone ? 'block' : 'none'};">\uD83C\uDFC6 MASTERED</div>
                </div>`;
            });
        }

        chapterList.innerHTML = html;
    }

    // ════════════════════════════════════════════════════════
    //  PROGRESS UPDATE
    // ════════════════════════════════════════════════════════

    function _updateProgress(chapter, field, isChecked) {
        const chapId = chapter.replace(/\s+/g, '');
        const card = _container?.querySelector(`#chap-${chapId}`);
        if (!card) return;

        // Update the specific checkbox's visual state
        // Read current state from all 3 checkboxes
        const readCb = card.querySelector('[data-field="read"]');
        const notesCb = card.querySelector('[data-field="notes"]');
        const pyqCb = card.querySelector('[data-field="pyq"]');

        const readVal = readCb ? readCb.checked : false;
        const notesVal = notesCb ? notesCb.checked : false;
        const pyqVal = pyqCb ? pyqCb.checked : false;

        const checkedCount = [readVal, notesVal, pyqVal].filter(Boolean).length;
        const isMastered = checkedCount === 3;
        const wasMastered = card.classList.contains('mastered');

        // Update progress bar
        const fill = _container?.querySelector(`#fill-${chapId}`);
        const perc = _container?.querySelector(`#perc-${chapId}`);
        const badge = _container?.querySelector(`#badge-${chapId}`);
        const chapterName = card.querySelector('.chapter-name');

        const progress = Math.round((checkedCount / 3) * 100);

        if (fill) {
            fill.style.width = progress + '%';
            fill.style.background = isMastered ?
                'linear-gradient(90deg, #28a745, #20c997)' :
                'linear-gradient(90deg, #00d4ff, #0072ff)';
        }
        if (perc) perc.innerText = progress + '%';

        // Mastery logic
        if (isMastered && !wasMastered) {
            card.classList.add('mastered');
            if (badge) badge.style.display = 'block';
            if (chapterName) chapterName.classList.add('completed-task');

            // PP reward — ONLY on transition from non-mastered to mastered
            const rewardId = `mastered_${chapId}_${new Date().toDateString().replace(/\s+/g, '_')}`;
            PulseEngine.addPoints(20, 'mission', { rewardId });
            _showToast(`CHAPTER MASTERED: +20 PP \uD83C\uDFC6`);
        } else if (!isMastered) {
            card.classList.remove('mastered');
            if (badge) badge.style.display = 'none';
            if (chapterName) chapterName.classList.remove('completed-task');
        }

        // Save to smartPadhaiData — PRESERVE ALL existing chapters
        // CRITICAL: Read the FULL object, update ONLY this chapter, save FULL object back
        let masterData = SafeStorage.getItem(MASTER_KEY, {});

        // Defensive: masterData must be a plain object
        if (typeof masterData !== 'object' || masterData === null || Array.isArray(masterData)) {
            console.warn('[SyllabusRoute] masterData corrupted, resetting to {}');
            masterData = {};
        }

        const existing = masterData[chapter] || {};

        // Preserve ALL existing fields (_scheduledFor, isSyllabus, etc.)
        // Explicitly set isSyllabus: true — this is a syllabus chapter
        masterData[chapter] = {
            ...existing,  // preserve _scheduledFor, isSyllabus, subject, etc.
            read: readVal,
            notes: notesVal,
            pyq: pyqVal,
            isSyllabus: true,  // ALWAYS set — this is a syllabus chapter
            lastUpdated: new Date().toLocaleDateString()
        };

        SafeStorage.setItem(MASTER_KEY, masterData);
        _syncToSupabase(); // fire-and-forget
    }

    // ════════════════════════════════════════════════════════
    //  PROGRESS TRACKER
    // ════════════════════════════════════════════════════════

    function _syncProgressTracker(classNum) {
        let progressTracker = SafeStorage.getItem(TRACKER_KEY, {});
        const subjects = _SYLLABUS_DATA[classNum];
        if (!subjects) return;

        for (const subj in subjects) {
            for (const book in subjects[subj]) {
                subjects[subj][book].forEach(chap => {
                    if (!progressTracker[chap]) {
                        progressTracker[chap] = { isRegistered: true };
                    }
                });
            }
        }
        SafeStorage.setItem(TRACKER_KEY, progressTracker);
    }

    // ════════════════════════════════════════════════════════
    //  NAVIGATION
    // ════════════════════════════════════════════════════════

    function _goBackToClass() {
        const classSelector = _container?.querySelector('#classSelector');
        const subjectSection = _container?.querySelector('#subjectSection');
        const checklistSection = _container?.querySelector('#checklistSection');

        if (classSelector) classSelector.style.display = 'flex';
        if (subjectSection) subjectSection.style.display = 'none';
        if (checklistSection) checklistSection.style.display = 'none';
    }

    function _goBackToSubjects() {
        const subjectSection = _container?.querySelector('#subjectSection');
        const checklistSection = _container?.querySelector('#checklistSection');

        if (subjectSection) subjectSection.style.display = 'block';
        if (checklistSection) checklistSection.style.display = 'none';
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING — Delegation + AbortController
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {
        // ── CLICK DELEGATION ──
        container.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;

            switch (action) {
                case 'select-class': {
                    const classNum = parseInt(target.dataset.class);
                    if (!isNaN(classNum)) _selectClass(classNum);
                    break;
                }

                case 'show-chapters': {
                    const subject = target.dataset.subject;
                    if (subject) _showChapters(subject);
                    break;
                }

                case 'go-back-to-class':
                    _goBackToClass();
                    break;

                case 'go-back-to-subjects':
                    _goBackToSubjects();
                    break;

                case 'filter-book': {
                    // Toggle active tab and scroll to book section
                    const book = target.dataset.book;
                    if (book) {
                        // Toggle active class on book tabs
                        container.querySelectorAll('.book-tabs .back-btn').forEach(b => b.classList.remove('active'));
                        target.classList.add('active');
                        // Scroll to book title
                        const headings = container.querySelectorAll('.book-title');
                        headings.forEach(h => {
                            if (h.textContent === book) {
                                h.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            }
                        });
                    }
                    break;
                }
            }
        }, { signal });

        // ── CHANGE DELEGATION (checkboxes) ──
        container.addEventListener('change', (e) => {
            const target = e.target;
            const action = target.dataset.action;

            if (action === 'update-progress') {
                const chapter = target.dataset.chapter;
                const field = target.dataset.field;
                if (chapter && field) {
                    _updateProgress(chapter, field, target.checked);
                }
            }
        }, { signal });
    }

    // ════════════════════════════════════════════════════════
    //  TOAST
    // ════════════════════════════════════════════════════════

    function _showToast(message) {
        const toast = _container?.querySelector('#sylToast');
        if (!toast) return;

        toast.textContent = message;
        toast.classList.add('visible');

        if (_toastTimeout) clearTimeout(_toastTimeout);
        _toastTimeout = setTimeout(() => {
            toast.classList.remove('visible');
        }, 3000);
    }

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();

window.SyllabusRoute = SyllabusRoute;
