/**
 * ═══════════════════════════════════════════════════════
 *  SMART PADHAI — TIMETABLE ROUTE (Phase 6H + 7F-4C)
 *  Full SPA conversion of Time.html with legacy styling preserved
 *  Phase 7F-2A: Data Bridge Foundation — time_blocks_v1 + commanderMissions bridge
 *  Phase 7F-3: Time Block UI Upgrade — type/priority/status badges, free gaps
 *  Phase 7F-3B: Mission Timeline Professional UI — hero dashboard, redesigned cards,
 *              styled dropdowns, timeline accents, improved CTAs, responsive polish
 *  Phase 7F-4A: Tactical Clock / Smart Time Intelligence — live clock, active block
 *              detection, countdown, execution messages, day progress, minute tracking
 *  Phase 7F-4B: UI/UX Polish — stronger hierarchy, spacing, typography, state colors,
 *              improved badges, refined tactical style, hover/focus feedback
 *  Phase 7F-4C: Clock Modal Premium Refinement — visual hierarchy, polished clock face,
 *              upgraded selectors, tactical preview, animations, premium CTAs
 * ═══════════════════════════════════════════════════════
 *
 *  Architecture:
 *    - IIFE pattern with render/init/cleanup lifecycle
 *    - AbortController for all event listeners
 *    - data-action delegation — NO inline onclick
 *    - Dynamic CSS load/unload via <link data-route-css>
 *    - SafeStorage keys: commanderMissions (read-only backup), time_blocks_v1,
 *      brainDump_{date}, notes_{date}, time_table_last_opened_date
 *    - PP rewards via PulseEngine.addPoints() with unique rewardId
 *    - NEVER calls loadPulseEngineFromSupabase / syncPulseEngineToSupabase
 *    - NEVER resets PulseEngine
 */

const TimetableRoute = (() => {

    // ── State ──
    let _container = null;
    let _abortController = null;
    let _cssLinkEl = null;
    const CSS_PATH = './styles/modules/timetable.css';

    let missions = { morning: [], afternoon: [], night: [] };
    const TIME_TABLE_LAST_OPENED_KEY = 'time_table_last_opened_date';
    const TIME_BLOCKS_KEY = 'time_blocks_v1';
    let blocksData = null; // { version: 1, date: '...', blocks: [...] }

    // Intervals / timeouts (tracked for cleanup)
    let _tacticalInterval = null;
    let _phaseInterval = null;
    let _clockInterval = null; // Phase 7F-4A: 1-second tactical clock tick

    // ── Clock Modal State ──
    let ckStep = 0;
    let ckActiveInput = null;
    let ckActiveSlot = null;
    let ckActiveIndex = null;
    let ckSelH = null;
    let ckSelM = null;
    let ckSelAMPM = 'AM';
    let ckStartH = null;
    let ckStartM = null;
    let ckStartAMPM = 'AM';

    // ═══════════════════════════════════════════
    //  DATA BRIDGE & HELPERS (Phase 7F-2A)
    // ═══════════════════════════════════════════

    function getTodayKey() {
        return new Date().toDateString();
    }

    function generateBlockId() {
        return 'blk_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
    }

    function getPhaseFromHour(hour24) {
        if (hour24 >= 6 && hour24 < 12) return 'morning';
        if (hour24 >= 12 && hour24 < 18) return 'afternoon';
        return 'night';
    }

    function parseTimeWindow(timeString, slotHint) {
        const defaultResult = { startH: 9, startM: 0, endH: 10, endM: 0 };
        if (!timeString || typeof timeString !== 'string') return defaultResult;

        const parts = timeString.split(' - ');
        if (parts.length !== 2) return defaultResult;

        const startMatch = parts[0].trim().match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
        const endMatch   = parts[1].trim().match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
        if (!startMatch || !endMatch) return defaultResult;

        let startH = parseInt(startMatch[1]);
        let startM = parseInt(startMatch[2]);
        let endH   = parseInt(endMatch[1]);
        let endM   = parseInt(endMatch[2]);

        const startAMPM = (startMatch[3] || '').toUpperCase();
        const endAMPM   = (endMatch[3] || '').toUpperCase();

        // Convert to 24h if AM/PM specified
        if (startAMPM) {
            if (startAMPM === 'PM' && startH !== 12) startH += 12;
            else if (startAMPM === 'AM' && startH === 12) startH = 0;
        } else if (slotHint && slotHint !== 'morning') {
            // No AM/PM, not morning: assume PM for hours 1-11
            if (startH >= 1 && startH <= 11) startH += 12;
        }

        if (endAMPM) {
            if (endAMPM === 'PM' && endH !== 12) endH += 12;
            else if (endAMPM === 'AM' && endH === 12) endH = 0;
        } else if (slotHint && slotHint !== 'morning') {
            if (endH >= 1 && endH <= 11) endH += 12;
        }

        return { startH, startM, endH, endM };
    }

    function formatBlockTime(block) {
        const startH12  = block.startHour % 12 || 12;
        const startAMPM = block.startHour < 12 ? 'AM' : 'PM';
        const endH12    = block.endHour % 12 || 12;
        const endAMPM   = block.endHour < 12 ? 'AM' : 'PM';
        return String(startH12).padStart(2, '0') + ':' + String(block.startMinute).padStart(2, '0') + ' ' + startAMPM +
               ' - ' +
               String(endH12).padStart(2, '0') + ':' + String(block.endMinute).padStart(2, '0') + ' ' + endAMPM;
    }

    function mapBlockStatusToLegacy(blockStatus) {
        switch (blockStatus) {
            case 'completed': return 'done';
            case 'missed':    return 'fail';
            case 'active':    return 'pending'; // active treated as pending in legacy UI
            case 'planned':   return 'pending';
            case 'shifted':   return 'pending'; // shifted treated as pending in legacy UI
            default:          return 'pending';
        }
    }

    function mapLegacyStatusToBlock(legacyStatus) {
        switch (legacyStatus) {
            case 'done':  return 'completed';
            case 'fail':  return 'missed';
            default:      return 'planned';
        }
    }

    function hasAnyOldMissions(oldMissions) {
        if (!oldMissions) return false;
        return ['morning', 'afternoon', 'night'].some(slot =>
            Array.isArray(oldMissions[slot]) && oldMissions[slot].length > 0
        );
    }

    function bridgeOldMissionsToNew(oldMissions) {
        const blocks = [];
        ['morning', 'afternoon', 'night'].forEach(slot => {
            if (!Array.isArray(oldMissions[slot])) return;
            oldMissions[slot].forEach((m, i) => {
                const parsed = parseTimeWindow(m.time, slot);
                const isGold = m.isGold || false;
                blocks.push({
                    id: generateBlockId(),
                    title: m.title || '',
                    subject: '',
                    type: isGold ? 'deep_work' : 'other',
                    priority: isGold ? 'gold' : 'normal',
                    status: mapLegacyStatusToBlock(m.status),
                    startHour: parsed.startH,
                    startMinute: parsed.startM,
                    endHour: parsed.endH,
                    endMinute: parsed.endM,
                    duration: Math.max(0, (parsed.endH * 60 + parsed.endM) - (parsed.startH * 60 + parsed.startM)),
                    phase: slot,
                    legacySlot: slot,
                    legacyIndex: i,
                    actualStart: null,
                    actualEnd: null,
                    completedAt: null,
                    subtasks: m.subtasks || [],
                    subtasksOpen: m.subtasksOpen || false,
                    color: isGold ? '#ffd700' : (m.color || '#00ff9d'),
                    isGold: isGold,
                    ppRewarded: m.ppRewarded || false,
                    shiftedFrom: null,
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                });
            });
        });
        return { version: 1, date: getTodayKey(), blocks };
    }

    // Phase 7F-3: blocksToMissions carries type/priority/blockStatus
    function blocksToMissions(bData) {
        const m = { morning: [], afternoon: [], night: [] };
        if (!bData || !Array.isArray(bData.blocks)) return m;

        bData.blocks.forEach(block => {
            const slot = block.phase || getPhaseFromHour(block.startHour);
            if (!m[slot]) m[slot] = [];
            m[slot].push({
                time: formatBlockTime(block),
                title: block.title || '',
                status: mapBlockStatusToLegacy(block.status),
                color: block.color || '#00ff9d',
                isGold: block.isGold || block.priority === 'gold' || false,
                subtasks: block.subtasks || [],
                subtasksOpen: block.subtasksOpen || false,
                ppRewarded: block.ppRewarded || false,
                _blockId: block.id,
                _type: block.type || 'other',
                _priority: block.priority || (block.isGold ? 'gold' : 'normal'),
                _blockStatus: block.status || 'planned'
            });
        });

        return m;
    }

    // Phase 7F-3: missionsToBlocks reads _type/_priority back
    function missionsToBlocks(missionsObj, existingBData) {
        const blocks = [];
        const existingBlocks = (existingBData && Array.isArray(existingBData.blocks)) ? existingBData.blocks : [];

        ['morning', 'afternoon', 'night'].forEach(slot => {
            if (!Array.isArray(missionsObj[slot])) return;
            missionsObj[slot].forEach((m, i) => {
                // Find existing block by _blockId for ID preservation
                const existingBlock = m._blockId
                    ? existingBlocks.find(b => b.id === m._blockId)
                    : null;

                const parsed = parseTimeWindow(m.time, slot);

                blocks.push({
                    id: existingBlock ? existingBlock.id : (m._blockId || generateBlockId()),
                    title: m.title || '',
                    subject: existingBlock ? existingBlock.subject : '',
                    type: m._type || (m.isGold ? 'deep_work' : 'other'),
                    priority: m._priority || (m.isGold ? 'gold' : 'normal'),
                    status: mapLegacyStatusToBlock(m.status),
                    startHour: parsed.startH,
                    startMinute: parsed.startM,
                    endHour: parsed.endH,
                    endMinute: parsed.endM,
                    duration: Math.max(0, (parsed.endH * 60 + parsed.endM) - (parsed.startH * 60 + parsed.startM)),
                    phase: slot,
                    legacySlot: slot,
                    legacyIndex: i,
                    actualStart: existingBlock ? existingBlock.actualStart : null,
                    actualEnd: existingBlock ? existingBlock.actualEnd : null,
                    completedAt: existingBlock ? existingBlock.completedAt : null,
                    subtasks: m.subtasks || [],
                    subtasksOpen: m.subtasksOpen || false,
                    color: m.isGold ? '#ffd700' : (m.color || '#00ff9d'),
                    isGold: m.isGold || false,
                    ppRewarded: m.ppRewarded || false,
                    shiftedFrom: existingBlock ? existingBlock.shiftedFrom : null,
                    createdAt: existingBlock ? existingBlock.createdAt : new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                });
            });
        });

        return { version: 1, date: getTodayKey(), blocks };
    }

    function loadTimeBlocksData() {
        try {
            // 1. Try to load new format first
            const existing = SafeStorage.getItem(TIME_BLOCKS_KEY, null);
            if (existing && existing.version === 1 && Array.isArray(existing.blocks)) {
                return existing;
            }

            // 2. Try to bridge from old format
            const oldMissions = SafeStorage.getItem('commanderMissions', { morning: [], afternoon: [], night: [] });
            if (hasAnyOldMissions(oldMissions)) {
                const bridged = bridgeOldMissionsToNew(oldMissions);
                saveTimeBlocksData(bridged);
                console.log('[TimetableRoute] Bridged commanderMissions \u2192 time_blocks_v1:', bridged.blocks.length, 'blocks');
                return bridged;
            }

            // 3. Fresh start
            const fresh = { version: 1, date: getTodayKey(), blocks: [] };
            saveTimeBlocksData(fresh);
            return fresh;

        } catch (err) {
            console.error('[TimetableRoute] Bridge failed, attempting fallback:', err);
            try {
                const oldMissions = SafeStorage.getItem('commanderMissions', { morning: [], afternoon: [], night: [] });
                if (hasAnyOldMissions(oldMissions)) {
                    const bridged = bridgeOldMissionsToNew(oldMissions);
                    saveTimeBlocksData(bridged);
                    return bridged;
                }
            } catch (err2) {
                console.error('[TimetableRoute] Fallback bridge also failed:', err2);
            }
            return { version: 1, date: getTodayKey(), blocks: [] };
        }
    }

    function saveTimeBlocksData(data) {
        SafeStorage.setItem(TIME_BLOCKS_KEY, data);
    }

    // ═══════════════════════════════════════════
    //  _syncBlockIds (Phase 7F-2B)
    //  Ensures every mission has a valid _blockId
    // ═══════════════════════════════════════════
    function _syncBlockIds() {
        ['morning', 'afternoon', 'night'].forEach(slot => {
            if (!Array.isArray(missions[slot])) return;
            missions[slot].forEach(m => {
                if (!m._blockId) {
                    m._blockId = generateBlockId();
                }
            });
        });
    }

    // ═══════════════════════════════════════════
    //  HERO DASHBOARD (Phase 7F-3B → 7F-4A upgraded)
    //  Computes NOW BLOCK, NEXT BLOCK, DAY EFFICIENCY
    //  Also returns computed data for tactical clock
    // ═══════════════════════════════════════════
    function _computeTimeState() {
        const now = new Date();
        const nowMins = now.getHours() * 60 + now.getMinutes();
        const nowSecs = now.getSeconds();
        const allBlocks = blocksData ? (blocksData.blocks || []) : [];

        // ── NOW BLOCK ──
        const nowBlock = allBlocks.find(b => {
            const start = b.startHour * 60 + b.startMinute;
            const end = b.endHour * 60 + b.endMinute;
            return nowMins >= start && nowMins < end;
        });

        // ── NEXT BLOCK ──
        const upcomingBlocks = allBlocks
            .filter(b => b.status === 'planned' || b.status === 'active')
            .filter(b => (b.startHour * 60 + b.startMinute) > nowMins)
            .sort((a, b) => (a.startHour * 60 + a.startMinute) - (b.startHour * 60 + b.startMinute));

        const nextBlock = upcomingBlocks.length > 0 ? upcomingBlocks[0] : null;

        // ── DAY EFFICIENCY ──
        const total = allBlocks.length;
        const completed = allBlocks.filter(b => b.status === 'completed').length;
        const plannedMins = allBlocks.reduce((sum, b) => sum + (b.duration || 0), 0);
        const completedMins = allBlocks
            .filter(b => b.status === 'completed')
            .reduce((sum, b) => sum + (b.duration || 0), 0);
        const goldCount = allBlocks.filter(b => b.priority === 'gold' || b.isGold).length;
        const pct = total === 0 ? 0 : Math.round((completed / total) * 100);

        // ── Time remaining in active block ──
        let activeRemainingMins = 0;
        let activeRemainingSecs = 0;
        if (nowBlock) {
            const endTotal = nowBlock.endHour * 60 + nowBlock.endMinute;
            const remTotal = (endTotal - nowMins) * 60 - nowSecs;
            activeRemainingMins = Math.max(0, Math.floor(remTotal / 60));
            activeRemainingSecs = Math.max(0, remTotal % 60);
        }

        // ── Next block starts in ──
        let nextStartsInMins = 0;
        if (nextBlock) {
            nextStartsInMins = (nextBlock.startHour * 60 + nextBlock.startMinute) - nowMins;
        }

        // ── Day progress (6 AM to midnight) ──
        const dayStartMins = 6 * 60;
        const dayEndMins = 24 * 60;
        const dayTotal = dayEndMins - dayStartMins;
        const dayElapsed = Math.max(0, nowMins - dayStartMins);
        const dayPct = Math.min(100, Math.round((dayElapsed / dayTotal) * 100));

        // ── Active phase label (7F-4A) ──
        let activePhase = 'night';
        let activePhaseLabel = 'DARK OPS';
        if (nowMins >= 6 * 60 && nowMins < 12 * 60) {
            activePhase = 'morning';
            activePhaseLabel = 'DAWN ASCENDANCY';
        } else if (nowMins >= 12 * 60 && nowMins < 18 * 60) {
            activePhase = 'afternoon';
            activePhaseLabel = 'MERIDIAN RECON';
        }

        // ── Active block elapsed (7F-4A) ──
        let activeElapsedMins = 0;
        let activeTotalMins = 0;
        let activePct = 0;
        if (nowBlock) {
            const startTotal = nowBlock.startHour * 60 + nowBlock.startMinute;
            activeElapsedMins = nowMins - startTotal;
            activeTotalMins = nowBlock.duration || (nowBlock.endHour * 60 + nowBlock.endMinute - startTotal);
            activePct = activeTotalMins > 0 ? Math.min(100, Math.round((activeElapsedMins / activeTotalMins) * 100)) : 0;
        }

        return {
            now, nowMins, nowSecs, nowBlock, nextBlock,
            total, completed, plannedMins, completedMins, goldCount, pct,
            activeRemainingMins, activeRemainingSecs, nextStartsInMins,
            dayPct, dayElapsed, allBlocks,
            activePhase, activePhaseLabel,
            activeElapsedMins, activeTotalMins, activePct
        };
    }

    function _updateHeroDashboard() {
        if (!_container || !blocksData) return;
        const ts = _computeTimeState();

        // ── NOW BLOCK ──
        const nowValue = _container.querySelector('#hero-now-value');
        const nowSub = _container.querySelector('#hero-now-sub');
        if (ts.nowBlock) {
            if (nowValue) nowValue.textContent = ts.nowBlock.title || 'Untitled Block';
            if (nowSub) nowSub.textContent =
                formatBlockTime(ts.nowBlock) + ' \u00B7 ' +
                (TYPE_LABELS[ts.nowBlock.type] || 'OTHER') + ' \u00B7 ' +
                (STATUS_LABELS[ts.nowBlock.status] || 'PLANNED');
        } else {
            if (nowValue) nowValue.textContent = 'No active block';
            if (nowSub) nowSub.textContent = 'All clear \u2014 stand by';
        }

        // ── NEXT BLOCK ──
        const nextValue = _container.querySelector('#hero-next-value');
        const nextSub = _container.querySelector('#hero-next-sub');
        if (ts.nextBlock) {
            const diff = ts.nextStartsInMins;
            const diffHrs = Math.floor(diff / 60);
            const diffMin = diff % 60;
            const timeStr = diffHrs > 0
                ? diffHrs + 'h ' + diffMin + 'm'
                : diffMin + ' min';
            if (nextValue) nextValue.textContent = ts.nextBlock.title || 'Untitled Block';
            if (nextSub) nextSub.textContent =
                'Starts in ' + timeStr + ' \u00B7 ' + formatBlockTime(ts.nextBlock);
        } else {
            if (nextValue) nextValue.textContent = 'No upcoming';
            if (nextSub) nextSub.textContent = 'All blocks scheduled';
        }

        // ── DAY EFFICIENCY ──
        const effValue = _container.querySelector('#hero-eff-value');
        const effSub = _container.querySelector('#hero-eff-sub');
        if (effValue) effValue.textContent = ts.pct + '%';
        if (effSub) effSub.textContent =
            ts.completed + '/' + ts.total + ' blocks \u00B7 ' +
            ts.goldCount + ' gold \u00B7 ' +
            ts.completedMins + '/' + ts.plannedMins + ' min';
    }

    // ═══════════════════════════════════════════
    //  TACTICAL CLOCK (Phase 7F-4A)
    //  Live time, active block countdown, execution
    //  messages, day progress, minute tracking
    // ═══════════════════════════════════════════
    function _updateTacticalClock() {
        if (!_container || !blocksData) return;
        const ts = _computeTimeState();

        // ── Live time ──
        const clockEl = _container.querySelector('#tac-clock-time');
        if (clockEl) {
            const h = String(ts.now.getHours() % 12 || 12).padStart(2, '0');
            const m = String(ts.now.getMinutes()).padStart(2, '0');
            const s = String(ts.now.getSeconds()).padStart(2, '0');
            const ampm = ts.now.getHours() < 12 ? 'AM' : 'PM';
            clockEl.textContent = h + ':' + m + ':' + s + ' ' + ampm;
        }

        // ── Active phase label (7F-4A) ──
        const phaseLabelEl = _container.querySelector('#tac-phase-label');
        if (phaseLabelEl) {
            phaseLabelEl.textContent = ts.activePhaseLabel || 'DARK OPS';
        }

        // ── Day progress bar ──
        const dayBarEl = _container.querySelector('#tac-day-progress-fill');
        const dayLabelEl = _container.querySelector('#tac-day-pct');
        if (dayBarEl) dayBarEl.style.width = ts.dayPct + '%';
        if (dayLabelEl) dayLabelEl.textContent = ts.dayPct + '%';

        // ── Active indicator dot (7F-4A: toggle active class) ──
        const dotEl = _container.querySelector('#tac-active-dot');
        if (dotEl) {
            if (ts.nowBlock) {
                dotEl.classList.add('active');
            } else {
                dotEl.classList.remove('active');
            }
        }

        // ── Active block countdown ──
        const activeLabelEl = _container.querySelector('#tac-active-label');
        const activeCountdownEl = _container.querySelector('#tac-active-countdown');
        const activeTypeEl = _container.querySelector('#tac-active-type');
        const execMsgEl = _container.querySelector('#tac-exec-msg');

        // ── Active block progress bar (7F-4A) ──
        const activeProgressBar = _container.querySelector('#tac-active-progress-fill');
        const activeProgressLabel = _container.querySelector('#tac-active-progress-label');

        if (ts.nowBlock) {
            if (activeLabelEl) activeLabelEl.textContent = ts.nowBlock.title || 'Untitled Block';
            const rMins = String(ts.activeRemainingMins).padStart(2, '0');
            const rSecs = String(ts.activeRemainingSecs).padStart(2, '0');
            if (activeCountdownEl) activeCountdownEl.textContent = rMins + ':' + rSecs;
            const typeKey = ts.nowBlock.type || 'other';
            if (activeTypeEl) activeTypeEl.textContent = TYPE_LABELS[typeKey] || 'OTHER';

            // Active block progress (7F-4A)
            if (activeProgressBar) activeProgressBar.style.width = ts.activePct + '%';
            if (activeProgressLabel) activeProgressLabel.textContent = ts.activeElapsedMins + '/' + ts.activeTotalMins + ' min elapsed';

            // Execution message
            if (execMsgEl) {
                const rem = ts.activeRemainingMins;
                const typeName = TYPE_LABELS[typeKey] || 'OTHER';
                if (rem <= 5 && rem > 0) {
                    execMsgEl.textContent = 'Transition window in ' + rem + ' min \u2014 wrap up now';
                    execMsgEl.className = 'tac-exec-msg tac-exec-transition';
                } else if (rem === 0) {
                    execMsgEl.textContent = 'Block ending \u2014 execute transition now';
                    execMsgEl.className = 'tac-exec-msg tac-exec-urgent';
                } else if (rem <= 15) {
                    execMsgEl.textContent = 'Inside ' + typeName + ' \u2014 ' + rem + ' min remaining';
                    execMsgEl.className = 'tac-exec-msg tac-exec-active';
                } else {
                    execMsgEl.textContent = 'Executing ' + typeName + ' block \u2014 stay focused';
                    execMsgEl.className = 'tac-exec-msg tac-exec-active';
                }
            }
        } else {
            if (activeLabelEl) activeLabelEl.textContent = 'NO ACTIVE BLOCK';
            if (activeCountdownEl) activeCountdownEl.textContent = '--:--';
            if (activeTypeEl) activeTypeEl.textContent = '';
            if (activeProgressBar) activeProgressBar.style.width = '0%';
            if (activeProgressLabel) activeProgressLabel.textContent = '';
            if (execMsgEl) {
                // Check if there's a next block coming
                if (ts.nextBlock) {
                    const diff = ts.nextStartsInMins;
                    if (diff <= 5) {
                        execMsgEl.textContent = 'Next deployment in ' + diff + ' min \u2014 prepare now';
                        execMsgEl.className = 'tac-exec-msg tac-exec-transition';
                    } else if (diff <= 30) {
                        execMsgEl.textContent = 'Next block in ' + diff + ' min \u2014 standby';
                        execMsgEl.className = 'tac-exec-msg tac-exec-idle';
                    } else {
                        execMsgEl.textContent = 'No active block \u2014 deploy your next mission';
                        execMsgEl.className = 'tac-exec-msg tac-exec-idle';
                    }
                } else {
                    execMsgEl.textContent = 'No active block \u2014 deploy your next mission';
                    execMsgEl.className = 'tac-exec-msg tac-exec-idle';
                }
            }
        }

        // ── Next block indicator ──
        const nextIndEl = _container.querySelector('#tac-next-indicator');
        if (nextIndEl) {
            if (ts.nextBlock) {
                const diff = ts.nextStartsInMins;
                const h = Math.floor(diff / 60);
                const m = diff % 60;
                const timeStr = h > 0 ? h + 'h ' + m + 'm' : m + ' min';
                nextIndEl.innerHTML = '<span class="tac-next-arrow">\u25B6</span> ' + (ts.nextBlock.title || 'Untitled') + ' <span class="tac-next-time">in ' + timeStr + '</span>';
                nextIndEl.className = 'tac-next-indicator tac-next-pending';
            } else {
                nextIndEl.textContent = 'No upcoming blocks scheduled';
                nextIndEl.className = 'tac-next-indicator tac-next-none';
            }
        }

        // ── Minute tracking with progress bar (7F-4A enhanced) ──
        const minTrackEl = _container.querySelector('#tac-min-tracking');
        if (minTrackEl) {
            const completedM = ts.completedMins;
            const plannedM = ts.plannedMins;
            const pctM = plannedM > 0 ? Math.round((completedM / plannedM) * 100) : 0;
            minTrackEl.innerHTML =
                '<span class="tac-min-done">' + completedM + '</span>' +
                '<span class="tac-min-sep">/</span>' +
                '<span class="tac-min-total">' + plannedM + ' min</span>' +
                '<span class="tac-min-pct">' + pctM + '%</span>';
        }
        const minBarEl = _container.querySelector('#tac-min-progress-fill');
        if (minBarEl) {
            const plannedM = ts.plannedMins;
            const completedM = ts.completedMins;
            const pctM = plannedM > 0 ? Math.round((completedM / plannedM) * 100) : 0;
            minBarEl.style.width = pctM + '%';
        }
    }

    // ═══════════════════════════════════════════
    //  LIFECYCLE
    // ═══════════════════════════════════════════
    function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;

        _loadCSS();
        container.innerHTML = render();

        // Load time blocks data (bridges from commanderMissions if needed)
        blocksData = loadTimeBlocksData();
        missions = blocksToMissions(blocksData);

        // Ensure all missions have _blockId
        _syncBlockIds();

        // Daily reset guard
        applyDailyTimeTableResetGuard();

        // Initial renders
        renderUI();
        updateEfficiency();
        _updateHeroDashboard();
        _updateTacticalClock();
        updateLivePhase();
        tacticalEngine();

        // Load brain dump / notes
        const today2 = new Date().toDateString();
        const bd = container.querySelector('#brain-dump-area');
        const nt = container.querySelector('#notes-area');
        if (bd) bd.value = SafeStorage.getItem('brainDump_' + today2, '') || '';
        if (nt) nt.value = SafeStorage.getItem('notes_' + today2, '') || '';

        // Intervals
        _tacticalInterval = setInterval(tacticalEngine, 60000);
        _phaseInterval = setInterval(updateLivePhase, 60000);
        _clockInterval = setInterval(_updateTacticalClock, 1000); // Phase 7F-4A: 1-second tick

        _bindEvents(container, _abortController.signal);
    }

    function cleanup() {
        if (_abortController) { _abortController.abort(); _abortController = null; }
        if (_tacticalInterval) { clearInterval(_tacticalInterval); _tacticalInterval = null; }
        if (_phaseInterval) { clearInterval(_phaseInterval); _phaseInterval = null; }
        if (_clockInterval) { clearInterval(_clockInterval); _clockInterval = null; }
        _unloadCSS();
        // Remove clock modal overlay if still in DOM
        const ckOverlay = document.getElementById('ck-overlay');
        if (ckOverlay) ckOverlay.classList.remove('open');
        _container = null;
    }

    // ═══════════════════════════════════════════
    //  CSS DYNAMIC LOAD / UNLOAD
    // ═══════════════════════════════════════════
    function _loadCSS() {
        if (document.querySelector(`link[data-route-css="timetable"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.setAttribute('data-route-css', 'timetable');
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector(`link[data-route-css="timetable"]`);
        if (el && el.parentElement) el.parentElement.removeChild(el);
        _cssLinkEl = null;
    }

    // ═══════════════════════════════════════════
    //  RENDER: Full HTML (matches legacy Time.html structure)
    // ═══════════════════════════════════════════
    function render() {
        return `
<div class="tt-route-wrapper">

    <div class="header-container">
        <div>
            <h1 class="page-title">MISSION TIMELINE</h1>
            <p class="sub-title">DEPLOY YOUR DAY. DOMINATE YOUR TIME.</p>
            <div class="rank-container">
                <span class="rank-label">CURRENT RANK:</span>
                <span id="commander-rank" class="rank-value">CADET</span>
                <div id="rank-icon" class="rank-icon">\uD83D\uDEE1\uFE0F</div>
            </div>
            <div id="drop-risk-zone" class="risk-hidden">
                <span class="glitch-icon">\u26A0\uFE0F</span>
                <span id="risk-message">RANK INSTABILITY DETECTED</span>
            </div>
            <div id="toast-container"></div>
        </div>
        <div class="efficiency-card glass-panel">
            <span class="eff-label">STRATEGIC EFFICIENCY: <span id="eff-val">0%</span></span>
            <div class="progress-bg"><div class="progress-fill" id="eff-bar"></div></div>
            <br>
            <div id="pressure-zone" class="pressure-hidden">
                <span class="pulse-icon">\u26A0\uFE0F</span>
                <span id="pressure-message">PROXIMITY ALERT: 1 MISSION AWAY FROM UPGRADE</span>
            </div>
        </div>
    </div>

    <div class="mission-stats-container">
        <div class="stat-box">
            <span class="stat-label">\uD83C\uDFAF MISSIONS</span>
            <span id="stat-total" class="stat-value">0/0</span>
        </div>
        <div class="stat-box gold-stat">
            <span class="stat-label">\uD83D\uDD31 GOLD TARGETS</span>
            <span id="stat-gold" class="stat-value">0/0</span>
        </div>
        <div class="stat-box fail-stat">
            <span class="stat-label">\u26A0\uFE0F FAILED</span>
            <span id="stat-fail" class="stat-value">0</span>
        </div>
    </div>

    <!-- Phase 7F-3B: Hero Dashboard -->
    <div class="hero-dashboard">
        <div class="hero-card hero-now">
            <div class="hero-card-icon">\u26A1</div>
            <div class="hero-card-label">NOW BLOCK</div>
            <div class="hero-card-value" id="hero-now-value">No active block</div>
            <div class="hero-card-sub" id="hero-now-sub">All clear \u2014 stand by</div>
        </div>
        <div class="hero-card hero-next">
            <div class="hero-card-icon">\u23ED</div>
            <div class="hero-card-label">NEXT BLOCK</div>
            <div class="hero-card-value" id="hero-next-value">No upcoming</div>
            <div class="hero-card-sub" id="hero-next-sub">All blocks scheduled</div>
        </div>
        <div class="hero-card hero-eff">
            <div class="hero-card-icon">\uD83D\uDCCA</div>
            <div class="hero-card-label">DAY EFFICIENCY</div>
            <div class="hero-card-value" id="hero-eff-value">0%</div>
            <div class="hero-card-sub" id="hero-eff-sub">0/0 blocks</div>
        </div>
    </div>

    <!-- Phase 7F-4A: Tactical Clock Panel (enhanced) -->
    <div class="tac-clock-panel">
        <div class="tac-clock-left">
            <div class="tac-phase-row">
                <span class="tac-phase-dot"></span>
                <span class="tac-phase-label" id="tac-phase-label">DARK OPS</span>
            </div>
            <div class="tac-live-time" id="tac-clock-time">--:--:-- --</div>
            <div class="tac-day-progress-row">
                <span class="tac-day-label">DAY PROGRESS</span>
                <div class="tac-day-bar">
                    <div class="tac-day-fill" id="tac-day-progress-fill"></div>
                </div>
                <span class="tac-day-pct" id="tac-day-pct">0%</span>
            </div>
        </div>
        <div class="tac-clock-center">
            <div class="tac-active-row">
                <div class="tac-active-indicator" id="tac-active-dot"></div>
                <div class="tac-active-info">
                    <span class="tac-active-label" id="tac-active-label">NO ACTIVE BLOCK</span>
                    <span class="tac-active-type" id="tac-active-type"></span>
                </div>
                <div class="tac-countdown" id="tac-active-countdown">--:--</div>
            </div>
            <div class="tac-active-progress-row">
                <div class="tac-active-progress-bar">
                    <div class="tac-active-progress-fill" id="tac-active-progress-fill"></div>
                </div>
                <span class="tac-active-progress-label" id="tac-active-progress-label"></span>
            </div>
            <div class="tac-exec-msg tac-exec-idle" id="tac-exec-msg">No active block</div>
        </div>
        <div class="tac-clock-right">
            <div class="tac-next-indicator tac-next-none" id="tac-next-indicator">No upcoming blocks</div>
            <div class="tac-min-tracking" id="tac-min-tracking">
                <span class="tac-min-done">0</span><span class="tac-min-sep">/</span><span class="tac-min-total">0 min</span><span class="tac-min-pct">0%</span>
            </div>
            <div class="tac-min-bar">
                <div class="tac-min-progress-fill" id="tac-min-progress-fill"></div>
            </div>
        </div>
    </div>

    <div id="grid-system-wrapper" style="position: relative;">
        <div class="celestial-axis">
            <div class="pathway">
                <div id="pathway-fill"></div>
            </div>
            <div id="celestial-tracker" class="tracker-head">\uD83C\uDF05</div>
        </div>

        <section class="mission-sector dawn-phase glass-panel phase-container" id="sector-dawn">
            <div class="slot-title">
                <h3 id="morning-header" class="slot-header">\uD83C\uDF05 DAWN ASCENDANCY</h3>
            </div>
            <div class="mission-grid" id="morning-grid"></div>
        </section>

        <section class="mission-sector meridian-phase glass-panel phase-container" id="sector-meridian">
            <div class="slot-title">
                <h3 id="afternoon-header" class="slot-header">\u2600\uFE0F MERIDIAN RECON</h3>
            </div>
            <div class="mission-grid" id="afternoon-grid"></div>
        </section>

        <section class="mission-sector night-phase glass-panel phase-container" id="sector-night">
            <div class="slot-title">
                <h3 id="night-header" class="slot-header">\uD83C\uDF19 DARK OPS</h3>
            </div>
            <div class="mission-grid" id="night-grid"></div>
        </section>
    </div>

    <div class="tt-dump-row">
        <div class="tt-dump-card">
            <div class="tt-dump-header">\uD83E\uDDE0 BRAIN DUMP</div>
            <textarea id="brain-dump-area" placeholder="Dimaag mein jo bhi chal raha hai... yahan dump karo."
                style="width:100%; min-height:160px; background:transparent; border:none; color:rgba(255,255,255,0.7); font-family:'Rajdhani',sans-serif; font-size:1rem; padding:14px 16px; resize:vertical; outline:none; line-height:1.7;"
                data-action="save-brain-dump"></textarea>
        </div>
        <div class="tt-dump-card">
            <div class="tt-dump-header">\uD83D\uDCDD NOTES</div>
            <textarea id="notes-area" placeholder="End of day reflection, observations..."
                style="width:100%; min-height:160px; background:transparent; border:none; color:rgba(255,255,255,0.7); font-family:'Rajdhani',sans-serif; font-size:1rem; padding:14px 16px; resize:vertical; outline:none; line-height:1.7;"
                data-action="save-notes"></textarea>
        </div>
    </div>

    <!-- Clock Modal — Phase 7F-4C: Premium Tactical Time Deployer -->
    <div class="ck-overlay" id="ck-overlay">
        <div class="ck-modal">
            <!-- Header: Mission identity -->
            <div class="ck-header">
                <div class="ck-header-icon">\u23F0</div>
                <div class="ck-header-text">
                    <div class="ck-title">DEPLOY MISSION WINDOW</div>
                    <div class="ck-subtitle" id="ck-mission-name">Set Time Block</div>
                </div>
            </div>

            <!-- Step indicator -->
            <div class="ck-steps">
                <div class="ck-step-item" id="ck-step-0">
                    <div class="ck-dot active" id="ck-dot-0"></div>
                    <span class="ck-step-label">START</span>
                </div>
                <div class="ck-step-line" id="ck-step-line"></div>
                <div class="ck-step-item" id="ck-step-1">
                    <div class="ck-dot" id="ck-dot-1"></div>
                    <span class="ck-step-label">END</span>
                </div>
            </div>

            <!-- Digital time display — hero element -->
            <div class="ck-digital">
                <div class="ck-dig-time-wrap">
                    <span class="ck-dig-time" id="ck-dig-time">--:--</span>
                    <span class="ck-dig-ampm" id="ck-dig-ampm">--</span>
                </div>
                <div class="ck-dig-label" id="ck-dig-label">SELECT START TIME</div>
            </div>

            <!-- Analog clock face — refined -->
            <div class="ck-face" id="ck-face">
                <div class="ck-face-ring"></div>
                <div class="ck-face-ticks"></div>
                <div class="ck-hour-hand" id="ck-hour-hand"></div>
                <div class="ck-min-hand" id="ck-min-hand"></div>
            </div>

            <!-- AM/PM toggle -->
            <div class="ck-ampm">
                <button class="ck-ampm-btn active" id="ck-am" data-action="ck-set-ampm" data-ampm="AM">AM</button>
                <button class="ck-ampm-btn" id="ck-pm" data-action="ck-set-ampm" data-ampm="PM">PM</button>
            </div>

            <!-- Hour/Minute selectors -->
            <div class="ck-scrolls">
                <div class="ck-scroll-col">
                    <div class="ck-scroll-label">HOUR</div>
                    <div class="ck-scroll-box">
                        <div class="ck-scroll-hl"></div>
                        <div class="ck-scroll-inner" id="ck-hour-list"></div>
                    </div>
                </div>
                <div class="ck-scroll-colon">:</div>
                <div class="ck-scroll-col">
                    <div class="ck-scroll-label">MIN</div>
                    <div class="ck-scroll-box">
                        <div class="ck-scroll-hl"></div>
                        <div class="ck-scroll-inner" id="ck-min-list"></div>
                    </div>
                </div>
            </div>

            <!-- Tactical confirmation preview -->
            <div class="ck-result" id="ck-result">
                <div class="ck-result-inner">
                    <div class="ck-result-icon">\u2713</div>
                    <div class="ck-result-text" id="ck-result-text"></div>
                    <div class="ck-result-duration" id="ck-result-duration"></div>
                </div>
            </div>

            <!-- Action buttons -->
            <div class="ck-actions">
                <button class="ck-confirm-btn" id="ck-confirm" data-action="ck-confirm" disabled>CONFIRM START \u2192</button>
                <button class="ck-cancel-btn" data-action="ck-cancel">CANCEL</button>
            </div>
        </div>
    </div>

</div>
        `;
    }

    // ═══════════════════════════════════════════
    //  EVENT BINDING (data-action delegation)
    // ═══════════════════════════════════════════
    function _bindEvents(container, signal) {
        // ── Delegated click handler for data-action ──
        container.addEventListener('click', (e) => {
            const el = e.target.closest('[data-action]');
            if (!el) return;
            const action = el.getAttribute('data-action');
            const slot = el.getAttribute('data-slot');
            const index = el.getAttribute('data-index') !== null ? parseInt(el.getAttribute('data-index')) : null;
            const si = el.getAttribute('data-si') !== null ? parseInt(el.getAttribute('data-si')) : null;

            switch (action) {
                case 'add-mission':
                    addMission(slot);
                    break;
                case 'add-gold-mission':
                    addGoldMission(slot);
                    break;
                case 'set-status':
                    if (slot !== null && index !== null) {
                        const status = el.getAttribute('data-status');
                        setStatus(slot, index, status);
                    }
                    break;
                case 'delete-mission':
                    if (slot !== null && index !== null) deleteMission(slot, index);
                    break;
                case 'toggle-subtask-panel':
                    if (slot !== null && index !== null) toggleSubtaskPanel(slot, index);
                    break;
                case 'toggle-subtask':
                    if (slot !== null && index !== null && si !== null) toggleSubtask(slot, index, si);
                    break;
                case 'delete-subtask':
                    if (slot !== null && index !== null && si !== null) deleteSubtask(slot, index, si);
                    break;
                case 'open-clock-modal':
                    openClockModal(slot, index);
                    break;
                case 'ck-set-ampm':
                    ckSetAMPM(el.getAttribute('data-ampm'));
                    break;
                case 'ck-confirm':
                    ckConfirm();
                    break;
                case 'ck-cancel':
                    closeClockModal();
                    break;
                case 'ck-select-hour':
                    ckSelectH(parseInt(el.textContent));
                    break;
                case 'ck-select-min':
                    ckSelectM(parseInt(el.textContent));
                    break;
            }
        }, { signal });

        // ── Clock overlay click-to-close ──
        const ckOverlay = container.querySelector('#ck-overlay');
        if (ckOverlay) {
            ckOverlay.addEventListener('click', (e) => {
                if (e.target === ckOverlay) closeClockModal();
            }, { signal });
        }

        // ── Delegated input/change for mission fields ──
        container.addEventListener('change', (e) => {
            const el = e.target;
            if (el.classList.contains('task-input-field')) {
                const slot = el.getAttribute('data-slot');
                const index = parseInt(el.getAttribute('data-index'));
                if (slot && !isNaN(index)) updateData(slot, index, 'title', el.value);
            }
            // Phase 7F-3: Handle block type select
            if (el.classList.contains('tb-type-select')) {
                const slot = el.getAttribute('data-slot');
                const index = parseInt(el.getAttribute('data-index'));
                const type = el.value;
                if (slot && !isNaN(index) && type) {
                    missions[slot][index]._type = type;
                    saveAndRender();
                }
            }
            // Phase 7F-3: Handle priority select
            if (el.classList.contains('tb-priority-select')) {
                const slot = el.getAttribute('data-slot');
                const index = parseInt(el.getAttribute('data-index'));
                const priority = el.value;
                if (slot && !isNaN(index) && priority) {
                    missions[slot][index]._priority = priority;
                    if (priority === 'gold') {
                        missions[slot][index].isGold = true;
                        missions[slot][index].color = '#ffd700';
                    } else {
                        missions[slot][index].isGold = false;
                    }
                    saveAndRender();
                }
            }
        }, { signal });

        // ── Subtask input (Enter key) ──
        container.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && e.target.classList.contains('subtask-input')) {
                const slot = e.target.getAttribute('data-slot');
                const index = parseInt(e.target.getAttribute('data-index'));
                if (slot && !isNaN(index)) addSubtask(slot, index, e.target);
            }
        }, { signal });

        // ── Brain dump / notes save ──
        container.addEventListener('input', (e) => {
            const action = e.target.getAttribute('data-action');
            if (action === 'save-brain-dump') saveBrainDump();
            if (action === 'save-notes') saveNotes();
        }, { signal });
    }

    // ═══════════════════════════════════════════
    //  MISSION DATA LOGIC (preserved from Time.html)
    // ═══════════════════════════════════════════

    // Phase 7F-3: addMission pre-assigns _blockId, _type, _priority, _blockStatus
    function addMission(slot) {
        const colors = ['#00ff9d', '#00d1ff', '#ff4757', '#ffd700', '#ff8c00', '#5c67ff'];
        const randomColor = colors[Math.floor(Math.random() * colors.length)];
        missions[slot].push({
            time: "09:00 - 10:00",
            title: "",
            status: "pending",
            color: randomColor,
            _blockId: generateBlockId(),
            _type: "other",
            _priority: "normal",
            _blockStatus: "planned"
        });
        saveAndRender();
    }

    // Phase 7F-3: addGoldMission pre-assigns _blockId, _type, _priority, _blockStatus
    function addGoldMission(slot) {
        const totalGold = Object.values(missions).flat().filter(m => m.isGold).length;
        if (totalGold >= 3) {
            showPPToast('\u26A0\uFE0F ELITE LIMIT REACHED: Max 3 Gold Missions/day!');
            return;
        }
        missions[slot].push({
            time: "09:00 - 10:00",
            title: "",
            status: "pending",
            color: "#ffd700",
            isGold: true,
            _blockId: generateBlockId(),
            _type: "deep_work",
            _priority: "gold",
            _blockStatus: "planned"
        });
        saveAndRender();
    }

    function setStatus(slot, index, status) {
        const mission = missions[slot][index];
        if (!mission) return;
        mission.status = (mission.status === status) ? 'pending' : status;

        // Phase 7F-3: Update _blockStatus when status changes
        if (mission.status === 'done') {
            mission._blockStatus = 'completed';
        } else if (mission.status === 'fail') {
            mission._blockStatus = 'missed';
        } else {
            mission._blockStatus = 'planned';
        }

        if (mission.status === 'done' && !mission.ppRewarded) {
            const doneId = `time_${slot}_${index}_${new Date().toDateString().replace(/\s+/g, '_')}`;
            if (mission.isGold) {
                PulseEngine.addPoints(5, 'mission', { rewardId: doneId });
            } else {
                PulseEngine.addPoints(1, 'task', { rewardId: doneId });
            }
            mission.ppRewarded = true;
            showPPToast(`+${mission.isGold ? 5 : 1} PP \u2014 Mission Complete!`);
        } else if (mission.status === 'fail') {
            if (mission.isGold) {
                PulseEngine.deductPoints(5);
                showPPToast('GOLD TASK FAILED: -5 PP');
            } else {
                PulseEngine.deductPoints(1);
                showPPToast('TASK NOT DONE: -1 PP');
            }
        }

        saveAndRender();
    }

    function deleteMission(slot, index) {
        missions[slot].splice(index, 1);
        saveAndRender();
    }

    function updateData(slot, i, field, val) {
        if (!missions[slot] || !missions[slot][i]) return;
        missions[slot][i][field] = val;
        saveAndRender();
    }

    function saveAndRender() {
        blocksData = missionsToBlocks(missions, blocksData);
        saveTimeBlocksData(blocksData);
        renderUI();
        updateEfficiency();
        _updateHeroDashboard();
        _updateTacticalClock();
    }

    function applyDailyTimeTableResetGuard() {
        const today = getTodayKey();
        const lastOpened = SafeStorage.getItem(TIME_TABLE_LAST_OPENED_KEY);
        if (lastOpened === today) return false;

        // Reset all block statuses in blocksData
        if (blocksData && Array.isArray(blocksData.blocks)) {
            blocksData.blocks = blocksData.blocks.map(block => ({
                ...block,
                status: 'planned',
                ppRewarded: false,
                actualStart: null,
                actualEnd: null,
                completedAt: null,
                updatedAt: new Date().toISOString()
            }));
            blocksData.date = today;
        }

        saveTimeBlocksData(blocksData);

        // Re-derive missions from updated blocksData
        missions = blocksToMissions(blocksData);

        // Ensure all have _blockId
        _syncBlockIds();

        SafeStorage.setItem(TIME_TABLE_LAST_OPENED_KEY, today);
        return true;
    }

    // ═══════════════════════════════════════════
    //  SUBTASK SYSTEM
    // ═══════════════════════════════════════════
    function toggleSubtaskPanel(slot, index) {
        missions[slot][index].subtasksOpen = !missions[slot][index].subtasksOpen;
        saveAndRender();
    }

    function addSubtask(slot, index, input) {
        const text = input.value.trim();
        if (!text) return;
        if (!missions[slot][index].subtasks) missions[slot][index].subtasks = [];
        missions[slot][index].subtasks.push({ text, done: false });
        missions[slot][index].subtasksOpen = true;
        input.value = '';
        saveAndRender();
    }

    function deleteSubtask(slot, index, si) {
        missions[slot][index].subtasks.splice(si, 1);
        saveAndRender();
    }

    function toggleSubtask(slot, index, si) {
        const subtask = missions[slot][index].subtasks[si];
        subtask.done = !subtask.done;
        if (subtask.done) {
            const stId = `subtask_${slot}_${index}_${si}_${new Date().toDateString().replace(/\s+/g, '_')}`;
            PulseEngine.addPoints(1, 'task', { rewardId: stId });
            showPPToast('SUBTASK DONE: +1 PP');
        }
        saveAndRender();
    }

    // ═══════════════════════════════════════════
    //  Phase 7F-3: TYPE / PRIORITY / STATUS HELPERS
    // ═══════════════════════════════════════════
    const TYPE_LABELS = {
        deep_work: 'DEEP WORK',
        revision: 'REVISION',
        backlog: 'BACKLOG',
        test: 'TEST',
        break: 'BREAK',
        other: 'OTHER'
    };

    const PRIORITY_ICONS = {
        normal: '\u25CF',    // ●
        high: '\u25B2',      // ▲
        gold: '\u2605'       // ★
    };

    const STATUS_LABELS = {
        planned: 'PLANNED',
        active: 'ACTIVE',
        completed: 'COMPLETED',
        missed: 'MISSED',
        shifted: 'SHIFTED'
    };

    // ═══════════════════════════════════════════
    //  RENDER UI: Mission Cards (Phase 7F-3)
    // ═══════════════════════════════════════════
    function renderUI() {
        ['morning', 'afternoon', 'night'].forEach(slot => {
            const grid = _container ? _container.querySelector(`#${slot}-grid`) : null;
            if (!grid) return;
            grid.innerHTML = '';

            // Phase 7F-3: Sort missions by parsed start time for gap detection
            const slotMissions = missions[slot].map((m, i) => {
                const parsed = parseTimeWindow(m.time, slot);
                return { m, i, startMin: parsed.startH * 60 + parsed.startM, endMin: parsed.endH * 60 + parsed.endM };
            });
            slotMissions.sort((a, b) => a.startMin - b.startMin);

            slotMissions.forEach(({ m, i, startMin, endMin }, sortedIdx) => {
                // Phase 7F-3B: Free gap detection with styled indicator
                if (sortedIdx > 0) {
                    const prev = slotMissions[sortedIdx - 1];
                    const gapMin = startMin - prev.endMin;
                    if (gapMin > 30) {
                        const gapEl = document.createElement('div');
                        gapEl.className = 'tb-free-gap';
                        gapEl.innerHTML = `
                            <div class="tb-gap-line"></div>
                            <span class="tb-gap-label">FREE GAP \u2014 ${gapMin} min</span>
                            <div class="tb-gap-line"></div>
                        `;
                        grid.appendChild(gapEl);
                    }
                }

                const blockType = m._type || 'other';
                const priority = m._priority || (m.isGold ? 'gold' : 'normal');
                const blockStatus = m._blockStatus || 'planned';
                const duration = Math.max(0, endMin - startMin);

                // Build CSS class modifiers
                const priorityClass = `tb-priority-${priority}`;
                const statusClass = `tb-status-${blockStatus}`;

                const card = document.createElement('div');
                card.className = `mission-row-card tb-block-card ${m.isGold ? 'gold-mission' : ''} ${priorityClass} ${statusClass}`;
                card.style.borderLeft = m.isGold ? '5px solid #ffd700' : `4px solid ${m.color || '#00ff9d'}`;

                const subtasks = m.subtasks || [];
                const doneCount = subtasks.filter(s => s.done).length;
                const subtaskHTML = subtasks.map((st, si) => `
                    <div class="subtask-row ${st.done ? 'subtask-done' : ''}">
                        <div class="subtask-check ${st.done ? 'checked' : ''}"
                             data-action="toggle-subtask" data-slot="${slot}" data-index="${i}" data-si="${si}">${st.done ? '\u2713' : ''}</div>
                        <span class="subtask-text">${st.text}</span>
                        <button class="subtask-delete" data-action="delete-subtask" data-slot="${slot}" data-index="${i}" data-si="${si}">\u00D7</button>
                    </div>
                `).join('');

                // Type select options
                const typeOptions = ['deep_work', 'revision', 'backlog', 'test', 'break', 'other']
                    .map(t => `<option value="${t}" ${t === blockType ? 'selected' : ''}>${TYPE_LABELS[t]}</option>`)
                    .join('');

                // Priority select options
                const priorityOptions = ['normal', 'high', 'gold']
                    .map(p => `<option value="${p}" ${p === priority ? 'selected' : ''}>${PRIORITY_ICONS[p]} ${p.charAt(0).toUpperCase() + p.slice(1)}</option>`)
                    .join('');

                // Badge labels
                const statusLabel = STATUS_LABELS[blockStatus] || 'PLANNED';
                const typeLabel = TYPE_LABELS[blockType] || 'OTHER';

                // Phase 7F-3B: Professional block card layout
                card.innerHTML = `
                    <div class="mission-card-top">
                        <div class="tb-time-group">
                            <input type="text" class="time-badge-input" value="${m.time}"
                                   readonly data-action="open-clock-modal" data-slot="${slot}" data-index="${i}">
                            <span class="tb-duration-tag">${duration} min</span>
                        </div>
                        <div class="tb-title-area">
                            <input type="text" class="task-input-field" value="${m.title}"
                                   placeholder="${m.isGold ? 'ENTER ELITE GOAL...' : 'Mission Objective...'}"
                                   data-slot="${slot}" data-index="${i}">
                            <div class="tb-badge-strip">
                                <span class="tb-type-badge tb-type-${blockType}">${typeLabel}</span>
                                <span class="tb-priority-badge tb-pri-${priority}">${PRIORITY_ICONS[priority]} ${priority.toUpperCase()}</span>
                                <span class="tb-status-badge tb-st-${blockStatus}">${statusLabel}</span>
                            </div>
                        </div>
                        <div class="action-group">
                            <button class="mini-status-btn ${m.status === 'done' ? 'btn-done-active' : ''}"
                                    data-action="set-status" data-slot="${slot}" data-index="${i}" data-status="done">\u2713</button>
                            <button class="mini-status-btn ${m.status === 'fail' ? 'btn-fail-active' : ''}"
                                    data-action="set-status" data-slot="${slot}" data-index="${i}" data-status="fail">\u2715</button>
                            <button class="mini-status-btn ${m.subtasksOpen ? 'btn-subtask-active' : ''}"
                                    data-action="toggle-subtask-panel" data-slot="${slot}" data-index="${i}">\u2295</button>
                            <button class="mini-status-btn btn-delete"
                                    data-action="delete-mission" data-slot="${slot}" data-index="${i}">\uD83D\uDDD1</button>
                        </div>
                    </div>
                    <div class="tb-card-meta-row">
                        <select class="tb-type-select" data-action="set-block-type" data-slot="${slot}" data-index="${i}">
                            ${typeOptions}
                        </select>
                        <select class="tb-priority-select" data-action="set-priority" data-slot="${slot}" data-index="${i}">
                            ${priorityOptions}
                        </select>
                    </div>
                    <div class="subtask-panel ${m.subtasksOpen ? 'open' : ''}">
                        <div class="subtask-list">${subtaskHTML}</div>
                        <div class="subtask-add-row">
                            <input type="text" class="subtask-input"
                                   placeholder="+ Add subtask... (Enter)"
                                   data-slot="${slot}" data-index="${i}">
                        </div>
                        ${subtasks.length > 0 ? `
                        <div class="subtask-progress">
                            <div class="subtask-bar">
                                <div class="subtask-fill" style="width:${Math.round((doneCount / subtasks.length) * 100)}%"></div>
                            </div>
                            <span class="subtask-count">${doneCount}/${subtasks.length}</span>
                        </div>` : ''}
                    </div>
                `;

                grid.appendChild(card);
            });

            // Phase 7F-3B: Professional deploy CTA buttons
            const btnContainer = document.createElement('div');
            btnContainer.className = 'deploy-group';
            btnContainer.innerHTML = `
                <button class="add-mission-btn" data-action="add-mission" data-slot="${slot}">+ DEPLOY</button>
                <button class="add-gold-btn add-mission-btn" data-action="add-gold-mission" data-slot="${slot}">\u2605 GOLD</button>
            `;
            grid.appendChild(btnContainer);
        });
    }

    // ═══════════════════════════════════════════
    //  EFFICIENCY / RANK / PRESSURE (from Time.html)
    // ═══════════════════════════════════════════
    function updateEfficiency() {
        if (!_container) return;
        let totalMissions = 0, doneMissions = 0;
        let totalGold = 0, doneGold = 0;
        let failedMissions = 0;

        Object.values(missions).flat().forEach(m => {
            totalMissions++;
            if (m.isGold) totalGold++;
            if (m.status === 'done') { doneMissions++; if (m.isGold) doneGold++; }
            else if (m.status === 'fail') { failedMissions++; }
        });

        const statTotal = _container.querySelector('#stat-total');
        const statGold = _container.querySelector('#stat-gold');
        const statFail = _container.querySelector('#stat-fail');
        if (statTotal) statTotal.innerText = `${doneMissions}/${totalMissions}`;
        if (statGold) statGold.innerText = `${doneGold}/${totalGold}`;
        if (statFail) statFail.innerText = failedMissions;

        const percent = totalMissions === 0 ? 0 : Math.round((doneMissions / totalMissions) * 100);
        let hasGoldCompleted = false;

        Object.values(missions).flat().forEach(m => {
            if (m.isGold && m.status === 'done') hasGoldCompleted = true;
        });

        const effBar = _container.querySelector('#eff-bar');
        const effVal = _container.querySelector('#eff-val');
        if (!effBar || !effVal) return;

        effBar.style.width = percent + '%';
        if (percent === 100) {
            effBar.classList.add('victory-glow');
            const isElite = Object.values(missions).flat().some(m => m.isGold);
            effVal.innerHTML = isElite
                ? '<span class="success-text" style="color:#ffd700;">\uD83D\uDD31 ELITE OPERATOR: LEGENDARY STATUS</span>'
                : '<span class="success-text">\uD83C\uDFC6 MISSION ACCOMPLISHED: COMMANDER LEVEL</span>';
        } else {
            effBar.classList.remove('victory-glow');
            if (hasGoldCompleted) {
                effVal.innerText = `${percent}% - High Value Targets Secured! \uD83D\uDD31`;
            } else {
                effVal.innerText = percent === 0 ? 'WAITING FOR ENGAGEMENT' : `${percent}% - Proceed with Caution...`;
            }
        }

        calculateRank(percent, totalGold, doneGold);
        updatePressure(percent, totalMissions, doneMissions);
        checkRankDrop(percent, failedMissions, totalGold, doneGold);
    }

    function calculateRank(percent, totalGold, doneGold) {
        const rankElement = _container ? _container.querySelector('#commander-rank') : null;
        const iconElement = _container ? _container.querySelector('#rank-icon') : null;
        if (!rankElement) return;

        let rank = 'SURVIVOR', icon = '\uD83D\uDEE1\uFE0F', color = '#ff4757';

        if (percent === 100 && totalGold > 0 && doneGold === totalGold) {
            rank = 'SUPREME COMMANDER'; icon = '\uD83D\uDC51'; color = '#ffd700';
        } else if (percent >= 85 && totalGold > 0 && doneGold === totalGold) {
            rank = 'MYTHIC CONQUEROR'; icon = '\uD83D\uDD31'; color = '#ff00ff';
        } else if (percent >= 65) {
            rank = 'ACE OPERATOR'; icon = '\u26A1'; color = '#00d1ff';
        } else if (percent >= 40) {
            rank = 'ELITE VETERAN'; icon = '\uD83C\uDF96\uFE0F'; color = '#00ff9d';
        }

        rankElement.innerText = rank;
        rankElement.style.color = color;
        if (iconElement) iconElement.innerText = icon;
    }

    function updatePressure(percent, totalMissions, doneMissions) {
        const banner = _container ? _container.querySelector('#pressure-zone') : null;
        const msg = _container ? _container.querySelector('#pressure-message') : null;
        if (!banner || !msg) return;

        const thresholds = [40, 65, 85, 100];
        let nextThreshold = thresholds.find(t => t > percent);
        if (percent >= 85 && percent < 100) nextThreshold = 100;

        if (nextThreshold) {
            const gap = nextThreshold - percent;
            const missionsLeft = totalMissions - doneMissions;
            if (gap <= 15 || missionsLeft <= 1) {
                banner.classList.remove('pressure-hidden');
                banner.classList.add('pressure-visible');
                if (nextThreshold === 100) {
                    msg.innerHTML = '<span class="pulse-icon">\u26A1</span> FINAL STRIKE: Secure the last objectives for SUPREME status!';
                } else {
                    msg.innerHTML = `<span class="pulse-icon">\u26A0\uFE0F</span> PROXIMITY ALERT: ${gap}% away from Rank Promotion!`;
                }
                return;
            }
        }
        banner.classList.add('pressure-hidden');
        banner.classList.remove('pressure-visible');
    }

    function checkRankDrop(percent, failedMissions, totalGold, doneGold) {
        const riskZone = _container ? _container.querySelector('#drop-risk-zone') : null;
        const riskMsg = _container ? _container.querySelector('#risk-message') : null;
        const rankElement = _container ? _container.querySelector('#commander-rank') : null;
        if (!riskZone || !rankElement) return;

        const thresholds = [40, 65, 85].reverse();
        let currentMin = thresholds.find(t => percent >= t) || 0;
        let isAtRisk = false;
        let warningMsg = '';

        const goldFailed = totalGold > 0 && (Object.values(missions).flat().filter(m => m.isGold && m.status === 'fail').length > 0);

        if (goldFailed) {
            isAtRisk = true;
            warningMsg = 'CRITICAL: GOLD MISSION FAILED - RANK UNSTABLE';
        } else if (percent - currentMin <= 5 && percent > 0) {
            isAtRisk = true;
            warningMsg = 'WARNING: EFFICIENCY DROPPING - RANK AT RISK';
        }

        if (isAtRisk) {
            riskZone.classList.remove('risk-hidden');
            riskZone.classList.add('risk-visible');
            rankElement.style.animation = 'rank-shake 0.3s infinite';
        } else {
            riskZone.classList.add('risk-hidden');
            riskZone.classList.remove('risk-visible');
            rankElement.style.animation = 'none';
        }
    }

    // ═══════════════════════════════════════════
    //  LIVE PHASE & TACTICAL ENGINE
    // ═══════════════════════════════════════════
    function updateLivePhase() {
        if (!_container) return;
        const hour = new Date().getHours();

        _container.querySelectorAll('.slot-header').forEach(h => {
            h.classList.remove('active-phase-glow');
        });

        let targetId = null;
        if (hour >= 6 && hour < 12) targetId = 'morning-header';
        else if (hour >= 12 && hour < 18) targetId = 'afternoon-header';
        else targetId = 'night-header';

        const el = _container.querySelector(`#${targetId}`);
        if (el) el.classList.add('active-phase-glow');
    }

    function tacticalEngine() {
        if (!_container) return;
        const tracker = _container.querySelector('#celestial-tracker');
        const fill = _container.querySelector('#pathway-fill');
        if (!tracker || !fill) return;

        const now = new Date();
        const hours = now.getHours();
        const minutes = now.getMinutes();
        const currentMins = (hours * 60) + minutes;

        const startDay = 6 * 60;
        const endDay = 24 * 60;
        const totalDayMins = endDay - startDay;

        if (currentMins >= startDay && currentMins <= endDay) {
            const progress = ((currentMins - startDay) / totalDayMins) * 100;
            tracker.style.top = progress + '%';
            fill.style.height = progress + '%';

            if (hours >= 6 && hours < 12) {
                tracker.innerText = '\uD83C\uDF05';
                fill.style.boxShadow = '0 0 20px rgba(255, 158, 34, 0.8)';
            } else if (hours >= 12 && hours < 18) {
                tracker.innerText = '\u2600\uFE0F';
                fill.style.boxShadow = '0 0 20px rgba(51, 204, 255, 0.8)';
            } else {
                tracker.innerText = '\uD83C\uDF19';
                fill.style.boxShadow = '0 0 20px rgba(157, 80, 187, 0.8)';
            }
        } else {
            tracker.style.top = '100%';
            fill.style.height = '100%';
            tracker.innerText = '\uD83C\uDF19';
        }

        // Phase 7F-3B: Refresh hero dashboard on every tick
        _updateHeroDashboard();
    }

    // ═══════════════════════════════════════════
    //  BRAIN DUMP & NOTES
    // ═══════════════════════════════════════════
    function saveBrainDump() {
        const today = new Date().toDateString();
        const bd = _container ? _container.querySelector('#brain-dump-area') : null;
        if (bd) SafeStorage.setItem('brainDump_' + today, bd.value);
    }

    function saveNotes() {
        const today = new Date().toDateString();
        const nt = _container ? _container.querySelector('#notes-area') : null;
        if (nt) SafeStorage.setItem('notes_' + today, nt.value);
    }

    // ═══════════════════════════════════════════
    //  CLOCK MODAL (data-action, no inline onclick)
    // ═══════════════════════════════════════════
    function ckBuildHours() {
        const el = _container ? _container.querySelector('#ck-hour-list') : null;
        if (!el) return;
        el.innerHTML = '';
        el.insertAdjacentHTML('beforeend', '<div style="height:37px"></div>');
        for (let h = 1; h <= 12; h++) {
            const d = document.createElement('div');
            d.className = 'ck-scroll-item';
            d.textContent = String(h).padStart(2, '0');
            d.setAttribute('data-action', 'ck-select-hour');
            el.appendChild(d);
        }
        el.insertAdjacentHTML('beforeend', '<div style="height:37px"></div>');
    }

    function ckBuildMins() {
        const el = _container ? _container.querySelector('#ck-min-list') : null;
        if (!el) return;
        el.innerHTML = '';
        el.insertAdjacentHTML('beforeend', '<div style="height:37px"></div>');
        [0, 15, 30, 45].forEach(m => {
            const d = document.createElement('div');
            d.className = 'ck-scroll-item';
            d.textContent = String(m).padStart(2, '0');
            d.setAttribute('data-action', 'ck-select-min');
            el.appendChild(d);
        });
        el.insertAdjacentHTML('beforeend', '<div style="height:37px"></div>');
    }

    function ckSelectH(h) {
        if (!_container) return;
        _container.querySelectorAll('#ck-hour-list .ck-scroll-item').forEach(e => e.classList.remove('sel'));
        // Find and select the matching item
        _container.querySelectorAll('#ck-hour-list .ck-scroll-item').forEach(e => {
            if (parseInt(e.textContent) === h) e.classList.add('sel');
        });
        ckSelH = h;
        ckUpdateClock();
        ckCheckReady();
    }

    function ckSelectM(m) {
        if (!_container) return;
        _container.querySelectorAll('#ck-min-list .ck-scroll-item').forEach(e => e.classList.remove('sel'));
        _container.querySelectorAll('#ck-min-list .ck-scroll-item').forEach(e => {
            if (parseInt(e.textContent) === m) e.classList.add('sel');
        });
        ckSelM = m;
        ckUpdateClock();
        ckCheckReady();
    }

    function ckSetAMPM(v) {
        ckSelAMPM = v;
        if (!_container) return;
        const am = _container.querySelector('#ck-am');
        const pm = _container.querySelector('#ck-pm');
        if (am) am.classList.toggle('active', v === 'AM');
        if (pm) pm.classList.toggle('active', v === 'PM');
        ckUpdateClock();
    }

    function ckUpdateClock() {
        if (!_container) return;
        if (ckSelH === null) return;
        const m = ckSelM !== null ? ckSelM : 0;
        const digTime = _container.querySelector('#ck-dig-time');
        const digAmpm = _container.querySelector('#ck-dig-ampm');
        const hourHand = _container.querySelector('#ck-hour-hand');
        const minHand = _container.querySelector('#ck-min-hand');
        if (digTime) digTime.textContent = String(ckSelH).padStart(2, '0') + ':' + String(m).padStart(2, '0');
        if (digAmpm) digAmpm.textContent = ckSelAMPM;
        const hDeg = ((ckSelH % 12) / 12) * 360 + (m / 60) * 30;
        const mDeg = (m / 60) * 360;
        if (hourHand) hourHand.style.transform = 'rotate(' + hDeg + 'deg)';
        if (minHand) minHand.style.transform = 'rotate(' + mDeg + 'deg)';
        // Update result preview when in step 1
        if (ckStep === 1) {
            const resText = _container.querySelector('#ck-result-text');
            if (resText) {
                resText.textContent = String(ckStartH).padStart(2, '0') + ':' + String(ckStartM).padStart(2, '0') + ' ' + ckStartAMPM + '  \u2192  ' + String(ckSelH).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ' ' + ckSelAMPM;
            }
            // Compute and show duration
            _ckUpdateDuration();
        }
    }

    // Phase 7F-4C: Compute and display duration in result preview
    function _ckUpdateDuration() {
        if (!_container) return;
        if (ckStep !== 1) return;
        const durEl = _container.querySelector('#ck-result-duration');
        if (!durEl) return;
        // Convert start/end to 24h minutes for calculation
        let start24 = ckStartH;
        if (ckStartAMPM === 'PM' && ckStartH !== 12) start24 += 12;
        else if (ckStartAMPM === 'AM' && ckStartH === 12) start24 = 0;
        let end24 = ckSelH !== null ? ckSelH : 0;
        if (ckSelAMPM === 'PM' && end24 !== 12) end24 += 12;
        else if (ckSelAMPM === 'AM' && end24 === 12) end24 = 0;
        const startMins = start24 * 60 + (ckStartM || 0);
        const endMins = end24 * 60 + (ckSelM || 0);
        let dur = endMins - startMins;
        if (dur <= 0) dur += 24 * 60; // cross midnight
        const h = Math.floor(dur / 60);
        const min = dur % 60;
        if (h > 0 && min > 0) {
            durEl.textContent = h + 'h ' + min + 'm block';
        } else if (h > 0) {
            durEl.textContent = h + 'h block';
        } else {
            durEl.textContent = min + 'm block';
        }
    }

    function ckCheckReady() {
        const btn = _container ? _container.querySelector('#ck-confirm') : null;
        if (btn) btn.disabled = (ckSelH === null || ckSelM === null);
    }

    function ckReset() {
        ckSelH = null; ckSelM = null; ckSelAMPM = 'AM';
        if (_container) {
            _container.querySelectorAll('.ck-scroll-item').forEach(e => e.classList.remove('sel'));
            const hourHand = _container.querySelector('#ck-hour-hand');
            const minHand = _container.querySelector('#ck-min-hand');
            const digTime = _container.querySelector('#ck-dig-time');
            const digAmpm = _container.querySelector('#ck-dig-ampm');
            const am = _container.querySelector('#ck-am');
            const pm = _container.querySelector('#ck-pm');
            const confirm = _container.querySelector('#ck-confirm');
            if (hourHand) hourHand.style.transform = 'rotate(0deg)';
            if (minHand) minHand.style.transform = 'rotate(0deg)';
            if (digTime) digTime.textContent = '--:--';
            if (digAmpm) digAmpm.textContent = '--';
            if (am) am.classList.add('active');
            if (pm) pm.classList.remove('active');
            if (confirm) confirm.disabled = true;
        }
    }

    function ckConfirm() {
        if (!_container) return;
        if (ckStep === 0) {
            ckStartH = ckSelH; ckStartM = ckSelM; ckStartAMPM = ckSelAMPM;
            ckStep = 1;
            ckReset();
            const dot0 = _container.querySelector('#ck-dot-0');
            const dot1 = _container.querySelector('#ck-dot-1');
            const step0 = _container.querySelector('#ck-step-0');
            const step1 = _container.querySelector('#ck-step-1');
            const stepLine = _container.querySelector('#ck-step-line');
            const digLabel = _container.querySelector('#ck-dig-label');
            const confirm = _container.querySelector('#ck-confirm');
            const res = _container.querySelector('#ck-result');
            const resText = _container.querySelector('#ck-result-text');
            const resDur = _container.querySelector('#ck-result-duration');
            if (dot0) dot0.className = 'ck-dot done';
            if (dot1) dot1.className = 'ck-dot active';
            if (step0) step0.classList.add('done');
            if (step1) step1.classList.add('active');
            if (stepLine) stepLine.classList.add('active');
            if (digLabel) digLabel.textContent = 'SELECT END TIME';
            if (confirm) confirm.textContent = 'SET WINDOW';
            if (res) { res.style.display = 'flex'; res.classList.add('ck-step-transition'); }
            if (resText) {
                resText.textContent = String(ckStartH).padStart(2, '0') + ':' + String(ckStartM).padStart(2, '0') + ' ' + ckStartAMPM + '  \u2192  ?';
            }
            if (resDur) resDur.textContent = '';
        } else {
            const startStr = String(ckStartH).padStart(2, '0') + ':' + String(ckStartM).padStart(2, '0') + ' ' + ckStartAMPM;
            const endStr = String(ckSelH).padStart(2, '0') + ':' + String(ckSelM).padStart(2, '0') + ' ' + ckSelAMPM;
            const finalStr = startStr + ' - ' + endStr;

            if (ckActiveSlot !== null && ckActiveIndex !== null) {
                missions[ckActiveSlot][ckActiveIndex].time = finalStr;
                saveAndRender();
            }

            const res = _container.querySelector('#ck-result');
            const resText = _container.querySelector('#ck-result-text');
            const resDur = _container.querySelector('#ck-result-duration');
            const confirm = _container.querySelector('#ck-confirm');
            const digLabel = _container.querySelector('#ck-dig-label');
            if (resText) resText.textContent = finalStr;
            if (resDur) {
                // Show final duration
                _ckUpdateDuration();
            }
            if (confirm) { confirm.textContent = 'WINDOW DEPLOYED'; confirm.disabled = true; confirm.classList.add('ck-confirmed'); }
            if (digLabel) digLabel.textContent = 'MISSION WINDOW READY';
            if (res) res.classList.add('ck-final-flash');
            setTimeout(closeClockModal, 900);
        }
    }

    function openClockModal(slot, index) {
        ckActiveSlot = slot;
        ckActiveIndex = index;
        ckStep = 0;
        ckReset();

        if (!_container) return;

        const isAM = (slot === 'morning');
        const isPM = (slot === 'afternoon' || slot === 'night');
        ckSetAMPM(isAM ? 'AM' : 'PM');

        const dot0 = _container.querySelector('#ck-dot-0');
        const dot1 = _container.querySelector('#ck-dot-1');
        const step0 = _container.querySelector('#ck-step-0');
        const step1 = _container.querySelector('#ck-step-1');
        const stepLine = _container.querySelector('#ck-step-line');
        const digLabel = _container.querySelector('#ck-dig-label');
        const confirm = _container.querySelector('#ck-confirm');
        const result = _container.querySelector('#ck-result');
        const resultText = _container.querySelector('#ck-result-text');
        const resultDur = _container.querySelector('#ck-result-duration');
        const missionName = _container.querySelector('#ck-mission-name');

        // Set mission name in subtitle
        if (missionName) {
            const m = missions[slot] && missions[slot][index];
            const phaseLabel = slot === 'morning' ? 'DAWN' : slot === 'afternoon' ? 'MERIDIAN' : 'DARK OPS';
            if (m && m.title) {
                missionName.textContent = m.title + ' \u00B7 ' + phaseLabel;
            } else {
                missionName.textContent = 'New Mission \u00B7 ' + phaseLabel;
            }
        }

        if (dot0) dot0.className = 'ck-dot active';
        if (dot1) dot1.className = 'ck-dot';
        if (step0) { step0.className = 'ck-step-item active'; }
        if (step1) { step1.className = 'ck-step-item'; }
        if (stepLine) { stepLine.className = 'ck-step-line'; }
        if (digLabel) digLabel.textContent = 'SELECT START TIME';
        if (confirm) { confirm.textContent = 'CONFIRM START \u2192'; confirm.classList.remove('ck-confirmed'); }
        if (result) { result.style.display = 'none'; result.className = 'ck-result'; }
        if (resultText) resultText.textContent = '';
        if (resultDur) resultDur.textContent = '';

        ckBuildHours();
        ckBuildMins();

        // Auto-start time from previous task
        if (missions[slot] && index > 0) {
            const prevMission = missions[slot][index - 1];
            if (prevMission && prevMission.time && prevMission.time.includes(' - ')) {
                const endTime = prevMission.time.split(' - ')[1].trim();
                const parts = endTime.split(' ');
                if (parts.length === 2) {
                    const timeParts = parts[0].split(':').map(Number);
                    const autoH = timeParts[0];
                    const autoM = timeParts[1] || 0;
                    const autoAMPM = parts[1];

                    _container.querySelectorAll('#ck-hour-list .ck-scroll-item').forEach(item => {
                        if (parseInt(item.textContent) === autoH) {
                            item.classList.add('sel');
                            ckSelH = autoH;
                        }
                    });

                    _container.querySelectorAll('#ck-min-list .ck-scroll-item').forEach(item => {
                        if (parseInt(item.textContent) === autoM) {
                            item.classList.add('sel');
                            ckSelM = autoM;
                        }
                    });

                    ckSelAMPM = autoAMPM;
                    const am = _container.querySelector('#ck-am');
                    const pm = _container.querySelector('#ck-pm');
                    if (am) am.classList.toggle('active', autoAMPM === 'AM');
                    if (pm) pm.classList.toggle('active', autoAMPM === 'PM');

                    ckUpdateClock();
                    ckCheckReady();
                }
            }
        }

        const overlay = _container.querySelector('#ck-overlay');
        if (overlay) overlay.classList.add('open');
    }

    function closeClockModal() {
        if (!_container) return;
        const overlay = _container.querySelector('#ck-overlay');
        if (overlay) overlay.classList.remove('open');
    }

    // ═══════════════════════════════════════════
    //  PP TOAST (replaces alert)
    // ═══════════════════════════════════════════
    function showPPToast(message) {
        const toastContainer = _container ? _container.querySelector('#toast-container') : null;
        if (!toastContainer) return;

        const toast = document.createElement('div');
        toast.className = 'pp-toast';
        toast.innerHTML = message;
        toastContainer.appendChild(toast);

        setTimeout(() => { if (toast.parentElement) toast.remove(); }, 4000);
    }

    // ═══════════════════════════════════════════
    //  PUBLIC API
    // ═══════════════════════════════════════════
    return {
        init,
        cleanup
    };

})();

window.TimetableRoute = TimetableRoute;
