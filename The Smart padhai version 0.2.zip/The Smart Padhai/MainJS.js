/**
 * PULSE ENGINE - MASTER SJ EDITION (FULLY UPGRADED)
 * Original code preserved + New Logic Injection
 */

const rankLogos = {
    "Initiate": `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 5px #888);"><path d="M12 2L4 5V11C4 16.07 7.41 20.84 12 22C16.59 20.84 20 16.07 20 11V5L12 2Z" stroke="#888" stroke-width="2" fill="rgba(136,136,136,0.2)"/></svg>`,
    "Operator": `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 8px #00ccff);"><path d="M13 2L3 14H12L11 22L21 10H12L13 2Z" fill="#00ccff"/></svg>`,
    "War Machine": `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 8px #00ff9d);"><path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" fill="#00ff9d"/><path d="M19.4 15V9L17.6 7.2L14.8 7.7L12 5L9.2 7.7L6.4 7.2L4.6 9V15L6.4 16.8L9.2 16.3L12 19L14.8 16.3L17.6 16.8L19.4 15Z" stroke="#00ff9d" stroke-width="2"/></svg>`,
    "Commander": `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 10px #ffd700);"><path d="M12 2L2 7L12 12L22 7L12 2Z" fill="#ffd700"/><path d="M2 17L12 22L22 17M2 12L12 17L22 12" stroke="#ffd700" stroke-width="2"/></svg>`,
    "Architect": `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 12px #cc00ff);"><path d="M12 5C7 5 2.73 8.11 1 12.5C2.73 16.89 7 20 12 20C17 20 21.27 16.89 23 12.5C21.27 8.11 17 5 12 5ZM12 17.5C9.24 17.5 7 15.26 7 12.5C7 9.74 9.24 7.5 12 7.5C14.76 7.5 17 9.74 17 12.5C17 15.26 14.76 17.5 12 17.5ZM12 9.5C10.34 9.5 9 10.84 9 12.5C9 14.16 10.34 15.5 12 15.5C13.66 15.5 15 14.16 15 12.5C15 10.84 13.66 9.5 12 9.5Z" fill="#cc00ff"/></svg>`
};

const PulseEngine = {
    data: (() => {
        const legacy = JSON.parse(localStorage.getItem('pulse_engine_data')) || {};
        return {
            totalPP: Number(legacy.totalPP || 500),
            level: legacy.level || "Initiate",
            hasAscended: !!legacy.hasAscended,
            shields: Number(legacy.shields ?? 1),
            streak: Number(legacy.streak ?? 0),
            lastActivity: legacy.lastActivity || new Date().toDateString(),
            multiplier: Number(legacy.multiplier ?? 1.0),
            inventory: legacy.inventory || [],
            dailyDate: legacy.dailyDate || new Date().toDateString(),
            dailyEarned: Number(legacy.dailyEarned ?? 0),
            rewardLedger: legacy.rewardLedger || {},
            priorityTasks: legacy.priorityTasks || {}
        };
    })(),

    save() {
        localStorage.setItem('pulse_engine_data', JSON.stringify(this.data));
        this.updateUI();
    },

    dailyCheck() {
        const today = new Date().toDateString();
        if (this.data.dailyDate === today) return;

        const hadIncompletePriority = Object.values(this.data.priorityTasks || {}).some(v => v === false);
        if (hadIncompletePriority) {
            this.data.totalPP = Math.max(0, this.data.totalPP - 10);
            if (typeof Alfred !== 'undefined') Alfred.show("PRIORITY MISS: -10 PP", 'penalty', 10);
        }

        this.data.dailyDate = today;
        this.data.dailyEarned = 0;
        this.data.rewardLedger = {};
        this.data.priorityTasks = {};
        this.calculateLevel();
        this.save();
    },

    setPriorityTask(taskId, isCompleted) {
        this.data.priorityTasks[taskId] = !!isCompleted;
        this.save();
    },

    addPoints(amount, type = "task", meta = {}) {
        this.dailyCheck();
        const isDev = meta?.isDev === true;
        const baseRates = { timer: 10, task: 5, mission: 15, checkin: 2 };

        if (amount === null || amount === undefined) {
            amount = baseRates[type] ?? 5;
        }

        // Guards
        if (!isDev) {
            if ((type === 'task' || type === 'mission') && meta.rewardId) {
                if (this.data.rewardLedger[meta.rewardId]) return 0;
            }
            if (this.data.dailyEarned >= 50) {
                if (typeof Alfred !== 'undefined') Alfred.show("DAILY CAP REACHED (50 PP)", 'penalty', 0);
                return 0;
            }
        }

        // Multiplier
        let m = 1.0;
        if (this.data.streak >= 30) m = 2.0;
        else if (this.data.streak >= 15) m = 1.5;
        else if (this.data.streak >= 7) m = 1.2;
        this.data.multiplier = m;

        const finalPoints = Math.floor(Number(amount || 0) * m);
        if (finalPoints <= 0) return 0;

        // Allocation logic
        const remaining = Math.max(0, 50 - this.data.dailyEarned);
        const granted = isDev ? finalPoints : Math.min(finalPoints, remaining);
        
        if (granted <= 0) return 0;

        this.data.totalPP += granted;
        if (!isDev) {
            this.data.dailyEarned += granted;
            if (meta.rewardId) this.data.rewardLedger[meta.rewardId] = true;
        }

        this.calculateLevel();
        this.save();
        
        const multDisplay = document.getElementById('multiplier-tag');
        if (multDisplay) multDisplay.innerText = m + "x";
        
        return granted;
    },

    deductPoints(amount) {
        this.dailyCheck();
        this.data.totalPP = Math.max(0, this.data.totalPP - Math.abs(Number(amount || 0)));
        this.calculateLevel();
        this.save();
    },

    calculateLevel() {
        const pp = this.data.totalPP;
        const oldLevel = this.data.level;
        let newLevel = "Initiate";

        if (pp >= 30000) newLevel = "Architect";
        else if (pp >= 15000) newLevel = "Commander";
        else if (pp >= 5000) newLevel = "War Machine";
        else if (pp >= 1000) newLevel = "Operator";

        if (pp < 30000) this.data.hasAscended = false;

        if (newLevel !== oldLevel) {
            if (newLevel === "Architect" && !this.data.hasAscended) {
                this.data.hasAscended = true;
                setTimeout(() => {
                    if (typeof triggerArchitectAscension === 'function') triggerArchitectAscension();
                }, 800);
            }
            this.data.level = newLevel;
            if (typeof Alfred !== 'undefined') Alfred.show(`RANK UPGRADED: ${newLevel}`, 'reward', 0);
        }
        this.syncThemeClasses();
    },

    syncThemeClasses() {
        const header = document.querySelector('.master-header');
        if (!header) return;
        const rankClass = `theme-${this.data.level.replace(/\s+/g, '')}`;
        header.classList.remove('theme-Initiate', 'theme-Operator', 'theme-WarMachine', 'theme-Commander', 'theme-Architect');
        header.classList.add(rankClass);
    },

    updateUI() {
        const ppValue = this.data.totalPP;
        const currentRank = this.data.level;

        const elements = {
            level: document.getElementById('global-level-display'),
            ppDisplay: document.getElementById('global-pp-display'),
            xpNeeded: document.getElementById('xp-needed'),
            pulseFill: document.getElementById('global-pulse-fill'),
            trophy: document.getElementById('trophy-pp-display'),
            mainBadge: document.getElementById('main-shard-badge'),
            rankName: document.getElementById('rank-name')
        };

        // Rank Display with Logo
        if (elements.level) {
            elements.level.innerHTML = `<div style="display:flex; align-items:center; gap:8px;">${rankLogos[currentRank]} <span>${currentRank}</span></div>`;
            const colors = { "Initiate": "#888", "Operator": "#00ccff", "War Machine": "#00ff9d", "Commander": "#ffd700", "Architect": "#cc00ff" };
            elements.level.style.color = colors[currentRank];
        }

        if (elements.ppDisplay) elements.ppDisplay.innerText = ppValue.toLocaleString();
        if (elements.trophy) elements.trophy.innerText = ppValue.toLocaleString();

        // FIXED PROGRESS BAR (RELATIVE LOGIC)
        if (elements.pulseFill) {
            const brackets = {
                "Initiate": { min: 0, max: 1000, img: "assets/Iniate rank.png", color: "#808080" },
                "Operator": { min: 1000, max: 5000, img: "assets/Operator.png", color: "#00eeff" },
                "War Machine": { min: 5000, max: 15000, img: "assets/war machine.png", color: "#39ff14" },
                "Commander": { min: 15000, max: 30000, img: "assets/commander rank.png", color: "#ffcc00" },
                "Architect": { min: 30000, max: 50000, img: "assets/The all seeing Eye.png", color: "#bc13fe" }
            };

            const config = brackets[currentRank];
            if (elements.xpNeeded) elements.xpNeeded.innerText = `${config.max.toLocaleString()} PP`;

            // Progress within the rank bracket
            const relativePP = ppValue - config.min;
            const range = config.max - config.min;
            const progress = Math.min(Math.max((relativePP / range) * 100, 0), 100);
            elements.pulseFill.style.width = progress + "%";

            // Visual badge update
            if (elements.mainBadge && elements.mainBadge.getAttribute('src') !== config.img) {
                elements.mainBadge.style.opacity = '0';
                setTimeout(() => {
                    elements.mainBadge.src = config.img;
                    elements.mainBadge.style.opacity = '0.7';
                }, 300);
            }
            if (elements.rankName) elements.rankName.innerText = currentRank;

            document.documentElement.style.setProperty('--accent-color', config.color);
            document.documentElement.style.setProperty('--accent-glow', config.color + "66");
        }

        this.syncThemeClasses();
        if (typeof updateTimelinePath === 'function') updateTimelinePath();
    }
};

// --- PRESERVED FUNCTIONS ---
function triggerArchitectAscension() {
    const overlay = document.getElementById('ascension-overlay');
    if (!overlay) return;
    overlay.style.display = 'flex';
    overlay.style.opacity = '1';
    overlay.classList.add('flash-active');
    setTimeout(() => overlay.classList.add('show-content'), 500);
    setTimeout(() => {
        overlay.style.transition = "opacity 3s cubic-bezier(0.4, 0, 0.2, 1)";
        overlay.style.opacity = '0';
        setTimeout(() => {
            overlay.style.display = 'none';
            overlay.classList.remove('flash-active', 'show-content');
            overlay.style.opacity = '1';
        }, 3000);
    }, 9000);
}

const Alfred = {
    show(message, type = 'reward', cost = 0) {
        const card = document.getElementById('alfred-card');
        const text = document.getElementById('alfred-text');
        const badge = document.getElementById('alfred-badge');
        if (!card) return;
        card.className = type + '-mode active';
        const headers = { 'reward': 'SYST_AUTH // SUCCESS', 'penalty': 'SYST_WARN // PENALTY', 'jar': 'NEURAL_SYNC // COOKIE_JAR' };
        badge.innerHTML = `<span>${headers[type]}</span>`;
        text.style.opacity = '0';
        text.innerText = message;
        setTimeout(() => { text.style.transition = "opacity 0.5s ease"; text.style.opacity = '1'; }, 300);
        setTimeout(() => card.classList.remove('active'), 7000);
    }
};

function openCookieJar() {
    const victories = ["Remember when you crushed that Physics backlog?", "You stop when you're DONE.", "Stay Hard!"];
    const randomWin = victories[Math.floor(Math.random() * victories.length)];
    PulseEngine.deductPoints(1000);
    Alfred.show(randomWin, 'jar', 1000);
}

const rankData = [
    { name: "Initiate", points: 0, icon: "🛡️", desc: "The journey begins.", color: "#888" },
    { name: "Operator", points: 1000, icon: "⚡", desc: "Breaking the cycle.", color: "#00ccff" },
    { name: "War Machine", points: 5000, icon: "⚙️", desc: "Unstoppable force.", color: "#00ff9d" },
    { name: "Commander", points: 15000, icon: "🦅", desc: "Tactical genius.", color: "#ffd700" },
    { name: "Architect", points: 30000, icon: "👁️", desc: "You create the rules.", color: "#cc00ff" }
];

function openRankModal() {
    const container = document.getElementById('rank-list-container');
    const pp = PulseEngine.data.totalPP;
    container.innerHTML = rankData.map(rank => `
        <div class="rank-node ${pp >= rank.points ? 'unlocked' : ''} ${PulseEngine.data.level === rank.name ? 'current' : ''}">
            <div class="node-circle">${rank.icon}</div>
            <div class="node-name">${rank.name.toUpperCase()}</div>
        </div>`).join('');
    document.getElementById('rank-modal').style.display = 'flex';
}

function updateTimelinePath() {
    const trackFill = document.querySelector('.timeline-track-fill');
    if (!trackFill) return;
    const pp = PulseEngine.data.totalPP;
    let fill = pp >= 30000 ? 100 : pp >= 15000 ? 75 : pp >= 5000 ? 50 : pp >= 1000 ? 25 : 0;
    setTimeout(() => { trackFill.style.width = fill + "%"; }, 300);
}

function triggerDevPoints() {
    PulseEngine.addPoints(1000, 'mission', { rewardId: 'dev_boost_' + Date.now(), isDev: true });
}

document.addEventListener('DOMContentLoaded', () => {
    PulseEngine.dailyCheck();
    PulseEngine.updateUI();
});