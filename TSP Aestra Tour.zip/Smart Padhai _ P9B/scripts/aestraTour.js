/*
 * Smart Padhai — AESTRA System Briefing
 * Scripted, local-only onboarding tour. No AI/API calls are made here.
 */
(function () {
    'use strict';

    const STORAGE_KEY = 'smart_padhai_aestra_intro_tour_seen';
    const ROUTE_WAIT_MS = 520;
    const MODULE_LOADING_TEXT = 'Opening module...';

    const state = {
        active: false,
        introOpen: false,
        index: 0,
        overlay: null,
        panel: null,
        highlighted: null,
        loading: false,
        personalization: null
    };

    const TOUR_ID_TARGETS = {
        'sidebar-dashboard': '[data-route="dashboard"], a[href="#/dashboard"]',
        'sidebar-syllabus': '[data-route="syllabus"], a[href="#/syllabus"]',
        'sidebar-backlog': '[data-route="backlog"], a[href="#/backlog"]',
        'sidebar-notebooks': '[data-route="notebooks"], a[href="#/notebooks"]',
        'sidebar-study-vault': '[data-route="vault"], a[href="#/vault"]',
        'sidebar-timetable': '[data-route="timetable"], a[href="#/timetable"]',
        'sidebar-calendar': '[data-route="calendar"], a[href="#/calendar"], .sidebar-link[href="#/calendar"]',
        'sidebar-aestra': '[data-route="aestra"], a[href="#/aestra"]',
        'sidebar-plans': '[data-route="plans"], a[href="#/plans"], .nav-item-upgrade',
        'syllabus-page': '.syllabus-wrapper, .syllabus-page, .syllabus-master-container',
        'syllabus-stats': '.syllabus-header-card, .syllabus-stats-grid, .syllabus-stats, .stats-grid',
        'syllabus-gap-analyzer': '#gapAnalyzerSection, .gap-analyzer-section',
        'syllabus-subject-grid': '#subjectGrid, .subject-grid',
        'syllabus-book-tabs': '#bookTabs, .book-tabs',
        'syllabus-chapter-list': '#chapterList, .chapter-list-container, .chapters-list',
        'syllabus-chapter-card': '.chapter-card, .syllabus-chapter-card',
        'syllabus-progress-controls': '.chapter-actions, .chapter-stage-controls, .progress-controls, .status-controls',
        'backlog-page': '.backlog-wrapper, .backlog-master-container, .backlog-page',
        'backlog-stats': '.backlog-stats-container, .backlog-stats, .stats-grid',
        'backlog-focus-zone': '#focusMissionZone, .focus-mission-zone',
        'backlog-priority': '#autoRankSection, .auto-rank-section, .priority-list, .rank-panel-header',
        'backlog-list': '.backlog-list, #backlogList, .backlog-items, .tasks-list',
        'backlog-timer': '#focusActiveCard, #missionTimer, .backlog-timer, .timer-card, .focus-timer-card',
        'notebook-page': '.notebook-container, .notebooks-page, .nb-command-center',
        'notebook-directive': '#nbDirectiveCard, .nb-directive-card, .notebook-directive',
        'notebook-tabs': '.nb-copy-tabs',
        'cw-tab': '#nbTabCw, [data-action="switch-copy-tab"][data-tab="cw"], [data-tab="cw"]',
        'hw-tab': '#nbTabHw, [data-action="switch-copy-tab"][data-tab="hw"], [data-tab="hw"]',
        'notes-tab': '#nbTabNotes, [data-action="switch-copy-tab"][data-tab="notes"], [data-tab="notes"]',
        'sticky-tab': '#nbTabNotes, [data-action="switch-copy-tab"][data-tab="notes"]',
        'missions-tab': '#nbTabMissions, [data-action="switch-copy-tab"][data-tab="missions"], [data-tab="missions"]',
        'cw-copy-section': '.nb-command-section, .nb-cw-panel, .cw-copy-card, .notebook-index',
        'cw-index': '.nb-cw-index-panel, .notebook-index',
        'hw-missions-section': '.nb-command-section, .nb-hw-panel, .homework-missions',
        'notes-vault-section': '.nb-nv-section, .nb-notes-vault, .notes-vault',
        'sticky-board-section': '.nb-sn-board, .nb-sticky-board, .sticky-board',
        'notebook-mission-center': '.nb-missions-section, #nbMissionBoard, .nb-mission-board',
        'notebook-missions': '#nbMissionBoard, .nb-mission-board, .nb-mission-preview-grid',
        'notebook-active-timer': '#nbActiveTimerSection, .nb-active-timer',
        'notebook-priority-mission': '#nbPriorityMissionSection, .nb-priority-mission',
        'notebook-mission-buckets': '#nbMissionBucketsSection, .nb-mission-buckets',
        'notebook-all-missions': '#nbAllMissionsSection, .nb-all-missions',
        'timetable-page': '.timetable-wrapper, .timetable-page, .time-table-page, .tb-budget-section',
        'time-allocation': '.tb-budget-section, .time-allocation-section, .allocation-panel',
        'time-allocation-matrix': '#budget-matrix, .tb-budget-matrix',
        'time-allocation-graph': '#budget-graph, .tb-budget-graph',
        'timetable-hero': '.hero-dashboard',
        'timetable-clock': '.tac-clock-panel',
        'timetable-grid': '#morning-grid, .mission-grid, .timetable-grid',
        'study-blocks': '.mission-card, .study-blocks, .study-block, .time-block, .schedule-block',
        'calendar-page': '#strategy-map-page, .calendar-page, .calendar-shell, .calendar-wrapper',
        'calendar-modes': '.strategy-controls',
        'calendar-container': '.calendar-container',
        'calendar-grid': '.calendar-grid',
        'calendar-dates': '#calendarDates, .dates-wrapper',
        'calendar-legend': '.cal-legend',
        'calendar-events': '.day-details, .calendar-events, .events-list, .event-list, .calendar-event',
        'calendar-add-event': '[data-action="add-event"], [data-action="open-add-event"], .add-event-btn, .calendar-add-event',
        'plans-page': '.plans-page, .plans-wrapper, .plans-header',
        'plans-header': '.plans-header',
        'current-plan-badge': '#spa-currentPlanBadge, .current-plan-badge',
        'plans-grid': '.plans-grid, .pricing-grid',
        'free-plan': '[data-tier="free"], .plan-card.free, .plan-card:first-child, [data-plan="free"]',
        'starter-plan': '[data-tier="starter"], [data-plan="starter"]',
        'pro-plan': '[data-tier="pro"], [data-plan="pro"]',
        'elite-plan': '[data-tier="elite"], [data-plan="elite"]',
        'preview-plans': '[data-tier="starter"], [data-tier="pro"], [data-tier="elite"], .plans-grid',
        'plans-aestra-preview': '.aestra-section',
        'aestra-page': '.aestra-workspace.aestra-locked-gate',
        'aestra-gate': '.aestra-gate-content',
        'aestra-orb': '.aestra-gate-orb-container, .aestra-gate-orb',
        'aestra-coming-soon-badge': '.aestra-gate-badge',
        'aestra-cta-row': '.aestra-gate-cta-row',
        'aestra-feature-preview': '.aestra-gate-features, .aestra-feature-preview',
        'aestra-demo-note': '.aestra-gate-demo-note'
    };

    const steps = [
        {
            id: 'dashboard-command-center',
            route: 'dashboard',
            title: 'Dashboard Command Center',
            message: 'This is your control room. It shows identity, progress, discipline signals, planning pressure, and the next action to execute.',
            targetSelector: '[data-tour-id="dashboard-page"], .dashboard-wrapper',
            fallbackSelector: '[data-tour-id="dashboard-hero"], #app-content'
        },
        {
            id: 'hero-identity',
            route: 'dashboard',
            title: 'Hero Identity',
            message: 'Your hero area shows nickname, operative type, rank, and PP. Check it first to understand your current study identity.',
            targetSelector: '[data-tour-id="dashboard-hero"], .dashboard-hero, .hero-section, .hero-card, .master-header',
            fallbackSelector: '[data-tour-id="dashboard-page"], .dashboard-wrapper'
        },
        {
            id: 'pulse-points',
            route: 'dashboard',
            title: 'Pulse Points',
            message: 'PP is proof of execution. Earn it through real study actions and use it as a discipline signal, not a decoration.',
            targetSelector: '[data-tour-id="hero-pp"], .hero-pp-section',
            fallbackSelector: '[data-tour-id="pulse-score-card"], #pulse-square, [data-tour-id="dashboard-hero"]'
        },
        {
            id: 'rank-journey',
            route: 'dashboard',
            title: 'Rank Journey',
            message: 'Ranks show long-term discipline growth. Open the rank area to see what your current execution is building toward.',
            targetSelector: '[data-tour-id="hero-rank"], .hero-rank-pill, #rank-icon, #commander-rank',
            fallbackSelector: '[data-tour-id="dashboard-hero"], .master-header'
        },
        {
            id: 'ghost-mode',
            route: 'dashboard',
            title: 'Ghost Mode',
            message: 'Ghost Mode removes dashboard noise for focused execution. Use it when attention matters more than browsing the system.',
            targetSelector: '[data-tour-id="ghost-mode"], .ghost-mode-btn, #ghostBtn, .ghost-button-style',
            fallbackSelector: '[data-tour-id="dashboard-hero"], .master-header'
        },
        {
            id: 'cookie-jar',
            route: 'dashboard',
            title: 'Cookie Jar',
            message: 'Cookie Jar stores wins and mental fuel. When motivation drops, open it to remember why you keep going.',
            targetSelector: '[data-tour-id="cookie-jar"], .cookie-jar-btn, #cookie-jar-trigger, .cookie-btn-pro',
            fallbackSelector: '[data-tour-id="dashboard-hero"], .master-header'
        },
        {
            id: 'daily-directive',
            route: 'dashboard',
            title: 'Daily Directive',
            message: 'The Directive turns system data into one recommended next move. Read it when you feel scattered.',
            targetSelector: '[data-tour-id="daily-directive"], #dailyDirectiveCard, .dash-directive-section',
            fallbackSelector: '[data-tour-id="dashboard-page"], .dashboard-wrapper'
        },
        {
            id: 'dashboard-view-toggle',
            route: 'dashboard',
            title: 'Dashboard View Toggle',
            message: 'Switch between full detail and compact command view. Use compact mode when you need speed, full view when reviewing the system.',
            targetSelector: '[data-tour-id="dashboard-view-toggle"], [data-tour="dashboard-controls"], .dashboard-command-actions',
            fallbackSelector: '[data-tour-id="dashboard-page"], .dashboard-wrapper'
        },
        {
            id: 'backlog-card',
            route: 'dashboard',
            title: 'Backlog Card',
            message: 'This card warns you about pending academic work. A rising backlog means pressure is building and needs clearing.',
            targetSelector: '[data-tour-id="backlog-card"], #backlog-square',
            fallbackSelector: '[data-tour-id="dashboard-cards"], .dash-stats-section'
        },
        {
            id: 'progress-card',
            route: 'dashboard',
            title: 'Progress Card',
            message: 'Progress reflects syllabus completion. Keep chapter stages updated so this card reports reality, not hope.',
            targetSelector: '[data-tour-id="progress-card"], #progress-square',
            fallbackSelector: '[data-tour-id="dashboard-cards"], .dash-stats-section'
        },
        {
            id: 'notebook-card',
            route: 'dashboard',
            title: 'Notebook Card',
            message: 'Notebook signals show written work health. Use it to catch incomplete classwork, homework, and notes before they become backlog.',
            targetSelector: '[data-tour-id="notebook-card"], #notebook-square',
            fallbackSelector: '[data-tour-id="dashboard-cards"], .dash-stats-section'
        },
        {
            id: 'pulse-score-card',
            route: 'dashboard',
            title: 'Pulse Score Card',
            message: 'Pulse Score reads today’s discipline. Use it to see whether your actions are strong enough for the day.',
            targetSelector: '[data-tour-id="pulse-score-card"], #pulse-square',
            fallbackSelector: '[data-tour-id="dashboard-cards"], .dash-stats-section'
        },
        {
            id: 'performance-analytics',
            route: 'dashboard',
            title: 'Performance Analytics',
            message: 'Analytics convert study behavior into weekly signals. Review them to spot consistency, PP, and progress patterns.',
            targetSelector: '[data-tour-id="performance-analytics"], .dashboard-section-group',
            fallbackSelector: '[data-tour-id="dashboard-page"], .dashboard-wrapper'
        },
        {
            id: 'weekly-pp-goal',
            route: 'dashboard',
            title: 'Weekly PP Goal',
            message: 'The weekly goal gives PP a target. Set a realistic number and let the bar expose whether your week is on track.',
            targetSelector: '[data-tour-id="weekly-pp-goal"], [data-section-id="weeklyPPGoal"], #weeklyPPGoalCard',
            fallbackSelector: '[data-tour-id="performance-analytics"], .dashboard-section-group',
            beforeStepAction: 'expand-dashboard-section:weeklyPPGoal'
        },
        {
            id: 'weekly-reality-mirror',
            route: 'dashboard',
            title: 'Weekly Reality Mirror',
            message: 'The mirror gives an honest weekly review. Use it to see what actually happened, not what you planned to happen.',
            targetSelector: '[data-tour-id="weekly-reality-mirror"], [data-section-id="weeklyRealityMirror"], #weekly-report-card',
            fallbackSelector: '[data-tour-id="performance-analytics"], .dashboard-section-group',
            beforeStepAction: 'expand-dashboard-section:weeklyRealityMirror'
        },
        {
            id: 'session-insights',
            route: 'dashboard',
            title: 'Session Insights',
            message: 'Session Insights track study quality, not just minutes. Log sessions honestly so patterns become visible.',
            targetSelector: '[data-tour-id="session-insights"], [data-section-id="sessionInsights"], #sessionInsightsCard',
            fallbackSelector: '[data-tour-id="dashboard-page"], .dashboard-wrapper',
            beforeStepAction: 'expand-dashboard-section:sessionInsights'
        },
        {
            id: 'streak-heatmap',
            route: 'dashboard',
            title: 'Streak and Heatmap',
            message: 'The heatmap shows consistency over time. Use it to protect streaks and detect weak days before they repeat.',
            targetSelector: '[data-tour-id="streak-heatmap"], [data-section-id="streakHeatmap"], #streakHeatmapCard',
            fallbackSelector: '[data-tour-id="dashboard-page"], .dashboard-wrapper',
            beforeStepAction: 'expand-dashboard-section:streakHeatmap'
        },
        {
            id: 'panic-protocol',
            route: '#/dashboard',
            title: 'Panic Protocol',
            message: 'Panic Protocol is for heavy workload or exam pressure. Set scope first so recovery plans are based on real chapters.',
            targetSelector: '[data-tour-id="panic-protocol"], #panicProtocolV2Card, #panicProtocolCard, .panic-card',
            fallbackSelector: '[data-tour-id="dashboard-page"], .dashboard-wrapper',
            beforeStepAction: 'expand-dashboard-section:panicProtocol'
        },
        {
            id: 'syllabus-page',
            route: '#/syllabus',
            title: 'Syllabus Tracker',
            message: 'Syllabus is the source of truth for chapters. Add accurate data so dashboard progress and planning become useful.',
            targetSelector: '[data-tour-id="syllabus-page"], .syllabus-wrapper',
            fallbackSelector: '#app-content, main'
        },
        {
            id: 'syllabus-gap-analyzer',
            route: '#/syllabus',
            title: 'Gap Analyzer',
            message: 'Gap Analyzer shows where your syllabus is weak or mismatched. Use it before deciding what to study next.',
            targetSelector: '[data-tour-id="syllabus-gap-analyzer"], #gapAnalyzerSection',
            fallbackSelector: '[data-tour-id="syllabus-page"], #app-content'
        },
        {
            id: 'syllabus-chapter-list',
            route: '#/syllabus',
            title: 'Chapter List',
            message: 'The chapter list is where raw syllabus becomes trackable work. Keep chapters visible and current here.',
            targetSelector: '[data-tour-id="syllabus-chapter-list"], #chapterList',
            fallbackSelector: '[data-tour-id="syllabus-page"], #app-content'
        },
        {
            id: 'syllabus-status-stages',
            route: '#/syllabus',
            title: 'Chapter Status Stages',
            message: 'Read, notes, revision, and practice together form real progress. Update stages so the dashboard reads reality.',
            targetSelector: '[data-tour-id="syllabus-progress-controls"], .chapter-actions',
            fallbackSelector: '[data-tour-id="syllabus-chapter-card"], .chapter-card, [data-tour-id="syllabus-chapter-list"]'
        },
        {
            id: 'backlog-page',
            route: '#/backlog',
            title: 'Backlog Manager',
            message: 'Backlog means unfinished academic work. Capture it here so pressure becomes visible and controllable.',
            targetSelector: '[data-tour-id="backlog-page"], .backlog-wrapper',
            fallbackSelector: '#app-content, main'
        },
        {
            id: 'backlog-focus-zone',
            route: '#/backlog',
            title: 'Focus Mission Zone',
            message: 'The focus zone turns backlog into one current mission. Use it when you need execution, not another list.',
            targetSelector: '[data-tour-id="backlog-focus-zone"], #focusMissionZone',
            fallbackSelector: '[data-tour-id="backlog-page"], #app-content'
        },
        {
            id: 'backlog-priority',
            route: '#/backlog',
            title: 'Backlog Priority',
            message: 'Priority ranking tells you what to clear first. Do not treat every pending task as equally dangerous.',
            targetSelector: '[data-tour-id="backlog-priority"], #autoRankSection, .auto-rank-section',
            fallbackSelector: '[data-tour-id="backlog-page"], #app-content'
        },
        {
            id: 'backlog-list',
            route: '#/backlog',
            title: 'Backlog List',
            message: 'The list keeps every pending task visible. Clearing items here should reduce pressure across the system.',
            targetSelector: '[data-tour-id="backlog-list"], .backlog-list, #backlogList',
            fallbackSelector: '[data-tour-id="backlog-page"], #app-content'
        },
        {
            id: 'backlog-timer',
            route: '#/backlog',
            title: 'Backlog Timer',
            message: 'Timed backlog work converts pressure into execution. Use a session when one item needs focused clearing.',
            targetSelector: '[data-tour-id="backlog-timer"], #focusActiveCard, #missionTimer',
            fallbackSelector: '[data-tour-id="backlog-focus-zone"], [data-tour-id="backlog-page"]'
        },
        {
            id: 'notebook-page',
            route: '#/notebooks',
            title: 'Notebook Command Center',
            message: 'Notebook connects physical copy work with digital control. Use it to manage C.W., H.W., notes, and reminders.',
            targetSelector: '[data-tour-id="notebook-page"], .notebook-container',
            fallbackSelector: '#app-content, main'
        },
        {
            id: 'notebook-directive',
            route: '#/notebooks',
            title: 'Notebook Directive',
            message: 'The notebook directive points to the most important notebook action. Follow it when copy work feels scattered.',
            targetSelector: '[data-tour-id="notebook-directive"], #nbDirectiveCard, .nb-directive-card',
            fallbackSelector: '[data-tour-id="notebook-page"], #app-content'
        },
        {
            id: 'cw-copy-section',
            route: '#/notebooks',
            title: 'C.W. Copy',
            message: 'C.W. Copy indexes physical classwork so you know which chapters are written, incomplete, current, or risky.',
            targetSelector: '[data-tour-id="cw-copy-section"], .nb-cw-panel, .cw-copy-card',
            fallbackSelector: '[data-tour-id="cw-index"], [data-tour-id="notebook-page"]',
            beforeStepAction: 'notebook-cw'
        },
        {
            id: 'hw-missions-section',
            route: '#/notebooks',
            title: 'H.W. Missions',
            message: 'H.W. Missions organize homework by urgency, due date, and completion so daily work does not vanish from memory.',
            targetSelector: '[data-tour-id="hw-missions-section"], .nb-hw-panel, .homework-missions',
            fallbackSelector: '[data-tour-id="notebook-page"], .nb-copy-tabs',
            beforeStepAction: 'notebook-hw'
        },
        {
            id: 'notes-vault-section',
            route: '#/notebooks',
            title: 'Notes Vault',
            message: 'Notes Vault stores formulas, weak points, mistakes, and revision material. Use it for information you cannot afford to lose.',
            targetSelector: '[data-tour-id="notes-vault-section"], .nb-nv-section, .notes-vault',
            fallbackSelector: '[data-tour-id="notebook-page"], .nb-copy-tabs',
            beforeStepAction: 'notebook-notes'
        },
        {
            id: 'sticky-board-section',
            route: '#/notebooks',
            title: 'Sticky Board',
            message: 'Sticky Board keeps quick reminders and warnings visible. Use it for small notes that must stay in sight.',
            targetSelector: '[data-tour-id="sticky-board-section"], .nb-sn-board, .sticky-board',
            fallbackSelector: '[data-tour-id="notes-vault-section"], [data-tour-id="notebook-page"]',
            beforeStepAction: 'notebook-sticky'
        },
        {
            id: 'notebook-mission-center',
            route: '#/notebooks',
            title: 'Notebook Mission Center',
            message: 'Mission Center turns notebook work into executable tasks. Complete real work here when you want notebook actions to count.',
            targetSelector: '[data-tour-id="notebook-mission-center"], .nb-missions-section, #nbMissionBoard',
            fallbackSelector: '[data-tour-id="notebook-missions"], [data-tour-id="notebook-page"]',
            beforeStepAction: 'notebook-missions'
        },
        {
            id: 'time-allocation',
            route: '#/timetable',
            title: 'Time Allocation',
            message: 'Allocation decides where your hours go: study, school work, revision, projects, and rest. Plan balance before filling slots.',
            targetSelector: '[data-tour-id="time-allocation"], .tb-budget-section',
            fallbackSelector: '[data-tour-id="timetable-page"], #app-content'
        },
        {
            id: 'time-allocation-matrix',
            route: '#/timetable',
            title: 'Budget Matrix and Graph',
            message: 'The matrix and graph show whether planned time matches real priorities. Use them before building the grid.',
            targetSelector: '[data-tour-id="time-allocation-matrix"], #budget-matrix',
            fallbackSelector: '[data-tour-id="time-allocation-graph"], [data-tour-id="time-allocation"]'
        },
        {
            id: 'timetable-clock',
            route: '#/timetable',
            title: 'Clock and Study Blocks',
            message: 'The clock and grid make plans executable. Convert broad goals into visible sessions and protect those blocks.',
            targetSelector: '[data-tour-id="timetable-clock"], .tac-clock-panel',
            fallbackSelector: '[data-tour-id="timetable-grid"], [data-tour-id="study-blocks"], [data-tour-id="timetable-page"]'
        },
        {
            id: 'calendar-page',
            route: '#/calendar',
            title: 'Calendar and Deadlines',
            message: 'Calendar keeps exams, deadlines, and study dates visible. Planning should not depend on memory.',
            targetSelector: '[data-tour-id="calendar-page"], #strategy-map-page, .calendar-page',
            fallbackSelector: '#app-content, main'
        },
        {
            id: 'calendar-grid',
            route: '#/calendar',
            title: 'Calendar Grid and Events',
            message: 'The grid, events, and add controls keep important dates visible. Add deadlines early so planning has real context.',
            targetSelector: '[data-tour-id="calendar-grid"], .calendar-grid',
            fallbackSelector: '[data-tour-id="calendar-events"], [data-tour-id="calendar-add-event"], [data-tour-id="calendar-page"]'
        },
        {
            id: 'plans-page',
            route: '#/plans',
            title: 'Free Plan Reality',
            message: 'Every account starts on Free for now. Check the current plan before assuming a feature is unlocked.',
            targetSelector: '[data-tour-id="free-plan"], [data-tour-id="plans-page"], .plans-page',
            fallbackSelector: '#app-content, main'
        },
        {
            id: 'preview-plans',
            route: '#/plans',
            title: 'Preview Plans and AESTRA Access',
            message: 'Starter, Pro, Elite, and AESTRA previews show future direction without pretending paid activation is live.',
            targetSelector: '[data-tour-id="preview-plans"], [data-tour-id="starter-plan"], [data-tour-id="pro-plan"], [data-tour-id="elite-plan"]',
            fallbackSelector: '[data-tour-id="plans-grid"], [data-tour-id="plans-aestra-preview"], [data-tour-id="plans-page"]'
        },
        {
            id: 'aestra-gate',
            route: '#/aestra',
            title: 'AESTRA AI — Locked',
            message: 'The AI chat is locked for stability. This local tour explains the system now; no AI API is called.',
            targetSelector: '[data-tour-id="aestra-gate"], .aestra-gate-content',
            fallbackSelector: '[data-tour-id="aestra-page"], #app-content'
        },
        {
            id: 'aestra-feature-preview',
            route: '#/aestra',
            title: 'Future Mentor Layer',
            message: 'Later, AESTRA can use syllabus, backlog, notebook, and progress data to guide smarter decisions. For now, the briefing teaches the system.',
            targetSelector: '[data-tour-id="aestra-feature-preview"], .aestra-gate-features',
            fallbackSelector: '[data-tour-id="aestra-gate"], [data-tour-id="aestra-page"]'
        },
        {
            id: 'first-three-actions',
            route: '#/dashboard',
            title: 'Your First 3 Actions',
            message: 'Start simple: add syllabus data, create one notebook or backlog item, then complete one small task to earn real progress.',
            targetSelector: '[data-tour-id="dashboard-page"], .dashboard-wrapper',
            fallbackSelector: '#app-content, main, body'
        },
        {
            id: 'briefing-complete',
            route: '#/dashboard',
            title: 'System Briefing Complete',
            message: 'You are ready. Add real data, complete one task, and let Smart Padhai become your command system one action at a time.',
            targetSelector: '[data-tour-id="dashboard-hero"], .master-header, .dashboard-wrapper',
            fallbackSelector: '#app-content, main, body',
            primaryAction: 'finish',
            secondaryAction: 'open-syllabus'
        }
    ];

    function storageGet(key) {
        try {
            if (window.SafeStorage && typeof window.SafeStorage.getItem === 'function') {
                const value = window.SafeStorage.getItem(key, null);
                if (value !== null && value !== undefined) return value;
            }
        } catch (err) { /* local fallback below */ }
        try { return localStorage.getItem(key); } catch (err) { return null; }
    }

    function storageSet(key, value) {
        try {
            if (window.SafeStorage && typeof window.SafeStorage.setItem === 'function') {
                window.SafeStorage.setItem(key, value);
                return;
            }
        } catch (err) { /* local fallback below */ }
        try { localStorage.setItem(key, String(value)); } catch (err) { /* no-op */ }
    }

    function isSeen() {
        const raw = storageGet(STORAGE_KEY);
        return raw === true || raw === 'true' || raw === '1';
    }

    function markSeen() {
        storageSet(STORAGE_KEY, true);
    }

    function parseStoredObject(key) {
        const raw = storageGet(key);
        if (!raw) return null;
        if (typeof raw === 'object') return raw;
        try { return JSON.parse(raw); } catch (err) { return null; }
    }

    function readProfile() {
        const candidates = [
            parseStoredObject('smart_padhai_profile'),
            parseStoredObject('smartPadhaiProfile'),
            parseStoredObject('user_profile'),
            parseStoredObject('smartPadhaiUser'),
            parseStoredObject('smartPadhaiData')
        ].filter(Boolean);

        const profile = Object.assign({}, ...candidates);
        const nested = profile.profile || profile.studentProfile || profile.user || {};
        const data = Object.assign({}, profile, nested);
        const emailPrefix = typeof data.email === 'string' ? data.email.split('@')[0] : '';
        const displayName = data.operativeName || data.nickname || data.name || data.fullName || data.displayName || emailPrefix || 'operative';
        const operativeLevel = data.operativeLevel || data.studentType || data.level || data.type || '';
        const classLevel = data.classLevel || data.class || data.grade || data.standard || '';
        const board = data.board || data.curriculum || '';

        return {
            displayName: String(displayName || 'operative').trim(),
            operativeLevel: String(operativeLevel || '').trim(),
            classLine: [classLevel, board].filter(Boolean).join(' ')
        };
    }

    function getPersonalGreeting() {
        state.personalization = state.personalization || readProfile();
        const profile = state.personalization;
        if (!profile || !profile.displayName || profile.displayName.toLowerCase() === 'operative') {
            return 'Welcome, operative.';
        }
        const classText = profile.classLine ? ` ${profile.classLine} detected.` : '';
        return `Welcome, ${escapeHtml(profile.displayName)}.${classText} Let me brief you on your command system.`;
    }

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>'"]/g, (char) => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
        }[char]));
    }

    function normalizeRoute(route) {
        if (!route) return null;
        let value = String(route).trim();
        if (value.startsWith('#')) value = value.slice(1);
        if (!value.startsWith('/')) value = '/' + value;
        if (value === '/upgrade') value = '/plans';
        return value;
    }

    function currentRoute() {
        if (window.SpaRouter && typeof window.SpaRouter.getCurrentRoute === 'function') {
            return window.SpaRouter.getCurrentRoute();
        }
        return normalizeRoute(window.location.hash.slice(1) || '/dashboard');
    }

    function wait(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    async function navigateIfNeeded(route) {
        const normalized = normalizeRoute(route);
        if (!normalized) return;
        if (currentRoute() === normalized) return;
        setLoading(true);
        try {
            if (window.SpaRouter && typeof window.SpaRouter.navigate === 'function') {
                await window.SpaRouter.navigate(normalized);
            } else {
                window.location.hash = '#' + normalized;
            }
        } catch (err) {
            console.warn('[AESTRA Tour] Route navigation failed:', err);
        } finally {
            await wait(ROUTE_WAIT_MS);
            setLoading(false);
        }
    }

    function buildShell() {
    removeShell();

    const overlay = document.createElement('div');
    overlay.className = 'aestra-tour-overlay';
    overlay.setAttribute('aria-hidden', 'true');
    overlay.innerHTML = `<div class="aestra-tour-scrim"></div>`;

    const panel = document.createElement('section');
    panel.className = 'aestra-tour-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'true');
    panel.setAttribute('aria-live', 'polite');
    panel.innerHTML = `
        <div class="aestra-tour-orb-wrap" aria-hidden="true">
            <div class="aestra-tour-orb"></div>
            <div class="aestra-tour-ring aestra-tour-ring-one"></div>
            <div class="aestra-tour-ring aestra-tour-ring-two"></div>
        </div>
        <div class="aestra-tour-kicker">AESTRA System Briefing</div>
        <div class="aestra-tour-step-count"></div>
        <h2 class="aestra-tour-title"></h2>
        <p class="aestra-tour-message"></p>
        <div class="aestra-tour-loading" hidden>${MODULE_LOADING_TEXT}</div>
        <div class="aestra-tour-actions"></div>
    `;

    document.body.appendChild(overlay);
    document.body.appendChild(panel);

    state.overlay = overlay;
    state.panel = panel;
    document.body.classList.add('aestra-tour-active');
}

   function removeShell() {
    clearHighlight();

    document.querySelectorAll('.aestra-tour-overlay').forEach(el => el.remove());
    document.querySelectorAll('.aestra-tour-panel').forEach(el => el.remove());

    state.overlay = null;
    state.panel = null;
    document.body.classList.remove('aestra-tour-active');
}

    function buildIntro() {
    if (state.introOpen || state.active || isSeen()) return;
    state.introOpen = true;
    removeShell();

    const overlay = document.createElement('div');
    overlay.className = 'aestra-tour-overlay aestra-tour-intro-overlay';
    overlay.setAttribute('aria-hidden', 'true');
    overlay.innerHTML = `<div class="aestra-tour-scrim"></div>`;

    const panel = document.createElement('section');
    panel.className = 'aestra-tour-panel aestra-tour-intro-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'true');
    panel.innerHTML = `
        <div class="aestra-tour-orb-wrap" aria-hidden="true">
            <div class="aestra-tour-orb"></div>
            <div class="aestra-tour-ring aestra-tour-ring-one"></div>
            <div class="aestra-tour-ring aestra-tour-ring-two"></div>
        </div>
        <div class="aestra-tour-kicker">First-Time Command Briefing</div>
        <h2 class="aestra-tour-title">AESTRA System Briefing</h2>
        <p class="aestra-tour-message">Welcome to Smart Padhai. I am AESTRA, your study command assistant. My full AI chat module is still being upgraded, but I can guide you through the entire command system.</p>
        <p class="aestra-tour-personal-line">${getPersonalGreeting()}</p>
        <div class="aestra-tour-actions">
            <button type="button" class="aestra-tour-btn aestra-tour-btn-ghost" data-aestra-intro="skip">Skip for Now</button>
            <button type="button" class="aestra-tour-btn aestra-tour-btn-primary" data-aestra-intro="start">Start Full Tour</button>
        </div>
    `;

    document.body.appendChild(overlay);
    document.body.appendChild(panel);

    state.overlay = overlay;
    state.panel = panel;
    document.body.classList.add('aestra-tour-active');

    panel.addEventListener('click', (event) => {
        const action = event.target?.closest('[data-aestra-intro]')?.dataset.aestraIntro;
        if (!action) return;

        if (action === 'skip') {
            markSeen();
            state.introOpen = false;
            removeShell();
        } else if (action === 'start') {
            state.introOpen = false;
            start({ force: true });
        }
    });
}
    function setLoading(isLoading) {
        state.loading = isLoading;
        if (!state.panel) return;
        const loadingEl = state.panel.querySelector('.aestra-tour-loading');
        if (loadingEl) loadingEl.hidden = !isLoading;
        state.panel.classList.toggle('aestra-tour-panel-loading', isLoading);
    }

    function isVisibleTarget(node) {
        if (!node || typeof node.getClientRects !== 'function') return false;
        const style = window.getComputedStyle ? window.getComputedStyle(node) : null;
        if (style && (style.display === 'none' || style.visibility === 'hidden')) return false;
        return node.getClientRects().length > 0;
    }

    function findTarget(selector) {
        if (!selector) return null;
        try {
            const nodes = Array.from(document.querySelectorAll(selector));
            return nodes.find(isVisibleTarget) || null;
        } catch (err) {
            console.warn('[AESTRA Tour] Bad target selector:', selector, err);
            return null;
        }
    }

    function applyStableTourIds() {
        Object.entries(TOUR_ID_TARGETS).forEach(([tourId, selector]) => {
            if (!selector || document.querySelector(`[data-tour-id="${tourId}"]`)) return;
            const target = findTarget(selector);
            if (target && !target.hasAttribute('data-tour-id')) target.setAttribute('data-tour-id', tourId);
        });
    }

    async function waitForTarget(selector, timeout = 2000) {
        if (!selector) return null;
        const started = Date.now();
        while (Date.now() - started < timeout) {
            applyStableTourIds();
            const target = findTarget(selector);
            if (target) return target;
            await wait(100);
        }
        return null;
    }

    function expandDashboardSection(sectionId) {
        if (!sectionId) return;
        const section = document.querySelector(`[data-section-id="${sectionId}"]`);
        if (!section) return;
        const body = section.querySelector('.dashboard-collapsible-body');
        const isBodyHidden = body && (body.hidden || body.style.display === 'none' || body.offsetParent === null);
        const isCollapsed = section.classList.contains('collapsed') || section.classList.contains('is-collapsed') || isBodyHidden;
        if (!isCollapsed) return;
        const header = section.querySelector('[data-action="toggle-dashboard-section"]');
        if (header) header.click();
    }

    async function switchNotebookTab(tab) {
        const normalized = tab === 'sticky' ? 'notes' : tab;
        const idMap = {
            cw: '#nbTabCw',
            hw: '#nbTabHw',
            notes: '#nbTabNotes',
            sticky: '#nbTabNotes',
            missions: '#nbTabMissions'
        };
        const selectors = [
            `[data-action="switch-copy-tab"][data-tab="${normalized}"]`,
            `[data-action="switch-notebook-tab"][data-tab="${normalized}"]`,
            `[data-tab="${normalized}"]`,
            idMap[tab] || idMap[normalized]
        ].filter(Boolean).join(', ');
        const tabButton = findTarget(selectors);
        if (tabButton) tabButton.click();
        await wait(300);
        applyStableTourIds();
    }

    async function runBeforeStepAction(step) {
        const action = step?.beforeStepAction;
        if (!action) return;
        if (action.startsWith('expand-dashboard-section:')) {
            expandDashboardSection(action.split(':')[1]);
            return;
        }
        if (action.startsWith('notebook-')) {
            await switchNotebookTab(action.replace('notebook-', ''));
        }
    }

    function clearHighlight() {
        if (state.highlighted) {
            state.highlighted.classList.remove('aestra-tour-highlight');
            state.highlighted = null;
        }
    }

    function highlightElement(target) {
        clearHighlight();
        if (!target) return;
        target.classList.add('aestra-tour-highlight');
        state.highlighted = target;
        try { target.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' }); } catch (err) { /* no-op */ }
    }

    function logMissingTarget(step) {
        console.warn('[AESTRA Tour] Missing target', {
            stepId: step?.id,
            route: step?.route,
            targetSelector: step?.targetSelector,
            fallbackSelector: step?.fallbackSelector,
            beforeStepAction: step?.beforeStepAction
        });
    }

    async function renderStep() {
        if (!state.active) return;
        const step = steps[state.index];
        if (!step) return finish();

        if (!state.overlay) buildShell();
        renderPanel(step);
        await navigateIfNeeded(step.route);
        await wait(300);
        await runBeforeStepAction(step);
        await wait(200);
        applyStableTourIds();
        let target = await waitForTarget(step.targetSelector, 2200);
        if (!target && step.fallbackSelector) {
            target = await waitForTarget(step.fallbackSelector, 900);
        }
        if (!state.active) return;
        renderPanel(step);
        if (target) {
            window.requestAnimationFrame(() => highlightElement(target));
        } else {
            clearHighlight();
            logMissingTarget(step);
        }
    }

    function renderPanel(step) {
        if (!state.panel) return;
        const titleEl = state.panel.querySelector('.aestra-tour-title');
        const messageEl = state.panel.querySelector('.aestra-tour-message');
        const countEl = state.panel.querySelector('.aestra-tour-step-count');
        const actionsEl = state.panel.querySelector('.aestra-tour-actions');
        if (countEl) countEl.textContent = `Step ${state.index + 1} of ${steps.length}`;
        if (titleEl) titleEl.textContent = step.title;
        if (messageEl) {
            const prefix = state.index === 0 ? `${getPersonalGreeting()} ` : '';
            messageEl.innerHTML = `${prefix}${escapeHtml(step.message)}`;
        }
        if (actionsEl) actionsEl.innerHTML = getActionsHtml(step);
        bindActionButtons();
    }

    function getActionsHtml(step) {
        const isFirst = state.index === 0;
        const isLast = state.index === steps.length - 1;
        if (isLast) {
            return `
                <button type="button" class="aestra-tour-btn aestra-tour-btn-ghost" data-aestra-tour="open-notebook">Open Notebook</button>
                <button type="button" class="aestra-tour-btn aestra-tour-btn-ghost" data-aestra-tour="open-syllabus">Open Syllabus</button>
                <button type="button" class="aestra-tour-btn aestra-tour-btn-primary" data-aestra-tour="finish">Finish</button>
            `;
        }
        return `
            <button type="button" class="aestra-tour-btn aestra-tour-btn-ghost" data-aestra-tour="skip">Skip</button>
            <button type="button" class="aestra-tour-btn aestra-tour-btn-muted" data-aestra-tour="back" ${isFirst ? 'disabled' : ''}>Back</button>
            <button type="button" class="aestra-tour-btn aestra-tour-btn-primary" data-aestra-tour="next">Next</button>
        `;
    }

    function bindActionButtons() {
        if (!state.panel) return;
        state.panel.querySelectorAll('[data-aestra-tour]').forEach((button) => {
            button.onclick = () => handleAction(button.dataset.aestraTour);
        });
    }

    function handleAction(action) {
        if (state.loading) return;
        if (action === 'next') return next();
        if (action === 'back') return back();
        if (action === 'skip') return skip();
        if (action === 'finish') return finish();
        if (action === 'open-syllabus') return finishAndOpen('/syllabus');
        if (action === 'open-notebook') return finishAndOpen('/notebooks');
    }

    function next() {
        if (state.index >= steps.length - 1) return finish();
        state.index += 1;
        renderStep();
    }

    function back() {
        if (state.index <= 0) return;
        state.index -= 1;
        renderStep();
    }

    function skip() {
        markSeen();
        state.active = false;
        removeShell();
    }

    function finish() {
        markSeen();
        state.active = false;
        removeShell();
    }

    async function finishAndOpen(route) {
        markSeen();
        state.active = false;
        removeShell();
        try {
            if (window.SpaRouter && typeof window.SpaRouter.navigate === 'function') {
                await window.SpaRouter.navigate(route);
            } else {
                window.location.hash = '#' + route;
            }
        } catch (err) {
            console.warn('[AESTRA Tour] Finish route failed:', err);
        }
    }

    function start(options = {}) {
        if (state.active && !options.force) return;
        state.introOpen = false;
        state.active = true;
        state.index = 0;
        state.personalization = readProfile();
        buildShell();
        renderStep();
    }

    function maybeShowIntro() {
        if (state.active || state.introOpen || isSeen()) return;
        const route = normalizeRoute(window.location.hash.slice(1) || '/dashboard');
        if (route !== '/dashboard') return;
        window.setTimeout(() => {
            if (!state.active && !state.introOpen && !isSeen()) buildIntro();
        }, 350);
    }

    window.SmartPadhaiAestraTour = {
        start,
        maybeShowIntro,
        isActive: () => state.active,
        getSteps: () => steps.slice()
    };
})();
