/**
 * ═══════════════════════════════════════════════════════
 *  SMART PADHAI — PLANS ROUTE (Phase 6C — Validated)
 *  Full SPA conversion of plans.html — polished & safe
 * ═══════════════════════════════════════════════════════
 *
 *  Phase 6C fixes:
 *    - "Unlimited AESTRA" → "High-limit fair-use AESTRA (500/day)"
 *    - CTA buttons → "Coming Soon" / "Join Early Access" style
 *    - Event listener cleanup via AbortController
 *    - Container reference nullified on cleanup
 *    - No duplicate listeners on re-navigation
 *
 *  NO PulseEngine dependency.
 *  NO Supabase writes (plans are read-only for now).
 */

const PlansRoute = (() => {

    // ── State ──
    let isYearly = false;
    let currentPlan = 'free';
    let _container = null;
    let _abortController = null;

    // ── Plan data ──
    const planOrder = ['free', 'starter', 'pro', 'elite'];

    const planData = [
        {
            tier: 'free',
            icon: '🎯',
            name: 'Free',
            tagline: 'Perfect for getting started with Smart Padhai basics',
            price: 0,
            yearlyPrice: 0,
            period: '/ forever',
            features: [
                { status: 'included', text: 'Backlog & Syllabus Tracker' },
                { status: 'included', text: 'Basic Focus Timer' },
                { status: 'included', text: 'Pulse Points & Ranks' },
                { status: 'limited',  text: 'AESTRA: <span class="feature-highlight">5 msg/day</span>' },
                { status: 'excluded', text: 'Productivity Graph' },
                { status: 'excluded', text: 'Journal Analysis' }
            ],
            recommended: false
        },
        {
            tier: 'starter',
            icon: '🚀',
            name: 'Starter',
            tagline: 'For students ready to level up their study game',
            price: 49,
            yearlyPrice: 490,
            period: '/ month',
            originalYearly: 588,
            features: [
                { status: 'included', text: 'Everything in Free' },
                { status: 'included', text: 'Full Productivity Graph' },
                { status: 'included', text: 'Unlimited Notebook Pages' },
                { status: 'limited',  text: 'AESTRA: <span class="feature-highlight">25 msg/day</span>' },
                { status: 'included', text: 'Basic Journal + Mood Tracker' },
                { status: 'excluded', text: 'AI Journal Analysis' }
            ],
            recommended: false
        },
        {
            tier: 'pro',
            icon: '⚡',
            name: 'Pro',
            tagline: 'The complete toolkit for serious exam warriors',
            price: 99,
            yearlyPrice: 990,
            period: '/ month',
            originalYearly: 1188,
            features: [
                { status: 'included', text: 'Everything in Starter' },
                { status: 'included', text: 'AESTRA: <span class="feature-highlight">100 msg/day</span>' },
                { status: 'included', text: 'Weekly AI Journal Analysis' },
                { status: 'included', text: 'Advanced Study Methods' },
                { status: 'included', text: 'Custom Timer Presets' },
                { status: 'included', text: 'Priority Support' }
            ],
            recommended: true
        },
        {
            tier: 'elite',
            icon: '👑',
            name: 'Elite',
            tagline: 'Maximum power for topper-level domination',
            price: 149,
            yearlyPrice: 1490,
            period: '/ month',
            originalYearly: 1788,
            features: [
                { status: 'included', text: 'Everything in Pro' },
                { status: 'included', text: 'AESTRA: <span class="feature-highlight">High-limit fair-use (500/day)</span>' },
                { status: 'included', text: 'Daily AI Journal Analysis' },
                { status: 'included', text: 'Personalized Study Plans' },
                { status: 'included', text: 'Export Data & Reports' },
                { status: 'included', text: 'Early Access to Features' }
            ],
            recommended: false
        }
    ];

    // ── FAQ data ──
    const faqData = [
        {
            q: 'Can I switch plans anytime?',
            a: 'Haan, bilkul! You can upgrade or downgrade anytime. When upgrading, you get instant access. When downgrading, your current plan continues till the billing cycle ends.'
        },
        {
            q: 'What payment methods do you accept?',
            a: 'We accept UPI, Debit/Credit Cards, Net Banking, and Wallets via Razorpay. All transactions are 100% secure.'
        },
        {
            q: 'Is there a refund policy?',
            a: "Yes! If you're not satisfied within 7 days of purchase, we'll refund your money. No questions asked. We want you to study stress-free."
        },
        {
            q: 'What happens to my data if I downgrade?',
            a: "Your data stays safe! You just won't be able to access premium features. When you upgrade again, everything will be right where you left it."
        },
        {
            q: 'Do you offer student discounts?',
            a: "Our prices are already student-friendly! But if you're from a government school or facing financial difficulties, DM us — we'll work something out."
        }
    ];

    // ─────────────────────────────────
    //  RENDER: Full Plans UI
    // ─────────────────────────────────
    function init(container) {
        // Abort any previous listeners
        if (_abortController) {
            _abortController.abort();
        }
        _abortController = new AbortController();
        _container = container;

        container.innerHTML = renderFullUI();
        bindEvents(container, _abortController.signal);
    }

    function cleanup() {
        // Abort all event listeners from this route
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }
        // Reset state
        isYearly = false;
        _container = null;
    }

    // ─────────────────────────────────
    //  RENDER: HTML Builder
    // ─────────────────────────────────
    function renderFullUI() {
        return `
            <div class="plans-page" data-tour-id="plans-page">

                <!-- PAGE HEADER -->
                <div class="plans-header" data-tour-id="plans-header">
                    <div class="current-plan-badge" id="spa-currentPlanBadge" data-tour-id="current-plan-badge">CURRENT PLAN: ${currentPlan.toUpperCase()}</div>
                    <h1>Unlock Your Full Potential</h1>
                    <p>Choose the plan that matches your ambition. Upgrade anytime, downgrade whenever. No lock-in, no drama.</p>
                </div>

                <!-- BILLING TOGGLE -->
                <div class="billing-toggle">
                    <span class="billing-option active" id="spa-monthlyOption">Monthly</span>
                    <div class="toggle-switch" id="spa-billingToggle"></div>
                    <span class="billing-option" id="spa-yearlyOption">Yearly</span>
                    <span class="save-badge">SAVE 17%</span>
                </div>

                <!-- PLANS GRID -->
                <div class="plans-grid" data-tour-id="plans-grid">
                    ${planData.map(plan => renderPlanCard(plan)).join('')}
                </div>

                <!-- AESTRA SECTION -->
                <div class="aestra-section" data-tour-id="plans-aestra-preview">
                    <div class="aestra-title">POWERED BY AESTRA</div>
                    <div class="aestra-headline">Your AI Study Companion</div>
                    <p class="aestra-desc">
                        AESTRA analyzes your study patterns, journal entries, and progress to give you personalized insights.
                        The more you use it, the smarter it gets about YOUR learning style.
                    </p>
                    <div class="aestra-features">
                        <div class="aestra-feature">
                            <span class="aestra-feature-icon">🧠</span>
                            <span>Pattern Recognition</span>
                        </div>
                        <div class="aestra-feature">
                            <span class="aestra-feature-icon">📊</span>
                            <span>Productivity Insights</span>
                        </div>
                        <div class="aestra-feature">
                            <span class="aestra-feature-icon">💬</span>
                            <span>24/7 Study Support</span>
                        </div>
                        <div class="aestra-feature">
                            <span class="aestra-feature-icon">🎯</span>
                            <span>Personalized Tips</span>
                        </div>
                    </div>
                </div>

                <!-- FAQ SECTION -->
                <div class="faq-section">
                    <h2 class="faq-title">Frequently Asked Questions</h2>
                    ${faqData.map((faq, i) => renderFaqItem(faq, i)).join('')}
                </div>

                <!-- GUARANTEE -->
                <div class="guarantee-section">
                    <div class="guarantee-badge">
                        <span class="guarantee-icon">🛡️</span>
                        <div class="guarantee-text">
                            <div class="guarantee-title">7-Day Money Back Guarantee</div>
                            <div class="guarantee-desc">Not satisfied? Full refund, no questions asked.</div>
                        </div>
                    </div>
                </div>

            </div>
        `;
    }

    function renderPlanCard(plan) {
        const isCurrent = plan.tier === currentPlan;
        const planIndex = planOrder.indexOf(plan.tier);
        const currentIndex = planOrder.indexOf(currentPlan);
        const displayPrice = isYearly ? plan.yearlyPrice : plan.price;
        const displayPeriod = plan.tier === 'free' ? '/ forever' : (isYearly ? '/ year' : '/ month');

        // CTA logic — all non-current buttons are "Coming Soon" style
        let ctaClass = 'plan-cta ';
        let ctaText = '';

        if (isCurrent) {
            ctaClass += 'current';
            ctaText = 'Current Plan';
        } else if (planIndex < currentIndex) {
            ctaClass += 'coming-soon';
            ctaText = 'Coming Soon';
        } else if (planIndex === 2) {
            ctaClass += 'primary coming-soon';
            ctaText = 'Join Early Access';
        } else {
            ctaClass += 'coming-soon';
            ctaText = 'Join Early Access';
        }

        return `
            <div class="plan-card ${plan.recommended ? 'recommended' : ''}" data-tier="${plan.tier}" data-tour-id="${plan.tier === 'free' ? 'free-plan' : (plan.tier === 'starter' ? 'starter-plan' : (plan.tier === 'pro' ? 'pro-plan' : (plan.tier === 'elite' ? 'elite-plan' : 'preview-plans')))}">
                ${plan.recommended ? '<div class="recommended-badge">MOST POPULAR</div>' : ''}
                <div class="plan-icon">${plan.icon}</div>
                <div class="plan-name">${plan.name}</div>
                <div class="plan-tagline">${plan.tagline}</div>

                <div class="plan-price">
                    <span class="price-currency">₹</span><span class="price-amount" data-monthly="${plan.price}" data-yearly="${plan.yearlyPrice}">${displayPrice}</span>
                    <span class="price-period">${displayPeriod}</span>
                    ${plan.tier !== 'free' && isYearly ? `<span class="price-original">₹${plan.originalYearly}</span>` : ''}
                </div>

                <ul class="features-list">
                    ${plan.features.map(f => `
                        <li>
                            <span class="feature-icon ${f.status}">${f.status === 'included' ? '✓' : f.status === 'limited' ? '~' : '✕'}</span>
                            <span>${f.text}</span>
                        </li>
                    `).join('')}
                </ul>

                <button class="${ctaClass}" ${isCurrent ? 'disabled' : ''}>${ctaText}</button>
            </div>
        `;
    }

    function renderFaqItem(faq, index) {
        return `
            <div class="faq-item" data-faq="${index}">
                <div class="faq-question" data-faq-toggle="${index}">
                    <span>${faq.q}</span>
                    <span class="faq-arrow">▼</span>
                </div>
                <div class="faq-answer">
                    <p>${faq.a}</p>
                </div>
            </div>
        `;
    }

    // ─────────────────────────────────
    //  EVENT BINDING (with AbortController)
    // ─────────────────────────────────
    function bindEvents(container, signal) {
        // Billing toggle
        const billingToggle = container.querySelector('#spa-billingToggle');
        const monthlyOption = container.querySelector('#spa-monthlyOption');
        const yearlyOption  = container.querySelector('#spa-yearlyOption');

        if (billingToggle) {
            billingToggle.addEventListener('click', () => {
                isYearly = !isYearly;
                billingToggle.classList.toggle('yearly', isYearly);
                monthlyOption.classList.toggle('active', !isYearly);
                yearlyOption.classList.toggle('active', isYearly);
                updatePrices(container);
            }, { signal });
        }

        // Also allow clicking the monthly/yearly labels
        if (monthlyOption) {
            monthlyOption.addEventListener('click', () => {
                if (isYearly) {
                    isYearly = false;
                    billingToggle.classList.remove('yearly');
                    monthlyOption.classList.add('active');
                    yearlyOption.classList.remove('active');
                    updatePrices(container);
                }
            }, { signal });
        }

        if (yearlyOption) {
            yearlyOption.addEventListener('click', () => {
                if (!isYearly) {
                    isYearly = true;
                    billingToggle.classList.add('yearly');
                    monthlyOption.classList.remove('active');
                    yearlyOption.classList.add('active');
                    updatePrices(container);
                }
            }, { signal });
        }

        // FAQ accordion
        const faqToggles = container.querySelectorAll('[data-faq-toggle]');
        faqToggles.forEach(toggle => {
            toggle.addEventListener('click', () => {
                const faqIndex = toggle.getAttribute('data-faq-toggle');
                const faqItem = container.querySelector(`.faq-item[data-faq="${faqIndex}"]`);
                if (!faqItem) return;

                // Close all others
                container.querySelectorAll('.faq-item').forEach(item => {
                    if (item !== faqItem) item.classList.remove('open');
                });

                faqItem.classList.toggle('open');
            }, { signal });
        });

        // CTA buttons — "Coming Soon" / "Join Early Access" — show toast instead of alert
        const ctaButtons = container.querySelectorAll('.plan-cta.coming-soon');
        ctaButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const tier = btn.closest('.plan-card')?.dataset.tier || 'unknown';
                showComingSoonToast(container, tier);
            }, { signal });
        });
    }

    // ─────────────────────────────────
    //  UPDATE PRICES (Monthly/Yearly toggle)
    // ─────────────────────────────────
    function updatePrices(container) {
        const priceAmounts = container.querySelectorAll('.price-amount[data-monthly]');
        const periodLabels = container.querySelectorAll('.price-period');

        priceAmounts.forEach(el => {
            if (isYearly) {
                el.textContent = el.dataset.yearly;
            } else {
                el.textContent = el.dataset.monthly;
            }
        });

        periodLabels.forEach(el => {
            const card = el.closest('.plan-card');
            if (card && card.dataset.tier === 'free') return;
            el.textContent = isYearly ? '/ year' : '/ month';
        });

        // Show/hide original price strikethroughs
        container.querySelectorAll('.price-original').forEach(el => {
            el.style.display = isYearly ? 'inline' : 'none';
        });
    }

    // ─────────────────────────────────
    //  COMING SOON TOAST (replaces alert)
    // ─────────────────────────────────
    function showComingSoonToast(container, tier) {
        // Remove any existing toast
        const existing = container.querySelector('.coming-soon-toast');
        if (existing) existing.remove();

        const tierName = tier.charAt(0).toUpperCase() + tier.slice(1);
        const toast = document.createElement('div');
        toast.className = 'coming-soon-toast';
        toast.innerHTML = `
            <div class="toast-icon">🚀</div>
            <div class="toast-content">
                <div class="toast-title">${tierName} — Coming Soon!</div>
                <div class="toast-desc">Payment integration is being built. Join our early access list on Instagram @smartpadhai</div>
            </div>
            <button class="toast-close" onclick="this.parentElement.remove()">✕</button>
        `;

        // Insert at top of plans page
        const plansPage = container.querySelector('.plans-page');
        if (plansPage) {
            plansPage.insertBefore(toast, plansPage.firstChild);
        }

        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (toast.parentElement) {
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(-10px)';
                setTimeout(() => toast.remove(), 300);
            }
        }, 5000);
    }

    // ── Public API ──
    return {
        init,
        cleanup
    };

})();

// Make globally accessible
window.PlansRoute = PlansRoute;
