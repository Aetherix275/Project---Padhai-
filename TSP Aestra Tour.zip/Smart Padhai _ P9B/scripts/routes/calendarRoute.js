/**
 * ═══════════════════════════════════════════════════════════════════
 *  SMART PADHAI — CALENDAR ROUTE MODULE (Phase 7E-3 + Supabase Sync Fix)
 *  Full SPA conversion of Strategic Planning Area / Calendar
 * ═══════════════════════════════════════════════════════════════════
 *
 *  Lifecycle:  init(container)  → render HTML, bind events, load data
 *              cleanup()        → abort listeners, remove CSS, clear state
 *
 *  Key improvements over legacy:
 *    - NO prompt() — uses inline modal for event description input
 *    - NO confirm() — uses inline confirm dialog for delete
 *    - NO alert()   — uses toast notification for "select mode first"
 *    - Updates shared next-exam sidebar after calendar changes
 *
 *  Data: SafeStorage-first, Supabase mirror second
 *  Events: All via event delegation + AbortController. Zero inline onclick.
 *
 *  Phase 7E-3: Calendar Reskin — visual strength only.
 *  No logic changes. All IDs, data-actions, storage keys preserved.
 *
 *  Supabase Sync Fix:
 *    - Robust client/user resolvers checking multiple window locations
 *    - Direct upsert/delete with proper error handling & logging
 *    - Timestamp-aware cloud merge (newer wins, local wins on tie)
 *    - source_key format: cal_${dateKey} (e.g. cal_2026-06-15)
 *    - Backward compatible with rows stored without cal_ prefix
 *    - Debug functions: testCalendarSupabaseSync, forceCalendarSupabaseSync
 * ═══════════════════════════════════════════════════════════════════
 */

const CalendarRoute = (() => {

    // ── Private state ──
    let _container = null;
    let _abortController = null;
    let _viewDate = null;
    let _strategyData = {};
    let _currentMode = null;
    let _cssLinkEl = null;

    const CSS_PATH = './styles/modules/calendar.css';
    const STORAGE_KEY = 'calendarStrategy';  // SafeStorage key — NOT renamed
    const SUPABASE_TABLE = 'calendar_events';
    const SOURCE_KEY_PREFIX = 'cal_';        // source_key = cal_${dateKey}

    const MONTHS = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE",
                    "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];

    // ════════════════════════════════════════════════════════
    //  SOURCE KEY MAPPING
    //  Local keys are dateKey (e.g. "2026-06-15")
    //  Supabase source_key is cal_${dateKey} (e.g. "cal_2026-06-15")
    // ════════════════════════════════════════════════════════

    function _toSourceKey(dateKey) {
        return SOURCE_KEY_PREFIX + dateKey;
    }

    /**
     * Convert a Supabase source_key back to a local dateKey.
     * Handles both new format (cal_2026-06-15) and legacy format (2026-06-15).
     */
    function _fromSourceKey(sourceKey) {
        if (!sourceKey) return null;
        if (sourceKey.startsWith(SOURCE_KEY_PREFIX)) {
            return sourceKey.slice(SOURCE_KEY_PREFIX.length);
        }
        // Legacy format — source_key was stored as bare dateKey
        return sourceKey;
    }

    // ════════════════════════════════════════════════════════
    //  SAFE SUPABASE HELPERS
    // ════════════════════════════════════════════════════════

    /**
     * Resolve Supabase client from multiple possible window locations.
     * Returns the client object or null.
     */
    function _getSupabaseClientSafe() {
        const sources = [
            () => window.supabaseClient,
            () => window.supabase,
            () => window.SUPABASE_CLIENT,
            () => window.sb,
            () => window.AppSupabase?.client,
            () => window.SPSyncManager?.supabase,
            () => window.SyncManager?.supabase
        ];
        for (const source of sources) {
            try {
                const client = typeof source === 'function' ? source() : null;
                if (client && typeof client.from === 'function') {
                    console.log('[Calendar Sync] client found');
                    return client;
                }
            } catch (e) { /* skip */ }
        }
        console.warn('[Calendar Sync] no Supabase client found from any source');
        return null;
    }

    /**
     * Resolve user ID from multiple possible sources (async).
     * Tries synchronous sources first, then falls back to Supabase auth.
     * Returns user ID string or null.
     */
    async function _getUserIdAsyncSafe() {
        // Try synchronous sources first
        const syncSources = [
            () => window.SPSyncManager?.getUserId?.(),
            () => window.SyncManager?.getUserId?.(),
            () => window.AppState?.currentUser?.id,
            () => {
                try { return SafeStorage?.getItem?.('_current_user_id') || null; } catch(e) { return null; }
            },
            () => localStorage.getItem('_current_user_id'),
        ];

        for (const source of syncSources) {
            try {
                const id = typeof source === 'function' ? source() : null;
                if (id) {
                    console.log('[Calendar Sync] userId found:', id);
                    return id;
                }
            } catch (e) { /* skip */ }
        }

        // Try Supabase auth.getUser() as async fallback
        const client = _getSupabaseClientSafe();
        if (client?.auth?.getUser) {
            try {
                const { data } = await client.auth.getUser();
                const id = data?.user?.id;
                if (id) {
                    console.log('[Calendar Sync] userId found via auth.getUser():', id);
                    return id;
                }
            } catch (e) {
                console.warn('[Calendar Sync] auth.getUser() failed:', e.message || e);
            }
        }

        console.warn('[Calendar Sync] No userId found from any source');
        return null;
    }

    /**
     * Direct upsert a calendar item to Supabase.
     * @param {object} item - Row data to upsert. Must include at least source_key.
     *   Recommended fields: { source_key, title, event_type, event_date,
     *       start_time, end_time, subject, description, priority,
     *       completed, raw_data, last_updated, user_key }
     * @returns {boolean} true if success, false if failure
     */
    async function _directUpsertCalendarItem(item) {
        const client = _getSupabaseClientSafe();
        if (!client) {
            console.warn('[Calendar Sync] upsert skipped — no Supabase client');
            return false;
        }

        const userId = await _getUserIdAsyncSafe();
        if (!userId) {
            console.warn('[Calendar Sync] upsert skipped — no userId');
            return false;
        }

        if (!item || !item.source_key) {
            console.warn('[Calendar Sync] upsert skipped — missing item or source_key');
            return false;
        }

        try {
            const row = {
                user_id: userId,
                source_key: item.source_key,
                title: item.title || item.text || '',
                event_type: item.event_type || item.mode || 'exam',
                event_date: item.event_date || item.source_key.replace(SOURCE_KEY_PREFIX, '') || null,
                start_time: item.start_time || null,
                end_time: item.end_time || null,
                subject: item.subject || null,
                description: item.description || item.text || '',
                priority: item.priority || null,
                completed: item.completed ?? false,
                raw_data: item.raw_data || JSON.stringify({ mode: item.mode || item.event_type || 'exam', text: item.text || '' }),
                last_updated: item.last_updated || new Date().toISOString(),
                user_key: item.user_key || userId
            };

            const { error } = await client
                .from(SUPABASE_TABLE)
                .upsert(row, { onConflict: 'user_id,source_key' });

            if (error) {
                console.error('[Calendar Sync] upsert failed:', error.message || error);
                return false;
            }

            console.log('[Calendar Sync] upsert success:', item.source_key);
            return true;
        } catch (err) {
            console.error('[Calendar Sync] upsert failed:', err.message || err);
            return false;
        }
    }

    /**
     * Direct delete a calendar item from Supabase by source_key.
     * @param {string} sourceKey - The source_key value to delete
     * @returns {boolean} true if success, false if failure
     */
    async function _directDeleteCalendarItem(sourceKey) {
        const client = _getSupabaseClientSafe();
        if (!client) {
            console.warn('[Calendar Sync] delete skipped — no Supabase client');
            return false;
        }

        const userId = await _getUserIdAsyncSafe();
        if (!userId) {
            console.warn('[Calendar Sync] delete skipped — no userId');
            return false;
        }

        if (!sourceKey) {
            console.warn('[Calendar Sync] delete skipped — no sourceKey');
            return false;
        }

        try {
            const { error } = await client
                .from(SUPABASE_TABLE)
                .delete()
                .eq('user_id', userId)
                .eq('source_key', sourceKey);

            if (error) {
                console.error('[Calendar Sync] delete failed:', error.message || error);
                return false;
            }

            console.log('[Calendar Sync] delete success:', sourceKey);
            return true;
        } catch (err) {
            console.error('[Calendar Sync] delete failed:', err.message || err);
            return false;
        }
    }

    /**
     * Load all calendar items from Supabase for the current user.
     * @returns {Array} Array of row objects, or empty array on failure
     */
    async function _loadCalendarItemsFromCloud() {
        const client = _getSupabaseClientSafe();
        if (!client) {
            console.warn('[Calendar Sync] load skipped — no Supabase client');
            return [];
        }

        const userId = await _getUserIdAsyncSafe();
        if (!userId) {
            console.warn('[Calendar Sync] load skipped — no userId');
            return [];
        }

        try {
            const { data, error } = await client
                .from(SUPABASE_TABLE)
                .select('*')
                .eq('user_id', userId);

            if (error) {
                console.error('[Calendar Sync] load failed:', error.message || error);
                return [];
            }

            console.log('[Calendar Sync] client found — loaded', (data || []).length, 'rows from', SUPABASE_TABLE);
            return data || [];
        } catch (err) {
            console.error('[Calendar Sync] load failed:', err.message || err);
            return [];
        }
    }

    // ════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════

    async function init(container) {
        if (_abortController) _abortController.abort();
        _abortController = new AbortController();
        _container = container;

        // Load CSS
        _loadCSS();

        // Init state — load local first (SafeStorage is source of truth)
        const now = new Date();
        _viewDate = new Date(2026, now.getMonth(), 1);
        _strategyData = SafeStorage.getItem(STORAGE_KEY, {});
        _currentMode = null;

        console.log('[Calendar Sync] local data loaded —', Object.keys(_strategyData).length, 'entries');

        // Try loading from cloud (best-effort merge)
        await _loadFromCloud();

        // Render
        container.innerHTML = renderFullUI();
        _renderCalendar();

        // Bind events
        _bindEvents(container, _abortController.signal);

        console.log('[CalendarRoute] Initialized');
    }

    function cleanup() {
        if (_abortController) {
            _abortController.abort();
            _abortController = null;
        }
        // Remove any open modals
        document.querySelectorAll('.cal-modal-overlay').forEach(el => el.remove());
        _unloadCSS();
        _container = null;
        _strategyData = {};
        _currentMode = null;
        console.log('[CalendarRoute] Cleaned up');
    }

    // ════════════════════════════════════════════════════════
    //  CSS DYNAMIC LOADING
    // ════════════════════════════════════════════════════════

    function _loadCSS() {
        if (document.querySelector(`link[href="${CSS_PATH}"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_PATH;
        link.dataset.calendarCss = 'true';
        document.head.appendChild(link);
        _cssLinkEl = link;
    }

    function _unloadCSS() {
        const el = _cssLinkEl || document.querySelector('link[data-calendar-css]');
        if (el) { el.remove(); _cssLinkEl = null; }
    }

    // ════════════════════════════════════════════════════════
    //  SUPABASE SYNC — Load + Merge + Upsert + Delete
    // ════════════════════════════════════════════════════════

    /**
     * Load from cloud: tries SPSyncManager first, then direct Supabase.
     * Merges cloud-only items into local. Timestamp-aware: newer wins, local wins on tie.
     */
    async function _loadFromCloud() {
        // Use SPSyncManager if available
        if (window.SPSyncManager) {
            try {
                const rows = await SPSyncManager.loadFromCloud(SUPABASE_TABLE, {
                    columns: 'source_key,mode,text,title,event_type,event_date,description,raw_data,last_updated,updated_at',
                    statusKey: 'source_key'
                });
                if (rows && rows.length > 0) {
                    _mergeCloudRows(rows);
                    return;
                }
            } catch (err) {
                console.warn('[Calendar Sync] SPSyncManager load failed, falling back to direct:', err.message || err);
            }
        }

        // Direct Supabase load
        const rows = await _loadCalendarItemsFromCloud();
        if (rows.length > 0) {
            _mergeCloudRows(rows);
        }
    }

    /**
     * Merge cloud rows into local strategy data.
     * Rules:
     *   - Cloud-only item → add to local
     *   - Both exist → compare timestamps; newer last_updated wins
     *   - If timestamps equal or unclear → local wins (source of truth)
     *   - Handles both cal_ prefixed and legacy bare dateKey source_keys
     */
    function _mergeCloudRows(rows) {
        const local = SafeStorage.getItem(STORAGE_KEY, {});
        let merged = false;
        const now = new Date().toISOString();

        rows.forEach(row => {
            if (!row.source_key) return;

            // Convert source_key back to local dateKey
            const dateKey = _fromSourceKey(row.source_key);
            if (!dateKey) return;

            const cloudUpdated = row.last_updated || row.updated_at || null;
            const localEntry = local[dateKey];

            if (!localEntry) {
                // Cloud-only item — add to local
                let mode = row.mode || row.event_type || 'exam';
                let text = row.text || row.description || row.title || '';

                // Try parsing raw_data if available
                if (row.raw_data) {
                    try {
                        const parsed = typeof row.raw_data === 'string' ? JSON.parse(row.raw_data) : row.raw_data;
                        if (parsed.mode) mode = parsed.mode;
                        if (parsed.text) text = parsed.text;
                    } catch (e) { /* use mode/text as-is */ }
                }

                local[dateKey] = { mode, text, updatedAt: cloudUpdated || now };
                merged = true;
                console.log('[Calendar Sync] merged cloud-only item:', dateKey);
            } else if (cloudUpdated) {
                // Both exist — compare timestamps
                const localUpdated = localEntry.updatedAt || null;
                if (!localUpdated) {
                    // Local has no timestamp — local wins (source of truth rule)
                    // Stamp it for future comparisons
                    local[dateKey].updatedAt = now;
                } else if (cloudUpdated > localUpdated) {
                    // Cloud is newer — overwrite local
                    let mode = row.mode || row.event_type || localEntry.mode || 'exam';
                    let text = row.text || row.description || row.title || localEntry.text || '';

                    if (row.raw_data) {
                        try {
                            const parsed = typeof row.raw_data === 'string' ? JSON.parse(row.raw_data) : row.raw_data;
                            if (parsed.mode) mode = parsed.mode;
                            if (parsed.text) text = parsed.text;
                        } catch (e) { /* use mode/text as-is */ }
                    }

                    local[dateKey] = { mode, text, updatedAt: cloudUpdated };
                    merged = true;
                    console.log('[Calendar Sync] cloud-newer overwrite:', dateKey);
                }
                // else: local is newer or same age — local wins, no change
            }
        });

        if (merged) {
            SafeStorage.setItem(STORAGE_KEY, local);
            _strategyData = local;
            console.log('[Calendar Sync] merge complete —', Object.keys(_strategyData).length, 'total entries');
        }
    }

    /**
     * On add/edit calendar event:
     *   - Save local first
     *   - Direct upsert to Supabase immediately
     *   - Also enqueue to SPSyncManager if available (belt + suspenders)
     *   - Log success/error clearly
     */
    async function _syncUpsertEvent(dateKey) {
        const entry = _strategyData[dateKey];
        if (!entry) {
            console.warn('[Calendar Sync] upsert called but no entry for', dateKey);
            return;
        }

        const now = new Date().toISOString();

        // Update local timestamp
        entry.updatedAt = now;
        SafeStorage.setItem(STORAGE_KEY, _strategyData);

        const sourceKey = _toSourceKey(dateKey);

        const item = {
            source_key: sourceKey,
            mode: entry.mode,
            text: entry.text,
            title: entry.text,
            event_type: entry.mode,
            event_date: dateKey,
            description: entry.text,
            raw_data: JSON.stringify({ mode: entry.mode, text: entry.text }),
            last_updated: now
        };

        // Always try direct upsert first (immediate, not debounced)
        const directOk = await _directUpsertCalendarItem(item);

        // Also enqueue to SPSyncManager if available (for batch/retry reliability)
        if (window.SPSyncManager) {
            try {
                SPSyncManager.enqueue(SUPABASE_TABLE, {
                    source_key: sourceKey,
                    mode: entry.mode,
                    text: entry.text,
                    title: entry.text,
                    event_type: entry.mode,
                    event_date: dateKey,
                    description: entry.text,
                    raw_data: item.raw_data,
                    last_updated: now,
                    updated_at: now
                }, { conflictKey: 'user_id,source_key' });
                console.log('[Calendar Sync] enqueued to SPSyncManager:', sourceKey);
            } catch (err) {
                console.warn('[Calendar Sync] SPSyncManager enqueue failed:', err.message || err);
            }
        }

        if (!directOk && !window.SPSyncManager) {
            console.error('[Calendar Sync] upsert failed — no path to Supabase for', sourceKey);
        }
    }

    /**
     * On delete calendar event:
     *   - Delete from Supabase directly (uses source_key = cal_${dateKey})
     *   - Also enqueue to SPSyncManager if available
     *   - Log success/error
     */
    async function _syncDeleteEvent(dateKey) {
        const sourceKey = _toSourceKey(dateKey);

        // Direct delete from Supabase
        const directOk = await _directDeleteCalendarItem(sourceKey);

        // Also enqueue to SPSyncManager if available
        if (window.SPSyncManager) {
            try {
                SPSyncManager.enqueue(SUPABASE_TABLE, {}, {
                    operation: 'delete',
                    deleteFilter: 'source_key',
                    deleteValue: sourceKey
                });
                console.log('[Calendar Sync] delete enqueued to SPSyncManager:', sourceKey);
            } catch (err) {
                console.warn('[Calendar Sync] SPSyncManager delete enqueue failed:', err.message || err);
            }
        }

        if (!directOk && !window.SPSyncManager) {
            console.error('[Calendar Sync] delete failed — no path to Supabase for', sourceKey);
        }
    }

    // ════════════════════════════════════════════════════════
    //  SIDEBAR UPDATE (shared with app-init.js)
    // ════════════════════════════════════════════════════════

    function _updateNextExamSidebar() {
        const localStrategyData = SafeStorage.getItem(STORAGE_KEY, {});
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        let nextExamDate = null;
        let minDiff = Infinity;

        for (const key in localStrategyData) {
            if (localStrategyData[key].mode === 'exam') {
                const examDate = _parseDateKey(key);
                if (examDate >= today) {
                    const diffTime = examDate - today;
                    if (diffTime < minDiff) {
                        minDiff = diffTime;
                        nextExamDate = examDate;
                    }
                }
            }
        }

        const el = document.getElementById('nextExamCountdown');
        if (!el) return;

        if (nextExamDate) {
            const daysLeft = Math.ceil(minDiff / (1000 * 60 * 60 * 24));
            el.innerHTML = `<svg class="urgency-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg><span class="urgency-text">NEXT EXAM: ${daysLeft} DAYS</span>`;
            el.style.display = 'flex';
        } else {
            el.innerHTML = `<svg class="urgency-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg><span class="urgency-text">NO UPCOMING EXAMS</span>`;
        }
    }

    // ════════════════════════════════════════════════════════
    //  DATE UTILITIES
    // ════════════════════════════════════════════════════════

    function _makeDateKey(year, monthIndex, day) {
        const month = String(monthIndex + 1).padStart(2, '0');
        const date = String(day).padStart(2, '0');
        return `${year}-${month}-${date}`;
    }

    function _parseDateKey(dateKey) {
        const [year, month, day] = dateKey.split('-').map(Number);
        return new Date(year, month - 1, day); // month - 1 fix
    }

    // ════════════════════════════════════════════════════════
    //  HTML RENDERING
    // ════════════════════════════════════════════════════════

    function renderFullUI() {
        return `
        <div id="strategy-map-page" data-tour-id="calendar-page">
            <div class="strategy-header">
                <div class="header-main">
                    <h1 class="zone-title">STRATEGIC MAP</h1>
                    <p class="zone-subtitle">Tactical deployment & milestone tracker</p>
                </div>
                <div class="strategy-controls" data-tour-id="calendar-modes">
                    <button class="strat-btn exam sp-btn" data-action="set-mode" data-mode="exam" data-tour-id="calendar-add-event">
                        <span class="btn-icon">\uD83D\uDEA9</span> EXAM
                    </button>
                    <button class="strat-btn holiday sp-btn" data-action="set-mode" data-mode="holiday">
                        <span class="btn-icon">\uD83C\uDFD6\uFE0F</span> HOLIDAY
                    </button>
                    <button class="strat-btn special sp-btn" data-action="set-mode" data-mode="special">
                        <span class="btn-icon">\u2B50</span> SPECIAL
                    </button>
                </div>
            </div>

            <div class="calendar-container" data-tour-id="calendar-container">
                <div class="calendar-header-nav">
                    <button class="nav-arrow sp-btn" data-action="change-month" data-offset="-1">\u25C0</button>
                    <div class="calendar-month-year" id="currentMonthYear"></div>
                    <button class="nav-arrow sp-btn" data-action="change-month" data-offset="1">\u25B6</button>
                </div>

                <div class="cal-legend" data-tour-id="calendar-legend">
                    <span class="cal-legend-item"><span class="cal-legend-dot dot-exam"></span> Exam</span>
                    <span class="cal-legend-item"><span class="cal-legend-dot dot-holiday"></span> Holiday</span>
                    <span class="cal-legend-item"><span class="cal-legend-dot dot-special"></span> Special</span>
                    <span class="cal-legend-item"><span class="cal-legend-dot dot-today"></span> Today</span>
                    <span class="cal-legend-item"><span class="cal-legend-dot dot-productive"></span> Productive</span>
                    <span class="cal-legend-item"><span class="cal-legend-dot dot-wasted"></span> Wasted</span>
                </div>

                <div class="calendar-grid" data-tour-id="calendar-grid">
                    <div class="day-name">Sun</div><div class="day-name">Mon</div><div class="day-name">Tue</div>
                    <div class="day-name">Wed</div><div class="day-name">Thu</div><div class="day-name">Fri</div>
                    <div class="day-name">Sat</div>
                    <div id="calendarDates" class="dates-wrapper" data-tour-id="calendar-dates"></div>
                </div>
            </div>
        </div>
        <div class="cal-toast" id="calToast"></div>`;
    }

    function _renderCalendar() {
        const container = _container?.querySelector('#calendarDates');
        const monthYearDisplay = _container?.querySelector('#currentMonthYear');
        if (!container) return;

        container.innerHTML = '';

        const year = _viewDate.getFullYear();
        const month = _viewDate.getMonth();
        const dailyStats = SafeStorage.getItem('dailyStats', {});

        monthYearDisplay.innerText = `${MONTHS[month]} ${year}`;

        const firstDayIndex = new Date(year, month, 1).getDay();
        const lastDay = new Date(year, month + 1, 0).getDate();
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        // Empty slots before first day
        for (let s = 0; s < firstDayIndex; s++) {
            const emptySlot = document.createElement('div');
            container.appendChild(emptySlot);
        }

        // Track if any strategic events exist this month
        let hasEventsThisMonth = false;

        // Date boxes
        for (let i = 1; i <= lastDay; i++) {
            const dateBox = document.createElement('div');
            dateBox.className = 'date-box';

            const dateKey = _makeDateKey(year, month, i);
            const checkDateObj = new Date(year, month, i);
            const checkDateStr = checkDateObj.toDateString();

            const dateNum = document.createElement('span');
            dateNum.className = 'date-number';
            dateNum.innerText = i;
            dateBox.appendChild(dateNum);

            // Past day status
            if (checkDateObj < today) {
                dateBox.classList.add('past-dull');
                const statusTag = document.createElement('div');
                statusTag.className = 'day-status';
                if (dailyStats[checkDateStr] > 0) {
                    statusTag.innerText = 'PRODUCTIVE';
                    statusTag.classList.add('status-productive');
                } else {
                    statusTag.innerText = 'WASTED';
                    statusTag.classList.add('status-wasted');
                }
                dateBox.appendChild(statusTag);
            }

            // Strategy data
            if (_strategyData[dateKey]) {
                dateBox.classList.add('has-data', `${_strategyData[dateKey].mode}-day`);
                const desc = document.createElement('div');
                desc.className = 'date-desc';
                desc.setAttribute('data-tour-id', 'calendar-events');
                desc.innerText = _strategyData[dateKey].text;
                dateBox.appendChild(desc);
                hasEventsThisMonth = true;
            }

            // Today highlight
            if (checkDateStr === today.toDateString()) dateBox.classList.add('today');

            // Click handler via data attributes
            dateBox.dataset.action = 'date-click';
            dateBox.dataset.day = i;
            dateBox.dataset.month = month;
            dateBox.dataset.year = year;

            container.appendChild(dateBox);
        }

        // Show empty state message if no events this month
        _updateEmptyState(hasEventsThisMonth);
    }

    // ── Empty state for months with no events ──
    function _updateEmptyState(hasEvents) {
        // Remove existing empty state
        const existing = _container?.querySelector('.cal-empty-state');
        if (existing) existing.remove();

        if (!hasEvents) {
            const calContainer = _container?.querySelector('.calendar-container');
            if (!calContainer) return;
            const emptyEl = document.createElement('div');
            emptyEl.className = 'cal-empty-state';
            emptyEl.setAttribute('data-tour-id', 'calendar-events');
            emptyEl.innerHTML = `<span class="cal-empty-icon">\uD83D\uDCC5</span> No strategic events this month. Select a mode and click a date to add one.`;
            calContainer.appendChild(emptyEl);
        }
    }

    // ════════════════════════════════════════════════════════
    //  CALENDAR ACTIONS
    // ════════════════════════════════════════════════════════

    function _changeMonth(offset) {
        _viewDate.setMonth(_viewDate.getMonth() + offset);
        if (_viewDate.getFullYear() > 2026) _viewDate.setFullYear(2026, 11, 1);
        if (_viewDate.getFullYear() < 2026) _viewDate.setFullYear(2026, 0, 1);
        _renderCalendar();
    }

    function _setMode(mode) {
        _currentMode = mode;
        if (!_container) return;
        _container.querySelectorAll('.strat-btn').forEach(btn => btn.classList.remove('active-mode'));
        const targetBtn = _container.querySelector(`.strat-btn.${mode}`);
        if (targetBtn) targetBtn.classList.add('active-mode');
    }

    function _handleDateClick(day, month, year) {
        if (!_currentMode) {
            _showToast('\u26A0\uFE0F Select a Mode first (Exam/Holiday/Special)!');
            return;
        }

        const dateKey = _makeDateKey(year, month, day);
        const monthName = MONTHS[month];

        // If entry already exists → show delete confirm modal
        if (_strategyData[dateKey]) {
            _showDeleteConfirm(dateKey, day, monthName);
            return;
        }

        // Show input modal for new entry
        _showEntryModal(dateKey, day, monthName);
    }

    // ── Modal: New Entry Input (replaces prompt()) ──
    function _showEntryModal(dateKey, day, monthName) {
        // Remove any existing modal
        document.querySelectorAll('.cal-modal-overlay').forEach(el => el.remove());

        const overlay = document.createElement('div');
        overlay.className = 'cal-modal-overlay';
        overlay.innerHTML = `
            <div class="cal-modal-box">
                <div class="cal-modal-title">Enter ${_currentMode.toUpperCase()} details for ${day} ${monthName}:</div>
                <input type="text" class="cal-modal-input sp-input" id="calEntryInput" placeholder="e.g. Maths Final Exam" autofocus>
                <div class="cal-modal-btns">
                    <button class="cal-modal-cancel sp-btn" data-action="modal-cancel">Cancel</button>
                    <button class="cal-modal-confirm sp-btn" data-action="modal-confirm-add">Add</button>
                </div>
            </div>`;

        document.body.appendChild(overlay);

        // Focus the input
        setTimeout(() => {
            const input = overlay.querySelector('#calEntryInput');
            if (input) input.focus();
        }, 50);

        // Store dateKey for later use
        overlay.dataset.dateKey = dateKey;
    }

    // ── Modal: Delete Confirm (replaces confirm()) ──
    function _showDeleteConfirm(dateKey, day, monthName) {
        document.querySelectorAll('.cal-modal-overlay').forEach(el => el.remove());

        const overlay = document.createElement('div');
        overlay.className = 'cal-modal-overlay';
        overlay.innerHTML = `
            <div class="cal-modal-box">
                <div class="cal-modal-title">Entry exists for ${day} ${monthName}. Delete it?</div>
                <div class="cal-modal-btns">
                    <button class="cal-modal-cancel sp-btn" data-action="modal-cancel">Cancel</button>
                    <button class="cal-modal-delete sp-btn" data-action="modal-confirm-delete">Delete</button>
                </div>
            </div>`;

        document.body.appendChild(overlay);
        overlay.dataset.dateKey = dateKey;
    }

    function _confirmAddEntry() {
        const overlay = document.querySelector('.cal-modal-overlay');
        if (!overlay) return;

        const dateKey = overlay.dataset.dateKey;
        const input = overlay.querySelector('#calEntryInput');
        const description = input ? input.value.trim() : '';

        if (!description) {
            overlay.remove();
            return;
        }

        // Save local first (SafeStorage is source of truth)
        _strategyData[dateKey] = { mode: _currentMode, text: description };
        SafeStorage.setItem(STORAGE_KEY, _strategyData);

        // Sync to Supabase (fire-and-forget, non-blocking)
        _syncUpsertEvent(dateKey);

        overlay.remove();
        _renderCalendar();
        _updateNextExamSidebar();
        _showToast(`${_currentMode.charAt(0).toUpperCase() + _currentMode.slice(1)} added!`, true);
    }

    function _confirmDeleteEntry() {
        const overlay = document.querySelector('.cal-modal-overlay');
        if (!overlay) return;

        const dateKey = overlay.dataset.dateKey;

        // Delete local first (SafeStorage is source of truth)
        delete _strategyData[dateKey];
        SafeStorage.setItem(STORAGE_KEY, _strategyData);

        // Sync delete to Supabase (fire-and-forget, non-blocking)
        _syncDeleteEvent(dateKey);

        overlay.remove();
        _renderCalendar();
        _updateNextExamSidebar();
        _showToast('Entry deleted.', true);
    }

    function _cancelModal() {
        document.querySelectorAll('.cal-modal-overlay').forEach(el => el.remove());
    }

    // ════════════════════════════════════════════════════════
    //  EVENT BINDING
    // ════════════════════════════════════════════════════════

    function _bindEvents(container, signal) {
        // Click delegation on route container
        container.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;

            switch (action) {
                case 'set-mode':
                    _setMode(target.dataset.mode);
                    break;
                case 'change-month':
                    _changeMonth(parseInt(target.dataset.offset));
                    break;
                case 'date-click':
                    const day = parseInt(target.dataset.day);
                    const month = parseInt(target.dataset.month);
                    const year = parseInt(target.dataset.year);
                    _handleDateClick(day, month, year);
                    break;
            }
        }, { signal });

        // Modal events on document (for cal-modal buttons appended to body)
        _bindModalEvents(signal);
    }

    // Also bind modal buttons (they live on document.body, not route container)
    // Uses AbortController so cleanup() removes them properly
    function _bindModalEvents(signal) {
        document.addEventListener('click', (e) => {
            const target = e.target.closest('[data-action]');
            if (!target) return;

            const action = target.dataset.action;
            switch (action) {
                case 'modal-cancel':
                    _cancelModal();
                    break;
                case 'modal-confirm-add':
                    _confirmAddEntry();
                    break;
                case 'modal-confirm-delete':
                    _confirmDeleteEntry();
                    break;
            }
        }, { signal });

        // Handle Enter key in modal input
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && e.target.id === 'calEntryInput') {
                _confirmAddEntry();
            } else if (e.key === 'Escape') {
                _cancelModal();
            }
        }, { signal });
    }

    // ════════════════════════════════════════════════════════
    //  TOAST
    // ════════════════════════════════════════════════════════

    function _showToast(message, success = false) {
        const toast = _container?.querySelector('#calToast');
        if (!toast) return;

        toast.textContent = message;
        toast.className = `cal-toast ${success ? 'success' : ''} visible`;
        setTimeout(() => {
            toast.classList.remove('visible');
        }, 2800);
    }

    // ════════════════════════════════════════════════════════
    //  DEBUG FUNCTIONS (temporary, for testing)
    // ════════════════════════════════════════════════════════

    /**
     * window.testCalendarSupabaseSync()
     * Inserts one debug row into calendar_events, then reads it back, then deletes it.
     * Returns { pass: true/false, details: string }
     */
    window.testCalendarSupabaseSync = async function() {
        console.log('[Calendar Sync] testCalendarSupabaseSync — starting...');

        const testDateKey = '2099-12-31';
        const testSourceKey = _toSourceKey(testDateKey);  // cal_2099-12-31
        const testText = 'Sync test row ' + new Date().toISOString();

        // 1. Check client
        const client = _getSupabaseClientSafe();
        if (!client) {
            const msg = 'FAIL — no Supabase client found. Checked: supabaseClient, supabase, SUPABASE_CLIENT, sb, AppSupabase.client, SPSyncManager.supabase, SyncManager.supabase';
            console.error('[Calendar Sync]', msg);
            return { pass: false, details: msg };
        }

        // 2. Check userId
        const userId = await _getUserIdAsyncSafe();
        if (!userId) {
            const msg = 'FAIL — no userId found. Checked: SPSyncManager.getUserId, SyncManager.getUserId, AppState.currentUser.id, SafeStorage _current_user_id, localStorage _current_user_id, auth.getUser()';
            console.error('[Calendar Sync]', msg);
            return { pass: false, details: msg };
        }

        // 3. Insert debug row
        const insertOk = await _directUpsertCalendarItem({
            source_key: testSourceKey,
            mode: 'special',
            text: testText,
            title: testText,
            event_type: 'special',
            event_date: testDateKey,
            description: testText,
            raw_data: JSON.stringify({ mode: 'special', text: testText }),
            last_updated: new Date().toISOString()
        });

        if (!insertOk) {
            const msg = 'FAIL — upsert of test row failed (see errors above)';
            console.error('[Calendar Sync]', msg);
            return { pass: false, details: msg };
        }
        console.log('[Calendar Sync] test row upserted:', testSourceKey);

        // 4. Read it back
        try {
            const { data, error } = await client
                .from(SUPABASE_TABLE)
                .select('*')
                .eq('user_id', userId)
                .eq('source_key', testSourceKey);

            if (error) {
                const msg = 'FAIL — select failed: ' + (error.message || error);
                console.error('[Calendar Sync]', msg);
                return { pass: false, details: msg };
            }

            if (!data || data.length === 0) {
                const msg = 'FAIL — test row not found in select';
                console.error('[Calendar Sync]', msg);
                return { pass: false, details: msg };
            }

            console.log('[Calendar Sync] test row read back OK:', data[0].source_key);
        } catch (err) {
            const msg = 'FAIL — select threw: ' + (err.message || err);
            console.error('[Calendar Sync]', msg);
            return { pass: false, details: msg };
        }

        // 5. Clean up — delete test row
        const deleteOk = await _directDeleteCalendarItem(testSourceKey);
        if (!deleteOk) {
            console.warn('[Calendar Sync] test row cleanup delete failed (non-critical)');
        } else {
            console.log('[Calendar Sync] test row cleaned up:', testSourceKey);
        }

        const msg = 'PASS — insert, select, delete all succeeded for ' + testSourceKey;
        console.log('[Calendar Sync]', msg);
        return { pass: true, details: msg };
    };

    /**
     * window.forceCalendarSupabaseSync()
     * Pushes ALL local calendar items to Supabase.
     * Returns { pushed: number, failed: number, total: number }
     */
    window.forceCalendarSupabaseSync = async function() {
        console.log('[Calendar Sync] forceCalendarSupabaseSync — starting...');

        const local = SafeStorage.getItem(STORAGE_KEY, {});
        const keys = Object.keys(local);
        let pushed = 0;
        let failed = 0;

        console.log('[Calendar Sync] found', keys.length, 'local entries to push');

        for (const dateKey of keys) {
            const entry = local[dateKey];
            if (!entry) continue;

            const sourceKey = _toSourceKey(dateKey);

            const ok = await _directUpsertCalendarItem({
                source_key: sourceKey,
                mode: entry.mode,
                text: entry.text,
                title: entry.text,
                event_type: entry.mode,
                event_date: dateKey,
                description: entry.text,
                raw_data: JSON.stringify({ mode: entry.mode, text: entry.text }),
                last_updated: entry.updatedAt || new Date().toISOString()
            });

            if (ok) {
                pushed++;
            } else {
                failed++;
                console.warn('[Calendar Sync] force push failed for:', sourceKey);
            }
        }

        const result = { pushed, failed, total: keys.length };
        console.log('[Calendar Sync] force push complete:', result);
        return result;
    };

    // ════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════

    return { init, cleanup };

})();

window.CalendarRoute = CalendarRoute;
